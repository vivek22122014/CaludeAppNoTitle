# NoTitle V1 — reimplemented, runs natively on Windows

Pseudonymous one-to-one conversations about work: guest/account identity, fair matching, temporary
text, optional mutual audio, friends and invitations, report/block, saved **Chat with Moderator**,
a private staff site, one-time Premium passes with a verified ledger, privacy rights, aggregate
analytics and operator tooling — all ten blueprint phases.

**Stack:** Python 3.12 · FastAPI · psycopg 3 (raw, parameterised SQL) · PostgreSQL 17 ·
Next.js 16 (static export) · React 19 · TypeScript · Playwright.

## Quick start (Windows)

1. Install **Python 3.12** (tick *Add python.exe to PATH*). Docker Desktop is optional.
2. Double-click **`setup.cmd`** — installs everything, creates the database, builds both sites.
3. Double-click **`start.cmd`** — then open **http://localhost:8080** (users) and **http://localhost:8081** (staff).
4. Double-click **`test.cmd`** — runs every automated check.

Full beginner walkthrough, expected outputs and troubleshooting: **[TESTING_GUIDE.md](TESTING_GUIDE.md)**.

## Project layout

```
backend/            FastAPI runtime (one owner process, two listeners)
  app/runner.py     startup: migration check → owner lock → journal replay → listeners
  app/realtime/     coordinator (matching, text, friends, calls), wire protocol, WebSocket
  app/services/     identity, social, support, moderation, staff, billing (+ payments), privacy, journal, jobs, analytics, retention
  app/api/          public routes (/api/v1) and private staff routes (/internal/v1)
  migrations/       checksummed forward-only SQL migrations
  policies/         policy documents (single source for consent digests and the website)
  tests/            unit tests and integration tests (real PostgreSQL + real runtime)
frontend/
  shared/           API client, accessible UI primitives, design tokens
  public/           public Next.js static site
  admin/            private staff Next.js static site
  e2e/              Playwright browser tests (incl. real WebRTC audio)
scripts/            setup / start / stop / test / build / dev / db / reset (PowerShell 5.1 compatible)
docs/               architecture, phase map, API, review of the original implementation
```

## Documentation

* [TESTING_GUIDE.md](TESTING_GUIDE.md) — install, run and test, step by step
* [docs/PHASES.md](docs/PHASES.md) — what each of the 10 phases contains and how it was verified
* [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) — design, security model, deviations from the blueprint
* [docs/API.md](docs/API.md) — HTTP and WebSocket reference
* [docs/ORIGINAL_REVIEW.md](docs/ORIGINAL_REVIEW.md) — why the original package could not run on Windows and what changed

## Not production-ready by itself

The code implements the product, but public launch still needs genuine operator facts (legal entity,
grievance officer, processors), reviewed policies (all are marked *draft*), a real TURN relay for audio,
an approved Cashfree merchant account, HTTPS hosting and an independent restore rehearsal. See
[docs/ARCHITECTURE.md § Production checklist](docs/ARCHITECTURE.md#production-checklist).
