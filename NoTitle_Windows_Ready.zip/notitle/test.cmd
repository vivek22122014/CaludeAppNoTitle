@echo off
REM Runs scripts\test.ps1 without changing the PowerShell execution policy.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\test.ps1" %*
if "%1"=="" pause
