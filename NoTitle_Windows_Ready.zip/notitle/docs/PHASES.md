# The ten phases: implementation and verification status

Legend for **Verified**:
**A** = automated test executed and passing in this delivery ·
**B** = exercised by hand in a real browser during this delivery ·
**—** = implemented but not exercised (reason given).

Last full run (fresh clone → `setup.cmd` → `test.cmd -Build`): backend unit **49 passed**, backend integration
**40 passed** (real PostgreSQL 17 + real runtime), policy lint **pass**, frontend typecheck **pass**, both static
builds **pass**, browser E2E **9 passed** (Chromium). Windows 11, Python 3.12.6, Node 24.22.0.

## Phase 1 — Foundation and feasibility

| Item | Where | Verified |
|---|---|---|
| Typed configuration, production guard rails (refuses weak keys, http origins, simulator, non-relay audio) | `backend/app/config.py` | A (import), — production mode not run |
| Checksummed forward-only migrations under an advisory lock; runtime refuses to start on drift | `app/migrations.py`, `migrations/*.sql` | A |
| Least-privilege roles: `notitle_owner` migrates, `notitle_app` has DML only | `app/cli.py db-bootstrap`, `migrations.grant_runtime_role` | A (setup + tests run as app role) |
| Single owner: PostgreSQL advisory lock + monotonically increasing `owner_epoch`; second process exits | `app/runner.py` | A (`test_second_runtime_cannot_take_ownership`) |
| One process, two listeners (public 8080 / private 8081), shared services, coordinated shutdown | `app/runner.py`, `app/main.py` | A, B |
| Windows: SelectorEventLoop for psycopg async, own signal handling for two servers | `app/runner.py` | A, B |
| Health endpoints `/health/live`, `/health/ready` | `app/main.py` | A |
| Setup/run/test automation | `scripts/*.ps1`, `*.cmd` | A (fresh-clone run), Docker **and** portable PostgreSQL |

## Phase 2 — Interface and policy publication

| Item | Where | Verified |
|---|---|---|
| 35 public routes, 13 staff routes, static export, real 404, robots | `frontend/public/app`, `frontend/admin/app` | A (build), B |
| Policy pages rendered at build time from the same Markdown the backend digests (SHA-256 in consent proof) | `backend/policies/*.md`, `frontend/public/lib/policies.ts` | A (no-JS HTML test) |
| Publication lint (no email, no "fully compliant", no removed 24-hour refund) | `app/policies.py lint` | A |
| Accessible primitives (labels, focus-visible, dialogs trapping focus, 44 px targets, live regions), responsive + mobile bottom nav, dark mode | `frontend/shared/src/ui.tsx`, `tokens.css` | A (role-based Playwright selectors), B |
| Per-file CSP with SHA-256 hashes of Next's inline scripts (no `unsafe-inline` scripts); security headers | `app/static_site.py`, `app/http/middleware.py` | A |

## Phase 3 — Identity, consent and privacy primitives

| Item | Verified |
|---|---|
| Guests in RAM (30 min idle / 24 h), generated pseudonyms, capacity limit | A, B |
| Accounts with Argon2id (64 MiB/3), generic login errors, equal timing for unknown users | A |
| Prepared one-time secrets: recovery code shown once, saved acknowledgement before commit | A, B |
| Five-session cap with challenge (revoke one, create one) | A |
| Recovery with code rotation, password change and logout-all revoke other sessions | A |
| Fresh re-authentication (5 min) for sensitive actions | A |
| Four separate unchecked consents; policy-version conflict (409); professional withdrawal clears data | A, B |
| CSRF (HMAC of an HttpOnly boot cookie) + exact Origin allowlist + duplicate-cookie rejection | A |
| Guest → account conversion keeps the live conversation, promotes friends, carries blocks/restrictions | A |
| Data export (encrypted, 24 h), deletion with receipt, independent HMAC-chained journal replayed at startup | A (incl. simulated old-backup restore) |

## Phase 4 — Matching, realtime and temporary text

| Item | Verified |
|---|---|
| One shared pool; strict mutual gender rule; Premium-only specific preference; 4 s repeat exclusion; decaying repeat penalty; fading topic/professional relevance; oldest-anchor greedy matching with random ties; 10 000 pair-check budget | A (12 matching unit tests) |
| One socket per identity, one-use 60 s tickets in the first frame, explicit takeover | A |
| Text: 2000 code points / 6 KiB, ring of 30 messages / 64 KiB, Delivered after render, never stored | A (incl. scan of every text column for the message), B |
| End/Next, HTTP End fallback, 25 s reconnect grace with resume, no auto-search/auto-call | A, B |
| Bounded output queue (slow readers disconnected), rate limits, command de-duplication | A (unit), — load not measured |

## Phase 5 — Safety, support and private operations

| Item | Verified |
|---|---|
| Report: server snapshot (2 min), selected evidence, encrypted, report-and-block fences first, "Not submitted" on failure | A, B |
| Blocks: durable for account pairs, identity-scoped for guests, symmetric matching exclusion, outbound-only listing | A |
| Chat with Moderator: encrypted per-case keys, receipts for guests, nonce-idempotent messages, seen markers, reopen within 30 days, continuations, 1000-message cap | A, B |
| Staff accounts: password + TOTP (replay-protected), recovery codes, 15 min / 4 h sessions, role grants rechecked per request | A, B |
| Audited content reads (audit commits before plaintext), purpose required, internal notes separate | A, B |
| Claim/assign/status with expected versions; close blocked until obligations complete; legal clocks (draft rule pack) | A |
| Decisions via signed preview + fresh TOTP; restrictions fence live sessions; notices; independent appeal reviewer | A, B |

## Phase 6 — Friends, invitations and profile

| Item | Verified |
|---|---|
| Mutual request in conversation, reciprocal = accept, decline closes generically | A, B |
| Durable normalised pairs for accounts (Saving → Saved), temporary for guests, 100-friend cap | A, B |
| Presence Available/Busy/Offline, 30 s invitations, crossed invitations converge | A, B |
| Removal/Block end friend conversations and win promotion races (compensation) | A |
| Profile (versioned), preferences (saved vs effective), blocked list, sessions UI | A, B |

## Phase 7 — Free audio

| Item | Verified |
|---|---|
| Mutual consent, ringing 30 s, cooldown 15 s, 25-call capacity, setup timeout 20 s | A |
| Microphone requested only after both accept; tracks stopped on every exit; mute | A (real WebRTC in Chromium with fake devices), B (denial path) |
| SDP/ICE validation (single audio m-line, DTLS fingerprint, candidate grammar, relay-only mode) | A |
| TURN REST credentials (coturn `use-auth-secret`), `iceTransportPolicy=relay` when required | — no TURN server available locally |
| Kernel-level relay packet revocation (blueprint ch. 25–26 nftables guard) | — **not implemented**: requires a Linux relay host; see ARCHITECTURE.md |

## Phase 8 — Payments, ledger, receipts, remedies

| Item | Verified |
|---|---|
| Plans Short3/Week7/Month30 enabled, Annual365 disabled; immutable plan versions; INR paise integers | A |
| Stable purchase intent per nonce; policy acknowledgement snapshot; phone passed to provider only | A, B |
| Signed webhook inbox (dedupe), independent provider fetch before any grant, one lot per purchase | A |
| FIFO wall-clock ledger with conservation CHECK constraints; holds affect origin lot only | A |
| Required remedies only (payment_error / statutory_remedy / provider_bank_direction), preview + TOTP, refund settlement, failure releases hold | A |
| Receipts and billing-issue cases (no automatic hold/refund) | A, B |
| Development payment simulator (hosted-checkout stand-in, signed webhooks) | A, B |
| Cashfree adapter (orders, payments, refunds, webhook signature) | — needs sandbox credentials; contract test before enabling |

## Phase 9 — Analytics and operations

| Item | Verified |
|---|---|
| Fixed 26-metric catalog, bounded in-memory accumulator, idempotent minute batches, exact transactional counters, deterministic rollups, `<10` suppression | A (API), — rollup over real hours not observed |
| Durable jobs with leases/backoff; periodic maintenance (flush, rollup, overdue clocks, reconciliation sweep, retention) | A (jobs exercised by export/deletion/payment tests) |
| Retention sweeps respecting legal holds | — sweeps run hourly; deletions of aged data not time-travelled in tests |
| Backup (`pg_dump`, journal copy) and restore into a new database | A (manual run: backup → restore → schema verified) |
| Staff health page (database, migrations, jobs, journal, gates) | A, B |

## Phase 10 — Qualification and handoff

| Item | Verified |
|---|---|
| Unit, integration and browser suites + one-command runner with report | A |
| Fresh-clone setup on Windows (Docker DB) and (portable DB) | A |
| Beginner guide, API reference, architecture and review documents | — documentation |
| Load test (200 identities / 25 calls for 6 h), accessibility audit with assistive tech, security penetration test, legal review | — **not performed**; required before launch |
