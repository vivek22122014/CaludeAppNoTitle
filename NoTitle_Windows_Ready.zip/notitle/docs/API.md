# NoTitle API reference

Generated from the running code's OpenAPI documents. Development builds also serve interactive docs at
http://localhost:8080/docs and http://localhost:8081/docs (disabled when `APP_ENV=production`).

## Conventions

* Success: `{"data": ..., "request_id": "req_..."}`. Failure: `{"error": {"code", "message", "fields"?, "details"?, "retryable"}, "request_id"}`.
* Status codes: 400 malformed · 401 unauthenticated · 403 forbidden / CSRF / reauth or MFA required · 404 unknown **or** inaccessible (same shape) ·
  409 stale version / nonce conflict / policy changed · 410 expired preparation · 413 too large · 422 invalid field · 429 rate limited (`Retry-After`) · 503 unavailable.
* Every unsafe request needs an allowed `Origin` and `X-CSRF-Token` (from `GET /api/v1/bootstrap`, or `GET /internal/v1/bootstrap` on the private site).
  Provider webhooks are authenticated by signature instead.
* Body limits: 8 KiB ordinary, 12 KiB support/report, 256 KiB webhooks. Unknown fields are rejected.
* Retried mutations carry a `client_nonce` (UUID): same nonce + same content returns the original result; different content returns 409.
* Sensitive staff actions are two-step: `.../preview` returns a single-use `nonce` (2 minutes); `.../confirm` takes `{nonce, totp}`.

## Public API: 62 HTTP operations (port 8080)

| Method | Path |
|---|---|
| POST | /api/v1/auth/guest |
| POST | /api/v1/auth/login |
| POST | /api/v1/auth/logout |
| POST | /api/v1/auth/logout-all |
| POST | /api/v1/auth/reauth |
| POST | /api/v1/auth/recover |
| POST | /api/v1/auth/register |
| POST | /api/v1/auth/session-limit/resolve |
| GET | /api/v1/billing/entitlement |
| GET | /api/v1/billing/plans |
| GET | /api/v1/billing/purchases |
| POST | /api/v1/billing/purchases |
| GET | /api/v1/billing/purchases/{ref} |
| GET | /api/v1/billing/receipts |
| GET | /api/v1/billing/receipts/{ref} |
| POST | /api/v1/billing/refund-requests |
| GET | /api/v1/blocks |
| POST | /api/v1/blocks |
| DELETE | /api/v1/blocks/{ref} |
| GET | /api/v1/bootstrap |
| GET | /api/v1/catalogs |
| GET | /api/v1/dev/simulator/checkout/{merchant_order_id} |
| POST | /api/v1/dev/simulator/checkout/{merchant_order_id} |
| GET | /api/v1/friends |
| DELETE | /api/v1/friends/{ref} |
| POST | /api/v1/interactions/end |
| GET | /api/v1/me |
| GET | /api/v1/me/consent-proof |
| POST | /api/v1/me/consents |
| GET | /api/v1/me/notices |
| POST | /api/v1/me/notices/{ref}/seen |
| POST | /api/v1/me/password |
| PATCH | /api/v1/me/preferences |
| PATCH | /api/v1/me/profile |
| POST | /api/v1/me/recovery/rotate |
| GET | /api/v1/me/sessions |
| DELETE | /api/v1/me/sessions/{session_id} |
| POST | /api/v1/operations/prepare |
| GET | /api/v1/policies |
| GET | /api/v1/policies/{kind} |
| POST | /api/v1/privacy/delete |
| GET | /api/v1/privacy/exports |
| POST | /api/v1/privacy/exports |
| GET | /api/v1/privacy/exports/{ref} |
| GET | /api/v1/privacy/exports/{ref}/download |
| POST | /api/v1/privacy/requests |
| GET | /api/v1/privacy/retention |
| GET | /api/v1/privacy/status |
| POST | /api/v1/privacy/status/access |
| POST | /api/v1/reports |
| POST | /api/v1/reports/prepare |
| POST | /api/v1/support/access |
| POST | /api/v1/support/cases |
| GET | /api/v1/support/cases |
| GET | /api/v1/support/cases/{ref} |
| POST | /api/v1/support/cases/{ref}/continuations |
| GET | /api/v1/support/cases/{ref}/messages |
| POST | /api/v1/support/cases/{ref}/messages |
| POST | /api/v1/support/cases/{ref}/reopen |
| POST | /api/v1/support/cases/{ref}/seen |
| POST | /api/v1/webhooks/{provider_name} |
| POST | /api/v1/ws/ticket |
| WEBSOCKET | /api/v1/ws |

## Private staff API: 40 HTTP operations (port 8081 only; 404 on the public port)

| Method | Path |
|---|---|
| GET | /internal/v1/analytics/catalog |
| GET | /internal/v1/analytics/series |
| GET | /internal/v1/analytics/summary |
| POST | /internal/v1/appeals/{decision_ref}/resolve |
| GET | /internal/v1/audit |
| POST | /internal/v1/auth/login |
| POST | /internal/v1/auth/logout |
| POST | /internal/v1/auth/recovery |
| POST | /internal/v1/auth/step-up |
| GET | /internal/v1/billing/purchases |
| POST | /internal/v1/billing/purchases/{ref}/reconcile |
| GET | /internal/v1/billing/refunds |
| POST | /internal/v1/billing/refunds/confirm |
| POST | /internal/v1/billing/refunds/preview |
| GET | /internal/v1/bootstrap |
| GET | /internal/v1/cases |
| GET | /internal/v1/cases/{ref} |
| POST | /internal/v1/cases/{ref}/assignment |
| POST | /internal/v1/cases/{ref}/claim |
| GET | /internal/v1/cases/{ref}/messages |
| POST | /internal/v1/cases/{ref}/messages |
| GET | /internal/v1/cases/{ref}/notes |
| POST | /internal/v1/cases/{ref}/notes |
| POST | /internal/v1/cases/{ref}/obligations/complete |
| POST | /internal/v1/cases/{ref}/seen |
| POST | /internal/v1/cases/{ref}/status |
| POST | /internal/v1/decisions/confirm |
| POST | /internal/v1/decisions/preview |
| GET | /internal/v1/health |
| GET | /internal/v1/privacy/holds |
| POST | /internal/v1/privacy/holds/confirm |
| POST | /internal/v1/privacy/holds/preview |
| POST | /internal/v1/privacy/holds/{ref}/release |
| GET | /internal/v1/privacy/requests |
| POST | /internal/v1/privacy/requests/{ref}/status |
| GET | /internal/v1/reports |
| GET | /internal/v1/reports/{ref} |
| GET | /internal/v1/staff |
| POST | /internal/v1/staff |
| POST | /internal/v1/staff/{username}/roles |

## Realtime protocol (wire version 2)

1. `POST /api/v1/ws/ticket {"takeover": false}` returns a one-use ticket valid for 60 s.
2. Open `ws://<host>/api/v1/ws` (exact allowed Origin) and send within 5 s:
   `{"v":2,"id":"<uuid>","type":"session.hello","payload":{"ticket":"..."}}`. The server answers `session.ready` with a state snapshot.
3. Commands are `{"v":2,"id":"<uuid>","type":..., "payload":{...}}`; replies are `command.result` or `error` with `reply_to` = command id.
   Frames are at most 8 KiB (SDP 64 KiB). Heartbeat every 20 s; 45 s of silence closes the socket.

| Command | Payload | Result / events |
|---|---|---|
| `heartbeat` | `echo?` | `heartbeat.ack` |
| `queue.join` | `accept_everyone?` | `queue_token`; later `interaction.started` |
| `queue.cancel` | | `state: idle` |
| `interaction.end` / `interaction.next` | `interaction_id` | `interaction.ended` to both; `next` re-queues only the initiator |
| `text.send` | `interaction_id, client_id, body` (max 2000 code points / 6 KiB) | `message_id, seq`; peer gets `text.received` |
| `text.delivered` | `interaction_id, message_id` | sender gets `text.delivery` |
| `friend.request` | `interaction_id` | `pending` / `saving` / `temporary`; peer gets `friend.requested` |
| `friend.respond` | `request_id, accept` | `friend.saving` then `friend.persisted` (accounts) or `friend.accepted` (temporary) |
| `friend.invite` / `.respond` / `.cancel` | `relationship_id` / `invite_id, accept` / `invite_id` | `invite.received`, `invite.closed`, `interaction.started` |
| `call.request` | `interaction_id` | `call_id`; peer gets `call.incoming` |
| `call.respond` | `call_id, accept` | both get `call.authorized` (role, ICE servers, transport policy) |
| `call.sdp` / `call.ice` | `call_id, revision, ...` | validated and forwarded to the peer |
| `call.state` | `call_id, state` (`connected`/`failed`) | `call.connected` once both report |
| `call.refresh` | `call_id` | fresh TURN credentials |
| `call.end` | `call_id, reason` | `call.ended` to both |

Server-initiated events also include `interaction.interrupted` / `interaction.resumed` (25 s reconnect grace), `presence.update`,
`friend.removed`, `queue.paused`, `entitlement.changed`, `session.replaced`, `session.ended`, `service.draining`, `identity.converted`.
