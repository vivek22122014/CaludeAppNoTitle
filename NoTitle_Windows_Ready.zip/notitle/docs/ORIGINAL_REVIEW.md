# Review of the original package (`NoTitle_V1_Integrated_Phases1_to10.zip`)

The original archive (≈18 800 lines across `api/`, `web/`, `ops/`, `relay/`, `db/`, `tests/`) was reviewed
against both blueprints (Master Design PDF and the Next.js/FastAPI Implementation Blueprint v6.1). Its own
handoff states that dependency resolution, database, build and browser checks were *blocked* and never ran.
This delivery is a clean reimplementation; nothing from the archive is required at runtime.

## Why it could not run on a Windows machine

| # | Problem in the original | Effect | Resolution in this delivery |
|---|---|---|---|
| 1 | Supported only Linux/WSL2 ("Run in the extracted folder on Linux or WSL2"); operator code uses `fcntl`, `os.getuid`, `SO_PEERCRED`, `/etc/notitle`, `/run/secrets`, systemd units | Import errors / missing paths on Windows | Pure-Python cross-platform runtime; all state under the project (`.env`, `.local`) |
| 2 | Required `uv`, Docker Compose with `network_mode: host`, Caddy | Compose v2 plugin and host networking are often unavailable on Windows (not present on this machine) | No Compose/Caddy needed: the Python process serves the static sites; PostgreSQL via plain `docker run` **or** portable binaries (no admin, no Docker) |
| 3 | No lock files: `versions.lock` lists "unresolved: Python transitive hashes, npm integrity lockfiles"; setup tried to *resolve* locks at install time | Non-reproducible installs; failures behind restricted networks | Exact pinned `requirements.txt`; committed `package-lock.json`; verified installable |
| 4 | psycopg async on Windows needs a `SelectorEventLoop`, but uvicorn on Windows creates a `ProactorEventLoop` | `psycopg.InterfaceError` on first query | Runner creates the selector loop itself; tests set the policy |
| 5 | `__Host-` cookies always (require `Secure`/HTTPS) | Browsers drop the cookies on `http://localhost` → nobody can sign in | Prefix and `Secure` follow `COOKIE_SECURE` (false locally, required true in production by validation) |
| 6 | Production and local setup tied to coturn + nftables kernel guard + mTLS controller | Audio impossible without a Linux relay host | Audio works locally over WebRTC; relay-only mode and TURN REST credentials available by configuration |
| 7 | Payment flow only reachable with real Cashfree credentials; sales gated off | Premium, ledger and receipts untestable | Development-only payment simulator that signs webhooks and is verified through the same path as Cashfree; refused when `APP_ENV=production` |
| 8 | Migrations assume pre-created roles from `ops/managed_database.py` prompts | Fresh databases fail on GRANTs | `python -m app.cli db-bootstrap` creates database + roles idempotently; setup runs it |
| 9 | Interactive prompts during setup (owner password, TOTP enrolment file import) | Beginners stuck mid-setup | Non-interactive setup; staff owner created automatically with a generated password; `staff-code.ps1` prints dev TOTP codes |
| 10 | Very large ops surface (release signing, restic, S3 journal, CERT-In archive, systemd timers) mixed into the run path | Startup refused without production artefacts | Core runtime starts with local equivalents; production-only items documented as launch work |

## Functional gaps found in the original (relative to the blueprints)

* "Source presence is not acceptance": every phase was marked unaccepted, with database/browser execution blocked.
* Several flows depended on unfinished components it lists itself: journal segment rollover, key rotation, Annual365 late-remedy route, invoice duties.
* No executed end-to-end evidence that the Next.js apps built, type-checked or talked to the API.

## Bugs found and fixed while building and testing this delivery

These were caught by actually running the code (each now has a regression test or was verified in a browser):

| Bug | Found by | Fix |
|---|---|---|
| Query helpers did not commit when they owned the connection → `INSERT … RETURNING` writes silently rolled back | Code review before first run | Helpers commit (`app/db.py`) |
| Unknown `/api/*` paths fell through to the static site (503 "not built") | Integration test | API namespaces always return JSON 404 |
| WebSocket rejection closed the socket before the explaining error frame was flushed | Integration test | `Connection.close()` drains queued frames first; slow readers still abort immediately |
| Next.js 16 static export requests `__next.a.b.__PAGE__.txt` but writes `__next.a/b/__PAGE__.txt` → 404 on every prefetch | Browser network log | Static server maps the segment path |
| `Referrer-Policy: no-referrer` makes Chrome send `Origin: null` on form POSTs → simulator checkout rejected | Playwright E2E | `Referrer-Policy: same-origin` |
| Shared CSS `.page` padding removed the 16 px side gutter on every page | Browser screenshot | Only vertical padding on `.page` |
| Support case showed the user's own first message as unread | Browser | Creator's message marked seen |
| CSP blocked Cashfree SDK API calls/frames when the real provider is enabled | Review | Provider-specific `connect-src`/`frame-src` |
| Two Windows PowerShell 5.1 pitfalls in scripts (native stderr under `ErrorAction Stop`; function output mixed into return codes) | Script review / first setup run | `Continue` + explicit `$LASTEXITCODE`; `Out-Host` |
| Portable PostgreSQL: `pg_ctl start … \| Out-Null` hung setup forever because the server inherited the pipe | Portable-mode setup run | `pg_ctl` output is no longer piped |
| `localhost` resolves to IPv6 first on Windows → readiness probe stalled ~2 s per attempt | Setup run | Probe uses 127.0.0.1 |
