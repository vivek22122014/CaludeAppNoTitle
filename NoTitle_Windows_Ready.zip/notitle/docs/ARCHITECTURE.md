# Architecture

## Runtime

```
Browser ── http://localhost:8080 ──► public ASGI app ─┐                         ┌─► PostgreSQL 17
  (static site + /api/v1 + WebSocket)                  │   one Python process     │   (accounts, cases, reports,
Staff  ─── http://localhost:8081 ──► private ASGI app ─┼── shared services ───────┤    ledger, jobs, aggregates)
  (static staff site + /internal/v1)                   │   coordinator (RAM)      │
                                                       └── job supervisor ────────┴─► .local/journal (HMAC-chained)
```

* **One owner** (`app/runner.py`): verifies migrations, takes a PostgreSQL advisory lock, allocates `owner_epoch`,
  replays the privacy journal, then serves both listeners from one event loop. Losing the owner connection or a
  listener stops the process. A second copy refuses to start. Only one uvicorn worker is ever used.
* **Coordinator** (`app/realtime/coordinator.py`): all live state (participants, queue, interactions, text rings,
  friend requests, invites, calls) is mutated by synchronous methods on one event loop, so transitions never interleave.
  Durable work (friend persistence, blocks) re-validates before publishing results.
* **Ordinary chat is never persisted**: text lives only in a 30-message / 64 KiB ring per interaction and is cleared on
  End, grace expiry, sign-out or restart. An integration test scans every text column for a marker message.
* **Static sites**: Next.js `output: "export"`; the runtime serves them with per-file CSP hashes, a real 404 and
  immutable caching for hashed assets. No Node.js server runs at request time.

## Data and security

| Concern | Design |
|---|---|
| Passwords | Argon2id 64 MiB / t=3, bounded concurrency, re-hash on login, equal-time unknown users |
| Tokens / receipts | 256-bit random; only keyed HMAC verifiers stored |
| Cookies | HttpOnly, SameSite=Lax; `Secure` + `__Host-` when `COOKIE_SECURE=true` |
| CSRF | `X-CSRF-Token` = HMAC(HttpOnly boot cookie) + exact Origin allowlist on every unsafe request |
| Content encryption | AES-256-GCM per case / report / export / staff-TOTP data key, wrapped by `WRAPPING_KEY`, AAD binds table + row + field |
| Staff | Separate accounts, password + TOTP with replay protection, grants checked per request, audited reads before plaintext, preview → fresh-TOTP confirm |
| Database roles | `notitle_owner` (schema), `notitle_app` (DML only; cannot alter schema or write migration history) |
| Deletion | Receipt → live fence → fsynced HMAC-chained journal → disable → purge job; journal replayed at startup so restores cannot resurrect accounts |
| Payments | Server-side intents, signed webhooks, independent provider fetch before grant, FIFO ledger with CHECK-enforced conservation, no voluntary refunds |
| Limits | Body size per route, token-bucket rate limits, bounded WebSocket output, capacity caps (200 connected / 100 waiting / 25 calls / 1000 guests) |

## Deviations from the blueprint (deliberate, for a runnable local system)

| Blueprint | This delivery | Why |
|---|---|---|
| Caddy in front of FastAPI | FastAPI serves static exports and sets headers/CSP | No extra binary on Windows; Caddy remains the recommended production TLS edge |
| coturn + nftables kernel guard, mTLS relay controller, packet-proven teardown | WebRTC audio with server-authorised signalling; TURN REST credentials and `iceTransportPolicy=relay` via config; media teardown enforced client-side and by ending calls server-side | Kernel packet revocation needs a dedicated Linux relay host; it is the main open item for audio in production |
| Independent journal mirrored to versioned object storage | Local fsynced HMAC-chained file (`.local/journal`), copied with each backup | Object storage is an external dependency; mirror before production |
| restic encrypted backups, systemd timers, signed releases | `pg_dump` backup + restore-into-new-database commands | Local operation; production automation is deployment work |
| Hash-locked Python requirements | Exact version pins | `pip --require-hashes` can be added once the target platform is fixed |
| Data retention 180-day audit archive in India | Audit rows deleted after 180 days, no external archive | External archive is a deployment decision |

## Production checklist

1. HTTPS edge (e.g. Caddy) in front of both listeners; private listener reachable only through a VPN/SSH tunnel.
2. `APP_ENV=production`, `COOKIE_SECURE=true`, https origins, fresh 32-byte keys kept outside the server (losing `WRAPPING_KEY` makes saved cases unreadable).
3. Managed PostgreSQL with TLS (`sslmode=verify-full`) and separate role DSNs; run `db-bootstrap`/`migrate` with the owner role only.
4. TURN relay (coturn `use-auth-secret`), `TURN_URLS`, `TURN_SHARED_SECRET`, `AUDIO_REQUIRE_RELAY=true`; qualify media teardown.
5. Cashfree merchant approval; sandbox contract test of `create order / fetch payments / refunds / webhook signature`; `PAYMENT_PROVIDER=cashfree`.
6. Replace every `[Operator to supply]` in `backend/policies/*.md`, get legal review, set `state: published`; review `legal_rules.json`.
7. Off-host copies of backups and the journal; rehearse a restore into an empty server.
8. Load, accessibility and security testing on the production-like environment.
