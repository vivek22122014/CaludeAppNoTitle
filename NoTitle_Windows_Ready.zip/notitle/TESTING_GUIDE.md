# NoTitle — Beginner's Guide: Install, Run and Test on Windows

This guide assumes no prior experience. Follow the steps in order. Every command is typed into
**Windows PowerShell** or run by **double-clicking** a file. Expected output is shown after each step.

---

## 0. What you are about to run

NoTitle is a website where adults talk one-to-one, pseudonymously, about work. It has two parts:

| Part | Address | Who uses it |
|---|---|---|
| Public site + API | http://localhost:8080 | Users (guests and accounts) |
| Private staff site | http://localhost:8081 | Moderators, billing and privacy staff |

Everything runs on your own computer. No real money moves: payments use a built-in **simulator**.

---

## 1. Prerequisites (one time)

| Software | Needed? | How to get it |
|---|---|---|
| Windows 10 or 11 (64-bit) | Required | — |
| **Python 3.12** | Required | https://www.python.org/downloads/windows/ → "Windows installer (64-bit)". On the first screen **tick "Add python.exe to PATH"**, then *Install Now*. |
| Node.js | Automatic | Setup downloads a portable, checksum-verified copy if you don't have Node.js 20.9+. |
| PostgreSQL | Automatic | Setup uses **Docker Desktop** if it is running; otherwise it downloads portable PostgreSQL (about 330 MB, no admin rights needed). |
| Docker Desktop | Optional | https://www.docker.com/products/docker-desktop/ — only if you prefer the database in a container. |
| Internet access | Required for setup | Downloads Python packages, npm packages, Node.js and (if needed) PostgreSQL. |
| About 2 GB free disk | Required | — |

**Check Python** — open PowerShell (Start menu → type *PowerShell* → Enter) and run:

```powershell
py --version
```

Expected: `Python 3.12.x` (3.11 or 3.13 also work). If you see "not recognized", reinstall Python and tick *Add python.exe to PATH*.

---

## 2. Get the project

1. Put the `notitle` folder somewhere simple, for example `C:\Users\<you>\Desktop\notitle`.
   Avoid folders synced by OneDrive if possible (syncing can lock files during installs).
2. Open PowerShell **in that folder**: in File Explorer open the folder, click the address bar, type `powershell`, press Enter.

---

## 3. Run setup (one command)

Double-click **`setup.cmd`**, or in PowerShell:

```powershell
.\setup.cmd
```

It takes 3–10 minutes the first time. Expected output (abridged):

```
==> Checking Python
    [ok] Using C:\...\Python312\python.exe
==> Installing backend dependencies (backend\.venv)
    [ok] Backend dependencies installed
==> Configuration (.env)
    [ok] Created .env with new random secrets (keep this file private and backed up)
==> Checking Node.js
    [ok] Checksum verified
    [ok] Using Node.js v24.22.0 (...\.tools\node\node.exe)
==> Preparing PostgreSQL
    Database mode: docker          (or: portable)
    [ok] PostgreSQL is reachable
==> Creating database roles and applying migrations
applied: 0001_foundation, 0002_identity, 0003_social_safety_support, 0004_staff, 0005_billing, 0006_privacy_operations
    [ok] Database schema is up to date
==> Installing frontend dependencies ...
==> Building the public and private static sites
    [ok] Frontend built (frontend\public\out and frontend\admin\out)
==> Local staff owner account
Staff account 'admin' created with roles owner.
    [ok] Staff login saved in .local\staff\admin-password.txt (development only)

Setup complete.
```

Setup is safe to run again at any time; it keeps your existing `.env`, database and data.

> No Docker, or Docker is not running? Setup automatically uses portable PostgreSQL. To force it:
> `powershell -ExecutionPolicy Bypass -File scripts\setup.ps1 -DbMode portable`

---

## 4. Start the application

Double-click **`start.cmd`** (keep the window open; press **Ctrl+C** to stop), or run it in the background:

```powershell
powershell -ExecutionPolicy Bypass -File scripts\start.ps1 -Background
```

Expected:

```
==> Starting PostgreSQL
    [ok] PostgreSQL is reachable
==> Applying pending migrations (runtime is stopped)
applied: nothing (already up to date)
==> Starting NoTitle in the background
    [ok] NoTitle is running (PID 1234)
  Public site:  http://localhost:8080
  Staff site:   http://localhost:8081
```

Check it is healthy — open http://localhost:8080/health/ready. You should see `"status":"ready"`.

Stop it later with **`stop.cmd`** (add `-Database` to also stop PostgreSQL).

---

## 5. Manual test walkthrough

You need **two separate identities** to talk to yourself. Easiest way: use two browser tabs with
different addresses, because browsers keep cookies per address:

* **Person A:** http://localhost:8080
* **Person B:** http://127.0.0.1:8080

(Alternatively use two different browsers, e.g. Chrome and Edge.)

### 5.1 Guest entry and matching (Phases 3–4)
1. In tab A open http://localhost:8080 → **Start a Conversation**.
2. Click **Continue as guest** without filling anything → expected: *"Choose how you describe your gender."*
3. Choose a gender and topic, tick the three required confirmations (leave the optional one unticked), click **Continue as guest**.
   Expected: you land on **Chat** with a generated pseudonym (e.g. *MerryLynx26*) and a **Search** button. Nothing searches automatically.
4. Repeat in tab B (http://127.0.0.1:8080).
5. Click **Search** in A ("Searching for someone to talk to…"), then **Search** in B.
   Expected: both see the other's pseudonym, gender and topic.

### 5.2 Temporary text (Phase 4)
1. In A type a message and press **Enter** (Shift+Enter makes a new line).
2. Expected: B sees it; A's message shows **Sent**, then **Delivered** once B's browser displayed it.
3. Click **End** in A. Expected: B sees *"The other person ended the conversation."* and both transcripts are gone.

### 5.3 Friends and invitations (Phase 6)
1. Match again (Search in both). In A click **Add friend**; in B click **Accept friend**.
   Expected: both show **Friends (temporary)** (guests' friendships are temporary; two accounts get **Saved**).
2. Click **End**, then open **Friends** in both tabs. In A click **Invite to talk**; in B click **Accept**.
   Expected: a new conversation starts, marked *Friend*.

### 5.4 Audio (Phase 7)
1. In a conversation click **Request audio call** in A; B sees *Incoming audio call* → **Accept**.
2. Your browser asks for microphone permission — allow it. Expected: **Audio connected** in both; **Mute** works.
3. Click **End** (conversation) → the call ends immediately.

   Two tabs in the same browser share one microphone; that works but you hear echo. If permission is
   denied, the app says so and text continues.

### 5.5 Report and Block (Phase 5)
1. In a conversation, from B send nothing; from A send *"test message"*.
2. In B click **Report** → choose a reason → the message is pre-selected → tick **Also block this person**.
   As a guest you see a **Case receipt** (reference + secret): click *Download*, then tick *I have saved…* → **Submit report**.
   Expected: *Report saved* with a reference; A sees the conversation end; they will not be matched again.
3. In B open **Support** → the safety case is listed.

### 5.6 Chat with Moderator (Phase 5)
1. In any tab: **Support → New case**, fill subject and message, save the receipt, **Save case**.
2. Expected: the thread opens. Send a follow-up; it shows only after the server saved it.

### 5.7 Staff site (Phase 5, 8, 9)
1. Open http://localhost:8081. Username **admin**; the password is in `.local\staff\admin-password.txt`.
2. Authenticator code: either add the TOTP secret from `.local\staff\admin-enrollment.txt` to an authenticator
   app (Google Authenticator, Microsoft Authenticator…), or print a development code:

   ```powershell
   powershell -ExecutionPolicy Bypass -File scripts\staff-code.ps1
   ```
   Expected: a 6-digit number. Each code works **once** (replay protection); run it again for the next one.
3. **Cases** → open your case → choose a *Purpose of this read* → **Load messages** (this is audited) →
   write a reply → **Send reply to user**. In the user tab, reload the case: the reply shows as **Moderator**.
4. **Reports** → open the report → choose a purpose → **Load evidence** → choose an action (e.g. *Dismiss* or
   *Suspend*) and a reason code → **Preview decision** → enter a fresh authenticator code → **Confirm**.
   A suspended user can no longer search (*"Your access to matching is restricted."*).
5. **Audit** shows every content read, without message bodies. **Analytics** shows aggregate counts
   (values under 10 appear as `<10`; minute counters flush once a minute). **Health** shows database,
   migrations, journal and feature gates.

### 5.8 Accounts, recovery and settings (Phase 3)
1. **Register**: choose a username, password (12+ characters), display name; on the next step your
   **recovery code** is shown once — *Reveal / Copy / Download*, tick *I have saved…*, **Create account**.
2. **Account → Sign out**, then **Log in** again. A wrong password shows a generic error.
3. **Forgot password?** on the login page: username + recovery code → you get a new recovery code.
4. **Account**: signed-in devices (max 5), password change, new recovery code, blocked list.

### 5.9 Premium purchase (Phase 8) — simulated, no real money
1. Signed in with an account: **Premium → Choose 3-day pass**, enter any 10-digit mobile number starting
   with 6–9 (e.g. `9876543210`), tick the no-voluntary-refund acknowledgement → **Pay ₹99**.
2. The **Simulated payment** page opens → **Pay ₹99**. Expected: *Payment verified. Your pass is active.*
3. **Account → Premium & receipts** shows the remaining time and the receipt.
   **Preferences** → a specific gender preference is now *effective*.
4. Staff site → **Billing** → *Required remedy* (e.g. basis *payment_error*) → preview → authenticator code →
   confirm. The pass time of that purchase only is revoked. There are no voluntary refunds by design.

### 5.10 Privacy (Phases 3, 9)
1. **Account → Privacy**: withdraw/allow optional professional processing; **Request export**
   (confirm your password) → **Download** a JSON file of your data.
2. **Delete my account…** → save the deletion receipt → confirm. You are signed out; logging in fails.
   On **Account deletion** (footer link) enter the reference and secret → status *Completed*.

---

## 6. Automated tests

Double-click **`test.cmd`**, or:

```powershell
.\test.cmd
```

It runs six groups and prints a summary (about 5 minutes). Expected end of output:

```
Backend unit tests        PASS
Backend integration tests PASS
Policy lint               PASS
Frontend typecheck        PASS
Frontend build            PASS
Browser E2E tests         PASS
All checks passed.
```

* Integration and browser tests use their **own disposable databases** (`notitle_test`, `notitle_e2e`)
  and ports (18080/18081, 18180/18181); your data on 8080/8081 is not touched.
* The first run downloads the Playwright Chromium browser (about 150 MB).
* `.\test.cmd -SkipE2E` skips browser tests; `.\test.cmd -Build` rebuilds the frontend first.
* The summary is saved to `.local\test-report.txt`.

---

## 7. Everyday commands

| Task | Command |
|---|---|
| Start (foreground) | `start.cmd` |
| Start (background) | `powershell -ExecutionPolicy Bypass -File scripts\start.ps1 -Background` |
| Stop | `stop.cmd` (add `-Database` to stop PostgreSQL too) |
| Rebuild the websites after editing frontend code | `powershell -ExecutionPolicy Bypass -File scripts\build.ps1` |
| Hot-reload development (ports 3000/3001) | `powershell -ExecutionPolicy Bypass -File scripts\dev.ps1` |
| Database status | `powershell -ExecutionPolicy Bypass -File scripts\db.ps1 status` |
| Backup | `powershell -ExecutionPolicy Bypass -File scripts\db.ps1 backup` |
| Restore into a new database | `scripts\db.ps1 restore -File .local\backups\notitle-....sql -TargetDb notitle_restore` |
| New staff member | `scripts\create-staff.ps1 -Username alice -Roles moderator` |
| Next authenticator code (dev) | `scripts\staff-code.ps1 -Username admin` |
| Wipe everything local and start over | `powershell -ExecutionPolicy Bypass -File scripts\reset.ps1` then `setup.cmd` |

---

## 8. Troubleshooting

| Symptom | Cause and fix |
|---|---|
| `py` / `python` not recognized | Install Python 3.12 with *Add python.exe to PATH* ticked, then open a **new** PowerShell window. |
| "running scripts is disabled on this system" | Use the `.cmd` files, or prefix commands with `powershell -ExecutionPolicy Bypass -File`. |
| Setup stops at downloading Node.js or PostgreSQL | Check internet/proxy access to nodejs.org and get.enterprisedb.com, then re-run setup (it resumes). |
| `DB_MODE=docker but Docker is not running` | Start Docker Desktop, or run `scripts\setup.ps1 -DbMode portable`. |
| `PostgreSQL is not reachable` | Run `scripts\db.ps1 start`. Portable mode: see `.local\postgres.log`. Port 5433 must be free (change `DB_PORT` and the three database URLs in `.env` together if not). |
| `Another NoTitle runtime already owns this database` | One copy is already running. Run `stop.cmd`, then start again. |
| `database is missing migrations` | Stop NoTitle and run `scripts\db.ps1 migrate` (start.cmd does this automatically). |
| Browser shows *"The public frontend has not been built yet"* | Run `scripts\build.ps1`, then reload. |
| *"Request origin is not allowed"* | Open the site exactly at http://localhost:8080 or http://127.0.0.1:8080 (other addresses must be added to `EXTRA_PUBLIC_ORIGINS` in `.env`). |
| *"Your page session expired"* | Reload the page (it fetches a fresh request token). |
| *"NoTitle is open in another tab"* | One active tab per identity: click *Use this tab instead*, or close the other tab. |
| *"Too many requests"* | Rate limits protect sign-in and guest creation. Wait a few seconds. |
| Search says Premium is needed | Your saved gender preference needs an active pass; choose *Search with Everyone*. |
| Audio: "Microphone permission was denied" | Allow microphone access for the site in the browser's address bar, then request the call again. |
| Staff sign-in fails with a correct password | The 6-digit code was already used or expired: run `scripts\staff-code.ps1` again. |
| `Privacy journal check failed` at start | The journal file in `.local\journal` does not match the database (e.g. you deleted `.local` but kept the database). For a throw-away local setup run `scripts\reset.ps1` and setup again. Never do this with real data. |
| Port 8080/8081 in use | Change `PUBLIC_PORT`/`PRIVATE_PORT` and the matching `PUBLIC_ORIGIN`/`PRIVATE_ORIGIN` in `.env`. |
| Logs | Foreground: the start window. Background: `.local\runner.err.log`. |

Never share `.env` or anything in `.local\` — they contain secrets and personal data.
