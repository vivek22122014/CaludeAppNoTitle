"""Phase 5: reports, blocks, saved support, private staff operations, decisions and appeals."""

import uuid

import httpx

from tests.integration.conftest import (
    PRIVATE, STAFF2_USER, Api, CommandError, Socket, Staff, matched_pair, new_guest, register,
)


def new_case_as_guest(subject="Help with my case", body="Something happened"):
    guest = new_guest()
    prep = guest.data(guest.post("/api/v1/operations/prepare", {"kind": "case_receipt"}))
    case = guest.data(guest.post("/api/v1/support/cases", {
        "category": "general", "subject": subject, "body": body, "client_nonce": str(uuid.uuid4()),
        "reservation_id": prep["reservation_id"], "receipt_secret": prep["secret"], "saved": True}), 201)
    assert case["case_ref"] == prep["reference"]
    return guest, case, prep


def test_guest_support_case_with_receipt_and_staff_reply(server):
    guest, case, prep = new_case_as_guest()
    ref = case["case_ref"]
    nonce = str(uuid.uuid4())
    first = guest.post(f"/api/v1/support/cases/{ref}/messages", {"body": "follow-up", "client_nonce": nonce})
    assert first.status_code == 201 and first.json()["data"]["sequence"] == 2
    retry = guest.post(f"/api/v1/support/cases/{ref}/messages", {"body": "follow-up", "client_nonce": nonce})
    assert retry.status_code == 200 and retry.json()["data"]["sequence"] == 2  # idempotent
    clash = guest.post(f"/api/v1/support/cases/{ref}/messages", {"body": "different", "client_nonce": nonce})
    assert clash.status_code == 409

    # A different browser can return with the saved receipt only.
    other = Api()
    assert other.get(f"/api/v1/support/cases/{ref}").status_code == 404
    other.data(other.post("/api/v1/support/access", {"reference": ref, "secret": prep["secret"]}))
    assert other.data(other.get(f"/api/v1/support/cases/{ref}"))["status"] == "open"
    assert Api().post("/api/v1/support/access", {"reference": ref, "secret": "WRONG"}).status_code == 401

    staff = Staff(server)
    queue = staff.data(staff.get("/internal/v1/cases"))["items"]
    item = [c for c in queue if c["case_ref"] == ref][0]
    assert item["unread"] >= 1
    # Reading content requires a purpose and is audited.
    assert staff.get(f"/internal/v1/cases/{ref}/messages").status_code == 422
    msgs = staff.data(staff.get(f"/internal/v1/cases/{ref}/messages", params={"purpose": "case_handling"}))
    assert [m["body"] for m in msgs["items"]] == ["Something happened", "follow-up"]
    claim = staff.data(staff.post(f"/internal/v1/cases/{ref}/claim", {"expected_version": item["version"]}))
    assert staff.post(f"/internal/v1/cases/{ref}/claim", {"expected_version": item["version"]}).status_code == 409
    staff.data(staff.post(f"/internal/v1/cases/{ref}/notes", {"body": "internal: looks fine"}), 201)
    # Staff replies cannot contain email addresses or ask for secrets.
    assert staff.post(f"/internal/v1/cases/{ref}/messages", {"body": "mail me at a@b.co", "client_nonce": str(uuid.uuid4())}).status_code == 422
    assert staff.post(f"/internal/v1/cases/{ref}/messages", {"body": "send your password", "client_nonce": str(uuid.uuid4())}).status_code == 422
    staff.data(staff.post(f"/internal/v1/cases/{ref}/messages", {"body": "We are looking into it.",
                                                                "client_nonce": str(uuid.uuid4())}), 201)
    user_view = other.data(other.get(f"/api/v1/support/cases/{ref}/messages"))["items"]
    assert user_view[-1]["display_role"] == "Moderator" and "internal" not in str(user_view)
    assert other.data(other.post(f"/api/v1/support/cases/{ref}/seen", {"seen_through": 3}))["seen_user_sequence"] == 3
    assert other.post(f"/api/v1/support/cases/{ref}/seen", {"seen_through": 99}).status_code == 422

    # Closing needs completed obligations, then the user can reopen.
    detail = staff.data(staff.get(f"/internal/v1/cases/{ref}"))
    r = staff.post(f"/internal/v1/cases/{ref}/status", {"expected_version": detail["version"],
                                                        "target_status": "closed", "reason": "done"})
    assert r.status_code == 409 and r.json()["error"]["code"] == "obligations_open"
    for ob in detail["obligations"]:
        staff.data(staff.post(f"/internal/v1/cases/{ref}/obligations/complete",
                              {"obligation_id": ob["id"], "outcome": "answered", "evidence_ref": "reply#3"}))
    detail = staff.data(staff.get(f"/internal/v1/cases/{ref}"))
    staff.data(staff.post(f"/internal/v1/cases/{ref}/status", {"expected_version": detail["version"],
                                                               "target_status": "closed", "reason": "done"}))
    case_now = other.data(other.get(f"/api/v1/support/cases/{ref}"))
    assert case_now["status"] == "closed"
    assert other.post(f"/api/v1/support/cases/{ref}/messages", {"body": "x", "client_nonce": str(uuid.uuid4())}).status_code == 409
    other.data(other.post(f"/api/v1/support/cases/{ref}/reopen", {"expected_version": case_now["version"], "reason": "more"}))
    audit = staff.data(staff.get("/internal/v1/audit"))["items"]
    assert any(a["object_ref"] == ref and a["action"].startswith("read:") for a in audit)
    assert "follow-up" not in str(audit)
    assert claim["assigned_to_me"]


def test_account_cases_listed_and_isolated(server):
    (a, _), (b, _) = register(), register()
    case = a.data(a.post("/api/v1/support/cases", {"category": "security", "subject": "Mine",
                                                   "body": "private", "client_nonce": str(uuid.uuid4())}), 201)
    assert [c["case_ref"] for c in a.data(a.get("/api/v1/support/cases"))["items"]] == [case["case_ref"]]
    assert b.get(f"/api/v1/support/cases/{case['case_ref']}").status_code == 404
    assert b.data(b.get("/api/v1/support/cases"))["items"] == []


def test_report_and_block_then_decision_and_appeal(server):
    reporter = new_guest("female")
    reported, _ = register(gender="male")
    sr, sd, iid = matched_pair(reporter, reported)
    sd.command("text.send", {"interaction_id": iid, "client_id": "m1", "body": "threatening words"})
    msg = sr.wait("text.received")
    snap = reporter.data(reporter.post("/api/v1/reports/prepare", {"interaction_id": iid}))
    prep = reporter.data(reporter.post("/api/v1/operations/prepare", {"kind": "case_receipt"}))
    report = reporter.data(reporter.post("/api/v1/reports", {
        "interaction_id": iid, "snapshot_id": snap["snapshot_id"], "selected_message_ids": [msg["message_id"]],
        "reason": "threats", "allegation": "They threatened me", "block": True, "client_nonce": str(uuid.uuid4()),
        "reservation_id": prep["reservation_id"], "receipt_secret": prep["secret"], "saved": True}), 201)
    assert report["blocked"] is True and report["evidence_state"] == "server_snapshot"
    assert sd.wait("interaction.ended")

    staff = Staff(server)
    reports = staff.data(staff.get("/internal/v1/reports"))["items"]
    assert any(r["public_ref"] == report["report_ref"] and r["urgent"] for r in reports)
    detail = staff.data(staff.get(f"/internal/v1/reports/{report['report_ref']}", params={"purpose": "safety_review"}))
    assert detail["evidence"][0]["body"] == "threatening words" and detail["evidence"][0]["source"] == "server_snapshot"
    preview = staff.data(staff.post("/internal/v1/decisions/preview", {
        "report_ref": report["report_ref"], "action": "suspend", "reason_code": "threats", "duration_hours": 24}))
    decision = staff.data(staff.post("/internal/v1/decisions/confirm", {"nonce": preview["nonce"], "totp": staff.totp()}))
    replay = staff.post("/internal/v1/decisions/confirm", {"nonce": preview["nonce"], "totp": staff.totp()})
    assert replay.status_code in (401, 409)
    with_socket = Socket(reported, takeover=True)
    try:
        with_socket.command("queue.join")
        raise AssertionError("restricted account could search")
    except CommandError as err:
        assert err.code == "restricted"
    notices = reported.data(reported.get("/api/v1/me/notices"))["items"]
    assert notices[0]["payload"]["decision_ref"] == decision["decision_ref"]

    # The deciding moderator cannot review the appeal; an independent reviewer can.
    staff.data(staff.post("/internal/v1/auth/step-up", {"totp": staff.totp()}))
    own = staff.post(f"/internal/v1/appeals/{decision['decision_ref']}/resolve", {"outcome": "overturned", "reason": "x"})
    assert own.status_code == 403
    reviewer = Staff(server, STAFF2_USER)
    reviewer.data(reviewer.post(f"/internal/v1/appeals/{decision['decision_ref']}/resolve",
                                {"outcome": "overturned", "reason": "context shows no threat"}))
    assert with_socket.command("queue.join")["queue_token"]
    with_socket.command("queue.cancel")
    for s in (sr, sd, with_socket):
        s.close()


def test_staff_permissions_are_scoped_and_private_api_needs_mfa(server):
    anonymous = Api(PRIVATE, "/internal/v1/bootstrap")
    assert anonymous.get("/internal/v1/cases").status_code == 401
    r = anonymous.post("/internal/v1/auth/login", {"username": "teststaff", "password": "Test-Staff-Password-123",
                                                   "totp": "000000"})
    assert r.status_code == 401
    moderator = Staff(server, STAFF2_USER)
    assert moderator.get("/internal/v1/analytics/summary").status_code == 403
    assert moderator.get("/internal/v1/billing/purchases").status_code == 403
    assert moderator.get("/internal/v1/staff").status_code == 403
    assert httpx.get(f"{PRIVATE}/api/v1/bootstrap").status_code in (404, 503)
