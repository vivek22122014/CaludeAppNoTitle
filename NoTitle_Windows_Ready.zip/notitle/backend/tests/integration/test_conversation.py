"""Phases 4, 6 and 7: matching, temporary text, friends, invitations, audio signalling."""

import time

import psycopg
import pytest

from tests.integration.conftest import (
    CommandError, Socket, matched_pair, new_guest, register,
)

SDP_OFFER = ("v=0\r\no=- 1 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\nm=audio 9 UDP/TLS/RTP/SAVPF 111\r\n"
             "a=fingerprint:sha-256 AB:CD:EF\r\na=rtpmap:111 opus/48000/2\r\n")


def test_match_text_delivery_and_end(server):
    a, b = new_guest("male", "salaries"), new_guest("female", "salaries")
    sa, sb, iid = matched_pair(a, b)
    ack = sa.command("text.send", {"interaction_id": iid, "client_id": "c1", "body": "Hello from A"})
    assert ack["message_id"].startswith("m_")
    received = sb.wait("text.received")
    assert received["body"] == "Hello from A"
    sb.send("text.delivered", {"interaction_id": iid, "message_id": received["message_id"]})
    assert sa.wait("text.delivery")["state"] == "delivered"
    sb.command("interaction.end", {"interaction_id": iid})
    assert sa.wait("interaction.ended")["reason"] == "peer_ended"
    with pytest.raises(CommandError) as err:
        sa.command("text.send", {"interaction_id": iid, "client_id": "c2", "body": "late"})
    assert err.value.code == "stale_interaction"
    sa.close(); sb.close()


def test_peer_dto_exact_fields_and_no_private_data(server):
    a, creds = register(gender="other")
    b = new_guest("female")
    sa, sb = Socket(a), Socket(b)
    sa.command("queue.join")
    sb.command("queue.join")
    started = sb.wait("interaction.started")
    assert set(started["peer"]) == {"peer_handle", "display_name", "gender", "topic_id", "bio"}
    assert creds["username"] not in str(started)
    sa.close(); sb.close()


def test_ordinary_text_is_never_written_to_postgres(server):
    a, b = new_guest(), new_guest()
    sa, sb, iid = matched_pair(a, b)
    marker = "UNIQUE-MARKER-7f3a9c"
    sa.command("text.send", {"interaction_id": iid, "client_id": "c1", "body": marker})
    sb.wait("text.received")
    sa.command("interaction.end", {"interaction_id": iid})
    with psycopg.connect(server["env"]["DATABASE_MIGRATOR_URL"]) as conn:
        tables = [r[0] for r in conn.execute(
            "SELECT table_name FROM information_schema.columns WHERE table_schema='public' AND data_type IN ('text','jsonb')")]
        for table in set(tables):
            cols = [r[0] for r in conn.execute(
                "SELECT column_name FROM information_schema.columns WHERE table_schema='public' AND table_name=%s "
                "AND data_type IN ('text','jsonb')", (table,))]
            for col in cols:
                hit = conn.execute(f'SELECT 1 FROM "{table}" WHERE "{col}"::text LIKE %s LIMIT 1', (f"%{marker}%",)).fetchone()
                assert hit is None, f"chat text found in {table}.{col}"
    sa.close(); sb.close()


def test_next_requeues_initiator_only_and_http_end_fallback(server):
    a, b = new_guest(), new_guest()
    sa, sb, iid = matched_pair(a, b)
    result = sa.command("interaction.next", {"interaction_id": iid})
    assert result["queue_token"]
    assert sb.wait("interaction.ended")["reason"] == "peer_ended"
    sa.command("queue.cancel")
    # HTTP End is idempotent and works without the socket.
    c, d = new_guest(), new_guest()
    sc, sd, iid2 = matched_pair(c, d)
    assert c.data(c.post("/api/v1/interactions/end", {"interaction_id": iid2}))["ended"] is True
    assert c.data(c.post("/api/v1/interactions/end", {"interaction_id": iid2}))["already_ended"] is True
    assert sd.wait("interaction.ended")
    for s in (sa, sb, sc, sd):
        s.close()


def test_reconnect_within_grace_resumes_text(server):
    a, b = new_guest(), new_guest()
    sa, sb, iid = matched_pair(a, b)
    sa.command("text.send", {"interaction_id": iid, "client_id": "c1", "body": "before drop"})
    sb.wait("text.received")
    sa.close()
    assert sb.wait("interaction.interrupted")["grace_seconds"] == 25
    sa2 = Socket(a)
    assert sa2.ready["state"] == "in_interaction"
    assert sa2.ready["interaction"]["messages"][0]["body"] == "before drop"
    assert sb.wait("interaction.resumed")
    sa2.close(); sb.close()


def test_guest_friendship_is_temporary_and_invite_flow(server):
    a, b = new_guest(), new_guest()
    sa, sb, iid = matched_pair(a, b)
    assert sa.command("friend.request", {"interaction_id": iid})["state"] == "pending"
    request = sb.wait("friend.requested")
    result = sb.command("friend.respond", {"request_id": request["request_id"], "accept": True})
    assert result["state"] == "temporary"
    rel = result["relationship_id"]
    assert sa.wait("friend.accepted")["temporary"] is True
    friends = a.data(a.get("/api/v1/friends"))["items"]
    assert friends[0]["state"] == "temporary" and friends[0]["presence"] in ("busy", "available")
    sa.command("interaction.end", {"interaction_id": iid})
    sa.wait("interaction.ended"); sb.wait("interaction.ended")
    sent = sa.command("friend.invite", {"relationship_id": rel})
    invite = sb.wait("invite.received")
    assert invite["invite_id"] == sent["invite_id"]
    sb.command("friend.invite.respond", {"invite_id": invite["invite_id"], "accept": True})
    started = sa.wait("interaction.started")
    assert started["source"] == "invite" and started["friend_state"] == "friends"
    sa.close(); sb.close()


def test_account_friendship_is_saved_durably_and_removable(server):
    (a, _), (b, _) = register(), register()
    sa, sb, iid = matched_pair(a, b)
    sa.command("friend.request", {"interaction_id": iid})
    req = sb.wait("friend.requested")
    assert sb.command("friend.respond", {"request_id": req["request_id"], "accept": True})["state"] == "saving"
    persisted = sa.wait("friend.persisted")
    rel = persisted["relationship_id"]
    items = a.data(a.get("/api/v1/friends"))["items"]
    assert [i for i in items if i["relationship_id"] == rel][0]["state"] == "saved"
    a.data(a.delete(f"/api/v1/friends/{rel}"))
    assert sb.wait("friend.removed")["relationship_id"] == rel
    assert not [i for i in a.data(a.get("/api/v1/friends"))["items"] if i["relationship_id"] == rel]
    sa.close(); sb.close()


def test_block_ends_conversation_and_lists_without_identity(server):
    (a, _), (b, _) = register(), register()
    sa, sb, iid = matched_pair(a, b)
    result = a.data(a.post("/api/v1/blocks", {"interaction_id": iid}), 201)
    assert result["persisted"] is True
    assert sb.wait("interaction.ended")["reason"] == "peer_ended"
    blocks = a.data(a.get("/api/v1/blocks"))["items"]
    assert blocks and blocks[0]["label"] == "Blocked contact"
    assert b.data(b.get("/api/v1/blocks"))["items"] == []  # incoming blocks are not enumerated
    # They are never matched together again.
    sa.command("queue.join"); sb.command("queue.join")
    time.sleep(1.0)
    assert not [e for e in sa.events if e["type"] == "interaction.started"]
    sa.command("queue.cancel"); sb.command("queue.cancel")
    a.data(a.delete(f"/api/v1/blocks/{blocks[0]['block_ref']}"))
    sa.close(); sb.close()


def test_audio_signalling_and_teardown(server):
    a, b = new_guest(), new_guest()
    sa, sb, iid = matched_pair(a, b)
    ring = sa.command("call.request", {"interaction_id": iid})
    incoming = sb.wait("call.incoming")
    assert incoming["call_id"] == ring["call_id"]
    sb.command("call.respond", {"call_id": ring["call_id"], "accept": True})
    auth_a = sa.wait("call.authorized")
    auth_b = sb.wait("call.authorized")
    assert auth_a["role"] == "offerer" and auth_b["role"] == "answerer"
    sa.send("call.sdp", {"call_id": ring["call_id"], "revision": 1, "sdp_type": "offer", "sdp": SDP_OFFER})
    assert sb.wait("call.sdp")["sdp_type"] == "offer"
    bad = sa.send("call.sdp", {"call_id": ring["call_id"], "revision": 2, "sdp_type": "offer",
                               "sdp": SDP_OFFER + "m=video 9 UDP/TLS/RTP/SAVPF 96\r\n"})
    err = sa.wait("error", predicate=lambda p: p.get("code") == "invalid_sdp")
    assert err
    sa.send("call.ice", {"call_id": ring["call_id"], "revision": 1,
                         "candidate": "candidate:1 1 udp 2122260223 127.0.0.1 54400 typ host", "sdp_mid": "0"})
    assert sb.wait("call.ice")["candidate"].endswith("typ host")
    sb.command("call.end", {"call_id": ring["call_id"], "reason": "hangup"})
    assert sa.wait("call.ended")["reason"] == "hangup"
    # Text continues after the call ends.
    sa.command("text.send", {"interaction_id": iid, "client_id": "after", "body": "still here"})
    assert sb.wait("text.received")["body"] == "still here"
    sa.close(); sb.close()


def test_report_snapshot_requires_selection(server):
    a, b = new_guest(), new_guest()
    sa, sb, iid = matched_pair(a, b)
    sb.command("text.send", {"interaction_id": iid, "client_id": "x", "body": "rude message"})
    sa.wait("text.received")
    snap = a.data(a.post("/api/v1/reports/prepare", {"interaction_id": iid}))
    assert snap["messages"][0]["body"] == "rude message" and snap["messages"][0]["mine"] is False
    sa.close(); sb.close()
