"""Guest-to-account conversion and privacy-journal replay after a database restore."""

import subprocess
import time

import psycopg

from tests.integration.conftest import BACKEND, Api, matched_pair, new_guest, register


def test_guest_registers_mid_conversation_and_keeps_talking(server):
    guest = new_guest()
    other = new_guest()
    sg, so, iid = matched_pair(guest, other)
    sg.command("text.send", {"interaction_id": iid, "client_id": "c1", "body": "before registering"})
    so.wait("text.received")
    # Register from the guest session, carrying the live conversation.
    _, creds = register(guest, convert_guest=True)
    sg.wait("identity.converted")
    assert guest.data(guest.get("/api/v1/me"))["kind"] == "account"
    sg.command("text.send", {"interaction_id": iid, "client_id": "c2", "body": "after registering"})
    assert so.wait("text.received")["body"] == "after registering"
    sg.close(); so.close()


def test_deletion_survives_restore_of_older_database(server):
    api, creds = register()
    api.data(api.post("/api/v1/auth/reauth", {"password": creds["password"]}))
    prep = api.data(api.post("/api/v1/operations/prepare", {"kind": "deletion_receipt"}))
    api.data(api.post("/api/v1/privacy/delete", {"reservation_id": prep["reservation_id"], "receipt_secret": prep["secret"],
                                                 "saved": True, "confirm": True}), 202)
    url = server["env"]["DATABASE_MIGRATOR_URL"]
    # Simulate restoring a backup taken before the deletion: the account row is active again
    # and the deletion request has vanished from the database (the journal file survives).
    with psycopg.connect(url, autocommit=True) as conn:
        for _ in range(40):
            row = conn.execute("SELECT state FROM deletion_requests WHERE public_ref = %s", (prep["reference"],)).fetchone()
            if row and row[0] == "completed":
                break
            time.sleep(0.25)
        conn.execute("DELETE FROM durable_jobs WHERE kind = 'deletion.purge'")
        conn.execute("DELETE FROM scoped_receipts WHERE public_ref = %s", (prep["reference"],))
        conn.execute("DELETE FROM deletion_requests WHERE public_ref = %s", (prep["reference"],))
        conn.execute("UPDATE accounts SET status = 'active', username = %s, password_hash = 'x' "
                     "WHERE username LIKE 'deleted\\_%%' AND display_name = 'Deleted user' AND deleted_at IS NOT NULL "
                     "AND id = (SELECT id FROM accounts WHERE deleted_at IS NOT NULL ORDER BY deleted_at DESC LIMIT 1)",
                     (creds["username"],))
        conn.execute("DELETE FROM journal_checkpoints")
    # A replay (what the runtime does at startup) re-applies the deletion from the journal.
    env = dict(server["env"])
    code = ("import asyncio\n"
            "from app import db\n"
            "from app.services.journal import replay\n"
            "async def main():\n"
            "    await db.open_pool()\n"
            "    try:\n"
            "        print(await replay())\n"
            "    finally:\n"
            "        await db.close_pool()\n"
            "asyncio.run(main(), loop_factory=asyncio.SelectorEventLoop)\n")
    out = subprocess.run([server["python"], "-c", code], cwd=BACKEND, env=env, capture_output=True, text=True, timeout=60)
    assert out.returncode == 0, out.stderr[-800:]
    assert "'reapplied': 1" in out.stdout
    with psycopg.connect(url) as conn:
        status = conn.execute("SELECT status FROM accounts WHERE username = %s", (creds["username"],)).fetchone()
    assert status is None or status[0] != "active"
    fresh = Api()
    assert fresh.post("/api/v1/auth/login", {"username": creds["username"], "password": creds["password"]}).status_code == 401
