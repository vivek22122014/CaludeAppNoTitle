"""Phases 8–10: payments ledger, privacy rights, analytics and operations."""

import base64
import hashlib
import hmac
import json
import time
import uuid

import httpx
import psycopg

from tests.integration.conftest import PUBLIC, Api, Socket, Staff, register


def buy(api: Api, plan: str = "Short3", nonce: str | None = None) -> dict:
    plans = api.data(api.get("/api/v1/billing/plans"))
    p = [x for x in plans["plans"] if x["code"] == plan][0]
    return api.data(api.post("/api/v1/billing/purchases", {
        "plan_code": plan, "plan_version": p["version"], "policy_version": p["refund_policy_version"],
        "policy_accepted": True, "client_nonce": nonce or str(uuid.uuid4()), "payment_phone": "9876543210"}), 201)


def pay(api: Api, purchase: dict, outcome: str = "pay") -> httpx.Response:
    url = purchase["checkout"]["url"]
    page = api.get(url)
    assert page.status_code == 200 and "Simulated payment" in page.text
    return api.http.post(url, content=f"csrf={api.csrf}&outcome={outcome}",
                         headers={"Content-Type": "application/x-www-form-urlencoded", "Origin": PUBLIC})


def test_plans_catalog_annual_disabled(server):
    plans = httpx.get(f"{PUBLIC}/api/v1/billing/plans").json()["data"]
    by_code = {p["code"]: p for p in plans["plans"]}
    assert by_code["Short3"]["price_paise"] == 9900 and by_code["Short3"]["available"]
    assert by_code["Annual365"]["available"] is False
    assert plans["no_voluntary_refunds"] is True and plans["auto_renewal"] is False


def test_purchase_requires_account_policy_and_phone(server):
    from tests.integration.conftest import new_guest

    guest = new_guest()
    assert guest.post("/api/v1/billing/purchases", {"plan_code": "Short3", "plan_version": 1, "policy_version": "x",
                                                    "policy_accepted": True, "client_nonce": str(uuid.uuid4()),
                                                    "payment_phone": "9876543210"}).status_code == 403
    api, _ = register()
    base = {"plan_code": "Short3", "plan_version": 1, "client_nonce": str(uuid.uuid4()), "payment_phone": "9876543210"}
    assert api.post("/api/v1/billing/purchases", {**base, "policy_version": "stale", "policy_accepted": True}).status_code == 409
    version = httpx.get(f"{PUBLIC}/api/v1/policies").json()["data"]["refund"]["version"]
    assert api.post("/api/v1/billing/purchases", {**base, "policy_version": version, "policy_accepted": False}).status_code == 422
    assert api.post("/api/v1/billing/purchases", {**base, "policy_version": version, "policy_accepted": True,
                                                  "payment_phone": "123"}).status_code == 422
    assert api.post("/api/v1/billing/purchases", {**base, "plan_code": "Annual365", "policy_version": version,
                                                  "policy_accepted": True}).status_code == 422


def test_verified_capture_grants_once_and_receipt(server):
    api, _ = register()
    nonce = str(uuid.uuid4())
    purchase = buy(api, nonce=nonce)
    assert purchase["state"] == "pending" and purchase["checkout"]["provider"] == "simulator"
    again = buy(api, nonce=nonce)
    assert again["purchase_ref"] == purchase["purchase_ref"]  # stable intent, no second order
    ent = api.data(api.get("/api/v1/billing/entitlement"))
    assert ent["active"] is False
    r = pay(api, purchase)
    assert r.status_code == 303 and "/payment/status/" in r.headers["location"]
    status = api.data(api.get(f"/api/v1/billing/purchases/{purchase['purchase_ref']}"))
    assert status["state"] == "paid"
    ent = api.data(api.get("/api/v1/billing/entitlement"))
    assert ent["active"] and 259000 <= ent["available_seconds"] <= 259200
    receipts = api.data(api.get("/api/v1/billing/receipts"))["items"]
    assert receipts[0]["purchase_ref"] == purchase["purchase_ref"]
    assert receipts[0]["facts"]["amount_paise"] == 9900
    # Replayed signed webhooks never grant twice.
    with psycopg.connect(server["env"]["DATABASE_MIGRATOR_URL"]) as conn:
        lots = conn.execute("SELECT count(*) FROM entitlement_lots l JOIN purchases p ON p.id = l.purchase_id "
                            "WHERE p.public_ref = %s", (purchase["purchase_ref"],)).fetchone()[0]
    assert lots == 1
    # Premium makes a saved gender preference effective.
    me = api.data(api.get("/api/v1/me"))
    me = api.data(api.patch("/api/v1/me/preferences", {"expected_version": me["preferences"]["saved"]["version"],
                                                       "gender_preference": "female"}))
    assert me["preferences"]["effective"]["gender_preference"] == "female"


def test_failed_payment_grants_nothing(server):
    api, _ = register()
    purchase = buy(api)
    pay(api, purchase, outcome="fail")
    status = api.data(api.get(f"/api/v1/billing/purchases/{purchase['purchase_ref']}"))
    assert status["state"] == "failed"
    assert api.data(api.get("/api/v1/billing/entitlement"))["active"] is False


def test_fifo_lots_and_required_remedy_affects_origin_only(server):
    api, _ = register()
    first = buy(api, "Short3")
    pay(api, first)
    api.data(api.get(f"/api/v1/billing/purchases/{first['purchase_ref']}"))
    second = buy(api, "Week7")
    pay(api, second)
    api.data(api.get(f"/api/v1/billing/purchases/{second['purchase_ref']}"))
    ent = api.data(api.get("/api/v1/billing/entitlement"))
    assert [l["plan_code"] for l in ent["lots"]] == ["Short3", "Week7"]
    staff = Staff(server)
    # Voluntary refunds do not exist: the API only accepts required-remedy bases.
    bad = staff.post("/internal/v1/billing/refunds/preview", {
        "purchase_ref": second["purchase_ref"], "amount_paise": 19900, "revoke_seconds": 0,
        "remedy_basis": "change_of_mind", "evidence_ref": "n/a", "reason": "wants money back"})
    assert bad.status_code == 422
    too_much = staff.post("/internal/v1/billing/refunds/preview", {
        "purchase_ref": second["purchase_ref"], "amount_paise": 99999, "revoke_seconds": 0,
        "remedy_basis": "payment_error", "evidence_ref": "ticket-1", "reason": "duplicate"})
    assert too_much.status_code == 422
    preview = staff.data(staff.post("/internal/v1/billing/refunds/preview", {
        "purchase_ref": second["purchase_ref"], "amount_paise": 19900, "revoke_seconds": 604800,
        "remedy_basis": "payment_error", "evidence_ref": "provider-ticket-42", "reason": "verified duplicate charge"}))
    result = staff.data(staff.post("/internal/v1/billing/refunds/confirm", {"nonce": preview["nonce"], "totp": staff.totp()}))
    assert result["state"] == "succeeded"
    ent = api.data(api.get("/api/v1/billing/entitlement"))
    lots = {l["plan_code"]: l for l in ent["lots"]}
    assert lots["Week7"]["revoked_seconds"] == 604800 and lots["Week7"]["available_seconds"] == 0
    assert lots["Short3"]["revoked_seconds"] == 0 and lots["Short3"]["available_seconds"] > 0
    for lot in ent["lots"]:
        assert lot["granted_seconds"] == (lot["consumed_seconds"] + lot["available_seconds"]
                                          + lot["held_seconds"] + lot["revoked_seconds"])
    # A second remedy cannot exceed the captured amount.
    over = staff.post("/internal/v1/billing/refunds/preview", {
        "purchase_ref": second["purchase_ref"], "amount_paise": 1, "revoke_seconds": 0,
        "remedy_basis": "payment_error", "evidence_ref": "x", "reason": "again"})
    assert over.status_code == 422


def test_billing_complaint_creates_case_without_refund(server):
    api, _ = register()
    purchase = buy(api)
    pay(api, purchase)
    case = api.data(api.post("/api/v1/billing/refund-requests", {
        "purchase_ref": purchase["purchase_ref"], "reason": "duplicate_charge", "details": "charged twice?",
        "client_nonce": str(uuid.uuid4())}), 201)
    assert case["case_ref"].startswith("cs_")
    assert api.data(api.get("/api/v1/billing/entitlement"))["active"] is True


def test_webhook_signature_is_required(server):
    body = json.dumps({"type": "PAYMENT_SUCCESS_WEBHOOK", "data": {"order": {"order_id": "nt_fake"}}}).encode()
    r = httpx.post(f"{PUBLIC}/api/v1/webhooks/simulator", content=body,
                   headers={"x-webhook-signature": "bogus", "x-webhook-timestamp": str(int(time.time()))})
    assert r.status_code == 401
    secret = b"wrong-secret"
    ts = str(int(time.time()))
    sig = base64.b64encode(hmac.new(secret, ts.encode() + body, hashlib.sha256).digest()).decode()
    r = httpx.post(f"{PUBLIC}/api/v1/webhooks/simulator", content=body,
                   headers={"x-webhook-signature": sig, "x-webhook-timestamp": ts})
    assert r.status_code == 401
    assert httpx.post(f"{PUBLIC}/api/v1/webhooks/unknown", content=b"{}").status_code in (401, 404)


def test_export_and_deletion_with_receipt(server):
    api, creds = register()
    case = api.data(api.post("/api/v1/support/cases", {"category": "privacy", "subject": "export test",
                                                       "body": "please", "client_nonce": str(uuid.uuid4())}), 201)
    # Registration/login count as a fresh password confirmation for five minutes.
    api.data(api.post("/api/v1/auth/reauth", {"password": creds["password"]}))
    export = api.data(api.post("/api/v1/privacy/exports"), 202)
    for _ in range(30):
        status = api.data(api.get(f"/api/v1/privacy/exports/{export['export_ref']}"))
        if status["status"] == "ready":
            break
        time.sleep(0.5)
    assert status["status"] == "ready"
    package = api.get(f"/api/v1/privacy/exports/{export['export_ref']}/download")
    assert package.status_code == 200 and "attachment" in package.headers["content-disposition"]
    data = package.json()
    assert data["account"]["username"] == creds["username"]
    assert data["support_cases"][0]["case_ref"] == case["case_ref"]
    assert "password" not in json.dumps(data["account"])

    rights = api.data(api.post("/api/v1/privacy/requests", {"kind": "correction", "details": "fix my bio",
                                                            "client_nonce": str(uuid.uuid4())}), 201)
    assert rights["status"] == "received"

    prep = api.data(api.post("/api/v1/operations/prepare", {"kind": "deletion_receipt"}))
    r = api.post("/api/v1/privacy/delete", {"reservation_id": prep["reservation_id"], "receipt_secret": prep["secret"],
                                            "saved": True, "confirm": True})
    deletion = api.data(r, 202)
    assert deletion["state"] == "accepted" and deletion["deletion_ref"] == prep["reference"]
    assert api.get("/api/v1/me").status_code == 401
    fresh = Api()
    assert fresh.post("/api/v1/auth/login", {"username": creds["username"], "password": creds["password"]}).status_code == 401
    status = api.data(api.get("/api/v1/privacy/status"))
    assert status["deletion_ref"] == prep["reference"]
    other = Api()
    other.data(other.post("/api/v1/privacy/status/access", {"reference": prep["reference"], "secret": prep["secret"]}))
    for _ in range(30):
        status = other.data(other.get("/api/v1/privacy/status"))
        if status["state"] == "completed":
            break
        time.sleep(0.5)
    assert status["state"] == "completed"
    journal = (server["data_dir"] / "journal" / "privacy-journal.jsonl").read_text(encoding="utf-8")
    assert prep["reference"] in journal
    with psycopg.connect(server["env"]["DATABASE_MIGRATOR_URL"]) as conn:
        row = conn.execute("SELECT username, status, password_hash FROM accounts WHERE username = %s",
                           (creds["username"],)).fetchone()
    assert row is None  # username minimised


def test_analytics_audit_health_and_staff_admin(server):
    staff = Staff(server)
    summary = staff.data(staff.get("/internal/v1/analytics/summary"))
    assert "current" in summary and "active_now" in summary["current"]
    catalog = staff.data(staff.get("/internal/v1/analytics/catalog"))["metrics"]
    assert len(catalog) == 26 and catalog[0]["name"] == "registrations"
    now = time.time()
    from datetime import datetime, timedelta, timezone
    end = datetime.now(timezone.utc) + timedelta(minutes=1)
    series = staff.data(staff.get("/internal/v1/analytics/series", params={
        "metric_id": 1, "start": (end - timedelta(hours=2)).isoformat(), "end": end.isoformat(), "resolution": "hour"}))
    assert series["name"] == "registrations"
    assert all(p["value"] == "<10" or p["value"] >= 10 for p in series["points"])
    assert staff.get("/internal/v1/analytics/series", params={
        "metric_id": 1, "start": "2020-01-01T00:00:00Z", "end": "2026-01-01T00:00:00Z", "resolution": "minute"}).status_code == 422
    health = staff.data(staff.get("/internal/v1/health"))
    assert health["database"] == "ok" and health["gates"]["annual365"] is False
    assert all(m["applied"] for m in health["migrations"])
    staff_list = staff.data(staff.get("/internal/v1/staff"))
    assert {"teststaff", "secondmod"} <= {s["username"] for s in staff_list["items"]}
    assert now
