"""Integration fixtures: real PostgreSQL + the real runtime as a subprocess.

Requires the local database from scripts\\setup.ps1 (DATABASE_ADMIN_URL in .env).
A disposable database named ``notitle_test`` is dropped and recreated for each
session; the development database is never touched.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit

import httpx
import psycopg
import pyotp
import pytest
from psycopg import sql
from websockets.sync.client import connect as ws_connect

BACKEND = Path(__file__).resolve().parents[2]
PUBLIC_PORT = 18080
PRIVATE_PORT = 18081
PUBLIC = f"http://127.0.0.1:{PUBLIC_PORT}"
PRIVATE = f"http://127.0.0.1:{PRIVATE_PORT}"
TEST_DB = "notitle_test"
STAFF_USER = "teststaff"
STAFF_PASSWORD = "Test-Staff-Password-123"
STAFF2_USER = "secondmod"


def _dotenv() -> dict[str, str]:
    values: dict[str, str] = {}
    path = BACKEND.parent / ".env"
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            if "=" in line and not line.lstrip().startswith("#"):
                k, _, v = line.partition("=")
                values[k.strip()] = v.strip()
    return values


def _with_db(url: str, name: str) -> str:
    return urlunsplit(urlsplit(url)._replace(path="/" + name))


@pytest.fixture(scope="session")
def server():
    env_file = _dotenv()
    admin = os.environ.get("DATABASE_ADMIN_URL") or env_file.get("DATABASE_ADMIN_URL")
    app_url = env_file.get("DATABASE_URL")
    owner_url = env_file.get("DATABASE_MIGRATOR_URL")
    if not admin or not app_url or not owner_url:
        pytest.skip("Integration tests need .env from scripts\\setup.ps1 (DATABASE_ADMIN_URL etc.)")
    try:
        with psycopg.connect(admin, autocommit=True, connect_timeout=5) as conn:
            conn.execute(sql.SQL("DROP DATABASE IF EXISTS {} WITH (FORCE)").format(sql.Identifier(TEST_DB)))
            owner = urlsplit(owner_url).username
            conn.execute(sql.SQL("CREATE DATABASE {} OWNER {} TEMPLATE template0").format(
                sql.Identifier(TEST_DB), sql.Identifier(owner)))
            conn.execute(sql.SQL("GRANT CONNECT ON DATABASE {} TO {}").format(
                sql.Identifier(TEST_DB), sql.Identifier(urlsplit(app_url).username)))
        with psycopg.connect(_with_db(admin, TEST_DB), autocommit=True) as conn:
            conn.execute(sql.SQL("ALTER SCHEMA public OWNER TO {}").format(sql.Identifier(owner)))
    except psycopg.OperationalError as exc:
        pytest.skip(f"PostgreSQL not reachable: {exc}")

    data_dir = Path(tempfile.mkdtemp(prefix="notitle-it-"))
    env = {
        **os.environ,
        "APP_ENV": "test",
        "LOG_LEVEL": "WARNING",
        "DATABASE_URL": _with_db(app_url, TEST_DB),
        "DATABASE_MIGRATOR_URL": _with_db(owner_url, TEST_DB),
        "DATABASE_ADMIN_URL": admin,
        "PUBLIC_PORT": str(PUBLIC_PORT),
        "PRIVATE_PORT": str(PRIVATE_PORT),
        "PUBLIC_ORIGIN": PUBLIC,
        "PRIVATE_ORIGIN": PRIVATE,
        "EXTRA_PUBLIC_ORIGINS": "",
        "EXTRA_PRIVATE_ORIGINS": "",
        "DATA_DIR": str(data_dir),
        "PAYMENT_PROVIDER": "simulator",
        "PAYMENTS_ENABLED": "true",
        "AUDIO_ENABLED": "true",
        "AUDIO_REQUIRE_RELAY": "false",
        "PYTHONUNBUFFERED": "1",
    }
    python = sys.executable
    subprocess.run([python, "-m", "app.cli", "migrate"], cwd=BACKEND, env=env, check=True, capture_output=True)
    for user, roles in ((STAFF_USER, ["owner"]), (STAFF2_USER, ["moderator"])):
        subprocess.run([python, "-m", "app.cli", "create-staff", "--username", user, "--roles", *roles], cwd=BACKEND,
                       env={**env, "NOTITLE_STAFF_PASSWORD": STAFF_PASSWORD}, check=True, capture_output=True)
    log = open(data_dir / "runner.log", "wb")
    proc = subprocess.Popen([python, "-m", "app.runner"], cwd=BACKEND, env=env, stdout=log, stderr=subprocess.STDOUT)
    deadline = time.time() + 40
    while time.time() < deadline:
        try:
            if httpx.get(f"{PUBLIC}/health/ready", timeout=2).status_code == 200:
                break
        except httpx.HTTPError:
            pass
        if proc.poll() is not None:
            break
        time.sleep(0.3)
    else:
        proc.kill()
    if proc.poll() is not None:
        log.close()
        pytest.fail("runtime did not start:\n" + (data_dir / "runner.log").read_text(errors="replace")[-3000:])
    info = {"env": env, "data_dir": data_dir, "proc": proc, "python": python}
    yield info
    proc.terminate()
    try:
        proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        proc.kill()
    log.close()
    shutil.rmtree(data_dir, ignore_errors=True)


# ---------------------------------------------------------------------------
# Clients
# ---------------------------------------------------------------------------


class Api:
    """Browser-like client: cookie jar, exact Origin header and CSRF token."""

    def __init__(self, base: str = PUBLIC, bootstrap_path: str = "/api/v1/bootstrap") -> None:
        self.base = base
        self.http = httpx.Client(base_url=base, headers={"Origin": base}, timeout=15, follow_redirects=False)
        self.bootstrap_path = bootstrap_path
        self.csrf = ""
        self.bootstrap()

    def bootstrap(self) -> dict:
        r = self.http.get(self.bootstrap_path)
        assert r.status_code == 200, r.text
        data = r.json()["data"]
        self.csrf = data["csrf_token"]
        return data

    def _headers(self, extra: dict | None = None) -> dict:
        return {"X-CSRF-Token": self.csrf, **(extra or {})}

    def get(self, path: str, **kw) -> httpx.Response:
        return self.http.get(path, **kw)

    def post(self, path: str, json_body: dict | None = None, **kw) -> httpx.Response:
        return self.http.post(path, json=json_body if json_body is not None else {}, headers=self._headers(kw.pop("headers", None)), **kw)

    def patch(self, path: str, json_body: dict, **kw) -> httpx.Response:
        return self.http.patch(path, json=json_body, headers=self._headers(), **kw)

    def delete(self, path: str, **kw) -> httpx.Response:
        return self.http.delete(path, headers=self._headers(), **kw)

    def data(self, response: httpx.Response, status: int | tuple = (200, 201, 202)) -> dict:
        statuses = (status,) if isinstance(status, int) else status
        assert response.status_code in statuses, f"{response.status_code}: {response.text}"
        return response.json()["data"]


def versions() -> dict:
    data = httpx.get(f"{PUBLIC}/api/v1/policies").json()["data"]
    return {"terms": data["terms"]["version"], "privacy": data["privacy"]["version"]}


CONSENTS = {"adult": True, "terms": True, "core": True, "professional": False}


def new_guest(gender: str = "male", topic: str = "general", professional: bool = False) -> Api:
    api = Api()
    api.data(api.post("/api/v1/auth/guest", {
        "gender": gender, "topic_id": topic,
        "consents": {**CONSENTS, "professional": professional}, "policy_versions": versions()}), 201)
    return api


def register(api: Api | None = None, username: str | None = None, password: str = "correct horse battery",
             gender: str = "male", convert_guest: bool = False) -> tuple[Api, dict]:
    api = api or Api()
    username = username or ("u" + uuid.uuid4().hex[:12])
    prep = api.data(api.post("/api/v1/operations/prepare", {"kind": "registration"}))
    body = {"reservation_id": prep["reservation_id"], "recovery_code": prep["secret"], "saved": True,
            "username": username, "password": password, "display_name": "Tester " + username[-4:],
            "gender": gender, "topic_id": "general", "consents": CONSENTS, "policy_versions": versions(),
            "convert_guest": convert_guest}
    api.data(api.post("/api/v1/auth/register", body), 201)
    api.bootstrap()
    return api, {"username": username, "password": password, "recovery_code": prep["secret"]}


class Socket:
    def __init__(self, api: Api, takeover: bool = False) -> None:
        ticket = api.data(api.post("/api/v1/ws/ticket", {"takeover": takeover}))
        self.ws = ws_connect(f"ws://127.0.0.1:{PUBLIC_PORT}/api/v1/ws", origin=PUBLIC, open_timeout=5)
        self.events: list[dict] = []
        self.ready = self.command("session.hello", {"ticket": ticket["ticket"]}, expect="session.ready")

    def send(self, type_: str, payload: dict | None = None) -> str:
        cid = str(uuid.uuid4())
        self.ws.send(json.dumps({"v": 2, "id": cid, "type": type_, "payload": payload or {}}))
        return cid

    def wait(self, type_: str, timeout: float = 5.0, predicate=None) -> dict:
        for i, event in enumerate(self.events):
            if event["type"] == type_ and (predicate is None or predicate(event["payload"])):
                return self.events.pop(i)["payload"]
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                raw = self.ws.recv(timeout=max(0.05, deadline - time.time()))
            except TimeoutError:
                break
            event = json.loads(raw)
            if event["type"] == type_ and (predicate is None or predicate(event["payload"])):
                return event["payload"]
            self.events.append(event)
        raise AssertionError(f"timed out waiting for {type_}; saw {[e['type'] for e in self.events]}")

    def command(self, type_: str, payload: dict | None = None, expect: str = "command.result",
                timeout: float = 5.0) -> dict:
        cid = self.send(type_, payload)
        deadline = time.time() + timeout
        while time.time() < deadline:
            raw = self.ws.recv(timeout=max(0.05, deadline - time.time()))
            event = json.loads(raw)
            if event.get("reply_to") == cid and event["type"] in (expect, "error"):
                if event["type"] == "error" and expect != "error":
                    raise CommandError(event["payload"])
                return event["payload"]
            self.events.append(event)
        raise AssertionError(f"no reply to {type_}")

    def close(self) -> None:
        try:
            self.ws.close()
        except Exception:  # noqa: BLE001
            pass


class CommandError(Exception):
    def __init__(self, payload: dict) -> None:
        super().__init__(payload.get("code"))
        self.code = payload.get("code")
        self.payload = payload


def matched_pair(a: Api, b: Api) -> tuple[Socket, Socket, str]:
    sa, sb = Socket(a), Socket(b)
    sa.command("queue.join")
    sb.command("queue.join")
    started_a = sa.wait("interaction.started")
    started_b = sb.wait("interaction.started")
    assert started_a["interaction_id"] == started_b["interaction_id"]
    return sa, sb, started_a["interaction_id"]


# ---------------------------------------------------------------------------
# Staff client
# ---------------------------------------------------------------------------

_last_counter: dict[str, int] = {}


def totp_code(server, username: str) -> str:
    enrol = (server["data_dir"] / "staff" / f"{username}-enrollment.txt").read_text(encoding="utf-8")
    secret = next(line.split(": ", 1)[1] for line in enrol.splitlines() if line.startswith("TOTP secret"))
    totp = pyotp.TOTP(secret)
    while True:
        counter = int(time.time() // 30)
        for candidate in (counter, counter + 1):
            if candidate > _last_counter.get(username, -1):
                _last_counter[username] = candidate
                return totp.generate_otp(candidate)
        time.sleep(1)


class Staff(Api):
    def __init__(self, server, username: str = STAFF_USER) -> None:
        super().__init__(PRIVATE, "/internal/v1/bootstrap")
        self.server = server
        self.username = username
        r = self.post("/internal/v1/auth/login", {"username": username, "password": STAFF_PASSWORD,
                                                  "totp": totp_code(server, username)})
        assert r.status_code == 200, r.text

    def totp(self) -> str:
        return totp_code(self.server, self.username)
