"""Phases 1–3: foundation, HTTP boundary and identity/consent primitives."""

import subprocess

import httpx

from tests.integration.conftest import (
    CONSENTS, PUBLIC, Api, Socket, new_guest, register, versions,
)


def test_health_headers_and_static_fallback(server):
    r = httpx.get(f"{PUBLIC}/health/ready")
    assert r.status_code == 200 and r.json()["data"]["owner_epoch"] >= 1
    assert r.headers["x-content-type-options"] == "nosniff"
    assert r.headers["x-frame-options"] == "DENY"
    assert r.headers["cache-control"] == "no-store"
    assert r.json()["request_id"].startswith("req_")
    # Unknown API routes use the error envelope.
    r = httpx.get(f"{PUBLIC}/api/v1/does-not-exist")
    assert r.status_code == 404 and r.json()["error"]["code"] == "not_found"
    # Private API is not reachable on the public listener.
    assert httpx.get(f"{PUBLIC}/internal/v1/cases").status_code in (404, 503)


def test_origin_and_csrf_are_enforced(server):
    api = Api()
    body = {"gender": "male", "topic_id": "general", "consents": CONSENTS, "policy_versions": versions()}
    r = api.http.post("/api/v1/auth/guest", json=body, headers={"Origin": "https://evil.example", "X-CSRF-Token": api.csrf})
    assert r.status_code == 403 and r.json()["error"]["code"] == "origin_rejected"
    r = api.http.post("/api/v1/auth/guest", json=body)
    assert r.status_code == 403 and r.json()["error"]["code"] == "csrf_failed"
    r = api.http.post("/api/v1/auth/guest", json=body, headers={"X-CSRF-Token": "forged"})
    assert r.status_code == 403
    r = api.post("/api/v1/auth/guest", {**body, "unexpected": 1})
    assert r.status_code == 422


def test_body_limit_and_credentials_in_url(server):
    api = Api()
    r = api.post("/api/v1/auth/login", {"username": "x" * 20, "password": "y" * 9000})
    assert r.status_code in (413, 422)
    assert httpx.get(f"{PUBLIC}/api/v1/me?token=abc").status_code == 400


def test_guest_requires_explicit_consent_and_gets_pseudonym(server):
    api = Api()
    r = api.post("/api/v1/auth/guest", {"gender": "female", "topic_id": "general",
                                        "consents": {**CONSENTS, "terms": False}, "policy_versions": versions()})
    assert r.status_code == 422 and "consents.terms" in r.json()["error"]["fields"]
    r = api.post("/api/v1/auth/guest", {"gender": "female", "topic_id": "general", "consents": CONSENTS,
                                        "policy_versions": {"terms": "old", "privacy": "old"}})
    assert r.status_code == 409 and r.json()["error"]["code"] == "policy_changed"
    guest = new_guest("female")
    me = guest.data(guest.get("/api/v1/me"))
    assert me["kind"] == "guest" and me["display_name_editable"] is False and len(me["display_name"]) >= 6


def test_registration_requires_saved_matching_code(server):
    api = Api()
    prep = api.data(api.post("/api/v1/operations/prepare", {"kind": "registration"}))
    body = {"reservation_id": prep["reservation_id"], "recovery_code": "WRONG-CODE", "saved": True,
            "username": "codecheck1", "password": "correct horse battery", "display_name": "Coder",
            "gender": "male", "topic_id": "general", "consents": CONSENTS, "policy_versions": versions()}
    assert api.post("/api/v1/auth/register", body).status_code == 422
    assert api.post("/api/v1/auth/register", {**body, "recovery_code": prep["secret"], "saved": False}).status_code == 422
    assert api.post("/api/v1/auth/register", {**body, "recovery_code": prep["secret"]}).status_code == 201
    # The preparation is single use.
    again = api.post("/api/v1/auth/register", {**body, "recovery_code": prep["secret"], "username": "codecheck2"})
    assert again.status_code in (409, 410)


def test_login_logout_generic_errors_and_reserved_names(server):
    api, creds = register()
    api.data(api.post("/api/v1/auth/logout"))
    assert api.get("/api/v1/me").status_code == 401
    bad = api.post("/api/v1/auth/login", {"username": creds["username"], "password": "wrong password!!"})
    unknown = api.post("/api/v1/auth/login", {"username": "nobody_here", "password": "wrong password!!"})
    assert bad.status_code == unknown.status_code == 401
    assert bad.json()["error"]["message"] == unknown.json()["error"]["message"]
    api.data(api.post("/api/v1/auth/login", {"username": creds["username"], "password": creds["password"]}))
    assert api.data(api.get("/api/v1/me"))["username"] == creds["username"]
    prep = api.data(Api().post("/api/v1/operations/prepare", {"kind": "registration"}))
    assert prep["secret"]


def test_five_session_cap_with_challenge(server):
    first, creds = register()  # registration itself opens session 1 of 5
    clients = [Api() for _ in range(4)]
    for c in clients:
        c.data(c.post("/api/v1/auth/login", {"username": creds["username"], "password": creds["password"]}))
    sixth = Api()
    r = sixth.post("/api/v1/auth/login", {"username": creds["username"], "password": creds["password"]})
    assert r.status_code == 409 and r.json()["error"]["code"] == "session_limit"
    details = r.json()["error"]["details"]
    assert len(details["sessions"]) >= 5
    victim = details["sessions"][0]["session_id"]
    sixth.data(sixth.post("/api/v1/auth/session-limit/resolve",
                          {"challenge_id": details["challenge_id"], "session_id": victim}))
    assert sixth.data(sixth.get("/api/v1/me"))["username"] == creds["username"]
    # Exactly the chosen (oldest) session was revoked; the cap still holds at five.
    statuses = [c.get("/api/v1/me").status_code for c in [first, *clients]]
    assert statuses.count(401) == 1 and statuses[0] == 401


def test_recovery_rotates_code_and_revokes_sessions(server):
    api, creds = register()
    other = Api()
    rec = other.data(other.post("/api/v1/operations/prepare", {"kind": "recovery"}))
    body = {"username": creds["username"], "recovery_code": creds["recovery_code"], "new_password": "brand new password 1",
            "reservation_id": rec["reservation_id"], "new_recovery_code": rec["secret"], "saved": True}
    other.data(other.post("/api/v1/auth/recover", body))
    assert api.get("/api/v1/me").status_code == 401  # old session revoked
    # The old code no longer works.
    rec2 = other.data(other.post("/api/v1/operations/prepare", {"kind": "recovery"}))
    r = other.post("/api/v1/auth/recover", {**body, "reservation_id": rec2["reservation_id"],
                                            "new_recovery_code": rec2["secret"]})
    assert r.status_code == 401
    fresh = Api()
    fresh.data(fresh.post("/api/v1/auth/login", {"username": creds["username"], "password": "brand new password 1"}))


def test_profile_versioning_preferences_and_consent_withdrawal(server):
    api, _ = register()
    me = api.data(api.get("/api/v1/me"))
    updated = api.data(api.patch("/api/v1/me/profile", {"expected_version": me["profile_version"],
                                                        "display_name": "New Name", "bio": "I work in tech"}))
    assert updated["display_name"] == "New Name"
    stale = api.patch("/api/v1/me/profile", {"expected_version": me["profile_version"], "bio": "x"})
    assert stale.status_code == 409
    assert api.patch("/api/v1/me/profile", {"expected_version": updated["profile_version"],
                                            "display_name": "Official Moderator"}).status_code == 422
    prefs = updated["preferences"]["saved"]
    result = api.data(api.patch("/api/v1/me/preferences", {"expected_version": prefs["version"],
                                                           "gender_preference": "female"}))
    assert result["preferences"]["saved"]["gender_preference"] == "female"
    assert result["preferences"]["effective"]["gender_preference"] == "everyone"  # no Premium
    # Professional data requires optional consent.
    r = api.patch("/api/v1/me/profile", {"expected_version": result["profile_version"],
                                         "professional": {"industry_id": "technology"}})
    assert r.status_code == 422
    privacy = versions()["privacy"]
    api.data(api.post("/api/v1/me/consents", {"purpose": "professional", "choice": True, "policy_version": privacy}))
    me = api.data(api.get("/api/v1/me"))
    me = api.data(api.patch("/api/v1/me/profile", {"expected_version": me["profile_version"],
                                                   "professional": {"industry_id": "technology", "interest_ids": ["growth"]}}))
    assert me["professional"]["industry_id"] == "technology"
    me = api.data(api.post("/api/v1/me/consents", {"purpose": "professional", "choice": False, "policy_version": privacy}))
    assert me["professional"] is None


def test_sessions_list_and_reauth(server):
    api, creds = register()
    sessions = api.data(api.get("/api/v1/me/sessions"))
    assert sessions["items"][0]["is_current"] is True
    assert api.post("/api/v1/auth/reauth", {"password": "wrong wrong wrong"}).status_code == 401
    api.data(api.post("/api/v1/auth/reauth", {"password": creds["password"]}))
    rot = api.data(api.post("/api/v1/operations/prepare", {"kind": "recovery_rotation"}))
    api.data(api.post("/api/v1/me/recovery/rotate", {"reservation_id": rot["reservation_id"],
                                                     "recovery_code": rot["secret"], "saved": True}))


def test_password_change_ends_other_sessions(server):
    api, creds = register()
    other = Api()
    other.data(other.post("/api/v1/auth/login", {"username": creds["username"], "password": creds["password"]}))
    api.data(api.post("/api/v1/me/password", {"current_password": creds["password"], "new_password": "another long password"}))
    assert other.get("/api/v1/me").status_code == 401
    assert api.get("/api/v1/me").status_code == 200


def test_guest_login_requires_confirmation(server):
    _, creds = register()
    guest = new_guest()
    r = guest.post("/api/v1/auth/login", {"username": creds["username"], "password": creds["password"]})
    assert r.status_code == 409 and r.json()["error"]["code"] == "guest_active"
    guest.data(guest.post("/api/v1/auth/login", {"username": creds["username"], "password": creds["password"],
                                                 "confirm_end_guest": True}))
    assert guest.data(guest.get("/api/v1/me"))["kind"] == "account"


def test_second_runtime_cannot_take_ownership(server):
    from tests.integration.conftest import BACKEND

    result = subprocess.run([server["python"], "-m", "app.runner"], cwd=str(BACKEND),
                            env={**server["env"], "PUBLIC_PORT": "18090", "PRIVATE_PORT": "18091"},
                            capture_output=True, timeout=60)
    # Exit code 3 = owner lock held by the running instance.
    assert result.returncode in (2, 3), result.stderr.decode(errors="replace")[-500:]


def test_websocket_ticket_is_single_use_and_takeover(server):
    api = new_guest()
    first = Socket(api)
    ticket = api.data(api.post("/api/v1/ws/ticket", {"takeover": False}))
    from websockets.sync.client import connect
    import json, uuid
    ws = connect("ws://127.0.0.1:18080/api/v1/ws", origin=PUBLIC)
    ws.send(json.dumps({"v": 2, "id": str(uuid.uuid4()), "type": "session.hello", "payload": {"ticket": ticket["ticket"]}}))
    reply = json.loads(ws.recv(timeout=5))
    assert reply["type"] == "error" and reply["payload"]["code"] == "session_active"
    ws.close()
    second = Socket(api, takeover=True)
    assert second.ready["state"] == "idle"
    assert first.wait("session.replaced")
    second.close()


def test_websocket_rejects_foreign_origin(server):
    from websockets.sync.client import connect
    from websockets.exceptions import InvalidStatus, ConnectionClosed

    try:
        ws = connect("ws://127.0.0.1:18080/api/v1/ws", origin="https://evil.example")
        try:
            ws.recv(timeout=3)
        except ConnectionClosed:
            pass
    except InvalidStatus:
        pass
