"""Shared test configuration.

Unit tests need no database.  Integration tests (tests/integration) start the
real runtime as a subprocess against a disposable ``notitle_test`` database.
"""

from __future__ import annotations

import asyncio
import os
import sys
import tempfile

# Must be set before app modules read settings.
os.environ.setdefault("APP_ENV", "test")
os.environ.setdefault("DATA_DIR", tempfile.mkdtemp(prefix="notitle-unit-"))

if sys.platform == "win32":
    # psycopg's async driver needs a selector loop on Windows.
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())  # type: ignore[attr-defined]
