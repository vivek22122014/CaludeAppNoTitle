import json
import time
import uuid

import pyotp
import pytest

from app.http.ratelimit import RateLimiter
from app.realtime import protocol
from app.security import crypto, totp


def frame(type_, payload, v=2):
    return json.dumps({"v": v, "id": str(uuid.uuid4()), "type": type_, "payload": payload})


def test_parse_valid_text():
    cmd = protocol.parse(frame("text.send", {"interaction_id": "i_abc", "client_id": "c1", "body": "hello"}))
    assert cmd.type == "text.send" and cmd.payload.body == "hello"


@pytest.mark.parametrize("raw,code", [
    ("not json", "malformed"),
    (frame("text.send", {}, v=1), "unsupported_protocol"),
    (frame("nope", {}), "unknown_command"),
    (frame("text.send", {"interaction_id": "i_1", "client_id": "c", "body": "x", "extra": 1}), "invalid_payload"),
    (json.dumps({"v": 2, "id": "not-a-uuid", "type": "heartbeat", "payload": {}}), "malformed"),
])
def test_parse_rejects(raw, code):
    with pytest.raises(protocol.ProtocolError) as err:
        protocol.parse(raw)
    assert err.value.code == code


def test_text_limits_chars_and_bytes():
    ok = "a" * 2000
    protocol.parse(frame("text.send", {"interaction_id": "i_1", "client_id": "c", "body": ok}))
    with pytest.raises(protocol.ProtocolError):
        protocol.parse(frame("text.send", {"interaction_id": "i_1", "client_id": "c", "body": "a" * 2001}))
    # 2000 code points of a 4-byte emoji exceed 6 KiB first.
    with pytest.raises(protocol.ProtocolError):
        protocol.parse(frame("text.send", {"interaction_id": "i_1", "client_id": "c", "body": "😀" * 1600}))


def test_frame_size_limit():
    with pytest.raises(protocol.ProtocolError) as err:
        protocol.parse(frame("heartbeat", {"echo": 1}) + " " * 9000)
    assert err.value.code == "frame_too_large"


SDP = "v=0\r\no=- 1 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\nm=audio 9 UDP/TLS/RTP/SAVPF 111\r\na=fingerprint:sha-256 AB:CD\r\n"


def test_sdp_audio_only():
    protocol.validate_sdp(SDP, require_relay=False)
    with pytest.raises(protocol.ProtocolError):
        protocol.validate_sdp(SDP + "m=video 9 UDP/TLS/RTP/SAVPF 96\r\n", require_relay=False)
    with pytest.raises(protocol.ProtocolError):
        protocol.validate_sdp(SDP.replace("a=fingerprint:sha-256 AB:CD\r\n", ""), require_relay=False)


def test_candidates_relay_policy():
    host = "candidate:1 1 udp 2122260223 192.168.1.5 54400 typ host generation 0"
    relay = "candidate:2 1 udp 41885439 203.0.113.9 50000 typ relay raddr 0.0.0.0 rport 0"
    assert protocol.validate_candidate(host, require_relay=False)
    assert protocol.validate_candidate(relay, require_relay=True)
    with pytest.raises(protocol.ProtocolError):
        protocol.validate_candidate(host, require_relay=True)
    with pytest.raises(protocol.ProtocolError):
        protocol.validate_candidate("garbage", require_relay=False)


def test_envelope_round_trip_and_aad_binding():
    key = crypto.DataKey(id="k1", purpose="support", key=crypto.generate_data_key())
    blob = key.encrypt("secret text", "support_cases|1|subject")
    assert key.decrypt(blob, "support_cases|1|subject") == "secret text"
    with pytest.raises(Exception):
        key.decrypt(blob, "support_cases|2|subject")  # swapped row is rejected


def test_wrap_unwrap():
    raw = crypto.generate_data_key()
    assert crypto.unwrap_key(crypto.wrap_key(raw, "support"), "support") == raw
    with pytest.raises(Exception):
        crypto.unwrap_key(crypto.wrap_key(raw, "support"), "export")


def test_verifiers_are_keyed_and_normalised():
    code = crypto.new_secret_code()
    assert len(crypto.normalize_code(code)) == 52
    assert crypto.code_verifier(code, "p") == crypto.code_verifier(code.lower().replace("-", " "), "p")
    assert crypto.code_verifier(code, "p") != crypto.code_verifier(code, "q")


def test_rate_limiter_token_bucket():
    limiter = RateLimiter(max_keys=10)
    assert all(limiter.allow("k", rate=1, burst=3, now=0) for _ in range(3))
    assert not limiter.allow("k", rate=1, burst=3, now=0)
    assert limiter.allow("k", rate=1, burst=3, now=1.01)


def test_rate_limiter_is_bounded():
    limiter = RateLimiter(max_keys=5)
    for i in range(50):
        limiter.allow(f"k{i}", 1, 1)
    assert len(limiter._buckets) == 5


def test_totp_replay_protection():
    secret = totp.new_totp_secret()
    now = time.time()
    code = pyotp.TOTP(secret).at(now)
    counter = totp.verify_totp(secret, code, None, now=now)
    assert counter is not None
    assert totp.verify_totp(secret, code, counter, now=now) is None  # reuse rejected
    assert totp.verify_totp(secret, "000000" if code != "000000" else "111111", None, now=now) is None
