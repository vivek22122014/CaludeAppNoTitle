import json

import pytest

from app import migrations, policies
from app.services.journal import Journal, JournalError


def test_required_policies_and_lint_clean():
    assert policies.lint() == []
    for kind in ("privacy", "terms", "community", "cookies", "retention", "refund"):
        p = policies.get(kind)
        assert len(p.digest) == 64 and p.version


def test_lint_catches_email_and_refund_offer(monkeypatch):
    original = dict(policies.all_policies())
    bad = policies.Policy("privacy", "Privacy", "x", "/privacy", "write to help@example.com 24-hour refund", "d" * 64, "draft")
    monkeypatch.setattr(policies, "all_policies", lambda: {**original, "privacy": bad})
    problems = policies.lint()
    assert any("email" in p for p in problems)
    assert any("24-hour" in p for p in problems)


def test_migrations_are_ordered_and_checksummed():
    items = migrations.packaged()
    assert [m.id for m in items] == sorted(m.id for m in items)
    assert all(len(m.checksum) == 64 for m in items)
    assert items[0].id.startswith("0001_")


def test_journal_chain_and_tamper_detection(tmp_path):
    path = tmp_path / "j.jsonl"
    j = Journal(path)
    j.load()
    j.append("deletion", account_id="a1", subject_ref="s1", reference="dl_1")
    j.append("hold", subject_ref="s2", scope="all")
    fresh = Journal(path)
    assert len(fresh.load()) == 2 and fresh.seq == 2

    lines = path.read_text(encoding="utf-8").splitlines()
    entry = json.loads(lines[0])
    entry["account_id"] = "someone-else"
    lines[0] = json.dumps(entry, sort_keys=True, separators=(",", ":"))
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    with pytest.raises(JournalError):
        Journal(path).load()


def test_journal_detects_removed_entry(tmp_path):
    path = tmp_path / "j.jsonl"
    j = Journal(path)
    for i in range(3):
        j.append("deletion", account_id=f"a{i}", subject_ref="s", reference=f"dl_{i}")
    lines = path.read_text(encoding="utf-8").splitlines()
    path.write_text("\n".join([lines[0], lines[2]]) + "\n", encoding="utf-8")
    with pytest.raises(JournalError):
        Journal(path).load()
