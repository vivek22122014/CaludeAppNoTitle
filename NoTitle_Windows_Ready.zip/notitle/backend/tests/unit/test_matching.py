import random

from app.realtime import matching
from app.realtime.matching import Seeker


def seeker(key, gender="male", topic="general", joined=0.0, **kw):
    return Seeker(key=key, gender=gender, topic_id=topic, joined_at=joined, **kw)


def never(_a, _b):
    return None


def test_everyone_matches_all_genders():
    a, b = seeker("a", "male"), seeker("b", "other")
    assert matching.compatible(a, b, None)


def test_specific_gender_requires_premium():
    a = seeker("a", "male", gender_preference="female", premium=False)
    b = seeker("b", "male")
    # Without Premium the saved preference is not effective: Everyone applies.
    assert matching.compatible(a, b, None)
    a.premium = True
    assert not matching.compatible(a, b, None)
    assert matching.compatible(a, seeker("c", "female"), None)


def test_gender_acceptance_is_mutual():
    a = seeker("a", "female", gender_preference="female", premium=True)
    b = seeker("b", "female", gender_preference="male", premium=True)
    assert not matching.compatible(a, b, None)


def test_blocks_exclude_both_directions():
    a = seeker("a", blocked=frozenset({"b"}))
    b = seeker("b")
    assert not matching.compatible(a, b, None)
    assert not matching.compatible(b, a, None)


def test_repeat_exclusion_window():
    a, b = seeker("a"), seeker("b")
    assert not matching.compatible(a, b, 3.9)
    assert matching.compatible(a, b, 4.1)
    assert matching.repeat_penalty(4.0) == 60.0
    assert matching.repeat_penalty(300.0) == 0.0


def test_topic_bonus_ignores_general_talk():
    assert matching.topic_bonus(seeker("a", topic="salaries"), seeker("b", topic="salaries")) == 0.5
    assert matching.topic_bonus(seeker("a"), seeker("b")) == 0.0


def test_professional_relevance_needs_entitlement_and_caps():
    prof = {"industry_id": "technology", "role_id": "engineering", "experience_id": "3_5",
            "interest_ids": ["growth", "compensation"], "topic_ids": ["salaries"]}
    wanted = {"industry_ids": ["technology"], "role_ids": ["engineering"], "experience_ids": ["3_5"],
              "topic_ids": ["salaries"], "interest_ids": ["growth", "compensation"]}
    a = seeker("a", topic="salaries", premium=True, professional_enabled=True, wanted=wanted)
    b = seeker("b", topic="salaries", professional=prof)
    # One entitled direction contributes 0.5 (capped); the free direction contributes 0.
    assert matching.professional_bonus(a, b) == 0.25
    a.premium = False
    assert matching.professional_bonus(a, b) == 0.0
    a.premium = True
    a.topic_id = "general"
    assert matching.professional_bonus(a, b) == 0.0


def test_relevance_fades_after_five_seconds():
    a, b = seeker("a", topic="hiring", joined=0.0), seeker("b", topic="hiring", joined=0.0)
    early = matching.score(a, b, now=1.0, seconds_since_pair=None)
    late = matching.score(a, b, now=6.0, seconds_since_pair=None)
    assert early == 1.0 + 0.8 * 0.5
    assert late == 6.0


def test_incompatible_oldest_waiter_does_not_block_others():
    picky = seeker("picky", "male", gender_preference="other", premium=True, joined=0.0)
    w1, w2 = seeker("w1", "male", joined=1.0), seeker("w2", "female", joined=2.0)
    result = matching.find_matches([picky, w1, w2], now=10.0, since_pair=never, rng=random.Random(1))
    assert result.pairs == [("w1", "w2")]


def test_oldest_anchor_prefers_longest_waiting_candidate():
    a, b, c = seeker("a", joined=0.0), seeker("b", joined=1.0), seeker("c", joined=5.0)
    result = matching.find_matches([c, b, a], now=10.0, since_pair=never, rng=random.Random(1))
    assert result.pairs[0] == ("a", "b")


def test_ties_use_injected_random():
    a, b, c = seeker("a", joined=0.0), seeker("b", joined=3.0), seeker("c", joined=3.0)
    seen = {matching.find_matches([a, b, c], now=10.0, since_pair=never, rng=random.Random(s)).pairs[0][1]
            for s in range(20)}
    assert seen == {"b", "c"}


def test_pair_check_budget_is_bounded():
    waiters = [seeker(f"s{i}", "male", gender_preference="female", premium=True, joined=i) for i in range(100)]
    result = matching.find_matches(waiters, now=200.0, since_pair=never, max_checks=500)
    assert result.checks <= 500
    assert result.pairs == []
