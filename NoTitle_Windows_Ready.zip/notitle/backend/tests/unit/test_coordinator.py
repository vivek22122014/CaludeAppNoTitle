"""Coordinator state machine with fake sockets (no database, no network)."""

import asyncio
import random

import pytest

from app.realtime.coordinator import Coordinator, CoordinatorError, Participant


class FakeConn:
    def __init__(self):
        self.events = []
        self.detached = False
        self.closed = False
        self.participant_key = None
        self.session_id = None
        self.socket_generation = 0

    def send_event(self, type, payload, reply_to=None):
        self.events.append((type, payload))

    def of(self, type):
        return [p for t, p in self.events if t == type]

    async def close(self, code=1000, reason=""):
        self.closed = True


def make(c: Coordinator, key, gender="male", kind="guest", **kw):
    p = Participant(key=key, kind=kind, account_id=key[2:] if kind == "account" else None,
                    display_name=key.upper(), gender=gender, topic_id="general", bio="", **kw)
    c.admit(p)
    conn = FakeConn()
    conn.participant_key = key
    c.attach(key, conn, takeover=False)
    return conn


@pytest.fixture
def c():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    coordinator = Coordinator()
    coordinator._loop = loop
    yield coordinator
    loop.close()


def pair(c):
    a, b = make(c, "g:a"), make(c, "g:b", gender="female")
    c.join_queue("g:a")
    c.join_queue("g:b")
    assert c.match_tick(rng=random.Random(0)) == 1
    started = a.of("interaction.started")[0]
    return a, b, started["interaction_id"]


def test_match_publishes_exact_peer_dto(c):
    a, b, iid = pair(c)
    peer = a.of("interaction.started")[0]["peer"]
    assert set(peer) == {"peer_handle", "display_name", "gender", "topic_id", "bio"}
    assert peer["display_name"] == "G:B"
    assert b.of("interaction.started")[0]["interaction_id"] == iid


def test_text_ring_is_bounded_and_cleared(c):
    a, b, iid = pair(c)
    for i in range(40):
        c.send_text("g:a", iid, f"c{i}", f"message {i}")
    interaction = c.interactions[iid]
    assert len(interaction.ring) == 30
    assert len(b.of("text.received")) == 40
    c.end_interaction("g:a", iid)
    assert iid not in c.interactions
    assert interaction.ring_bytes == 0 and len(interaction.ring) == 0
    assert a.of("interaction.ended")[0]["by_self"] is True
    assert b.of("interaction.ended")[0]["reason"] == "peer_ended"


def test_end_is_idempotent_and_stale_ids_rejected(c):
    a, b, iid = pair(c)
    assert c.end_interaction("g:a", iid)
    assert not c.end_interaction("g:a", iid)
    with pytest.raises(CoordinatorError):
        c.send_text("g:a", iid, "x", "late")


def test_next_requeues_only_initiator_and_repeat_is_excluded(c):
    a, b, iid = pair(c)
    c.next_interaction("g:a", iid)
    assert c.participants["g:a"].queue_joined is not None
    assert c.participants["g:b"].queue_joined is None
    c.join_queue("g:b")
    # Within four seconds the same pair cannot match again.
    assert c.match_tick() == 0


def test_cannot_hold_two_interactions(c):
    a, b, iid = pair(c)
    with pytest.raises(CoordinatorError):
        c.join_queue("g:a")


def test_delivery_ack_only_for_recipient(c):
    a, b, iid = pair(c)
    ack = c.send_text("g:a", iid, "c1", "hi")
    c.mark_delivered("g:a", iid, ack["message_id"])  # sender cannot mark own message
    assert a.of("text.delivery") == []
    c.mark_delivered("g:b", iid, ack["message_id"])
    assert a.of("text.delivery")[0]["state"] == "delivered"


def test_disconnect_interrupts_and_resume(c):
    a, b, iid = pair(c)
    c.detach(a)
    assert b.of("interaction.interrupted")
    with pytest.raises(CoordinatorError):
        c.send_text("g:b", iid, "x", "while interrupted")
    new = FakeConn()
    new.participant_key = "g:a"
    c.attach("g:a", new, takeover=False)
    assert b.of("interaction.resumed")
    snap = c.state_snapshot("g:a")
    assert snap["state"] == "in_interaction"


def test_second_socket_needs_takeover(c):
    make(c, "g:a")
    other = FakeConn()
    with pytest.raises(CoordinatorError):
        c.attach("g:a", other, takeover=False)


def test_temporary_friendship_and_invite(c):
    a, b, iid = pair(c)
    pending = c.friend_request("g:a", iid)
    assert pending["state"] == "pending"
    request_id = b.of("friend.requested")[0]["request_id"]
    result = c.friend_respond("g:b", request_id, True)
    assert result["state"] == "temporary"
    rel = result["relationship_id"]
    c.end_interaction("g:a", iid)
    sent = c.invite("g:a", rel)
    invite_id = b.of("invite.received")[0]["invite_id"]
    assert sent["invite_id"] == invite_id
    out = c.respond_invite("g:b", invite_id, True)
    assert out["state"] == "accepted"
    assert a.of("interaction.started")[-1]["source"] == "invite"


def test_crossed_invites_converge(c):
    a, b, iid = pair(c)
    c.friend_request("g:a", iid)
    rel = c.friend_request("g:b", iid)["relationship_id"]  # reciprocal request = acceptance
    c.end_interaction("g:a", iid)
    c.invite("g:a", rel)
    result = c.invite("g:b", rel)
    assert result["state"] == "accepted"
    assert len(c.interactions) == 1


def test_block_ends_and_excludes(c):
    a, b, iid = pair(c)
    c.apply_block("g:a", "g:b", durable=False)
    assert iid not in c.interactions
    import time as _t
    c.pair_history.clear()
    c.join_queue("g:a")
    c.join_queue("g:b")
    assert c.match_tick(now=_t.monotonic() + 10) == 0


def test_report_snapshot_and_attribution(c):
    a, b, iid = pair(c)
    c.send_text("g:b", iid, "c1", "abusive text")
    snap = c.prepare_snapshot("g:a", iid)
    assert snap.subject == "g:b" and snap.messages[0]["sender_role"] == "reported"
    c.end_interaction("g:a", iid)
    # After End only attribution remains (no transcript).
    assert c.peer_key_for("g:a", iid) == "g:b"
    assert c.prepare_snapshot("g:a", iid).messages == []


def test_call_flow_and_teardown(c):
    a, b, iid = pair(c)
    req = c.call_request("g:a", iid)
    assert b.of("call.incoming")[0]["call_id"] == req["call_id"]
    c.call_respond("g:b", req["call_id"], True)
    assert {e["role"] for e in a.of("call.authorized") + b.of("call.authorized")} == {"offerer", "answerer"}
    with pytest.raises(CoordinatorError):
        c.call_signal("g:b", req["call_id"], "sdp", {"revision": 1, "sdp_type": "offer", "sdp": "x"})
    c.call_state("g:a", req["call_id"], "connected")
    c.call_state("g:b", req["call_id"], "connected")
    assert a.of("call.connected")
    c.end_interaction("g:b", iid)  # End always tears audio down
    assert a.of("call.ended")[0]["reason"] == "conversation_ended"
    assert not c.calls


def test_declined_call_sets_cooldown(c):
    a, b, iid = pair(c)
    req = c.call_request("g:a", iid)
    c.call_respond("g:b", req["call_id"], False)
    with pytest.raises(CoordinatorError) as err:
        c.call_request("g:a", iid)
    assert err.value.code == "cooldown"


def test_restriction_blocks_search(c):
    make(c, "g:a")
    c.set_restriction("g:a", float("inf"))
    with pytest.raises(CoordinatorError) as err:
        c.join_queue("g:a")
    assert err.value.code == "restricted"


def test_strict_preference_without_premium_asks_for_everyone(c):
    conn = make(c, "a:1", kind="account", gender_preference="female")
    with pytest.raises(CoordinatorError) as err:
        c.join_queue("a:1")
    assert err.value.code == "premium_preference_inactive"
    assert c.join_queue("a:1", accept_everyone=True)["queue_token"]
    conn.events.clear()
