---
kind: processors
title: Service Providers
version: 2026-10-draft.1
route: /processors
state: draft
---
## Providers used by this deployment

| Function | Provider | Data | Region |
|---|---|---|---|
| Hosting and database | **[Operator to supply]** | Account, support, safety and financial records | **[Operator to supply]** |
| Payments (hosted checkout) | Cashfree Payments (when enabled) | Order, amount, payment phone, payment status | India |
| Audio relay | **[Operator to supply]** | Encrypted audio packets (not recorded) | **[Operator to supply]** |
| Backups | **[Operator to supply]** | Encrypted database exports | **[Operator to supply]** |

This list must match the real deployment before public launch.
