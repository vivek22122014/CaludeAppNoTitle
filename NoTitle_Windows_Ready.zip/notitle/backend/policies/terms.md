---
kind: terms
title: Terms of Service
version: 2026-10-draft.1
route: /terms
state: draft
---
## Eligibility, account and service

By explicitly accepting these Terms you agree to use NoTitle lawfully and follow the Community Guidelines. You must be at least 18. Our Legal page identifies the operator. NoTitle enables pseudonymous workplace discussion; it is not professional legal, medical, financial, recruitment or employment advice and does not verify participants' identities or statements.

Keep your password and recovery code secure. There is no email recovery, and staff cannot recreate a lost recovery code from a payment receipt or a claim made in chat. You are responsible for the content you submit. Do not share credentials, impersonate staff or evade a safety restriction.

Ordinary conversations are temporary: a restart, disconnect, End or expiry may remove them. Saved support and selected safety evidence follow their own retention rules. Availability and a particular match are not guaranteed. Audio requires mutual consent, a compatible device and network, and may be interrupted for safety or maintenance.

## Premium purchases

Premium provides the benefits shown for the selected one-time pass: an optional gender preference and very soft professional relevance. It gives no queue priority and no verified status. Checkout shows the total, duration and policy version before payment. There is no automatic renewal. Time starts when the verified payment grants access and elapses in wall-clock time, including while you are logged out. Additional passes are used in purchase order.

Successful purchases are not voluntarily refundable, including for non-use, partial use, change of mind, account deletion or voluntary discontinuation. Statutory rights, verified payment-error remedies and binding bank or provider decisions are unaffected. The Refund and Billing Policy explains how to raise a billing issue; a complaint alone does not pause time or guarantee a refund.

## Conduct, safety and restrictions

Do not harass, threaten, discriminate, sexually exploit, groom, impersonate, scam, dox, promote unlawful activity, share non-consensual intimate material or submit malicious content. Do not reveal another person's private information or confidential workplace material without authority. Respect a peer's choice to end or decline a call. Do not record or redistribute conversations without everyone's consent and lawful authority.

Use Report and Block for safety concerns. Reports must be truthful. We may restrict access proportionately for safety, security, legal reasons or material rule breaches, record a reason and provide a review route. Restrictions are never decided automatically by a report count.

You keep your rights in your content and authorise only the processing needed to deliver the service, handle your support or report and meet applicable duties.

## Ending service, disputes and changes

You may end a conversation at any time and request account deletion in Privacy settings. Required records may survive account closure with restricted access. We may pause features for maintenance, security or legal reasons. Use Chat with Moderator and the published grievance route for disputes; non-waivable statutory rights remain available. Material changes are versioned and presented before acceptance.
