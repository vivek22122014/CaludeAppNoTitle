---
kind: legal
title: Legal Information
version: 2026-10-draft.1
route: /legal
state: draft
---
## Operator

**[Operator to supply: legal or trading name, entity type, registered address, registration and tax identifiers where applicable, governing law and forum. Pending legal review.]**

## Status of these policies

All policies on this site are **drafts** pending review of the actual operator, jurisdictions, processors and retention schedule. They describe how this software behaves; they are not a certification of legal compliance.
