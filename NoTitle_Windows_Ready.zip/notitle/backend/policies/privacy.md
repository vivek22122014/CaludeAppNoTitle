---
kind: privacy
title: Privacy Policy
version: 2026-10-draft.1
route: /privacy
state: draft
---
## Who operates NoTitle and what this notice covers

NoTitle provides adult, pseudonymous one-to-one conversations about work. Our Legal and Contact pages identify the operating entity, business address, grievance contact and approved ways to reach us. This notice covers the NoTitle application, accounts, Premium purchases, safety processes and Chat with Moderator. The effective version shown on this page identifies the notice you received.

## Information we process

For an account we process your username, a password hash, a recovery-code verifier, display name, declared gender, optional bio, matching preferences and consent records. Optional professional information (industry, role, experience band, interests and discussion topics) is processed only when you choose to provide it for that stated purpose. We do not verify your employer or professional claims. Guest identities and their preferences are temporary and exist only in server memory. We do not require an email address and there is no email-based recovery.

Ordinary text is held in a short, bounded in-memory buffer (at most 30 messages or 64 KiB per conversation) so that we can deliver your current conversation and allow a brief reconnection. We do not save ordinary chat history. Audio travels using WebRTC encryption; we do not record or transcribe it. If you report a conversation, the messages you select and your description become a separately retained safety record. Chat with Moderator is saved support history and is not covered by ordinary-chat deletion.

For purchases we process the plan, amount, order and payment references, status, receipts and necessary financial records. The payment provider's hosted checkout handles payment credentials; we never store card numbers, CVV or UPI secrets. A payment phone number may be required by the provider for checkout; it is passed to the provider and is not stored in your profile or shown to anyone.

## Purposes and choices

We use information to create and protect identities, match mutually compatible participants, deliver conversations, maintain accepted friendships, handle support and safety, fulfil paid access, respond to rights requests and meet applicable legal duties. Optional professional fields provide very weak matching relevance, not verification or a guaranteed outcome. You can withdraw optional processing in Account, Privacy without losing free conversation features.

We keep aggregate operational measurements (counts, capacity, performance and errors). We do not build individual browsing or activity timelines, sell personal information, use session replay or show advertising. Small aggregate values are suppressed.

## What others can see

Your current peer receives only your display name, declared gender, topic and bio, plus what you choose to say. Do not share confidential employer material, identifying details or another person's information. A peer may copy text or make an external recording despite our rules; pseudonymity is not a promise that nobody can identify you.

Authorised staff can access saved cases, selected report evidence and necessary records within their role and purpose; content access is audited. Service providers process limited information for hosting, database, payment, relay, storage and security functions (see Processors). There is no staff viewer for ordinary live chats.

## Retention, security and rights

The Data Retention Policy explains default periods and lawful exceptions. Ending a conversation clears its buffer; it does not erase an already submitted report or saved support case. Deleting an account disables access immediately and starts profile minimisation, while required financial, safety and legal subsets may remain restricted. Restored backups are checked against an independent deletion journal before the service reopens.

We use access controls, encryption, secure transport, limited retention and operational safeguards. No system can promise absolute security. Use Account, Privacy to correct information, manage purposes, request an export or delete your account. If access is unavailable, use Chat with Moderator or the route on the Contact page.

NoTitle is for people aged 18 and over. Report suspected underage use through the safety route. Material changes to purposes or this notice are versioned and presented as required; optional processing is never silently expanded.
