---
kind: cookies
title: Cookie Policy
version: 2026-10-draft.1
route: /cookies
state: draft
---
## Necessary cookies only

We use necessary first-party cookies for account and guest sessions, request (CSRF) protection, support-case and receipt access, and private staff authentication. They are HttpOnly and SameSite=Lax (and Secure over HTTPS) and contain opaque random tokens, never conversation text.

| Cookie | Purpose | Lifetime |
|---|---|---|
| nt_account | Account session | 7 days idle, 30 days absolute |
| nt_guest | Guest session | 30 minutes idle, 24 hours absolute |
| nt_boot | Request protection | 30 days |
| nt_support | Access to one saved support case | 30 minutes idle, 24 hours absolute |
| nt_receipt | Access to one deletion status | 30 minutes idle, 24 hours absolute |

We do not use advertising, analytics or cross-site tracking cookies. Blocking necessary cookies prevents sign-in and protected actions. The payment provider's hosted checkout may use its own necessary technologies under its own notice.

We do not store chat, support drafts or credentials in browser storage.
