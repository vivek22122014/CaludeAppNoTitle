---
kind: refund
title: Refund and Billing Policy
version: 2026-10-draft.1
route: /refund-policy
state: draft
---
## One-time passes, no automatic renewal

Premium passes (3, 7 and 30 days) are one-time purchases. There is no subscription and nothing to cancel. Paid time starts when the payment is verified and elapses in wall-clock time.

## No voluntary refunds

All successful purchases are final for voluntary-refund purposes. We do not refund because you change your mind, do not use or partly use a pass, delete your account or stop using the service.

## Required remedies still apply

This policy does not limit non-waivable statutory remedies, verified payment errors or binding payment-provider or bank decisions. If you believe a payment was duplicated, charged incorrectly, not granted or affected by a legally remediable failure, open Chat with Moderator and choose Payment, or use Report billing issue on your receipt. Include the purchase reference, never card details or passwords.

A request is not an approval and does not automatically pause your pass. Approved remedies use the payment provider's processing times. If a payment shows as pending or unknown, check its status before paying again.
