---
kind: contact
title: Contact
version: 2026-10-draft.1
route: /contact
state: draft
---
## Chat with Moderator

The way to reach us is **Chat with Moderator** in the app (Support). It is a saved case system: you get a reference and, if you are not signed in, a private receipt to return to your case. There is no support email address.

## Operator contact

**[Operator to supply: legal name, registered address and any legally required contact route. Pending legal review; public launch is blocked until this is resolved.]**

Never send passwords, recovery codes or payment authentication codes to anyone, including moderators.
