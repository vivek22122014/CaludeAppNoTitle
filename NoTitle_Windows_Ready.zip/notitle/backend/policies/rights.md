---
kind: rights
title: Your Rights
version: 2026-10-draft.1
route: /your-rights
state: draft
---
## What you can do

- **Access and export**: Account, Privacy, Request export. The download is available for 24 hours.
- **Correction**: edit your profile and preferences at any time.
- **Withdraw optional processing**: turn off professional matching in Account, Privacy; free features keep working.
- **Deletion**: Account, Privacy, Delete account. Access stops immediately; minimisation completes within 30 days. Save the deletion receipt to check status later on the Account deletion page.
- **Other requests**: submit a rights request in Account, Privacy; it creates a tracked case with a deadline.

Guests can download their consent proof before their temporary identity expires.
