---
kind: community
title: Community Guidelines
version: 2026-10-draft.1
route: /community-guidelines
state: draft
---
## Talk about work, respectfully

NoTitle is for honest, pseudonymous conversations about careers, salaries, hiring, culture and workplace experience. Disagreement is fine; abuse is not.

## Not allowed

- Harassment, threats, hate or discrimination
- Sexual content, grooming or any sexual approach. NoTitle is not a dating service
- Doxxing, revealing someone's identity or private information
- Sharing confidential employer material you are not authorised to share
- Targeted false accusations against identifiable people
- Scams, spam, recruitment fraud or impersonating staff or companies
- Any use by people under 18

## Safety tools

You can End a conversation at any time. Block stops further contact from that identity immediately. Report copies only the messages you select into a saved safety case for review. Audio is never recorded. Moderators review reports with a recorded reason; restrictions can be appealed through Chat with Moderator, Appeal.
