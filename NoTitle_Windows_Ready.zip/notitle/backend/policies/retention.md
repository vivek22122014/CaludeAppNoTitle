---
kind: retention
title: Data Retention Policy
version: 2026-10-draft.1
route: /data-retention
state: draft
---
## Default retention

| Information | Retention |
|---|---|
| Ordinary text | Memory only (max 30 messages / 64 KiB); cleared at End, expiry or restart |
| Audio | Never recorded |
| Guest identity | 30 minutes idle / 24 hours; lost on restart |
| Recent-pair information | At most 5 minutes in memory |
| Ended-conversation attribution | At most 10 minutes, no transcript |
| Prepared report snapshot | At most 2 minutes unless submitted |
| Saved support cases | 90 days after closure |
| Safety reports and decisions | 180 days after closure |
| Deleted account profile | Disabled immediately, minimised within 30 days |
| Consent and rights proof | 180 days after withdrawal or closure |
| Data export packages | 24 hours |
| Security and access audit | 180 days |
| Financial records | The operator's reviewed statutory schedule |
| Aggregates | Minute 7 days, hour 30 days, day 90 days, month 12 months |

Backups are restored only after re-applying the independent deletion journal. A documented legal hold can extend specific records; it never authorises unrelated retention.
