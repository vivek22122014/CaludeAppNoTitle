---
kind: grievance
title: Grievance Procedure
version: 2026-10-draft.1
route: /grievance
state: draft
---
## How to raise a grievance

Open Chat with Moderator and choose the category that fits (Safety, Privacy, Payment, Appeal or General). Save the case receipt if you are not signed in. Each case shows its status; legal response clocks are tracked separately from ordinary case status and are not reset by reassignment or continuation.

## Grievance officer

**[Operator to supply: grievance officer name, designation and lawful contact route. Pending legal review.]**

## Appeals

Decisions about your account include a reference. Appeal through Chat with Moderator, Appeal. An appeal is reviewed by someone other than the person who made the original decision. Applicable statutory appeal routes remain available.

NoTitle does not provide emergency services. If you are in immediate danger, contact local emergency services.
