-- Phase 5: private staff identities, grants, MFA sessions, audit and signed previews.

CREATE TABLE staff_accounts (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    username text NOT NULL UNIQUE CHECK (username ~ '^[a-z0-9_.-]{3,32}$'),
    password_hash text NOT NULL,
    status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','disabled')),
    role_version integer NOT NULL DEFAULT 1 CHECK (role_version > 0),
    totp_secret_ct bytea NOT NULL,
    totp_key_id uuid NOT NULL REFERENCES data_keys(id),
    last_totp_counter bigint,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE staff_grants (
    staff_id uuid NOT NULL REFERENCES staff_accounts(id) ON DELETE CASCADE,
    permission text NOT NULL,
    granted_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (staff_id, permission)
);

CREATE TABLE staff_sessions (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    staff_id uuid NOT NULL REFERENCES staff_accounts(id) ON DELETE CASCADE,
    token_hmac bytea NOT NULL UNIQUE CHECK (octet_length(token_hmac) = 32),
    role_version integer NOT NULL,
    mfa_at timestamptz NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    last_active_at timestamptz NOT NULL DEFAULT now(),
    expires_at timestamptz NOT NULL,
    absolute_expires_at timestamptz NOT NULL,
    revoked_at timestamptz
);

CREATE TABLE staff_recovery_codes (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    staff_id uuid NOT NULL REFERENCES staff_accounts(id) ON DELETE CASCADE,
    verifier bytea NOT NULL UNIQUE CHECK (octet_length(verifier) = 32),
    consumed_at timestamptz
);

-- Metadata only: never bodies, secrets or credentials.
CREATE TABLE access_audit (
    id bigserial PRIMARY KEY,
    actor_ref text NOT NULL,
    purpose text NOT NULL,
    object_type text NOT NULL,
    object_ref text NOT NULL,
    action text NOT NULL,
    decision text NOT NULL CHECK (decision IN ('allowed','denied')),
    request_id text,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX access_audit_time ON access_audit (created_at DESC);

CREATE TABLE sensitive_previews (
    nonce uuid PRIMARY KEY,
    staff_id uuid NOT NULL REFERENCES staff_accounts(id) ON DELETE CASCADE,
    kind text NOT NULL,
    object_ref text NOT NULL,
    payload jsonb NOT NULL,
    payload_digest bytea NOT NULL,
    expires_at timestamptz NOT NULL,
    consumed_at timestamptz
);

ALTER TABLE support_cases ADD CONSTRAINT support_cases_staff_fk
    FOREIGN KEY (assigned_staff_id) REFERENCES staff_accounts(id) ON DELETE SET NULL;
ALTER TABLE case_internal_notes ADD CONSTRAINT case_notes_staff_fk
    FOREIGN KEY (staff_id) REFERENCES staff_accounts(id);
ALTER TABLE moderation_decisions ADD CONSTRAINT decisions_staff_fk
    FOREIGN KEY (staff_id) REFERENCES staff_accounts(id);
