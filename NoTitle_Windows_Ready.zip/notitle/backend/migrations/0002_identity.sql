-- Phase 3: accounts, sessions, recovery, consent, policies, profile and preferences.

CREATE TABLE accounts (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    username text NOT NULL UNIQUE CHECK (username ~ '^[a-z0-9_-]{4,24}$' OR username ~ '^deleted_[0-9a-f]{32}$'),
    password_hash text,
    display_name text NOT NULL CHECK (char_length(display_name) BETWEEN 1 AND 24),
    gender text NOT NULL CHECK (gender IN ('male','female','other')),
    topic_id text NOT NULL,
    bio text NOT NULL DEFAULT '' CHECK (char_length(bio) <= 160),
    status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','disabled','deleted')),
    auth_generation integer NOT NULL DEFAULT 1 CHECK (auth_generation > 0),
    profile_version integer NOT NULL DEFAULT 1 CHECK (profile_version > 0),
    safety_revision integer NOT NULL DEFAULT 1 CHECK (safety_revision > 0),
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE TABLE account_sessions (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id uuid NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    token_hmac bytea NOT NULL UNIQUE CHECK (octet_length(token_hmac) = 32),
    auth_generation integer NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    last_active_at timestamptz NOT NULL DEFAULT now(),
    expires_at timestamptz NOT NULL,
    absolute_expires_at timestamptz NOT NULL,
    reauth_at timestamptz,
    revoked_at timestamptz
);
CREATE INDEX account_sessions_account ON account_sessions (account_id) WHERE revoked_at IS NULL;
CREATE INDEX account_sessions_expiry ON account_sessions (expires_at);

CREATE TABLE recovery_credentials (
    account_id uuid PRIMARY KEY REFERENCES accounts(id) ON DELETE CASCADE,
    verifier bytea NOT NULL UNIQUE CHECK (octet_length(verifier) = 32),
    key_version integer NOT NULL DEFAULT 1,
    rotated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE policy_versions (
    kind text NOT NULL,
    version text NOT NULL,
    content_sha256 text NOT NULL CHECK (length(content_sha256) = 64),
    effective_at timestamptz NOT NULL DEFAULT now(),
    publication_state text NOT NULL DEFAULT 'draft' CHECK (publication_state IN ('draft','reviewed','published','retired')),
    PRIMARY KEY (kind, version)
);

-- Append-only consent proof.  account_id is nulled on deletion; subject_ref keeps minimal proof.
CREATE TABLE consent_records (
    id bigserial PRIMARY KEY,
    account_id uuid REFERENCES accounts(id) ON DELETE SET NULL,
    subject_ref text NOT NULL,
    purpose text NOT NULL CHECK (purpose IN ('adult','terms','core','professional')),
    choice boolean NOT NULL,
    policy_kind text NOT NULL,
    policy_version text NOT NULL,
    text_digest text NOT NULL,
    recorded_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (policy_kind, policy_version) REFERENCES policy_versions(kind, version)
);
CREATE INDEX consent_records_account ON consent_records (account_id, purpose, recorded_at DESC);

CREATE TABLE professional_profiles (
    account_id uuid PRIMARY KEY REFERENCES accounts(id) ON DELETE CASCADE,
    industry_id text,
    role_id text,
    experience_id text,
    interest_ids text[] NOT NULL DEFAULT '{}' CHECK (cardinality(interest_ids) <= 10),
    topic_ids text[] NOT NULL DEFAULT '{}' CHECK (cardinality(topic_ids) <= 5),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE matching_preferences (
    account_id uuid PRIMARY KEY REFERENCES accounts(id) ON DELETE CASCADE,
    gender_preference text NOT NULL DEFAULT 'everyone' CHECK (gender_preference IN ('everyone','male','female','other')),
    professional_enabled boolean NOT NULL DEFAULT true,
    industry_ids text[] NOT NULL DEFAULT '{}' CHECK (cardinality(industry_ids) <= 5),
    role_ids text[] NOT NULL DEFAULT '{}' CHECK (cardinality(role_ids) <= 5),
    experience_ids text[] NOT NULL DEFAULT '{}' CHECK (cardinality(experience_ids) <= 5),
    interest_ids text[] NOT NULL DEFAULT '{}' CHECK (cardinality(interest_ids) <= 10),
    topic_ids text[] NOT NULL DEFAULT '{}' CHECK (cardinality(topic_ids) <= 5),
    version integer NOT NULL DEFAULT 1 CHECK (version > 0),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE account_notices (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    public_ref text NOT NULL UNIQUE,
    account_id uuid REFERENCES accounts(id) ON DELETE CASCADE,
    kind text NOT NULL CHECK (kind IN ('policy','safety','rights','billing','system')),
    version text NOT NULL DEFAULT '1',
    safe_payload jsonb NOT NULL DEFAULT '{}'::jsonb,
    issued_at timestamptz NOT NULL DEFAULT now(),
    seen_at timestamptz
);
CREATE INDEX account_notices_account ON account_notices (account_id, issued_at DESC);
