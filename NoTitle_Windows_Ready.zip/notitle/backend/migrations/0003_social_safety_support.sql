-- Phases 5 and 6: friendships, blocks, restrictions, support cases, reports, receipts.

CREATE TABLE friendships (
    low_account_id uuid NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    high_account_id uuid NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    state text NOT NULL DEFAULT 'active' CHECK (state IN ('active','removed')),
    revision integer NOT NULL DEFAULT 1 CHECK (revision > 0),
    accepted_at timestamptz NOT NULL DEFAULT now(),
    removed_at timestamptz,
    PRIMARY KEY (low_account_id, high_account_id),
    CHECK (low_account_id < high_account_id)
);
CREATE INDEX friendships_high ON friendships (high_account_id) WHERE state = 'active';

CREATE TABLE blocks (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    public_ref text NOT NULL UNIQUE,
    blocker_id uuid NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    blocked_id uuid NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    created_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (blocker_id, blocked_id),
    CHECK (blocker_id <> blocked_id)
);
CREATE INDEX blocks_blocked ON blocks (blocked_id);

-- Scoped receipts: one canonical verifier table for case / financial / deletion access.
CREATE TABLE scoped_receipts (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    public_ref text NOT NULL UNIQUE,
    kind text NOT NULL CHECK (kind IN ('case','financial','deletion')),
    scope_ref text NOT NULL,
    verifier bytea NOT NULL UNIQUE CHECK (octet_length(verifier) = 32),
    key_version integer NOT NULL DEFAULT 1,
    created_at timestamptz NOT NULL DEFAULT now(),
    revoked_at timestamptz
);
CREATE INDEX scoped_receipts_scope ON scoped_receipts (kind, scope_ref);

CREATE TABLE scoped_sessions (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    receipt_id uuid NOT NULL REFERENCES scoped_receipts(id) ON DELETE CASCADE,
    token_hmac bytea NOT NULL UNIQUE CHECK (octet_length(token_hmac) = 32),
    created_at timestamptz NOT NULL DEFAULT now(),
    last_active_at timestamptz NOT NULL DEFAULT now(),
    expires_at timestamptz NOT NULL,
    absolute_expires_at timestamptz NOT NULL,
    revoked_at timestamptz
);

CREATE TABLE support_cases (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    public_ref text NOT NULL UNIQUE,
    account_id uuid REFERENCES accounts(id) ON DELETE SET NULL,
    category text NOT NULL CHECK (category IN ('general','payment','safety','privacy','appeal','security')),
    subject_ct bytea NOT NULL,
    key_id uuid NOT NULL REFERENCES data_keys(id),
    status text NOT NULL DEFAULT 'open' CHECK (status IN ('open','in_progress','waiting_user','resolved','closed')),
    urgent boolean NOT NULL DEFAULT false,
    assigned_staff_id uuid,
    parent_case_id uuid REFERENCES support_cases(id),
    related_ref text,
    last_sequence bigint NOT NULL DEFAULT 0 CHECK (last_sequence >= 0),
    seen_user_sequence bigint NOT NULL DEFAULT 0 CHECK (seen_user_sequence >= 0),
    seen_staff_sequence bigint NOT NULL DEFAULT 0 CHECK (seen_staff_sequence >= 0),
    version bigint NOT NULL DEFAULT 1 CHECK (version > 0),
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    closed_at timestamptz,
    CHECK (seen_user_sequence <= last_sequence AND seen_staff_sequence <= last_sequence),
    CHECK ((status = 'closed') = (closed_at IS NOT NULL))
);
CREATE INDEX support_cases_account ON support_cases (account_id, updated_at DESC);
CREATE INDEX support_cases_queue ON support_cases (status, urgent DESC, updated_at);

CREATE TABLE case_messages (
    case_id uuid NOT NULL REFERENCES support_cases(id) ON DELETE CASCADE,
    sequence bigint NOT NULL CHECK (sequence > 0),
    sender_kind text NOT NULL CHECK (sender_kind IN ('user','staff','system')),
    sender_ref text,
    body_ct bytea NOT NULL,
    client_nonce uuid NOT NULL,
    payload_digest bytea NOT NULL CHECK (octet_length(payload_digest) = 32),
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (case_id, sequence),
    UNIQUE (case_id, sender_kind, client_nonce),
    CHECK (sender_kind <> 'staff' OR sender_ref IS NOT NULL)
);

CREATE TABLE case_internal_notes (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id uuid NOT NULL REFERENCES support_cases(id) ON DELETE CASCADE,
    staff_id uuid NOT NULL,
    body_ct bytea NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE case_events (
    id bigserial PRIMARY KEY,
    case_id uuid NOT NULL REFERENCES support_cases(id) ON DELETE CASCADE,
    actor_ref text NOT NULL,
    kind text NOT NULL,
    old_value text,
    new_value text,
    reason text,
    request_id text,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE case_obligations (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id uuid NOT NULL REFERENCES support_cases(id) ON DELETE CASCADE,
    rule_id text NOT NULL,
    rule_version text NOT NULL,
    received_at timestamptz NOT NULL,
    acknowledge_by timestamptz NOT NULL,
    act_by timestamptz NOT NULL,
    acknowledged_at timestamptz,
    status text NOT NULL DEFAULT 'open' CHECK (status IN ('open','acknowledged','completed','overdue')),
    completed_at timestamptz,
    evidence_ref text,
    outcome text,
    CHECK (acknowledge_by <= act_by)
);
CREATE INDEX open_obligations ON case_obligations (act_by) WHERE status <> 'completed';

CREATE TABLE reports (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    public_ref text NOT NULL UNIQUE,
    reporter_kind text NOT NULL CHECK (reporter_kind IN ('account','guest')),
    reporter_ref text NOT NULL,
    subject_kind text NOT NULL CHECK (subject_kind IN ('account','guest')),
    subject_ref text NOT NULL,
    subject_account_id uuid REFERENCES accounts(id) ON DELETE SET NULL,
    interaction_ref text NOT NULL,
    reason text NOT NULL CHECK (reason IN ('harassment','threats','doxxing','confidentiality','false_accusation','scam','impersonation','underage','sexual_misconduct','spam','other')),
    allegation_ct bytea NOT NULL,
    key_id uuid NOT NULL REFERENCES data_keys(id),
    case_id uuid NOT NULL REFERENCES support_cases(id),
    blocked boolean NOT NULL DEFAULT false,
    evidence_state text NOT NULL CHECK (evidence_state IN ('server_snapshot','allegation_only')),
    submitted_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX reports_subject ON reports (subject_ref);

CREATE TABLE report_evidence (
    report_id uuid NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
    server_message_id text NOT NULL,
    sender_role text NOT NULL CHECK (sender_role IN ('reporter','reported')),
    sent_at timestamptz NOT NULL,
    body_ct bytea NOT NULL,
    source text NOT NULL DEFAULT 'server_snapshot' CHECK (source = 'server_snapshot'),
    PRIMARY KEY (report_id, server_message_id)
);

CREATE TABLE moderation_decisions (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    public_ref text NOT NULL UNIQUE,
    report_id uuid REFERENCES reports(id) ON DELETE SET NULL,
    case_id uuid REFERENCES support_cases(id) ON DELETE SET NULL,
    subject_kind text NOT NULL CHECK (subject_kind IN ('account','guest')),
    subject_ref text NOT NULL,
    action text NOT NULL CHECK (action IN ('dismiss','warn','suspend','ban')),
    reason_code text NOT NULL,
    starts_at timestamptz NOT NULL DEFAULT now(),
    ends_at timestamptz,
    staff_id uuid NOT NULL,
    appeal_case_id uuid REFERENCES support_cases(id),
    appeal_outcome text CHECK (appeal_outcome IN ('upheld','overturned')),
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE restrictions (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    subject_kind text NOT NULL CHECK (subject_kind IN ('account','guest')),
    subject_ref text NOT NULL,
    kind text NOT NULL CHECK (kind IN ('suspend','ban')),
    starts_at timestamptz NOT NULL DEFAULT now(),
    ends_at timestamptz,
    reason_code text NOT NULL,
    decision_id uuid NOT NULL REFERENCES moderation_decisions(id),
    lifted_at timestamptz,
    CHECK (ends_at IS NULL OR ends_at > starts_at)
);
CREATE INDEX restrictions_subject ON restrictions (subject_ref) WHERE lifted_at IS NULL;
