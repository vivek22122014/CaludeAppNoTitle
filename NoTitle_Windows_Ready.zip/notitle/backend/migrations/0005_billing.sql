-- Phase 8: one-time passes, purchases, verified payments, FIFO ledger, refunds, receipts.

CREATE TABLE financial_subjects (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id uuid UNIQUE REFERENCES accounts(id) ON DELETE SET NULL,
    ledger_revision integer NOT NULL DEFAULT 1 CHECK (ledger_revision > 0),
    last_accounted_at timestamptz NOT NULL DEFAULT now(),
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE plan_versions (
    code text NOT NULL CHECK (code IN ('Short3','Week7','Month30','Annual365')),
    version integer NOT NULL CHECK (version > 0),
    gross_paise integer NOT NULL CHECK (gross_paise > 0),
    duration_seconds integer NOT NULL CHECK (duration_seconds > 0),
    currency text NOT NULL DEFAULT 'INR' CHECK (currency = 'INR'),
    enabled boolean NOT NULL DEFAULT false,
    tax_note text NOT NULL DEFAULT 'Tax treatment pending operator review',
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (code, version)
);

INSERT INTO plan_versions (code, version, gross_paise, duration_seconds, enabled) VALUES
 ('Short3', 1, 9900, 259200, true),
 ('Week7', 1, 19900, 604800, true),
 ('Month30', 1, 49900, 2592000, true),
 -- Annual365 stays disabled until a provider-approved late-remedy route exists.
 ('Annual365', 1, 149900, 31536000, false);

CREATE TABLE purchases (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    public_ref text NOT NULL UNIQUE,
    financial_subject_id uuid NOT NULL REFERENCES financial_subjects(id),
    plan_code text NOT NULL,
    plan_version integer NOT NULL,
    amount_paise integer NOT NULL CHECK (amount_paise > 0),
    currency text NOT NULL DEFAULT 'INR' CHECK (currency = 'INR'),
    duration_seconds integer NOT NULL CHECK (duration_seconds > 0),
    provider text NOT NULL CHECK (provider IN ('simulator','cashfree')),
    environment text NOT NULL,
    merchant_order_id text NOT NULL UNIQUE,
    provider_order_id text UNIQUE,
    payment_session_id text,
    client_nonce uuid NOT NULL,
    state text NOT NULL DEFAULT 'created' CHECK (state IN ('created','pending','paid','failed','needs_review')),
    policy_version text NOT NULL,
    policy_digest text NOT NULL,
    policy_accepted_at timestamptz NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    captured_at timestamptz,
    last_reconciled_at timestamptz,
    UNIQUE (financial_subject_id, client_nonce),
    FOREIGN KEY (plan_code, plan_version) REFERENCES plan_versions(code, version)
);
CREATE INDEX purchases_subject ON purchases (financial_subject_id, created_at DESC);
CREATE INDEX purchases_pending ON purchases (state) WHERE state IN ('created','pending','needs_review');

CREATE TABLE payment_attempts (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    purchase_id uuid NOT NULL REFERENCES purchases(id),
    provider_payment_id text NOT NULL,
    status text NOT NULL CHECK (status IN ('success','failed','pending','user_dropped','cancelled','unknown')),
    amount_paise integer NOT NULL,
    currency text NOT NULL,
    environment text NOT NULL,
    verified_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX one_payment_fact ON payment_attempts (provider_payment_id);

CREATE TABLE webhook_inbox (
    id bigserial PRIMARY KEY,
    provider text NOT NULL,
    dedupe_digest bytea NOT NULL UNIQUE,
    event_type text NOT NULL,
    merchant_order_id text,
    provider_payment_id text,
    reported_status text,
    amount_paise integer,
    received_at timestamptz NOT NULL DEFAULT now(),
    processed_at timestamptz
);

CREATE TABLE entitlement_lots (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    purchase_id uuid NOT NULL REFERENCES purchases(id),
    subject_id uuid NOT NULL REFERENCES financial_subjects(id),
    grant_seq integer NOT NULL CHECK (grant_seq > 0),
    granted_seconds bigint NOT NULL,
    consumed_seconds bigint NOT NULL DEFAULT 0,
    available_seconds bigint NOT NULL,
    held_seconds bigint NOT NULL DEFAULT 0,
    revoked_seconds bigint NOT NULL DEFAULT 0,
    granted_at timestamptz NOT NULL DEFAULT now(),
    first_paid_use_at timestamptz,
    revision integer NOT NULL DEFAULT 1,
    CONSTRAINT lot_nonnegative CHECK (granted_seconds > 0 AND consumed_seconds >= 0
        AND available_seconds >= 0 AND held_seconds >= 0 AND revoked_seconds >= 0),
    CONSTRAINT lot_conservation CHECK (granted_seconds = consumed_seconds + available_seconds
        + held_seconds + revoked_seconds),
    CONSTRAINT one_lot_per_purchase UNIQUE (purchase_id),
    CONSTRAINT lot_order UNIQUE (subject_id, grant_seq)
);

CREATE TABLE ledger_adjustments (
    id bigserial PRIMARY KEY,
    subject_id uuid NOT NULL REFERENCES financial_subjects(id),
    lot_id uuid NOT NULL REFERENCES entitlement_lots(id),
    kind text NOT NULL CHECK (kind IN ('grant','hold','release','revoke')),
    delta_available bigint NOT NULL DEFAULT 0,
    delta_held bigint NOT NULL DEFAULT 0,
    delta_revoked bigint NOT NULL DEFAULT 0,
    origin_ref text NOT NULL UNIQUE,
    reason text NOT NULL,
    effective_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE refunds (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    public_ref text NOT NULL UNIQUE,
    purchase_id uuid NOT NULL REFERENCES purchases(id),
    lot_id uuid REFERENCES entitlement_lots(id),
    amount_paise integer NOT NULL CHECK (amount_paise > 0),
    revoke_seconds bigint NOT NULL DEFAULT 0 CHECK (revoke_seconds >= 0),
    held_seconds bigint NOT NULL DEFAULT 0 CHECK (held_seconds >= 0),
    state text NOT NULL CHECK (state IN ('held','submitting','pending','needs_review','succeeded','failed','cancelled')),
    remedy_basis text NOT NULL CHECK (remedy_basis IN ('payment_error','statutory_remedy','provider_bank_direction')),
    evidence_ref text NOT NULL,
    decision_reason text NOT NULL,
    provider_refund_id text NOT NULL UNIQUE,
    staff_id uuid NOT NULL REFERENCES staff_accounts(id),
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    verified_at timestamptz
);

CREATE SEQUENCE receipt_number_seq AS bigint START 1001;

CREATE TABLE receipts (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    public_ref text NOT NULL UNIQUE,
    receipt_number bigint NOT NULL UNIQUE DEFAULT nextval('receipt_number_seq'),
    subject_id uuid NOT NULL REFERENCES financial_subjects(id),
    purchase_id uuid NOT NULL UNIQUE REFERENCES purchases(id),
    issued_at timestamptz NOT NULL DEFAULT now(),
    facts jsonb NOT NULL
);

-- Development-only stand-in for the hosted payment provider (never used in production).
CREATE TABLE simulated_provider_orders (
    order_id text PRIMARY KEY,
    merchant_order_id text NOT NULL UNIQUE,
    amount_paise integer NOT NULL,
    status text NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','PAID','FAILED','EXPIRED')),
    payment_id text UNIQUE,
    refunds jsonb NOT NULL DEFAULT '[]'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);
