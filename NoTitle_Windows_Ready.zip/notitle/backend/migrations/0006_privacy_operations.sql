-- Phases 3 and 9: rights requests, exports, deletion, holds, journal checkpoints, analytics.

CREATE TABLE privacy_requests (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    public_ref text NOT NULL UNIQUE,
    account_id uuid REFERENCES accounts(id) ON DELETE SET NULL,
    kind text NOT NULL CHECK (kind IN ('access','correction','erasure','objection','grievance','other')),
    case_id uuid NOT NULL REFERENCES support_cases(id),
    status text NOT NULL DEFAULT 'received' CHECK (status IN ('received','in_review','completed','rejected')),
    deadline_at timestamptz NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE privacy_exports (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    public_ref text NOT NULL UNIQUE,
    account_id uuid REFERENCES accounts(id) ON DELETE CASCADE,
    status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','ready','expired','failed')),
    package_ct bytea,
    key_id uuid REFERENCES data_keys(id),
    created_at timestamptz NOT NULL DEFAULT now(),
    ready_at timestamptz,
    expires_at timestamptz,
    downloaded_at timestamptz
);

CREATE TABLE deletion_requests (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    public_ref text NOT NULL UNIQUE,
    account_id uuid REFERENCES accounts(id) ON DELETE SET NULL,
    subject_ref text NOT NULL,
    state text NOT NULL DEFAULT 'accepted' CHECK (state IN ('accepted','processing','completed','restricted')),
    journal_seq bigint NOT NULL,
    retained_categories text[] NOT NULL DEFAULT '{}',
    requested_at timestamptz NOT NULL DEFAULT now(),
    completed_at timestamptz
);

CREATE TABLE legal_holds (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    public_ref text NOT NULL UNIQUE,
    subject_ref text NOT NULL,
    scope text NOT NULL CHECK (scope IN ('account_profile','support_cases','safety_reports','financial','all')),
    basis text NOT NULL,
    approver_staff_id uuid NOT NULL REFERENCES staff_accounts(id),
    review_at timestamptz NOT NULL,
    expires_at timestamptz,
    state text NOT NULL DEFAULT 'active' CHECK (state IN ('active','released')),
    journal_seq bigint,
    created_at timestamptz NOT NULL DEFAULT now(),
    released_at timestamptz
);
CREATE INDEX legal_holds_subject ON legal_holds (subject_ref) WHERE state = 'active';

CREATE TABLE journal_checkpoints (
    stream_id text PRIMARY KEY,
    applied_seq bigint NOT NULL,
    head_hash text NOT NULL,
    updated_at timestamptz NOT NULL DEFAULT now()
);

-- Analytics (chapter 40): fixed metric catalog, idempotent batches, deterministic rollups.
CREATE TABLE metric_catalog (
    metric_code smallint PRIMARY KEY CHECK (metric_code BETWEEN 1 AND 32),
    name text NOT NULL UNIQUE,
    kind text NOT NULL CHECK (kind IN ('counter','histogram','integral')),
    unit text NOT NULL
);

INSERT INTO metric_catalog (metric_code, name, kind, unit) VALUES
 (1,'registrations','counter','count'),
 (2,'matches','counter','count'),
 (3,'searches_started','counter','count'),
 (4,'searches_cancelled','counter','count'),
 (5,'text_accepted','counter','count'),
 (6,'friend_acceptances','counter','count'),
 (7,'calls_attempted','counter','count'),
 (8,'calls_connected','counter','count'),
 (9,'calls_failed','counter','count'),
 (10,'call_seconds','integral','seconds'),
 (11,'participant_seconds','integral','seconds'),
 (12,'support_created','counter','count'),
 (13,'support_replies','counter','count'),
 (14,'match_wait_ms','histogram','ms'),
 (15,'api_latency_ms','histogram','ms'),
 (16,'call_setup_ms','histogram','ms'),
 (17,'requests_total','counter','count'),
 (18,'server_errors','counter','count'),
 (19,'auth_denials','counter','count'),
 (20,'loop_lag_ms','histogram','ms'),
 (21,'db_latency_ms','histogram','ms'),
 (22,'professional_enabled','counter','count'),
 (23,'professional_disabled','counter','count'),
 (24,'repeat_matches','counter','count'),
 (25,'searches_abandoned','counter','count'),
 (26,'metric_samples_dropped','counter','count');

CREATE TABLE aggregate_buckets (
    level text NOT NULL CHECK (level IN ('minute','hour','day','month')),
    bucket_start timestamptz NOT NULL,
    metric_code smallint NOT NULL REFERENCES metric_catalog(metric_code),
    value_sum numeric(24,3) NOT NULL DEFAULT 0 CHECK (value_sum >= 0),
    sample_count bigint NOT NULL DEFAULT 0 CHECK (sample_count >= 0),
    bins bigint[] NOT NULL DEFAULT '{}',
    complete boolean NOT NULL DEFAULT false,
    PRIMARY KEY (level, bucket_start, metric_code),
    CHECK (cardinality(bins) IN (0, 13))
);

CREATE TABLE aggregate_batches (
    batch_id uuid PRIMARY KEY,
    keyed_digest bytea NOT NULL CHECK (octet_length(keyed_digest) = 32),
    received_at timestamptz NOT NULL DEFAULT now(),
    source_kind text NOT NULL CHECK (source_kind IN ('runtime','outbox'))
);

CREATE TABLE aggregate_checkpoints (
    source_level text PRIMARY KEY,
    rolled_before timestamptz NOT NULL,
    updated_at timestamptz NOT NULL DEFAULT now()
);
