-- Phase 1: runtime ownership, encryption keys, idempotency and jobs.


CREATE SEQUENCE runtime_owner_epoch AS bigint START 1;

CREATE TABLE runtime_owner (
    singleton boolean PRIMARY KEY DEFAULT true CHECK (singleton),
    owner_epoch bigint NOT NULL,
    boot_id uuid NOT NULL,
    started_at timestamptz NOT NULL DEFAULT now(),
    heartbeat_at timestamptz NOT NULL DEFAULT now()
);

-- Wrapped (encrypted) data keys.  Plaintext keys never touch the database.
CREATE TABLE data_keys (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    purpose text NOT NULL CHECK (purpose IN ('support','evidence','export','staff','privacy')),
    wrapped_key bytea NOT NULL,
    wrapping_key_version integer NOT NULL CHECK (wrapping_key_version > 0),
    created_at timestamptz NOT NULL DEFAULT now(),
    retired_at timestamptz
);

-- Idempotent results for retried mutations (nonce bound to principal + payload digest).
CREATE TABLE operation_results (
    scope_ref text NOT NULL,
    kind text NOT NULL,
    client_nonce uuid NOT NULL,
    payload_digest bytea NOT NULL CHECK (octet_length(payload_digest) = 32),
    result jsonb NOT NULL,
    committed_at timestamptz NOT NULL DEFAULT now(),
    expires_at timestamptz NOT NULL,
    PRIMARY KEY (scope_ref, kind, client_nonce)
);
CREATE INDEX operation_results_expiry ON operation_results (expires_at);

-- Durable background jobs.  Payloads hold references and enums only.
CREATE TABLE durable_jobs (
    id bigserial PRIMARY KEY,
    kind text NOT NULL,
    dedupe_key text NOT NULL UNIQUE,
    payload jsonb NOT NULL DEFAULT '{}'::jsonb,
    state text NOT NULL DEFAULT 'ready' CHECK (state IN ('ready','running','retry','done','failed')),
    available_at timestamptz NOT NULL DEFAULT now(),
    lease_until timestamptz,
    attempts integer NOT NULL DEFAULT 0 CHECK (attempts >= 0),
    max_attempts integer NOT NULL DEFAULT 8 CHECK (max_attempts > 0),
    last_error text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX due_jobs ON durable_jobs (available_at) WHERE state IN ('ready','retry');

-- Retention schedule (blueprint chapter 37).  Reviewed values replace defaults.
CREATE TABLE retention_registry (
    category text PRIMARY KEY,
    duration_days integer NOT NULL CHECK (duration_days > 0),
    trigger_event text NOT NULL,
    description text NOT NULL
);

INSERT INTO retention_registry (category, duration_days, trigger_event, description) VALUES
 ('support_case', 90, 'case_closed', 'Saved moderator support after closure'),
 ('safety_report', 180, 'case_closed', 'Selected report evidence and decisions after closure'),
 ('deleted_profile', 30, 'deletion_accepted', 'Profile minimisation after access is disabled'),
 ('consent_proof', 180, 'withdrawal_or_closure', 'Minimal consent and rights proof'),
 ('export_package', 1, 'export_ready', 'Encrypted personal data export'),
 ('access_audit', 180, 'recorded', 'Security and access audit metadata'),
 ('webhook_inbox', 30, 'processed', 'Sanitised payment notifications'),
 ('analytics_minute', 7, 'bucket_end', 'Minute aggregates'),
 ('analytics_hour', 30, 'bucket_end', 'Hour aggregates'),
 ('analytics_day', 90, 'bucket_end', 'Day aggregates'),
 ('analytics_month', 365, 'bucket_end', 'Month aggregates');
