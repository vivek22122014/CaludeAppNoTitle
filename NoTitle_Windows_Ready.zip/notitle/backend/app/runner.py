"""Single-owner runtime: ``python -m app.runner``.

Startup order (blueprint chapter 07):

1. Verify the database contains exactly the packaged migrations (never migrate here).
2. Open the pool and take the dedicated PostgreSQL advisory *owner lock*.
   A second process on the same database refuses to start.
3. Allocate a new monotonically increasing ``owner_epoch``.
4. Verify and replay the independent privacy journal.
5. Start the coordinator, job supervisor and both HTTP listeners.

Losing the owner connection or either listener shuts everything down; a
restart acquires a new epoch.  Windows note: psycopg's async driver needs a
SelectorEventLoop, which this runner installs explicitly.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import signal
import sys
import uuid

import psycopg
import uvicorn

from app import db, migrations
from app.config import get_settings

log = logging.getLogger("notitle.runner")
OWNER_LOCK_ID = 7_331_000


class _Server(uvicorn.Server):
    """uvicorn server that leaves signal handling to the runner (two servers, one owner)."""

    @contextlib.contextmanager
    def capture_signals(self):  # type: ignore[override]
        yield


def _configure_logging(level: str) -> None:
    logging.basicConfig(level=getattr(logging, level.upper(), logging.INFO),
                        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s")
    # Access logs would contain query strings and IPs; keep them off by default.
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)


async def acquire_owner(url: str) -> tuple[psycopg.AsyncConnection, int]:
    conn = await psycopg.AsyncConnection.connect(url, autocommit=True)
    cur = await conn.execute("SELECT pg_try_advisory_lock(%s)", (OWNER_LOCK_ID,))
    if not (await cur.fetchone())[0]:
        await conn.close()
        raise RuntimeError("Another NoTitle runtime already owns this database. Stop it first (scripts\\stop.ps1).")
    cur = await conn.execute("SELECT nextval('runtime_owner_epoch')")
    epoch = int((await cur.fetchone())[0])
    await conn.execute(
        """INSERT INTO runtime_owner (singleton, owner_epoch, boot_id) VALUES (true, %s, %s)
           ON CONFLICT (singleton) DO UPDATE SET owner_epoch = EXCLUDED.owner_epoch, boot_id = EXCLUDED.boot_id,
           started_at = now(), heartbeat_at = now()""", (epoch, str(uuid.uuid4())))
    return conn, epoch


async def run(stop: asyncio.Event | None = None) -> int:
    settings = get_settings()
    _configure_logging(settings.log_level)
    stop = stop or asyncio.Event()

    try:
        migrations.verify_runtime(settings.database_url)
    except migrations.MigrationError as exc:
        log.error("%s", exc)
        return 2
    except psycopg.OperationalError as exc:
        log.error("Cannot connect to PostgreSQL (%s). Is the database running? Try scripts\\db-start.ps1",
                  str(exc).splitlines()[0] if str(exc) else type(exc).__name__)
        return 2

    await db.open_pool()
    try:
        owner_conn, epoch = await acquire_owner(settings.database_url)
    except RuntimeError as exc:
        log.error("%s", exc)
        await db.close_pool()
        return 3

    from app.main import create_private_app, create_public_app
    from app.realtime.coordinator import coordinator
    from app.services import identity, social
    from app.services.jobs import supervisor
    from app.services.journal import JournalError, replay

    try:
        result = await replay()
        log.info("privacy journal verified: %s entries, %s re-applied", result["entries"], result["reapplied"])
    except JournalError as exc:
        log.error("Privacy journal check failed: %s", exc)
        await owner_conn.close()
        await db.close_pool()
        return 4

    async with db.transaction() as conn:
        await identity.ensure_policy_rows(conn)

    coordinator.owner_epoch = epoch
    coordinator.persist_friendship = social.persist_friendship
    coordinator.on_friendship_compensate = social.compensate_friendship
    coordinator.start()
    supervisor.start()

    public = _Server(uvicorn.Config(create_public_app(), host=settings.public_host, port=settings.public_port,
                                    lifespan="off", log_level=settings.log_level.lower(), ws_max_size=64 * 1024,
                                    proxy_headers=False, server_header=False, ws="auto"))
    private = _Server(uvicorn.Config(create_private_app(), host=settings.private_host, port=settings.private_port,
                                     lifespan="off", log_level=settings.log_level.lower(), proxy_headers=False,
                                     server_header=False))

    async def owner_heartbeat() -> None:
        while True:
            await asyncio.sleep(1)
            try:
                await asyncio.wait_for(owner_conn.execute(
                    "UPDATE runtime_owner SET heartbeat_at = now() WHERE owner_epoch = %s", (epoch,)), timeout=2)
            except Exception:  # noqa: BLE001
                log.error("lost database owner connection; shutting down to protect authority")
                stop.set()
                return

    tasks = [
        asyncio.create_task(public.serve(), name="public-listener"),
        asyncio.create_task(private.serve(), name="private-listener"),
        asyncio.create_task(owner_heartbeat(), name="owner-heartbeat"),
        asyncio.create_task(stop.wait(), name="stop"),
    ]
    log.info("NoTitle owner epoch %s – public %s  private %s", epoch, settings.public_origin, settings.private_origin)
    done, _ = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
    exit_code = 0
    for task in done:
        if task.get_name() in ("public-listener", "private-listener"):
            exc = task.exception()
            log.error("listener %s stopped%s", task.get_name(), f": {exc}" if exc else "")
            exit_code = 5
    log.info("shutting down")
    public.should_exit = True
    private.should_exit = True
    await coordinator.stop()
    await supervisor.stop()
    for task in tasks:
        if not task.done():
            task.cancel()
    await asyncio.gather(*tasks, return_exceptions=True)
    with contextlib.suppress(Exception):
        await owner_conn.execute("SELECT pg_advisory_unlock(%s)", (OWNER_LOCK_ID,))
        await owner_conn.close()
    await db.close_pool()
    log.info("stopped")
    return exit_code


def main() -> None:
    stop_holder: dict[str, asyncio.Event] = {}

    async def runner() -> int:
        stop = asyncio.Event()
        stop_holder["stop"] = stop
        loop = asyncio.get_running_loop()

        def handle(*_: object) -> None:
            loop.call_soon_threadsafe(stop.set)

        signal.signal(signal.SIGINT, handle)
        if hasattr(signal, "SIGTERM"):
            signal.signal(signal.SIGTERM, handle)
        if hasattr(signal, "SIGBREAK"):
            signal.signal(signal.SIGBREAK, handle)  # Ctrl+Break / console close on Windows
        return await run(stop)

    code = asyncio.run(runner(), loop_factory=asyncio.SelectorEventLoop)
    sys.exit(code)


if __name__ == "__main__":
    main()
