"""Password hashing (Argon2id) with bounded concurrency.

Hashing is CPU/memory heavy, so it runs in a worker thread behind a semaphore
(blueprint: at most two concurrent hashing jobs) and never blocks the event loop.
"""

from __future__ import annotations

import asyncio
import unicodedata

from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError, VerifyMismatchError

from app.config import get_settings

_settings = get_settings()
# 64 MiB / 3 iterations / parallelism 1 (blueprint chapter 21).  Tests use a
# lighter profile so the suite stays fast; hashes store their own parameters.
_hasher = (
    PasswordHasher(time_cost=1, memory_cost=8 * 1024, parallelism=1)
    if _settings.app_env == "test"
    else PasswordHasher(time_cost=3, memory_cost=64 * 1024, parallelism=1)
)
_semaphore: asyncio.Semaphore | None = None
# Dummy hash so unknown usernames take the same time as wrong passwords.
_DUMMY_HASH = _hasher.hash("notitle-timing-equaliser-password")


def _sem() -> asyncio.Semaphore:
    global _semaphore
    if _semaphore is None:
        _semaphore = asyncio.Semaphore(2)
    return _semaphore


def validate_password(password: str) -> str | None:
    """Return an error message, or None when acceptable (12–128 code points, ≤512 bytes)."""
    if len(password) < 12:
        return "Password must be at least 12 characters."
    if len(password) > 128 or len(password.encode("utf-8")) > 512:
        return "Password must be at most 128 characters."
    if any(unicodedata.category(ch) == "Cc" for ch in password):
        return "Password contains unsupported control characters."
    return None


async def hash_password(password: str) -> str:
    async with _sem():
        return await asyncio.to_thread(_hasher.hash, password)


def _verify(stored: str | None, password: str) -> tuple[bool, bool]:
    try:
        ok = _hasher.verify(stored or _DUMMY_HASH, password)
        return (ok and stored is not None), (stored is not None and _hasher.check_needs_rehash(stored))
    except (VerifyMismatchError, VerificationError, InvalidHashError):
        return False, False


async def verify_password(stored: str | None, password: str) -> tuple[bool, bool]:
    """Return (valid, needs_rehash).  ``stored=None`` still spends equal time."""
    async with _sem():
        return await asyncio.to_thread(_verify, stored, password)
