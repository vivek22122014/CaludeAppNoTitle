"""Cryptographic primitives.

* Tokens and secrets: 256 bits from ``secrets``.
* Verifiers: keyed HMAC-SHA256 so a database leak does not reveal tokens.
* Content encryption: AES-256-GCM envelopes.  Each record class gets a random
  data key that is stored wrapped (AES-GCM) under the wrapping key; the
  associated data binds ciphertext to its table/record/field so blobs cannot be
  swapped between rows.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
from dataclasses import dataclass

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from app.config import get_settings

WRAPPING_KEY_VERSION = 1
_B32 = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # no I, O, 0, 1 to avoid confusion


def b64u(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def b64u_decode(value: str) -> bytes:
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))


def new_token() -> str:
    """Opaque 256-bit bearer token (cookie values, tickets)."""
    return secrets.token_urlsafe(32)


def new_ref(prefix: str) -> str:
    """Public reference with 128 random bits.  References are never authority."""
    return f"{prefix}_{secrets.token_urlsafe(16)}"


def new_secret_code(groups: int = 13) -> str:
    """Human-copyable secret (recovery codes, receipt secrets): 13x4 chars ≈ 260 bits."""
    return "-".join("".join(secrets.choice(_B32) for _ in range(4)) for _ in range(groups))


def normalize_code(code: str) -> str:
    return "".join(ch for ch in code.upper() if ch.isalnum())


def hmac_digest(*parts: str | bytes, purpose: str) -> bytes:
    key = get_settings().key_bytes("hmac_key")
    mac = hmac.new(key, purpose.encode() + b"\x00", hashlib.sha256)
    for part in parts:
        data = part.encode() if isinstance(part, str) else part
        mac.update(len(data).to_bytes(4, "big"))
        mac.update(data)
    return mac.digest()


def token_verifier(token: str, purpose: str) -> bytes:
    return hmac_digest(token, purpose=purpose)


def code_verifier(code: str, purpose: str) -> bytes:
    return hmac_digest(normalize_code(code), purpose=purpose)


def constant_equals(a: bytes | str, b: bytes | str) -> bool:
    if isinstance(a, str):
        a = a.encode()
    if isinstance(b, str):
        b = b.encode()
    return hmac.compare_digest(a, b)


def payload_digest(payload: object, purpose: str) -> bytes:
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
    return hmac_digest(canonical, purpose=purpose)


# ---------------------------------------------------------------------------
# Envelope encryption
# ---------------------------------------------------------------------------


def _wrapping_key() -> bytes:
    return get_settings().key_bytes("wrapping_key")


def wrap_key(data_key: bytes, purpose: str) -> bytes:
    nonce = os.urandom(12)
    return nonce + AESGCM(_wrapping_key()).encrypt(nonce, data_key, f"wrap:{purpose}".encode())


def unwrap_key(wrapped: bytes, purpose: str) -> bytes:
    return AESGCM(_wrapping_key()).decrypt(wrapped[:12], wrapped[12:], f"wrap:{purpose}".encode())


@dataclass(frozen=True)
class DataKey:
    id: str
    purpose: str
    key: bytes

    def encrypt(self, plaintext: str, aad: str) -> bytes:
        nonce = os.urandom(12)
        return nonce + AESGCM(self.key).encrypt(nonce, plaintext.encode("utf-8"), self._aad(aad))

    def decrypt(self, blob: bytes, aad: str) -> str:
        blob = bytes(blob)
        return AESGCM(self.key).decrypt(blob[:12], blob[12:], self._aad(aad)).decode("utf-8")

    def _aad(self, aad: str) -> bytes:
        return f"{self.purpose}|{self.id}|{aad}".encode()


def generate_data_key() -> bytes:
    return AESGCM.generate_key(bit_length=256)


def journal_mac(data: bytes) -> str:
    key = get_settings().key_bytes("journal_key")
    return hmac.new(key, data, hashlib.sha256).hexdigest()
