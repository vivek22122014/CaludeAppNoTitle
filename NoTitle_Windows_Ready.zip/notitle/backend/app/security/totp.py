"""Staff TOTP: 6 digits, 30-second step, ±1 step tolerance, replay protection."""

from __future__ import annotations

import time

import pyotp


def new_totp_secret() -> str:
    return pyotp.random_base32(32)


def provisioning_uri(secret: str, username: str, issuer: str = "NoTitle Staff") -> str:
    return pyotp.TOTP(secret).provisioning_uri(name=username, issuer_name=issuer)


def current_code(secret: str) -> str:
    return pyotp.TOTP(secret).now()


def verify_totp(secret: str, code: str, last_counter: int | None, now: float | None = None) -> int | None:
    """Return the accepted counter, or None.  Codes at or before ``last_counter`` are rejected."""
    code = "".join(ch for ch in code if ch.isdigit())
    if len(code) != 6:
        return None
    totp = pyotp.TOTP(secret)
    now = time.time() if now is None else now
    current = int(now // 30)
    for counter in (current - 1, current, current + 1):
        if last_counter is not None and counter <= last_counter:
            continue
        if pyotp.utils.strings_equal(totp.generate_otp(counter), code):
            return counter
    return None
