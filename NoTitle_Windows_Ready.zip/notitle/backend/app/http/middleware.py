"""ASGI middleware: request IDs, body limits, Origin/Host checks, headers, metrics."""

from __future__ import annotations

import json
import secrets
import time
from typing import Awaitable, Callable

from starlette.types import ASGIApp, Message, Receive, Scope, Send

from app.http.errors import request_id_var

UNSAFE_METHODS = {"POST", "PUT", "PATCH", "DELETE"}

# Per-route body limits (blueprint chapter 20): ordinary 8 KiB, support/report
# 12 KiB, raw provider webhooks 256 KiB.
DEFAULT_BODY_LIMIT = 8 * 1024
LARGE_BODY_PREFIXES = ("/api/v1/support", "/api/v1/reports", "/api/v1/billing/refund-requests",
                       "/internal/v1/cases", "/api/v1/privacy/requests")
WEBHOOK_PREFIX = "/api/v1/webhooks/"


def _body_limit(path: str) -> int:
    if path.startswith(WEBHOOK_PREFIX):
        return 256 * 1024
    if path.startswith(LARGE_BODY_PREFIXES):
        return 12 * 1024
    return DEFAULT_BODY_LIMIT


def _json_error(status: int, code: str, message: str, request_id: str) -> tuple[dict, bytes]:
    body = json.dumps({"error": {"code": code, "message": message, "retryable": False}, "request_id": request_id}).encode()
    start = {
        "type": "http.response.start",
        "status": status,
        "headers": [(b"content-type", b"application/json"), (b"cache-control", b"no-store"),
                    (b"content-length", str(len(body)).encode())],
    }
    return start, body


class EdgeMiddleware:
    """Combines the cheap pre-dispatch checks so every request pays one wrapper."""

    def __init__(self, app: ASGIApp, *, allowed_origins: Callable[[], set[str]], surface: str,
                 csp_for_path: Callable[[str], str | None] | None = None) -> None:
        self.app = app
        self.allowed_origins = allowed_origins
        self.surface = surface
        self.csp_for_path = csp_for_path

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] not in ("http", "websocket"):
            await self.app(scope, receive, send)
            return

        request_id = "req_" + secrets.token_urlsafe(9)
        token = request_id_var.set(request_id)
        try:
            if scope["type"] == "websocket":
                await self.app(scope, receive, send)
                return
            await self._http(scope, receive, send, request_id)
        finally:
            request_id_var.reset(token)

    async def _http(self, scope: Scope, receive: Receive, send: Send, request_id: str) -> None:
        from app.services.analytics import metrics

        method = scope["method"]
        path: str = scope["path"]
        headers = {k.decode("latin-1").lower(): v.decode("latin-1") for k, v in scope["headers"]}
        started = time.perf_counter()
        is_api = path.startswith(("/api/", "/internal/"))

        async def reject(status: int, code: str, message: str) -> None:
            start, body = _json_error(status, code, message, request_id)
            await send(start)
            await send({"type": "http.response.body", "body": body})

        if is_api:
            metrics.incr("requests_total")

        # Credentials in URLs are never accepted.
        query = scope.get("query_string", b"").decode("latin-1").lower()
        if is_api and (b"@" in scope.get("raw_path", b"") or any(
                f"{name}=" in query for name in ("token", "secret", "password", "ticket"))):
            await reject(400, "bad_request", "Credentials are not accepted in URLs.")
            return

        if method in UNSAFE_METHODS and is_api and not path.startswith(WEBHOOK_PREFIX):
            origin = headers.get("origin")
            if origin is None:
                referer = headers.get("referer", "")
                origin = "/".join(referer.split("/")[:3]) if referer else None
            if not origin or origin.rstrip("/") not in self.allowed_origins():
                await reject(403, "origin_rejected", "Request origin is not allowed. Open the site at its configured address.")
                return

        declared = headers.get("content-length")
        limit = _body_limit(path)
        if declared is not None:
            try:
                if int(declared) > limit:
                    await reject(413, "too_large", "Request body is too large.")
                    return
            except ValueError:
                await reject(400, "bad_request", "Invalid Content-Length.")
                return

        received = 0
        too_large = False

        async def limited_receive() -> Message:
            nonlocal received, too_large
            message = await receive()
            if message["type"] == "http.request":
                received += len(message.get("body", b""))
                if received > limit:
                    too_large = True
                    raise _BodyTooLarge()
            return message

        status_holder = {"status": 500}
        csp = self.csp_for_path(path) if self.csp_for_path and not is_api else None

        async def wrapped_send(message: Message) -> None:
            if message["type"] == "http.response.start":
                status_holder["status"] = message["status"]
                raw = list(message.get("headers", []))
                raw.append((b"x-request-id", request_id.encode()))
                raw.append((b"x-content-type-options", b"nosniff"))
                raw.append((b"referrer-policy", b"same-origin"))  # no-referrer makes Chrome send Origin: null on form POSTs
                raw.append((b"x-frame-options", b"DENY"))
                raw.append((b"cross-origin-opener-policy", b"same-origin"))
                raw.append((b"permissions-policy", b"camera=(), geolocation=(), microphone=(self)"))
                if self.surface == "private":
                    raw.append((b"x-robots-tag", b"noindex, nofollow"))
                if csp:
                    raw.append((b"content-security-policy", csp.encode()))
                message["headers"] = raw
            await send(message)

        try:
            await self.app(scope, limited_receive, wrapped_send)
        except _BodyTooLarge:
            await reject(413, "too_large", "Request body is too large.")
            return
        finally:
            if is_api:
                metrics.observe("api_latency_ms", (time.perf_counter() - started) * 1000)
                if status_holder["status"] >= 500:
                    metrics.incr("server_errors")
        if too_large:
            return


class _BodyTooLarge(Exception):
    pass


Handler = Callable[[Scope, Receive, Send], Awaitable[None]]
