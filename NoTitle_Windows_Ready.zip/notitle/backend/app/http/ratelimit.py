"""Bounded in-memory token buckets.

Keys combine a purpose with an identity (or a short-lived network key).  The
table is capped and least-recently-used keys are evicted, so it cannot grow into
a fingerprint database; nothing here is persisted.
"""

from __future__ import annotations

import time
from collections import OrderedDict
from dataclasses import dataclass

from app.http.errors import rate_limited


@dataclass
class _Bucket:
    tokens: float
    updated: float


class RateLimiter:
    def __init__(self, max_keys: int = 50_000) -> None:
        self._buckets: OrderedDict[str, _Bucket] = OrderedDict()
        self._max = max_keys

    def allow(self, key: str, rate: float, burst: int, cost: float = 1.0, now: float | None = None) -> bool:
        now = time.monotonic() if now is None else now
        bucket = self._buckets.get(key)
        if bucket is None:
            bucket = _Bucket(tokens=float(burst), updated=now)
            self._buckets[key] = bucket
            if len(self._buckets) > self._max:
                self._buckets.popitem(last=False)
        else:
            self._buckets.move_to_end(key)
            bucket.tokens = min(float(burst), bucket.tokens + (now - bucket.updated) * rate)
            bucket.updated = now
        if bucket.tokens >= cost:
            bucket.tokens -= cost
            return True
        return False

    def check(self, key: str, rate: float, burst: int) -> None:
        if not self.allow(key, rate, burst):
            raise rate_limited(max(1, int(1 / rate) if rate else 5))


limiter = RateLimiter()

# Named budgets (blueprint chapter 07).
LIMITS: dict[str, tuple[float, int]] = {
    "text": (5, 10),
    "command": (10, 20),
    "queue": (1, 3),
    "sdp": (2, 4),
    "ice": (20, 64),
    "login": (0.2, 5),        # 5 attempts then 1 per 5 s
    "register": (0.05, 3),
    "guest": (0.2, 5),
    "ticket": (0.5, 5),
    "support_write": (10 / 60, 3),
    "support_create": (5 / 86400, 5),
    "report": (0.1, 3),
    "staff_login": (0.1, 5),
    "purchase": (0.2, 3),
    "export": (1 / 600, 2),
}


def check(purpose: str, identity: str) -> None:
    rate, burst = LIMITS[purpose]
    from app.config import get_settings

    if get_settings().app_env == "test":
        # The automated suites drive many identities from one address; limits stay
        # active but scaled.  RateLimiter itself is unit-tested with real budgets.
        rate, burst = rate * 50, burst * 50
    limiter.check(f"{purpose}:{identity}", rate, burst)
