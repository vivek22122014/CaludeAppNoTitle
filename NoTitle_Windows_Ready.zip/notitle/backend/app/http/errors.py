"""Uniform response envelopes.

Success: ``{"data": ..., "request_id": "req_..."}``
Failure: ``{"error": {"code", "message", "fields"?, "retryable"}, "request_id"}``

Tracebacks, SQL and account-existence differences never reach clients.
"""

from __future__ import annotations

import contextvars
import logging
from typing import Any

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

log = logging.getLogger("notitle.http")

request_id_var: contextvars.ContextVar[str] = contextvars.ContextVar("request_id", default="req_none")

NO_STORE = {"Cache-Control": "no-store", "Pragma": "no-cache"}


class ApiError(Exception):
    def __init__(
        self,
        status: int,
        code: str,
        message: str,
        *,
        fields: dict[str, str] | None = None,
        retryable: bool = False,
        retry_after: int | None = None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.code = code
        self.message = message
        self.fields = fields
        self.retryable = retryable
        self.retry_after = retry_after
        self.extra = extra or {}


def bad_request(message: str = "The request is malformed.") -> ApiError:
    return ApiError(400, "bad_request", message)


def unauthenticated(message: str = "Please sign in to continue.") -> ApiError:
    return ApiError(401, "unauthenticated", message)


def forbidden(message: str = "You do not have access to this action.") -> ApiError:
    return ApiError(403, "forbidden", message)


def not_found(message: str = "Not found.") -> ApiError:
    return ApiError(404, "not_found", message)


def conflict(message: str, code: str = "conflict", **extra: Any) -> ApiError:
    return ApiError(409, code, message, extra=extra)


def gone(message: str = "This preparation has expired. Start again.") -> ApiError:
    return ApiError(410, "expired", message)


def invalid(field: str, message: str) -> ApiError:
    return ApiError(422, "invalid", message, fields={field: message})


def rate_limited(retry_after: int = 5) -> ApiError:
    return ApiError(429, "rate_limited", "Too many requests. Please wait and try again.", retryable=True, retry_after=retry_after)


def unavailable(message: str = "This feature is temporarily unavailable.", code: str = "unavailable") -> ApiError:
    return ApiError(503, code, message, retryable=True, retry_after=10)


def ok(data: Any = None, status: int = 200, headers: dict[str, str] | None = None) -> JSONResponse:
    response = JSONResponse({"data": data, "request_id": request_id_var.get()}, status_code=status)
    for key, value in {**NO_STORE, **(headers or {})}.items():
        response.headers[key] = value
    return response


def error_response(err: ApiError) -> JSONResponse:
    body: dict[str, Any] = {"code": err.code, "message": err.message, "retryable": err.retryable}
    if err.fields:
        body["fields"] = err.fields
    if err.extra:
        body["details"] = err.extra
    response = JSONResponse({"error": body, "request_id": request_id_var.get()}, status_code=err.status)
    for key, value in NO_STORE.items():
        response.headers[key] = value
    if err.retry_after:
        response.headers["Retry-After"] = str(err.retry_after)
    return response


_STATUS_CODES = {
    400: "bad_request",
    401: "unauthenticated",
    403: "forbidden",
    404: "not_found",
    405: "method_not_allowed",
    409: "conflict",
    410: "expired",
    413: "too_large",
    415: "unsupported_media_type",
    422: "invalid",
    429: "rate_limited",
    503: "unavailable",
}


def install_handlers(app: FastAPI) -> None:
    @app.exception_handler(ApiError)
    async def _api_error(_: Request, exc: ApiError) -> JSONResponse:
        if exc.status == 401 or exc.status == 403:
            from app.services.analytics import metrics

            metrics.incr("auth_denials")
        return error_response(exc)

    @app.exception_handler(RequestValidationError)
    async def _validation(_: Request, exc: RequestValidationError) -> JSONResponse:
        fields: dict[str, str] = {}
        for item in exc.errors()[:20]:
            loc = [str(p) for p in item.get("loc", []) if p not in ("body", "query", "path")]
            key = ".".join(loc) or "body"
            msg = str(item.get("msg", "Invalid value"))
            if msg.startswith("Value error, "):
                msg = msg[len("Value error, ") :]
            fields.setdefault(key, msg)
        return error_response(ApiError(422, "invalid", "Please correct the highlighted fields.", fields=fields))

    @app.exception_handler(StarletteHTTPException)
    async def _http(_: Request, exc: StarletteHTTPException) -> JSONResponse:
        code = _STATUS_CODES.get(exc.status_code, "error")
        message = exc.detail if isinstance(exc.detail, str) and exc.status_code < 500 else "Request failed."
        if exc.status_code == 404:
            message = "Not found."
        return error_response(ApiError(exc.status_code, code, message))

    @app.exception_handler(Exception)
    async def _unhandled(_: Request, exc: Exception) -> JSONResponse:
        log.exception("unhandled error request_id=%s", request_id_var.get())
        return error_response(ApiError(500, "internal", "Something went wrong. Please try again.", retryable=True))
