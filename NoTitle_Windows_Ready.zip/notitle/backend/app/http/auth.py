"""Principal resolution, cookies and CSRF for the public API.

Cookies (all HttpOnly, SameSite=Lax; Secure + ``__Host-`` prefix when
COOKIE_SECURE=true):

* ``nt_boot``    – bootstrap identity binding pre-auth CSRF and preparations
* ``nt_account`` – account session (7 days idle / 30 days absolute)
* ``nt_guest``   – guest session (30 minutes idle / 24 hours absolute)
* ``nt_support`` – one support case receipt session
* ``nt_receipt`` – one deletion/financial receipt session

CSRF: every unsafe request carries ``X-CSRF-Token`` = HMAC(boot id).  The token
is returned by ``GET /bootstrap`` (and auth responses); the boot cookie is
HttpOnly, so another site can neither read nor forge it.  Exact Origin checks
run first in the edge middleware.
"""

from __future__ import annotations

from dataclasses import dataclass
from fastapi import Request, Response

from app.config import get_settings
from app.http.errors import ApiError, forbidden, unauthenticated
from app.security import crypto
from app.services import identity

settings = get_settings()

BOOT = "nt_boot"
ACCOUNT = "nt_account"
GUEST = "nt_guest"
SUPPORT = "nt_support"
RECEIPT = "nt_receipt"
BOOT_MAX_AGE = 30 * 24 * 3600


def cookie(request: Request, base: str) -> str | None:
    name = settings.cookie_name(base)
    # Reject ambiguous duplicate cookies (cookie tossing) instead of guessing.
    raw = request.headers.get("cookie", "")
    if raw.count(f"{name}=") > 1:
        raise ApiError(400, "ambiguous_cookie", "Conflicting session cookies. Clear site cookies and retry.")
    return request.cookies.get(name)


def set_cookie(response: Response, base: str, value: str, max_age: int) -> None:
    response.set_cookie(
        settings.cookie_name(base), value, max_age=max_age, httponly=True, secure=settings.cookie_secure,
        samesite="lax", path="/",
    )


def clear_cookie(response: Response, base: str) -> None:
    response.delete_cookie(settings.cookie_name(base), path="/", secure=settings.cookie_secure,
                           httponly=True, samesite="lax")


def csrf_for(boot: str) -> str:
    return crypto.b64u(crypto.hmac_digest(boot, purpose="csrf"))


def boot_value(request: Request) -> tuple[str, bool]:
    """Return (boot id, is_new).  Callers set the cookie on their response when new."""
    boot = cookie(request, BOOT)
    if not boot or len(boot) < 30:
        return crypto.new_token(), True
    return boot, False


def set_boot(response: Response, boot: str) -> None:
    set_cookie(response, BOOT, boot, BOOT_MAX_AGE)


def require_boot(request: Request) -> str:
    boot = cookie(request, BOOT)
    if not boot:
        raise ApiError(403, "csrf_failed", "Your page session expired. Reload the page and try again.")
    return boot


def check_csrf(request: Request) -> str:
    boot = require_boot(request)
    supplied = request.headers.get("x-csrf-token", "")
    if not supplied or not crypto.constant_equals(supplied, csrf_for(boot)):
        raise ApiError(403, "csrf_failed", "Your page session expired. Reload the page and try again.")
    return boot


@dataclass
class Principal:
    kind: str  # 'account' | 'guest'
    key: str
    account: dict | None = None
    guest: identity.Guest | None = None

    @property
    def account_id(self) -> str | None:
        return str(self.account["id"]) if self.account else None

    @property
    def session_id(self) -> str | None:
        return str(self.account["session_id"]) if self.account else None

    @property
    def scope(self) -> str:
        return f"session:{self.session_id}" if self.account else f"guest:{self.guest.id}"  # type: ignore[union-attr]

    @property
    def subject_ref(self) -> str:
        if self.account:
            return identity.subject_ref_for_account(self.account_id or "")
        return identity.subject_ref_for_guest(self.guest.id)  # type: ignore[union-attr]


async def optional_principal(request: Request) -> Principal | None:
    token = cookie(request, ACCOUNT)
    if token:
        row = await identity.resolve_session(token)
        if row:
            return Principal(kind="account", key=f"a:{row['id']}", account=row)
    guest = identity.guests.resolve(cookie(request, GUEST), touch=True)
    if guest:
        return Principal(kind="guest", key=guest.key, guest=guest)
    return None


async def require_principal(request: Request) -> Principal:
    principal = await optional_principal(request)
    if principal is None:
        raise unauthenticated()
    return principal


async def require_account(request: Request) -> Principal:
    principal = await require_principal(request)
    if principal.kind != "account":
        raise forbidden("This needs a registered account.")
    return principal


def mutation(request: Request) -> str:
    """Dependency for every unsafe public route: CSRF (Origin was checked at the edge)."""
    return check_csrf(request)


def identity_label(principal: Principal | None, request: Request) -> str:
    if principal:
        return principal.key
    client = request.client.host if request.client else "unknown"
    return f"net:{client}"

