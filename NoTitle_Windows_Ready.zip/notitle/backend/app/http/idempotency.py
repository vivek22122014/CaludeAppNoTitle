"""Nonce-bound idempotent results.

A retried mutation with the same (scope, kind, client_nonce) and the same keyed
payload digest returns the original committed result for 24 hours; the same
nonce with a different payload is a 409 conflict.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from typing import Any

from app import db
from app.http.errors import conflict
from app.security.crypto import payload_digest

TTL = timedelta(hours=24)


async def lookup(scope: str, kind: str, nonce: str, payload: Any) -> dict | None:
    row = await db.fetch_one(
        "SELECT payload_digest, result FROM operation_results WHERE scope_ref = %s AND kind = %s AND client_nonce = %s",
        (scope, kind, nonce),
    )
    if row is None:
        return None
    if bytes(row["payload_digest"]) != payload_digest(payload, purpose=f"op:{kind}"):
        raise conflict("This request id was already used for different content.", code="nonce_conflict")
    return row["result"]


async def store(conn: Any, scope: str, kind: str, nonce: str, payload: Any, result: dict) -> None:
    await conn.execute(
        """INSERT INTO operation_results (scope_ref, kind, client_nonce, payload_digest, result, expires_at)
           VALUES (%s, %s, %s, %s, %s, %s)""",
        (scope, kind, nonce, payload_digest(payload, purpose=f"op:{kind}"), json.dumps(result, default=str),
         datetime.now(timezone.utc) + TTL),
    )
