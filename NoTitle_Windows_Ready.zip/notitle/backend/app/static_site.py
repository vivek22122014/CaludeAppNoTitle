"""Serves a Next.js static export (``output: 'export'``, ``trailingSlash: true``).

* ``/route/`` → ``route/index.html``; ``/route`` redirects to ``/route/``.
* Unknown paths return the export's real ``404.html`` with status 404.
* Each HTML file gets a Content-Security-Policy whose ``script-src`` lists the
  SHA-256 hashes of that file's inline scripts – no ``unsafe-inline``/``eval``.
* Hashed ``/_next/static`` assets are cached immutably; HTML is ``no-cache``.
"""

from __future__ import annotations

import base64
import hashlib
import mimetypes
import re
from functools import lru_cache
from pathlib import Path

from starlette.responses import FileResponse, HTMLResponse, RedirectResponse, Response
from starlette.types import Receive, Scope, Send

mimetypes.add_type("application/javascript", ".js")
mimetypes.add_type("text/css", ".css")
mimetypes.add_type("image/svg+xml", ".svg")
mimetypes.add_type("application/manifest+json", ".webmanifest")
mimetypes.add_type("text/plain", ".txt")

_INLINE_SCRIPT = re.compile(rb"<script(?![^>]*\bsrc=)[^>]*>(.*?)</script>", re.S | re.I)

NOT_BUILT = """<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Frontend not built</title>
<style>body{font-family:system-ui;max-width:640px;margin:60px auto;padding:0 16px;line-height:1.5}</style></head>
<body><h1>The {name} frontend has not been built yet</h1>
<p>The API is running. Build the static site, then reload this page:</p>
<pre>scripts\\build.ps1</pre><p>Or run the full setup: <code>scripts\\setup.ps1</code>.</p></body></html>"""


class StaticSite:
    def __init__(self, root: str, name: str, extra_script_src: tuple[str, ...] = (),
                 extra_connect_src: tuple[str, ...] = (), frame_src: tuple[str, ...] = ()) -> None:
        self.root = Path(root)
        self.name = name
        self.extra_script_src = extra_script_src
        self.extra_connect_src = extra_connect_src
        self.frame_src = frame_src

    def built(self) -> bool:
        return (self.root / "index.html").exists()

    def _resolve(self, path: str) -> tuple[Path | None, str | None]:
        rel = path.lstrip("/")
        if ".." in rel.split("/") or "\\" in rel or "\x00" in rel:
            return None, None
        candidate = (self.root / rel).resolve()
        try:
            candidate.relative_to(self.root.resolve())
        except ValueError:
            return None, None
        if candidate.is_file():
            return candidate, None
        if candidate.is_dir() and (candidate / "index.html").is_file():
            if not path.endswith("/"):
                return None, path + "/"
            return candidate / "index.html", None
        html = candidate.with_suffix(".html") if candidate.suffix == "" else None
        if html and html.is_file():
            return html, None
        segment = self._segment_payload(candidate)
        if segment is not None:
            return segment, None
        return None, None

    @staticmethod
    def _segment_payload(candidate: Path) -> Path | None:
        """Next 16 prefetches ``__next.a.b.__PAGE__.txt`` but exports ``__next.a/b/__PAGE__.txt``."""
        name = candidate.name
        if not (name.startswith("__next.") and name.endswith(".txt")):
            return None
        parts = name[: -len(".txt")].split(".")
        if len(parts) < 3:
            return None
        mapped = candidate.parent / f"__next.{parts[1]}" / Path(*parts[2:-1], parts[-1] + ".txt")
        return mapped if mapped.is_file() else None

    @lru_cache(maxsize=512)  # noqa: B019 - bounded per-file cache
    def csp_for_file(self, file: str, mtime: float) -> str:
        data = Path(file).read_bytes()
        hashes = sorted({"'sha256-" + base64.b64encode(hashlib.sha256(m).digest()).decode() + "'"
                         for m in _INLINE_SCRIPT.findall(data) if m.strip()})
        script_src = " ".join(["'self'", *hashes, *self.extra_script_src])
        connect_src = " ".join(["'self'", "ws:", "wss:", *self.extra_connect_src])
        frame_src = " ".join(self.frame_src) if self.frame_src else "'none'"
        return ("default-src 'self'; "
                f"script-src {script_src}; "
                "style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; "
                f"connect-src {connect_src}; frame-src {frame_src}; "
                "media-src 'self' blob:; object-src 'none'; "
                "frame-ancestors 'none'; base-uri 'self'; form-action 'self'")

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            return
        method = scope["method"]
        if method not in ("GET", "HEAD"):
            await Response("Method not allowed", status_code=405)(scope, receive, send)
            return
        path = scope["path"]
        if path.startswith(("/api/", "/internal/", "/health/")):
            # API namespaces never fall through to the static site.
            body = b'{"error":{"code":"not_found","message":"Not found.","retryable":false},"request_id":null}'
            await Response(body, status_code=404, media_type="application/json",
                           headers={"Cache-Control": "no-store"})(scope, receive, send)
            return
        if not self.built():
            await HTMLResponse(NOT_BUILT.replace("{name}", self.name), status_code=503,
                               headers={"Cache-Control": "no-store"})(scope, receive, send)
            return
        file, redirect = self._resolve(path)
        if redirect:
            query = scope.get("query_string", b"").decode()
            await RedirectResponse(redirect + (f"?{query}" if query else ""), status_code=308)(scope, receive, send)
            return
        status = 200
        if file is None:
            file = self.root / "404.html"
            status = 404
            if not file.exists():
                await Response("Not found", status_code=404)(scope, receive, send)
                return
        headers = {}
        if file.suffix == ".html":
            headers["Cache-Control"] = "no-cache"
            headers["Content-Security-Policy"] = self.csp_for_file(str(file), file.stat().st_mtime)
        elif "/_next/static/" in path:
            headers["Cache-Control"] = "public, max-age=31536000, immutable"
        else:
            headers["Cache-Control"] = "public, max-age=3600"
        media_type = mimetypes.guess_type(file.name)[0] or "application/octet-stream"
        await FileResponse(file, status_code=status, headers=headers, media_type=media_type)(scope, receive, send)
