"""Versioned policy documents.

``backend/policies/*.md`` is the single source for both the backend (versions
and SHA-256 digests bound into consent proof) and the static frontend pages.
Each file starts with a small front-matter block::

    ---
    kind: privacy
    title: Privacy Policy
    version: 2026-10-draft.1
    route: /privacy
    ---
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

from app.config import BACKEND_DIR

POLICY_DIR = BACKEND_DIR / "policies"

# Consent purposes map to the policy whose text the user accepts.
CONSENT_POLICY = {
    "adult": "terms",
    "terms": "terms",
    "core": "privacy",
    "professional": "privacy",
}
REQUIRED_PURPOSES = ("adult", "terms", "core")


@dataclass(frozen=True)
class Policy:
    kind: str
    title: str
    version: str
    route: str
    body: str
    digest: str
    state: str

    def summary(self) -> dict:
        return {
            "kind": self.kind,
            "title": self.title,
            "version": self.version,
            "route": self.route,
            "digest": self.digest,
            "publication_state": self.state,
        }


def _parse(path: Path) -> Policy:
    raw = path.read_bytes().replace(b"\r\n", b"\n")
    text = raw.decode("utf-8")
    if not text.startswith("---\n"):
        raise ValueError(f"{path.name}: missing front matter")
    _, header, body = text.split("---\n", 2)
    meta: dict[str, str] = {}
    for line in header.strip().splitlines():
        key, _, value = line.partition(":")
        meta[key.strip()] = value.strip()
    for field in ("kind", "title", "version", "route"):
        if not meta.get(field):
            raise ValueError(f"{path.name}: front matter field {field} missing")
    return Policy(
        kind=meta["kind"],
        title=meta["title"],
        version=meta["version"],
        route=meta["route"],
        body=body.strip(),
        digest=hashlib.sha256(raw).hexdigest(),
        state=meta.get("state", "draft"),
    )


@lru_cache
def all_policies() -> dict[str, Policy]:
    out: dict[str, Policy] = {}
    for path in sorted(POLICY_DIR.glob("*.md")):
        policy = _parse(path)
        out[policy.kind] = policy
    return out


def get(kind: str) -> Policy:
    return all_policies()[kind]


def current_versions() -> dict[str, str]:
    return {kind: p.version for kind, p in all_policies().items()}


def lint() -> list[str]:
    """Publication checks: no email addresses, no unsupported compliance claims,
    consistent no-voluntary-refund wording."""
    import re

    problems = []
    email = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
    for policy in all_policies().values():
        if email.search(policy.body):
            problems.append(f"{policy.kind}: contains an email address (no support email is published)")
        if re.search(r"fully compliant|guaranteed compliance|100% secure", policy.body, re.I):
            problems.append(f"{policy.kind}: contains an unsupported compliance claim")
        if re.search(r"24[- ]hour (unused|refund)", policy.body, re.I):
            problems.append(f"{policy.kind}: mentions the removed 24-hour refund offer")
    for required in ("privacy", "terms", "community", "cookies", "retention", "refund"):
        if required not in all_policies():
            problems.append(f"missing required policy: {required}")
    return problems
