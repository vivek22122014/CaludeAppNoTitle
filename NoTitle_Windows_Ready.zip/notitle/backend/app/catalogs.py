"""Versioned allowlisted catalogs (topics and private professional categories).

Professional values are controlled categories, never employer free text.
"""

from __future__ import annotations

CATALOG_VERSION = "2026-10-1"

GENERAL_TOPIC = "general"

TOPICS: list[tuple[str, str]] = [
    ("general", "General Talk"),
    ("careers", "Careers and job search"),
    ("salaries", "Salaries and compensation"),
    ("hiring", "Hiring and interviews"),
    ("culture", "Company culture"),
    ("politics", "Office politics"),
    ("leadership", "Management and leadership"),
    ("industry", "Industry experience"),
    ("balance", "Work-life balance"),
    ("switching", "Career switching"),
    ("startups", "Startups and entrepreneurship"),
    ("remote", "Remote and hybrid work"),
]

INDUSTRIES: list[tuple[str, str]] = [
    ("technology", "Technology and software"),
    ("finance", "Banking, finance and insurance"),
    ("consulting", "Consulting and professional services"),
    ("healthcare", "Healthcare and life sciences"),
    ("manufacturing", "Manufacturing and engineering"),
    ("retail", "Retail and e-commerce"),
    ("education", "Education"),
    ("media", "Media, marketing and advertising"),
    ("public", "Government and public sector"),
    ("legal", "Legal"),
    ("energy", "Energy and utilities"),
    ("telecom", "Telecom"),
    ("other", "Other industry"),
]

ROLES: list[tuple[str, str]] = [
    ("engineering", "Engineering"),
    ("product", "Product management"),
    ("design", "Design"),
    ("data", "Data and analytics"),
    ("sales", "Sales"),
    ("marketing", "Marketing"),
    ("operations", "Operations"),
    ("people", "HR and people"),
    ("finance", "Finance and accounting"),
    ("legal", "Legal and compliance"),
    ("support", "Customer support"),
    ("leadership", "Leadership and executive"),
    ("research", "Research"),
    ("other", "Other role"),
]

EXPERIENCE: list[tuple[str, str]] = [
    ("student", "Student or intern"),
    ("0_2", "0–2 years"),
    ("3_5", "3–5 years"),
    ("6_10", "6–10 years"),
    ("11_15", "11–15 years"),
    ("16_plus", "16+ years"),
]

INTERESTS: list[tuple[str, str]] = [
    ("growth", "Career growth"),
    ("compensation", "Compensation"),
    ("negotiation", "Negotiation"),
    ("leadership", "Leadership"),
    ("mentoring", "Mentoring"),
    ("job_switch", "Changing jobs"),
    ("studies", "Higher studies"),
    ("entrepreneurship", "Entrepreneurship"),
    ("remote", "Remote work"),
    ("upskilling", "Upskilling"),
    ("wellbeing", "Workplace wellbeing"),
    ("layoffs", "Layoffs and job security"),
    ("appraisals", "Appraisals and promotions"),
    ("interviewing", "Interviewing"),
]

GENDERS = ("male", "female", "other")
GENDER_PREFERENCES = ("everyone", "male", "female", "other")

REPORT_REASONS = (
    "harassment", "threats", "doxxing", "confidentiality", "false_accusation", "scam",
    "impersonation", "underage", "sexual_misconduct", "spam", "other",
)
CASE_CATEGORIES = ("general", "payment", "safety", "privacy", "appeal", "security")
CASE_STATUSES = ("open", "in_progress", "waiting_user", "resolved", "closed")

TOPIC_IDS = {t for t, _ in TOPICS}
INDUSTRY_IDS = {t for t, _ in INDUSTRIES}
ROLE_IDS = {t for t, _ in ROLES}
EXPERIENCE_IDS = {t for t, _ in EXPERIENCE}
INTEREST_IDS = {t for t, _ in INTERESTS}


def as_dict() -> dict:
    def items(rows: list[tuple[str, str]]) -> list[dict]:
        return [{"id": i, "label": label} for i, label in rows]

    return {
        "version": CATALOG_VERSION,
        "topics": items(TOPICS),
        "industries": items(INDUSTRIES),
        "roles": items(ROLES),
        "experience": items(EXPERIENCE),
        "interests": items(INTERESTS),
        "genders": [{"id": g, "label": g.capitalize()} for g in GENDERS],
        "report_reasons": list(REPORT_REASONS),
        "case_categories": list(CASE_CATEGORIES),
    }
