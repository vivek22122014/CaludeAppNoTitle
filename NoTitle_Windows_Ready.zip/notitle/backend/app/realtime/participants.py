"""Builds coordinator participants from durable (account) or RAM (guest) identity."""

from __future__ import annotations

from app import db
from app.realtime.coordinator import Participant, relationship_id_for
from app.services import identity


async def restriction_until(subject_ref: str) -> float | None:
    row = await db.fetch_one(
        """SELECT bool_or(ends_at IS NULL) AS permanent, max(ends_at) AS until FROM restrictions
           WHERE subject_ref = %s AND lifted_at IS NULL AND starts_at <= now()
             AND (ends_at IS NULL OR ends_at > now())""",
        (subject_ref,),
    )
    if not row or (row["permanent"] is None and row["until"] is None):
        return None
    if row["permanent"]:
        return float("inf")
    return row["until"].timestamp()


async def for_account(account_id: str) -> Participant:
    from app.services import billing

    account = await db.fetch_one("SELECT * FROM accounts WHERE id = %s", (account_id,))
    if account is None or account["status"] != "active":
        raise LookupError("account not active")
    profile = await identity.load_profile(account_id)
    consents = await identity.current_consents(account_id)
    professional_ok = consents.get("professional", {}).get("choice", False)
    core_ok = consents.get("core", {}).get("choice", False)
    prefs = profile["preferences"]
    blocks = await db.fetch_all(
        "SELECT blocked_id AS other FROM blocks WHERE blocker_id = %s UNION SELECT blocker_id FROM blocks WHERE blocked_id = %s",
        (account_id, account_id),
    )
    friends = await db.fetch_all(
        """SELECT CASE WHEN low_account_id = %s THEN high_account_id ELSE low_account_id END AS other
           FROM friendships WHERE state = 'active' AND (low_account_id = %s OR high_account_id = %s)""",
        (account_id, account_id, account_id),
    )
    p = Participant(
        key=f"a:{account_id}",
        kind="account",
        account_id=account_id,
        display_name=account["display_name"],
        gender=account["gender"],
        topic_id=account["topic_id"],
        bio=account["bio"],
        professional=profile["professional"] if professional_ok else None,
        gender_preference=prefs["gender_preference"],
        professional_enabled=bool(prefs["professional_enabled"] and professional_ok),
        wanted={k: prefs[k] for k in ("industry_ids", "role_ids", "experience_ids", "interest_ids", "topic_ids")},
        premium_until=await billing.premium_until(account_id),
        core_consent=core_ok,
        restricted_until=await restriction_until(identity.subject_ref_for_account(account_id)),
    )
    p.blocked = {f"a:{row['other']}" for row in blocks}
    for row in friends:
        other = str(row["other"])
        rel_id = relationship_id_for(account_id, other)
        p.friends[rel_id] = f"a:{other}"
        p.friend_saved[rel_id] = True
    return p


async def for_guest(guest: identity.Guest) -> Participant:
    professional_ok = guest.consents.get("professional", {}).get("choice", False)
    prefs = guest.preferences
    return Participant(
        key=guest.key,
        kind="guest",
        account_id=None,
        display_name=guest.display_name,
        gender=guest.gender,
        topic_id=guest.topic_id,
        bio=guest.bio,
        professional=guest.professional if professional_ok else None,
        gender_preference="everyone",
        professional_enabled=False,  # guests cannot purchase, so saved choices have no influence
        wanted={k: prefs.get(k, []) for k in ("industry_ids", "role_ids", "experience_ids", "interest_ids", "topic_ids")},
        premium_until=0.0,
        core_consent=guest.consents.get("core", {}).get("choice", False),
        restricted_until=await restriction_until(identity.subject_ref_for_guest(guest.id)),
    )

