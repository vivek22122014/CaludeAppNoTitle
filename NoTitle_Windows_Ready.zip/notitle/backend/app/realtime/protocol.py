"""Realtime wire protocol, version 2.

Client → server envelope::

    {"v": 2, "id": "<uuid>", "type": "text.send", "payload": {...}}

Server → client envelope::

    {"v": 2, "seq": 17, "type": "text.received", "ts": "...", "payload": {...},
     "reply_to": "<command id>"?}

Every payload is a strict Pydantic model (unknown fields rejected).  Frames are
limited to 8 KiB, except ``call.sdp`` (64 KiB).
"""

from __future__ import annotations

import json
import re
from typing import Any, Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator

PROTOCOL_VERSION = 2
MAX_FRAME = 8 * 1024
MAX_SDP_FRAME = 64 * 1024
MAX_TEXT_CHARS = 2000
MAX_TEXT_BYTES = 6 * 1024


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Empty(_Strict):
    pass


class Hello(_Strict):
    ticket: str = Field(min_length=20, max_length=200)


class Heartbeat(_Strict):
    echo: int | None = None


class QueueJoin(_Strict):
    accept_everyone: bool = False


class InteractionRef(_Strict):
    interaction_id: str = Field(min_length=3, max_length=64)


class TextSend(_Strict):
    interaction_id: str = Field(min_length=3, max_length=64)
    client_id: str = Field(min_length=1, max_length=64)
    body: str

    @field_validator("body")
    @classmethod
    def _bounded(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Message is empty")
        if len(value) > MAX_TEXT_CHARS:
            raise ValueError("Message exceeds 2000 characters")
        if len(value.encode("utf-8")) > MAX_TEXT_BYTES:
            raise ValueError("Message exceeds 6 KiB")
        return value


class TextDelivered(_Strict):
    interaction_id: str = Field(min_length=3, max_length=64)
    message_id: str = Field(min_length=3, max_length=64)


class FriendRespond(_Strict):
    request_id: str = Field(min_length=3, max_length=64)
    accept: bool


class FriendInvite(_Strict):
    relationship_id: str = Field(min_length=3, max_length=64)


class InviteRespond(_Strict):
    invite_id: str = Field(min_length=3, max_length=64)
    accept: bool


class InviteCancel(_Strict):
    invite_id: str = Field(min_length=3, max_length=64)


class CallRef(_Strict):
    call_id: str = Field(min_length=3, max_length=64)


class CallRespond(_Strict):
    call_id: str = Field(min_length=3, max_length=64)
    accept: bool


class CallEnd(_Strict):
    call_id: str = Field(min_length=3, max_length=64)
    reason: Literal["hangup", "cancel", "failed", "permission_denied"] = "hangup"


class CallState(_Strict):
    call_id: str = Field(min_length=3, max_length=64)
    state: Literal["connected", "failed"]


class CallSdp(_Strict):
    call_id: str = Field(min_length=3, max_length=64)
    revision: int = Field(ge=1, le=1000)
    sdp_type: Literal["offer", "answer"]
    sdp: str = Field(min_length=10, max_length=60_000)


class CallIce(_Strict):
    call_id: str = Field(min_length=3, max_length=64)
    revision: int = Field(ge=1, le=1000)
    candidate: str = Field(max_length=1024)
    sdp_mid: str | None = Field(default=None, max_length=32)
    sdp_mline_index: int | None = Field(default=None, ge=0, le=4)


COMMANDS: dict[str, type[BaseModel]] = {
    "session.hello": Hello,
    "heartbeat": Heartbeat,
    "queue.join": QueueJoin,
    "queue.cancel": Empty,
    "interaction.end": InteractionRef,
    "interaction.next": InteractionRef,
    "text.send": TextSend,
    "text.delivered": TextDelivered,
    "friend.request": InteractionRef,
    "friend.respond": FriendRespond,
    "friend.invite": FriendInvite,
    "friend.invite.respond": InviteRespond,
    "friend.invite.cancel": InviteCancel,
    "call.request": InteractionRef,
    "call.respond": CallRespond,
    "call.end": CallEnd,
    "call.state": CallState,
    "call.sdp": CallSdp,
    "call.ice": CallIce,
    "call.refresh": CallRef,
}


class ProtocolError(Exception):
    def __init__(self, code: str, message: str, command_id: str | None = None) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.command_id = command_id


class Command:
    __slots__ = ("id", "type", "payload")

    def __init__(self, id: str, type: str, payload: Any) -> None:
        self.id = id
        self.type = type
        self.payload = payload


def parse(raw: str) -> Command:
    limit = MAX_SDP_FRAME if '"call.sdp"' in raw[:200] else MAX_FRAME
    if len(raw.encode("utf-8")) > limit:
        raise ProtocolError("frame_too_large", "Frame exceeds the size limit.")
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        raise ProtocolError("malformed", "Frame is not valid JSON.") from None
    if not isinstance(data, dict) or set(data) - {"v", "id", "type", "payload"}:
        raise ProtocolError("malformed", "Unexpected envelope fields.")
    command_id = data.get("id")
    if data.get("v") != PROTOCOL_VERSION:
        raise ProtocolError("unsupported_protocol", "Unsupported protocol version.", command_id)
    try:
        UUID(str(command_id))
    except ValueError:
        raise ProtocolError("malformed", "Command id must be a UUID.") from None
    kind = data.get("type")
    model = COMMANDS.get(kind) if isinstance(kind, str) else None
    if model is None:
        raise ProtocolError("unknown_command", "Unknown command type.", command_id)
    try:
        payload = model.model_validate(data.get("payload") or {})
    except ValidationError as exc:
        first = exc.errors()[0]
        msg = str(first.get("msg", "Invalid payload")).removeprefix("Value error, ")
        raise ProtocolError("invalid_payload", msg, command_id) from None
    return Command(str(command_id), kind, payload)


# ---------------------------------------------------------------------------
# Signalling validation (audio)
# ---------------------------------------------------------------------------

_CANDIDATE = re.compile(
    r"^(?:candidate:)?\S+ \d \S+ \d+ (?P<addr>\S+) \d+ typ (?P<typ>host|srflx|prflx|relay)(?: .*)?$"
)


def validate_candidate(candidate: str, require_relay: bool) -> str:
    """Accept only well-formed ICE candidates; with relay-only policy, only relay ones."""
    if candidate == "":
        return candidate  # end-of-candidates marker
    match = _CANDIDATE.match(candidate.strip())
    if not match:
        raise ProtocolError("invalid_candidate", "Malformed ICE candidate.")
    if require_relay and match.group("typ") != "relay":
        raise ProtocolError("relay_required", "Only relay candidates are accepted.")
    return candidate.strip()


def validate_sdp(sdp: str, require_relay: bool) -> str:
    lines = sdp.replace("\r\n", "\n").split("\n")
    media = [line for line in lines if line.startswith("m=")]
    if len(media) != 1 or not media[0].startswith("m=audio "):
        raise ProtocolError("invalid_sdp", "Exactly one audio media section is allowed.")
    if not any(line.startswith("a=fingerprint:") for line in lines):
        raise ProtocolError("invalid_sdp", "SDP must carry a DTLS fingerprint.")
    if require_relay:
        for line in lines:
            if line.startswith("a=candidate:"):
                validate_candidate(line[2:], require_relay=True)
    return sdp
