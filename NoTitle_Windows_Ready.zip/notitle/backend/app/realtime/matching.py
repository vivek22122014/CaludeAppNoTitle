"""Pure matching rules (blueprint chapter 23).

Everything here is deterministic given its inputs (the random tie-breaker is
injected), so it is exhaustively unit-tested without sockets or a database.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from typing import Callable, Iterable

from app.catalogs import GENERAL_TOPIC

REPEAT_EXCLUSION_SECONDS = 4.0
REPEAT_MEMORY_SECONDS = 300.0
RELEVANCE_FADE_SECONDS = 5.0
MAX_PAIR_CHECKS = 10_000


@dataclass
class Seeker:
    key: str
    gender: str
    topic_id: str
    joined_at: float
    premium: bool = False
    gender_preference: str = "everyone"          # saved preference
    professional_enabled: bool = False           # saved "use professional relevance"
    professional: dict | None = None             # own private profile (consented)
    wanted: dict = field(default_factory=dict)   # preference sets: industry_ids, role_ids, ...
    blocked: frozenset[str] = frozenset()        # keys excluded in either direction

    @property
    def effective_gender_preference(self) -> str:
        return self.gender_preference if self.premium else "everyone"

    @property
    def relevance_active(self) -> bool:
        return self.premium and self.professional_enabled


def accepts(seeker: Seeker, other: Seeker) -> bool:
    pref = seeker.effective_gender_preference
    return pref == "everyone" or pref == other.gender


def compatible(a: Seeker, b: Seeker, seconds_since_pair: float | None) -> bool:
    if a.key == b.key:
        return False
    if b.key in a.blocked or a.key in b.blocked:
        return False
    if seconds_since_pair is not None and seconds_since_pair < REPEAT_EXCLUSION_SECONDS:
        return False
    return accepts(a, b) and accepts(b, a)


def topic_bonus(a: Seeker, b: Seeker) -> float:
    return 0.5 if a.topic_id == b.topic_id and a.topic_id != GENERAL_TOPIC else 0.0


def _direction_relevance(seeker: Seeker, candidate: Seeker) -> float:
    """Very soft professional relevance contributed by one entitled seeker."""
    if not seeker.relevance_active or not candidate.professional:
        return 0.0
    wanted = seeker.wanted
    prof = candidate.professional
    score = 0.0
    for want_key, have_key in (("industry_ids", "industry_id"), ("role_ids", "role_id"),
                               ("experience_ids", "experience_id")):
        selected = wanted.get(want_key) or []
        if selected and prof.get(have_key) in selected:
            score += 0.1
    topics = set(wanted.get("topic_ids") or [])
    if topics and topics & set(prof.get("topic_ids") or []):
        score += 0.1
    interests = set(wanted.get("interest_ids") or [])
    if interests:
        score += 0.1 * len(interests & set(prof.get("interest_ids") or [])) / len(interests)
    return min(score, 0.5)


def professional_bonus(a: Seeker, b: Seeker) -> float:
    # General Talk disables professional influence for both directions.
    if a.topic_id == GENERAL_TOPIC or b.topic_id == GENERAL_TOPIC:
        return 0.0
    return (_direction_relevance(a, b) + _direction_relevance(b, a)) / 2.0


def repeat_penalty(seconds_since_pair: float | None) -> float:
    if seconds_since_pair is None or seconds_since_pair >= REPEAT_MEMORY_SECONDS:
        return 0.0
    return 60.0 * math.exp(-(seconds_since_pair - REPEAT_EXCLUSION_SECONDS) / 10.0)


def score(anchor: Seeker, candidate: Seeker, now: float, seconds_since_pair: float | None) -> float:
    anchor_wait = max(0.0, now - anchor.joined_at)
    candidate_wait = max(0.0, now - candidate.joined_at)
    fade = max(0.0, 1.0 - max(anchor_wait, candidate_wait) / RELEVANCE_FADE_SECONDS)
    relevance = topic_bonus(anchor, candidate) + professional_bonus(anchor, candidate)
    return candidate_wait - repeat_penalty(seconds_since_pair) + fade * relevance


@dataclass
class MatchResult:
    pairs: list[tuple[str, str]]
    checks: int


def find_matches(
    waiters: Iterable[Seeker],
    now: float,
    since_pair: Callable[[str, str], float | None],
    rng: random.Random | None = None,
    max_checks: int = MAX_PAIR_CHECKS,
) -> MatchResult:
    """Greedy oldest-anchor matching.

    The oldest waiter with *any* compatible candidate is matched to its
    best-scoring candidate (ties: longer wait, then uniform random).  An
    incompatible oldest waiter never blocks other pairs.  Payment adds no
    priority term.
    """
    rng = rng or random.SystemRandom()
    pool = sorted(waiters, key=lambda s: s.joined_at)
    taken: set[str] = set()
    pairs: list[tuple[str, str]] = []
    checks = 0
    for anchor in pool:
        if anchor.key in taken:
            continue
        best: list[tuple[float, float, Seeker]] = []
        best_score = -math.inf
        best_wait = -math.inf
        for candidate in pool:
            if candidate.key in taken or candidate.key == anchor.key:
                continue
            if checks >= max_checks:
                return MatchResult(pairs, checks)
            checks += 1
            gap = since_pair(anchor.key, candidate.key)
            if not compatible(anchor, candidate, gap):
                continue
            value = score(anchor, candidate, now, gap)
            wait = now - candidate.joined_at
            if value > best_score + 1e-9 or (abs(value - best_score) <= 1e-9 and wait > best_wait + 1e-9):
                best_score, best_wait, best = value, wait, [(value, wait, candidate)]
            elif abs(value - best_score) <= 1e-9 and abs(wait - best_wait) <= 1e-9:
                best.append((value, wait, candidate))
        if best:
            chosen = rng.choice(best)[2]
            taken.update((anchor.key, chosen.key))
            pairs.append((anchor.key, chosen.key))
    return MatchResult(pairs, checks)
