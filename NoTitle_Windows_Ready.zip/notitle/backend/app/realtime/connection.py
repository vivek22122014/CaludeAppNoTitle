"""WebSocket transport: tickets, handshake, bounded output and command dispatch."""

from __future__ import annotations

import asyncio
import json
import logging
import time
from collections import OrderedDict
from dataclasses import dataclass
from typing import Any

from starlette.websockets import WebSocket, WebSocketDisconnect, WebSocketState

from app.config import get_settings
from app.http import ratelimit
from app.http.errors import ApiError
from app.realtime import protocol
from app.realtime.coordinator import CoordinatorError, coordinator, utcnow_iso
from app.security import crypto

log = logging.getLogger("notitle.ws")

TICKET_TTL = 60
HELLO_DEADLINE = 5.0
HEARTBEAT_TIMEOUT = 45.0
MAX_OUT_EVENTS = 64
MAX_OUT_BYTES = 256 * 1024
MAX_HANDSHAKES = 32


@dataclass
class Ticket:
    key: str
    kind: str
    session_id: str | None
    takeover: bool
    expires: float


class TicketStore:
    def __init__(self) -> None:
        self.items: dict[bytes, Ticket] = {}

    def issue(self, key: str, kind: str, session_id: str | None, takeover: bool) -> tuple[str, int]:
        now = time.time()
        for digest, item in list(self.items.items()):
            if item.expires < now:
                del self.items[digest]
        if len(self.items) > 5000:
            raise CoordinatorError("busy", "Too many pending connections.")
        token = crypto.new_token()
        self.items[crypto.token_verifier(token, "ws-ticket")] = Ticket(key, kind, session_id, takeover, now + TICKET_TTL)
        return token, TICKET_TTL

    def redeem(self, token: str) -> Ticket | None:
        item = self.items.pop(crypto.token_verifier(token, "ws-ticket"), None)
        if item is None or item.expires < time.time():
            return None
        return item


tickets = TicketStore()
_handshakes = 0


class Connection:
    def __init__(self, ws: WebSocket) -> None:
        self.ws = ws
        self.participant_key: str | None = None
        self.session_id: str | None = None
        self.socket_generation = 0
        self.detached = False
        self.queue: asyncio.Queue[str | None] = asyncio.Queue()
        self.queued_bytes = 0
        self.seq = 0
        self.closed = False
        self.last_activity = time.monotonic()
        self.results: OrderedDict[str, tuple[float, dict]] = OrderedDict()
        self.close_code: int | None = None
        self.close_reason = ""
        self.aborted = False
        self.writer_task: asyncio.Task | None = None

    # Called synchronously by the coordinator.
    def send_event(self, type: str, payload: dict, reply_to: str | None = None) -> None:
        if self.closed:
            return
        self.seq += 1
        frame: dict[str, Any] = {"v": protocol.PROTOCOL_VERSION, "seq": self.seq, "type": type,
                                 "ts": utcnow_iso(), "payload": payload}
        if reply_to:
            frame["reply_to"] = reply_to
        data = json.dumps(frame, separators=(",", ":"))
        if self.queue.qsize() >= MAX_OUT_EVENTS or self.queued_bytes + len(data) > MAX_OUT_BYTES:
            # Slow reader: never buffer without bound; abort without draining.
            log.info("disconnecting slow reader")
            self.closed = True
            self.aborted = True
            self.queue.put_nowait(None)
            return
        self.queued_bytes += len(data)
        self.queue.put_nowait(data)

    async def close(self, code: int = 1000, reason: str = "") -> None:
        """Flush already-queued frames (e.g. the error explaining why), then close."""
        if self.close_code is not None:
            return
        self.close_code, self.close_reason = code, reason[:100]
        self.closed = True
        self.queue.put_nowait(None)
        if self.writer_task is not None and self.writer_task is not asyncio.current_task():
            try:
                await asyncio.wait_for(asyncio.shield(self.writer_task), timeout=2)
            except (asyncio.TimeoutError, Exception):  # noqa: BLE001
                pass
        await self._close_socket()

    async def _close_socket(self) -> None:
        try:
            if self.ws.client_state == WebSocketState.CONNECTED:
                await self.ws.close(code=self.close_code or 1000, reason=self.close_reason)
        except Exception:  # noqa: BLE001
            pass

    async def writer(self) -> None:
        try:
            while True:
                data = await self.queue.get()
                if data is None or self.aborted:
                    break
                self.queued_bytes -= len(data)
                await self.ws.send_text(data)
        except Exception:  # noqa: BLE001 - socket gone
            pass
        finally:
            self.closed = True
            if self.close_code is None:
                self.close_code = 1013 if self.aborted else 1000
            await self._close_socket()


async def serve(ws: WebSocket) -> None:
    """Endpoint body for ``/api/v1/ws``."""
    global _handshakes
    settings = get_settings()
    origin = ws.headers.get("origin", "").rstrip("/")
    if origin not in settings.public_origins:
        await ws.close(code=4003)
        return
    if _handshakes >= MAX_HANDSHAKES:
        await ws.close(code=1013)
        return
    _handshakes += 1
    await ws.accept()
    conn = Connection(ws)
    writer = asyncio.create_task(conn.writer())
    conn.writer_task = writer
    try:
        try:
            raw = await asyncio.wait_for(ws.receive_text(), timeout=HELLO_DEADLINE)
        except (asyncio.TimeoutError, WebSocketDisconnect, RuntimeError):
            await conn.close(4008, "hello timeout")
            return
        finally:
            _handshakes -= 1
        try:
            cmd = protocol.parse(raw)
        except protocol.ProtocolError as exc:
            conn.send_event("error", {"code": exc.code, "message": exc.message})
            await conn.close(4400, "bad hello")
            return
        if cmd.type != "session.hello":
            conn.send_event("error", {"code": "hello_required", "message": "Send session.hello first."})
            await conn.close(4400, "hello required")
            return
        ticket = tickets.redeem(cmd.payload.ticket)
        if ticket is None:
            conn.send_event("error", {"code": "invalid_ticket", "message": "Connection ticket expired. Reconnect."},
                            cmd.id)
            await conn.close(4401, "invalid ticket")
            return
        try:
            participant = await _load_participant(ticket)
            coordinator.admit(participant)
            coordinator.attach(ticket.key, conn, ticket.takeover)
        except CoordinatorError as exc:
            conn.send_event("error", {"code": exc.code, "message": exc.message}, cmd.id)
            await conn.close(4409 if exc.code == "session_active" else 4429, exc.code)
            return
        except LookupError:
            conn.send_event("error", {"code": "unauthenticated", "message": "Please sign in again."}, cmd.id)
            await conn.close(4401, "unauthenticated")
            return
        conn.participant_key = ticket.key
        conn.session_id = ticket.session_id
        conn.send_event("session.ready", {
            "owner_epoch": coordinator.owner_epoch,
            "socket_generation": conn.socket_generation,
            "limits": {"text_chars": protocol.MAX_TEXT_CHARS, "text_bytes": protocol.MAX_TEXT_BYTES,
                       "heartbeat_seconds": 20, "grace_seconds": 25},
            **coordinator.state_snapshot(ticket.key),
        }, cmd.id)
        await _receive_loop(conn)
    except WebSocketDisconnect:
        pass
    except Exception:  # noqa: BLE001
        log.exception("websocket failure")
    finally:
        if not conn.detached:
            coordinator.detach(conn)
        conn.closed = True
        conn.queue.put_nowait(None)
        try:
            await asyncio.wait_for(writer, timeout=2)
        except (asyncio.TimeoutError, Exception):  # noqa: BLE001
            writer.cancel()


async def _load_participant(ticket: Ticket):
    from app.realtime import participants
    from app.services import identity

    existing = coordinator.participants.get(ticket.key)
    if ticket.kind == "account":
        p = await participants.for_account(ticket.key[2:])
    else:
        guest = identity.guests.by_id.get(ticket.key[2:])
        if guest is None:
            raise LookupError("guest expired")
        p = await participants.for_guest(guest)
    if existing:
        # Keep live state; refresh durable inputs.
        p.friends = {**existing.friends, **p.friends}
    return p


async def _receive_loop(conn: Connection) -> None:
    ws = conn.ws
    while not conn.closed:
        try:
            raw = await asyncio.wait_for(ws.receive_text(), timeout=HEARTBEAT_TIMEOUT)
        except asyncio.TimeoutError:
            await conn.close(4008, "heartbeat timeout")
            return
        except (WebSocketDisconnect, RuntimeError):
            return
        conn.last_activity = time.monotonic()
        if conn.detached:
            return
        key = conn.participant_key  # re-read: guest conversion can rebind the socket
        if key is None:
            return
        try:
            cmd = protocol.parse(raw)
        except protocol.ProtocolError as exc:
            conn.send_event("error", {"code": exc.code, "message": exc.message}, exc.command_id)
            continue
        cached = conn.results.get(cmd.id)
        if cached and time.monotonic() - cached[0] < 120:
            conn.send_event("command.result", cached[1], cmd.id)
            continue
        try:
            result = dispatch(conn, key, cmd)
        except CoordinatorError as exc:
            conn.send_event("error", {"code": exc.code, "message": exc.message, "command": cmd.type}, cmd.id)
            continue
        except ApiError as exc:
            conn.send_event("error", {"code": exc.code, "message": exc.message, "command": cmd.type}, cmd.id)
            continue
        if result is not None:
            payload = {"command": cmd.type, **result}
            conn.results[cmd.id] = (time.monotonic(), payload)
            while len(conn.results) > 128:
                conn.results.popitem(last=False)
            conn.send_event("command.result", payload, cmd.id)


_RATE = {
    "text.send": "text", "queue.join": "queue", "interaction.next": "queue", "call.sdp": "sdp", "call.ice": "ice",
}


def dispatch(conn: Connection, key: str, cmd: protocol.Command) -> dict | None:
    """Synchronous transition for one command.  Returns the acknowledgement payload."""
    t, p = cmd.type, cmd.payload
    if t not in ("interaction.end", "heartbeat", "call.end", "queue.cancel"):
        ratelimit.check(_RATE.get(t, "command"), key)
    c = coordinator
    if t == "heartbeat":
        conn.send_event("heartbeat.ack", {"echo": p.echo, "server_time": utcnow_iso()}, cmd.id)
        return None
    if t == "queue.join":
        return c.join_queue(key, p.accept_everyone)
    if t == "queue.cancel":
        c.cancel_queue(key)
        return {"state": "idle"}
    if t == "interaction.end":
        c.end_interaction(key, p.interaction_id)
        return {"state": "ended"}
    if t == "interaction.next":
        return c.next_interaction(key, p.interaction_id)
    if t == "text.send":
        return c.send_text(key, p.interaction_id, p.client_id, p.body)
    if t == "text.delivered":
        c.mark_delivered(key, p.interaction_id, p.message_id)
        return None
    if t == "friend.request":
        return c.friend_request(key, p.interaction_id)
    if t == "friend.respond":
        return c.friend_respond(key, p.request_id, p.accept)
    if t == "friend.invite":
        return c.invite(key, p.relationship_id)
    if t == "friend.invite.respond":
        return c.respond_invite(key, p.invite_id, p.accept)
    if t == "friend.invite.cancel":
        c.cancel_invite(key, p.invite_id)
        return {"state": "cancelled"}
    if t == "call.request":
        return c.call_request(key, p.interaction_id)
    if t == "call.respond":
        return c.call_respond(key, p.call_id, p.accept)
    if t == "call.end":
        c.call_end(key, p.call_id, p.reason)
        return {"state": "ended"}
    if t == "call.state":
        c.call_state(key, p.call_id, p.state)
        return None
    if t == "call.sdp":
        c.call_signal(key, p.call_id, "sdp", p.model_dump())
        return None
    if t == "call.ice":
        c.call_signal(key, p.call_id, "ice", p.model_dump())
        return None
    if t == "call.refresh":
        return c.call_refresh(key, p.call_id)
    if t == "session.hello":
        raise CoordinatorError("already_ready", "Session is already established.")
    raise CoordinatorError("unknown_command", "Unknown command.")

