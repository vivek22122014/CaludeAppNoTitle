"""The single realtime owner (blueprint chapters 07, 22–26).

One ``Coordinator`` instance owns every live identity, the shared queue,
interactions, the temporary text rings, friend requests, invitations and calls.
All state transitions are *synchronous* methods running on the single event
loop, so they are atomic with respect to each other.  Anything slow (database,
hashing) happens outside a transition and re-validates captured versions before
publishing its result, so a late result can never revive an ended interaction.

Ordinary text lives only in a bounded in-memory ring per interaction (30
messages / 64 KiB) and is cleared on End, grace expiry, logout or restart.
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import logging
import secrets
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Callable

from app.config import get_settings
from app.realtime import matching
from app.realtime.protocol import ProtocolError, validate_candidate, validate_sdp
from app.services.analytics import metrics

if TYPE_CHECKING:  # pragma: no cover
    from app.realtime.connection import Connection

log = logging.getLogger("notitle.coordinator")

RING_MESSAGES = 30
RING_BYTES = 64 * 1024
GRACE_SECONDS = 25.0
INVITE_SECONDS = 30.0
CALL_RING_SECONDS = 30.0
CALL_SETUP_SECONDS = 20.0
CALL_COOLDOWN_SECONDS = 15.0
ATTRIBUTION_SECONDS = 600.0
SNAPSHOT_SECONDS = 120.0
SNAPSHOT_GLOBAL_BYTES = 16 * 1024 * 1024
FRIEND_CAP = 100
COMMAND_CACHE = 128
TURN_CREDENTIAL_SECONDS = 600


def utcnow_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _handle(prefix: str) -> str:
    return f"{prefix}_{secrets.token_urlsafe(12)}"


# ---------------------------------------------------------------------------
# State objects
# ---------------------------------------------------------------------------


@dataclass
class Message:
    id: str
    seq: int
    sender: str
    body: str
    sent_at: str
    size: int
    delivered: bool = False


@dataclass
class Call:
    id: str
    interaction_id: str
    caller: str
    callee: str
    state: str = "ringing"  # ringing → connecting → connected → ended
    created: float = field(default_factory=time.monotonic)
    connected_reports: set[str] = field(default_factory=set)
    connected_at: float | None = None
    revisions: dict[str, int] = field(default_factory=dict)
    timer: asyncio.TimerHandle | None = None


@dataclass
class Interaction:
    id: str
    a: str
    b: str
    source: str
    started_at: str
    started_mono: float = field(default_factory=time.monotonic)
    handles: dict[str, str] = field(default_factory=dict)  # participant key -> handle the *other* side sees
    ring: deque[Message] = field(default_factory=deque)
    ring_bytes: int = 0
    seq: int = 0
    friend_requests: dict[str, str] = field(default_factory=dict)  # requester key -> request id
    call: Call | None = None
    interrupted: dict[str, float] = field(default_factory=dict)  # key -> grace deadline (monotonic)

    def other(self, key: str) -> str:
        return self.b if key == self.a else self.a

    def has(self, key: str) -> bool:
        return key in (self.a, self.b)


@dataclass
class Invite:
    id: str
    sender: str
    target: str
    relationship_id: str
    expires: float
    timer: asyncio.TimerHandle | None = None


@dataclass
class Participant:
    key: str
    kind: str  # 'account' | 'guest'
    account_id: str | None
    display_name: str
    gender: str
    topic_id: str
    bio: str
    professional: dict | None = None
    gender_preference: str = "everyone"
    professional_enabled: bool = False
    wanted: dict = field(default_factory=dict)
    premium_until: float = 0.0  # unix seconds
    core_consent: bool = True
    restricted_until: float | None = None  # unix seconds; inf for bans
    conn: "Connection | None" = None
    socket_generation: int = 0
    queue_joined: float | None = None
    queue_token: str | None = None
    everyone_override: bool = False
    interaction_id: str | None = None
    friends: dict[str, str] = field(default_factory=dict)  # relationship id -> peer key
    friend_saved: dict[str, bool] = field(default_factory=dict)
    blocked: set[str] = field(default_factory=set)  # keys excluded either direction
    call_cooldown_until: float = 0.0
    command_cache: dict[str, Any] = field(default_factory=dict)
    last_seen: float = field(default_factory=time.monotonic)

    @property
    def premium(self) -> bool:
        return self.premium_until > time.time()

    def peer_dto(self, handle: str) -> dict:
        """The exact public peer DTO: nothing private, financial or identifying."""
        return {
            "peer_handle": handle,
            "display_name": self.display_name,
            "gender": self.gender,
            "topic_id": self.topic_id,
            "bio": self.bio,
        }

    def friend_dto(self) -> dict:
        return {
            "display_name": self.display_name,
            "gender": self.gender,
            "topic_id": self.topic_id,
            "bio": self.bio,
        }


@dataclass
class Snapshot:
    id: str
    reporter: str
    subject: str
    interaction_id: str
    messages: list[dict]
    size: int
    expires: float


@dataclass
class Attribution:
    interaction_id: str
    keys: tuple[str, str]
    handles: dict[str, str]
    expires: float


class CoordinatorError(Exception):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


def relationship_id_for(account_a: str, account_b: str) -> str:
    low, high = sorted((account_a, account_b))
    key = get_settings().key_bytes("hmac_key")
    digest = hmac.new(key, f"relationship|{low}|{high}".encode(), hashlib.sha256).digest()
    return "r_" + base64.urlsafe_b64encode(digest[:16]).rstrip(b"=").decode()


# ---------------------------------------------------------------------------
# Coordinator
# ---------------------------------------------------------------------------


class Coordinator:
    def __init__(self) -> None:
        self.settings = get_settings()
        self.owner_epoch = 0
        self.participants: dict[str, Participant] = {}
        self.interactions: dict[str, Interaction] = {}
        self.calls: dict[str, Call] = {}
        self.invites: dict[str, Invite] = {}
        self.temp_relationships: dict[str, tuple[str, str]] = {}
        self.ram_blocks: dict[tuple[str, str], float] = {}  # (blocker, blocked) -> created unix
        self.pair_history: dict[frozenset[str], float] = {}  # pair -> ended (monotonic)
        self.snapshots: dict[str, Snapshot] = {}
        self.snapshot_bytes = 0
        self.attributions: dict[str, Attribution] = {}
        self.draining = False
        self._match_task: asyncio.Task | None = None
        self._loop: asyncio.AbstractEventLoop | None = None
        # Hooks for durable work (set by the runtime; replaced in tests).
        self.persist_friendship: Callable[[str, str], Any] | None = None
        self.on_friendship_compensate: Callable[[str, str], Any] | None = None
        self.on_participant_removed: Callable[[Participant], None] | None = None

    # ------------------------------------------------------------------ util
    def start(self) -> None:
        self._loop = asyncio.get_running_loop()
        if self._match_task is None:
            self._match_task = asyncio.create_task(self._match_loop(), name="matching")

    async def stop(self) -> None:
        self.draining = True
        for p in list(self.participants.values()):
            if p.conn:
                p.conn.send_event("service.draining", {"message": "The service is restarting. Conversations will end."})
        for interaction in list(self.interactions.values()):
            self._end_interaction(interaction, "service_restart", initiator=None)
        if self._match_task:
            self._match_task.cancel()
            try:
                await self._match_task
            except (asyncio.CancelledError, Exception):
                pass
            self._match_task = None
        for p in list(self.participants.values()):
            if p.conn:
                await p.conn.close(1012, "restart")

    def _later(self, delay: float, fn: Callable, *args: Any) -> asyncio.TimerHandle | None:
        loop = self._loop
        if loop is None:
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                return None
        return loop.call_later(delay, fn, *args)

    def emit(self, key: str, type: str, payload: dict, reply_to: str | None = None) -> None:
        p = self.participants.get(key)
        if p and p.conn:
            p.conn.send_event(type, payload, reply_to)

    def counts(self) -> dict:
        return {
            "connected": sum(1 for p in self.participants.values() if p.conn or p.interaction_id),
            "waiting": sum(1 for p in self.participants.values() if p.queue_joined is not None),
            "interactions": len(self.interactions),
            "calls": sum(1 for c in self.calls.values() if c.state in ("connecting", "connected")),
            "ringing": sum(1 for c in self.calls.values() if c.state == "ringing"),
        }

    # -------------------------------------------------------- participants
    def admit(self, participant: Participant) -> Participant:
        """Insert or refresh a participant (profile data comes from the caller)."""
        existing = self.participants.get(participant.key)
        if existing:
            for name in ("display_name", "gender", "topic_id", "bio", "professional", "gender_preference",
                         "professional_enabled", "wanted", "premium_until", "core_consent", "restricted_until"):
                setattr(existing, name, getattr(participant, name))
            for rel_id, peer in participant.friends.items():
                existing.friends.setdefault(rel_id, peer)
                existing.friend_saved[rel_id] = participant.friend_saved.get(rel_id, False)
            existing.blocked |= participant.blocked
            return existing
        live = sum(1 for p in self.participants.values() if p.conn or p.interaction_id)
        if live >= self.settings.max_connected:
            raise CoordinatorError("capacity", "The service is at capacity. Please try again shortly.")
        # Temporary relationships and RAM blocks survive reconnects.
        for rel_id, (a, b) in self.temp_relationships.items():
            if participant.key in (a, b):
                participant.friends[rel_id] = b if a == participant.key else a
                participant.friend_saved[rel_id] = False
        for (blocker, blocked) in self.ram_blocks:
            if participant.key == blocker:
                participant.blocked.add(blocked)
            elif participant.key == blocked:
                participant.blocked.add(blocker)
        self.participants[participant.key] = participant
        return participant

    def attach(self, key: str, conn: "Connection", takeover: bool) -> Participant:
        p = self.participants[key]
        if p.conn is not None and p.conn is not conn:
            if not takeover:
                raise CoordinatorError("session_active", "This identity is already connected in another tab.")
            old = p.conn
            p.socket_generation += 1
            old.send_event("session.replaced", {"message": "This conversation was opened in another tab."})
            old.detached = True
            asyncio.ensure_future(old.close(4001, "replaced"))
        p.conn = conn
        p.last_seen = time.monotonic()
        conn.socket_generation = p.socket_generation
        if p.interaction_id:
            interaction = self.interactions.get(p.interaction_id)
            if interaction and key in interaction.interrupted:
                del interaction.interrupted[key]
                self.emit(interaction.other(key), "interaction.resumed", {"interaction_id": interaction.id})
        self._broadcast_presence(p)
        return p

    def detach(self, conn: "Connection") -> None:
        key = conn.participant_key
        p = self.participants.get(key) if key else None
        if not p or p.conn is not conn:
            return
        p.conn = None
        if p.queue_joined is not None:
            self._leave_queue(p)
            metrics.incr("searches_abandoned")
        if p.interaction_id:
            interaction = self.interactions.get(p.interaction_id)
            if interaction:
                # Audio ends immediately; text may resume within the grace interval.
                if interaction.call:
                    self._end_call(interaction.call, "interrupted")
                deadline = time.monotonic() + GRACE_SECONDS
                interaction.interrupted[key] = deadline
                self.emit(interaction.other(key), "interaction.interrupted", {
                    "interaction_id": interaction.id,
                    "grace_seconds": int(GRACE_SECONDS),
                })
                self._later(GRACE_SECONDS + 0.05, self._grace_expired, interaction.id, key, deadline)
        self._cancel_invites_for(key)
        self._broadcast_presence(p)
        self._maybe_forget(p)

    def _grace_expired(self, interaction_id: str, key: str, deadline: float) -> None:
        interaction = self.interactions.get(interaction_id)
        if interaction and interaction.interrupted.get(key) == deadline:
            self._end_interaction(interaction, "peer_disconnected", initiator=key)
        p = self.participants.get(key)
        if p:
            self._maybe_forget(p)

    def _maybe_forget(self, p: Participant) -> None:
        if p.conn is None and p.interaction_id is None and p.queue_joined is None:
            self.participants.pop(p.key, None)
            if self.on_participant_removed:
                self.on_participant_removed(p)

    def end_identity(self, key: str, reason: str, close_code: int = 4002) -> None:
        """Logout, deletion, restriction or password change: fence everything now."""
        p = self.participants.get(key)
        if not p:
            return
        if p.queue_joined is not None:
            self._leave_queue(p)
        if p.interaction_id and p.interaction_id in self.interactions:
            self._end_interaction(self.interactions[p.interaction_id], reason, initiator=key)
        self._cancel_invites_for(key)
        conn = p.conn
        p.conn = None
        self._broadcast_presence(p)
        self.participants.pop(key, None)
        if conn:
            conn.send_event("session.ended", {"reason": reason})
            conn.detached = True
            asyncio.ensure_future(conn.close(close_code, reason))

    def forget_guest(self, guest_key: str) -> None:
        """Guest expiry: temporary links and RAM blocks die with the identity."""
        self.end_identity(guest_key, "guest_expired")
        for rel_id, (a, b) in list(self.temp_relationships.items()):
            if guest_key in (a, b):
                self._drop_relationship(rel_id, notify=True)
        for pair in [pair for pair in self.ram_blocks if guest_key in pair]:
            del self.ram_blocks[pair]

    def convert_guest(self, guest_key: str, account_key: str, profile: Participant, session_id: str) -> dict:
        """Rebind a live guest to its newly registered account.

        Returns the durable work the caller must commit: account friends to
        promote and outbound blocks to persist.  Temporary links to other guests
        stay temporary.  Any later End/Block simply operates on the new key.
        """
        promote: list[str] = []
        blocks: list[str] = []
        for rel_id, (a, b) in list(self.temp_relationships.items()):
            if guest_key not in (a, b):
                continue
            other = b if a == guest_key else a
            if other.startswith("a:"):
                del self.temp_relationships[rel_id]
                promote.append(other[2:])
                for p in self.participants.values():
                    if rel_id in p.friends:
                        del p.friends[rel_id]
                        p.friend_saved.pop(rel_id, None)
                        self.emit(p.key, "friends.changed", {})
            else:
                self.temp_relationships[rel_id] = (account_key, other)
        for (blocker, blocked), created in list(self.ram_blocks.items()):
            if guest_key not in (blocker, blocked):
                continue
            del self.ram_blocks[(blocker, blocked)]
            new = (account_key if blocker == guest_key else blocker, account_key if blocked == guest_key else blocked)
            if new[0] == account_key and new[1].startswith("a:"):
                blocks.append(new[1][2:])
            else:
                self.ram_blocks[new] = created
        old = self.participants.pop(guest_key, None)
        if old is not None:
            profile.conn = old.conn
            profile.socket_generation = old.socket_generation
            profile.queue_joined = old.queue_joined
            profile.queue_token = old.queue_token
            profile.interaction_id = old.interaction_id
            profile.blocked |= {k for k in old.blocked}
            for rel_id, peer in old.friends.items():
                if rel_id in self.temp_relationships:
                    profile.friends[rel_id] = peer
                    profile.friend_saved[rel_id] = False
            if old.conn:
                old.conn.participant_key = account_key
                old.conn.session_id = session_id
            interaction = self.interactions.get(old.interaction_id or "")
            if interaction:
                if interaction.a == guest_key:
                    interaction.a = account_key
                if interaction.b == guest_key:
                    interaction.b = account_key
                interaction.handles = {(account_key if k == guest_key else k): v for k, v in interaction.handles.items()}
                interaction.friend_requests = {(account_key if k == guest_key else k): v
                                               for k, v in interaction.friend_requests.items()}
                interaction.interrupted = {(account_key if k == guest_key else k): v
                                           for k, v in interaction.interrupted.items()}
                if interaction.call:
                    if interaction.call.caller == guest_key:
                        interaction.call.caller = account_key
                    if interaction.call.callee == guest_key:
                        interaction.call.callee = account_key
            for invite in list(self.invites.values()):
                if guest_key in (invite.sender, invite.target):
                    self._close_invite(invite, "closed")
        for p in self.participants.values():
            for rel_id, peer in list(p.friends.items()):
                if peer == guest_key:
                    p.friends[rel_id] = account_key
            if guest_key in p.blocked:
                p.blocked.discard(guest_key)
                p.blocked.add(account_key)
        self.participants[account_key] = profile
        return {"promote": promote, "blocks": blocks}

    def update_profile(self, key: str, **fields: Any) -> None:
        """Profile/preference edits affect the *next* peer snapshot only."""
        p = self.participants.get(key)
        if not p:
            return
        for name, value in fields.items():
            setattr(p, name, value)
        if p.queue_joined is not None:
            # Fence the old reservation but keep wait age.
            p.queue_token = _handle("q")
            if p.gender_preference != "everyone" and not p.premium:
                self._pause_queue(p, "premium_preference_inactive")

    def update_entitlement(self, account_id: str, premium_until: float) -> None:
        p = self.participants.get(f"a:{account_id}")
        if not p:
            return
        p.premium_until = premium_until
        if p.queue_joined is not None and p.gender_preference != "everyone" and not p.premium:
            self._pause_queue(p, "premium_preference_inactive")
        if p.conn:
            p.conn.send_event("entitlement.changed", {"premium": p.premium})

    def set_restriction(self, key: str, until: float | None) -> None:
        p = self.participants.get(key)
        if p:
            p.restricted_until = until
            if until and until > time.time():
                if p.queue_joined is not None:
                    self._pause_queue(p, "restricted")
                if p.interaction_id and p.interaction_id in self.interactions:
                    self._end_interaction(self.interactions[p.interaction_id], "restricted", initiator=key)

    # ---------------------------------------------------------------- queue
    def join_queue(self, key: str, accept_everyone: bool = False) -> dict:
        p = self.participants[key]
        if self.draining or not self.settings.admission_open:
            raise CoordinatorError("unavailable", "New conversations are paused for maintenance.")
        if not p.core_consent:
            raise CoordinatorError("consent_required", "Core processing consent is required to search.")
        if p.restricted_until and p.restricted_until > time.time():
            raise CoordinatorError("restricted", "Your access to matching is currently restricted.")
        if p.interaction_id:
            raise CoordinatorError("busy", "End the current conversation first.")
        if p.queue_joined is not None:
            return {"queue_token": p.queue_token, "already": True}
        if p.gender_preference != "everyone" and not p.premium:
            if not accept_everyone:
                raise CoordinatorError(
                    "premium_preference_inactive",
                    "Your gender preference needs an active Premium pass. Search with Everyone instead?",
                )
        waiting = sum(1 for x in self.participants.values() if x.queue_joined is not None)
        if waiting >= self.settings.max_waiting:
            raise CoordinatorError("queue_full", "Too many people are searching right now. Try again shortly.")
        p.queue_joined = time.monotonic()
        p.queue_token = _handle("q")
        p.everyone_override = accept_everyone
        metrics.incr("searches_started")
        relevance = p.premium and p.professional_enabled and p.topic_id != "general"
        metrics.incr("professional_enabled" if relevance else "professional_disabled")
        self._broadcast_presence(p)
        return {"queue_token": p.queue_token, "since": utcnow_iso()}

    def cancel_queue(self, key: str) -> None:
        p = self.participants.get(key)
        if p and p.queue_joined is not None:
            self._leave_queue(p)
            metrics.incr("searches_cancelled")
            self._broadcast_presence(p)

    def _leave_queue(self, p: Participant) -> None:
        p.queue_joined = None
        p.queue_token = None
        p.everyone_override = False

    def _pause_queue(self, p: Participant, reason: str) -> None:
        self._leave_queue(p)
        self.emit(p.key, "queue.paused", {"reason": reason})
        self._broadcast_presence(p)

    def _seeker(self, p: Participant) -> matching.Seeker:
        override = p.everyone_override
        return matching.Seeker(
            key=p.key,
            gender=p.gender,
            topic_id=p.topic_id,
            joined_at=p.queue_joined or time.monotonic(),
            premium=p.premium and not override,
            gender_preference=p.gender_preference,
            professional_enabled=p.professional_enabled,
            professional=p.professional,
            wanted=p.wanted,
            blocked=frozenset(p.blocked),
        )

    def _since_pair(self, a: str, b: str) -> float | None:
        ended = self.pair_history.get(frozenset((a, b)))
        return None if ended is None else time.monotonic() - ended

    async def _match_loop(self) -> None:
        while True:
            await asyncio.sleep(0.1)
            try:
                self.match_tick()
            except Exception:  # noqa: BLE001 - the loop must survive one bad tick
                log.exception("matching tick failed")

    def match_tick(self, now: float | None = None, rng: Any = None) -> int:
        now = time.monotonic() if now is None else now
        cutoff = now - matching.REPEAT_MEMORY_SECONDS
        for pair, ended in list(self.pair_history.items()):
            if ended < cutoff:
                del self.pair_history[pair]
        waiters = [self._seeker(p) for p in self.participants.values()
                   if p.queue_joined is not None and p.conn is not None]
        if len(waiters) < 2:
            return 0
        result = matching.find_matches(waiters, now, self._since_pair, rng=rng)
        for a, b in result.pairs:
            pa, pb = self.participants[a], self.participants[b]
            # Revalidate at publish time.
            if pa.queue_joined is None or pb.queue_joined is None or pa.interaction_id or pb.interaction_id:
                continue
            if frozenset((a, b)) in self.pair_history:
                metrics.incr("repeat_matches")
            for p in (pa, pb):
                metrics.observe("match_wait_ms", (now - (p.queue_joined or now)) * 1000)
                self._leave_queue(p)
            self._start_interaction(pa, pb, "random")
            metrics.incr("matches")
        return len(result.pairs)

    # --------------------------------------------------------- interactions
    def _start_interaction(self, pa: Participant, pb: Participant, source: str) -> Interaction:
        interaction = Interaction(id=_handle("i"), a=pa.key, b=pb.key, source=source, started_at=utcnow_iso())
        interaction.handles = {pa.key: _handle("p"), pb.key: _handle("p")}
        self.interactions[interaction.id] = interaction
        for me, other in ((pa, pb), (pb, pa)):
            me.interaction_id = interaction.id
            rel_id = self._relationship_between(me, other)
            self.emit(me.key, "interaction.started", {
                "interaction_id": interaction.id,
                "source": source,
                "started_at": interaction.started_at,
                "peer": other.peer_dto(interaction.handles[me.key]),
                "friend_state": "friends" if rel_id else "none",
                "relationship_id": rel_id,
            })
            self._broadcast_presence(me)
        return interaction

    def _relationship_between(self, me: Participant, other: Participant) -> str | None:
        for rel_id, peer in me.friends.items():
            if peer == other.key:
                return rel_id
        return None

    def _interaction_for(self, key: str, interaction_id: str) -> Interaction:
        interaction = self.interactions.get(interaction_id)
        if not interaction or not interaction.has(key):
            raise CoordinatorError("stale_interaction", "That conversation has already ended.")
        return interaction

    def end_interaction(self, key: str, interaction_id: str, reason: str = "ended") -> bool:
        interaction = self.interactions.get(interaction_id)
        if not interaction or not interaction.has(key):
            return False  # idempotent: already ended
        self._end_interaction(interaction, reason, initiator=key)
        return True

    def next_interaction(self, key: str, interaction_id: str) -> dict:
        self.end_interaction(key, interaction_id, "next")
        return self.join_queue(key)

    def _end_interaction(self, interaction: Interaction, reason: str, initiator: str | None) -> None:
        if self.interactions.pop(interaction.id, None) is None:
            return
        if interaction.call:
            self._end_call(interaction.call, "conversation_ended")
        # Keep only minimal attribution (no transcript) for late reports.
        self.attributions[interaction.id] = Attribution(
            interaction_id=interaction.id,
            keys=(interaction.a, interaction.b),
            handles=dict(interaction.handles),
            expires=time.monotonic() + ATTRIBUTION_SECONDS,
        )
        self._prune_attributions()
        interaction.ring.clear()
        interaction.ring_bytes = 0
        self.pair_history[frozenset((interaction.a, interaction.b))] = time.monotonic()
        for key in (interaction.a, interaction.b):
            p = self.participants.get(key)
            if not p:
                continue
            if p.interaction_id == interaction.id:
                p.interaction_id = None
            self.emit(key, "interaction.ended", {
                "interaction_id": interaction.id,
                "reason": reason if key == initiator or initiator is None else "peer_ended",
                "by_self": key == initiator,
            })
            self._broadcast_presence(p)
            self._maybe_forget(p)

    def _prune_attributions(self) -> None:
        now = time.monotonic()
        for ref, att in list(self.attributions.items()):
            if att.expires < now:
                del self.attributions[ref]
        while len(self.attributions) > 5000:
            self.attributions.pop(next(iter(self.attributions)))

    def peer_key_for(self, key: str, interaction_id: str) -> str | None:
        interaction = self.interactions.get(interaction_id)
        if interaction and interaction.has(key):
            return interaction.other(key)
        att = self.attributions.get(interaction_id)
        if att and key in att.keys and att.expires > time.monotonic():
            return att.keys[1] if att.keys[0] == key else att.keys[0]
        return None

    # ------------------------------------------------------------------ text
    def send_text(self, key: str, interaction_id: str, client_id: str, body: str) -> dict:
        interaction = self._interaction_for(key, interaction_id)
        if interaction.interrupted:
            raise CoordinatorError("interrupted", "Sending is paused while the connection recovers.")
        interaction.seq += 1
        message = Message(
            id=_handle("m"),
            seq=interaction.seq,
            sender=key,
            body=body,
            sent_at=utcnow_iso(),
            size=len(body.encode("utf-8")),
        )
        interaction.ring.append(message)
        interaction.ring_bytes += message.size
        while len(interaction.ring) > RING_MESSAGES or interaction.ring_bytes > RING_BYTES:
            old = interaction.ring.popleft()
            interaction.ring_bytes -= old.size
        metrics.incr("text_accepted")
        self.emit(interaction.other(key), "text.received", {
            "interaction_id": interaction.id,
            "message_id": message.id,
            "seq": message.seq,
            "body": body,
            "sent_at": message.sent_at,
        })
        return {"client_id": client_id, "message_id": message.id, "seq": message.seq, "sent_at": message.sent_at}

    def mark_delivered(self, key: str, interaction_id: str, message_id: str) -> None:
        interaction = self._interaction_for(key, interaction_id)
        for message in interaction.ring:
            if message.id == message_id:
                if message.sender != key and not message.delivered:
                    message.delivered = True
                    self.emit(message.sender, "text.delivery", {
                        "interaction_id": interaction.id, "message_id": message.id, "state": "delivered"})
                return

    # --------------------------------------------------------------- reports
    def prepare_snapshot(self, key: str, interaction_id: str) -> Snapshot:
        subject = self.peer_key_for(key, interaction_id)
        if subject is None:
            raise CoordinatorError("stale_interaction", "That conversation can no longer be reported here.")
        interaction = self.interactions.get(interaction_id)
        messages: list[dict] = []
        if interaction:
            for m in interaction.ring:
                messages.append({
                    "message_id": m.id,
                    "mine": m.sender == key,
                    "sender_role": "reporter" if m.sender == key else "reported",
                    "body": m.body,
                    "sent_at": m.sent_at,
                })
        size = sum(len(m["body"].encode()) for m in messages)
        now = time.monotonic()
        for sid, snap in list(self.snapshots.items()):
            if snap.expires < now or (snap.reporter == key):
                self.snapshot_bytes -= snap.size
                del self.snapshots[sid]
        if self.snapshot_bytes + size > SNAPSHOT_GLOBAL_BYTES:
            raise CoordinatorError("capacity", "Report preparation is busy. Please retry in a moment.")
        snap = Snapshot(id=_handle("s"), reporter=key, subject=subject, interaction_id=interaction_id,
                        messages=messages, size=size, expires=now + SNAPSHOT_SECONDS)
        self.snapshots[snap.id] = snap
        self.snapshot_bytes += size
        return snap

    def take_snapshot(self, key: str, snapshot_id: str) -> Snapshot | None:
        snap = self.snapshots.get(snapshot_id)
        if not snap or snap.reporter != key:
            return None
        if snap.expires < time.monotonic():
            return None
        return snap

    def drop_snapshot(self, snapshot_id: str) -> None:
        snap = self.snapshots.pop(snapshot_id, None)
        if snap:
            self.snapshot_bytes -= snap.size

    # ---------------------------------------------------------------- blocks
    def apply_block(self, blocker: str, blocked: str, durable: bool) -> None:
        """Immediate safety fence: end contact, drop relationship, exclude matching."""
        if not durable:
            self.ram_blocks[(blocker, blocked)] = time.time()
        for key, other in ((blocker, blocked), (blocked, blocker)):
            p = self.participants.get(key)
            if p:
                p.blocked.add(other)
        for interaction in list(self.interactions.values()):
            if interaction.has(blocker) and interaction.has(blocked):
                self._end_interaction(interaction, "blocked", initiator=blocker)
        for invite in list(self.invites.values()):
            if {invite.sender, invite.target} == {blocker, blocked}:
                self._close_invite(invite, "closed")
        for rel_id in self._relationships_between(blocker, blocked):
            self._drop_relationship(rel_id, notify=True)

    def lift_block(self, blocker: str, blocked: str) -> None:
        self.ram_blocks.pop((blocker, blocked), None)
        still = (blocked, blocker) in self.ram_blocks
        for key, other in ((blocker, blocked), (blocked, blocker)):
            p = self.participants.get(key)
            if p and not still:
                p.blocked.discard(other)

    def ram_blocks_by(self, blocker: str) -> list[tuple[str, float]]:
        return [(blocked, created) for (b, blocked), created in self.ram_blocks.items() if b == blocker]

    # --------------------------------------------------------------- friends
    def _relationships_between(self, a: str, b: str) -> list[str]:
        out = []
        pa = self.participants.get(a)
        if pa:
            out += [rid for rid, peer in pa.friends.items() if peer == b]
        out += [rid for rid, pair in self.temp_relationships.items() if set(pair) == {a, b}]
        if a.startswith("a:") and b.startswith("a:"):
            out.append(relationship_id_for(a[2:], b[2:]))
        return sorted(set(out))

    def friend_request(self, key: str, interaction_id: str) -> dict:
        interaction = self._interaction_for(key, interaction_id)
        me = self.participants[key]
        other_key = interaction.other(key)
        other = self.participants.get(other_key)
        if other is None:
            raise CoordinatorError("stale_interaction", "That conversation has ended.")
        if self._relationship_between(me, other):
            return {"state": "friends"}
        if other_key in interaction.friend_requests:
            # Reciprocal request is mutual acceptance.
            return self._accept_friendship(interaction, other_key, key)
        if len(me.friends) >= FRIEND_CAP:
            raise CoordinatorError("friend_cap", "You already have the maximum of 100 friends.")
        request_id = interaction.friend_requests.setdefault(key, _handle("fr"))
        self.emit(other_key, "friend.requested", {"interaction_id": interaction.id, "request_id": request_id})
        return {"state": "pending", "request_id": request_id}

    def friend_respond(self, key: str, request_id: str, accept: bool) -> dict:
        for interaction in self.interactions.values():
            if not interaction.has(key):
                continue
            requester = interaction.other(key)
            if interaction.friend_requests.get(requester) == request_id:
                if not accept:
                    del interaction.friend_requests[requester]
                    self.emit(requester, "friend.request_closed", {"interaction_id": interaction.id})
                    return {"state": "closed"}
                return self._accept_friendship(interaction, requester, key)
        raise CoordinatorError("stale_request", "That friend request is no longer available.")

    def _accept_friendship(self, interaction: Interaction, requester: str, accepter: str) -> dict:
        pa, pb = self.participants.get(requester), self.participants.get(accepter)
        if not pa or not pb:
            raise CoordinatorError("stale_interaction", "That conversation has ended.")
        if len(pa.friends) >= FRIEND_CAP or len(pb.friends) >= FRIEND_CAP:
            interaction.friend_requests.pop(requester, None)
            self.emit(requester, "friend.request_closed", {"interaction_id": interaction.id})
            raise CoordinatorError("friend_cap", "A friend limit of 100 has been reached.")
        interaction.friend_requests.clear()
        metrics.incr("friend_acceptances")
        if pa.kind == "account" and pb.kind == "account":
            rel_id = relationship_id_for(pa.account_id or "", pb.account_id or "")
            for me, other in ((pa, pb), (pb, pa)):
                me.friends[rel_id] = other.key
                me.friend_saved[rel_id] = False
                self.emit(me.key, "friend.saving", {
                    "interaction_id": interaction.id, "relationship_id": rel_id,
                    "friend": other.friend_dto()})
            if self.persist_friendship:
                asyncio.ensure_future(self._persist(rel_id, pa.key, pb.key))
            return {"state": "saving", "relationship_id": rel_id}
        rel_id = _handle("rt")
        self.temp_relationships[rel_id] = (pa.key, pb.key)
        for me, other in ((pa, pb), (pb, pa)):
            me.friends[rel_id] = other.key
            me.friend_saved[rel_id] = False
            self.emit(me.key, "friend.accepted", {
                "interaction_id": interaction.id, "relationship_id": rel_id, "temporary": True,
                "friend": other.friend_dto()})
        return {"state": "temporary", "relationship_id": rel_id}

    async def _persist(self, rel_id: str, a: str, b: str) -> None:
        ok = False
        try:
            assert self.persist_friendship is not None
            ok = bool(await self.persist_friendship(a[2:], b[2:]))
        except Exception:  # noqa: BLE001
            log.exception("friendship persist failed")
        pa, pb = self.participants.get(a), self.participants.get(b)
        # Revalidate: a Block or removal during the save wins.
        still_valid = all(p is None or p.friends.get(rel_id) for p in (pa, pb))
        if ok and still_valid:
            for me in (pa, pb):
                if me:
                    me.friend_saved[rel_id] = True
                    self.emit(me.key, "friend.persisted", {"relationship_id": rel_id})
        else:
            if ok and self.on_friendship_compensate:
                await self.on_friendship_compensate(a[2:], b[2:])
            self._drop_relationship(rel_id, notify=True, reason="not_saved")

    def add_saved_friend(self, a_key: str, b_key: str, rel_id: str) -> None:
        for me, other in ((a_key, b_key), (b_key, a_key)):
            p = self.participants.get(me)
            if p:
                p.friends[rel_id] = other
                p.friend_saved[rel_id] = True

    def _drop_relationship(self, rel_id: str, notify: bool, reason: str = "removed") -> None:
        self.temp_relationships.pop(rel_id, None)
        for p in self.participants.values():
            if rel_id in p.friends:
                del p.friends[rel_id]
                p.friend_saved.pop(rel_id, None)
                if notify:
                    self.emit(p.key, "friend.removed", {"relationship_id": rel_id, "reason": reason})
        for invite in list(self.invites.values()):
            if invite.relationship_id == rel_id:
                self._close_invite(invite, "closed")

    def remove_relationship(self, key: str, rel_id: str) -> str | None:
        """Owner-initiated removal; also ends a current conversation between the pair."""
        p = self.participants.get(key)
        peer = None
        if p and rel_id in p.friends:
            peer = p.friends[rel_id]
        elif rel_id in self.temp_relationships:
            a, b = self.temp_relationships[rel_id]
            peer = b if a == key else a if b == key else None
        if peer:
            for interaction in list(self.interactions.values()):
                if interaction.has(key) and interaction.has(peer):
                    self._end_interaction(interaction, "friend_removed", initiator=key)
        self._drop_relationship(rel_id, notify=True)
        return peer

    def temporary_relationships_for(self, key: str) -> list[tuple[str, str]]:
        return [(rid, b if a == key else a) for rid, (a, b) in self.temp_relationships.items() if key in (a, b)]

    def presence(self, key: str) -> str:
        p = self.participants.get(key)
        if not p or not p.conn:
            return "offline"
        return "busy" if p.interaction_id else "available"

    def _broadcast_presence(self, p: Participant) -> None:
        state = self.presence(p.key)
        for rel_id, peer in p.friends.items():
            self.emit(peer, "presence.update", {"relationship_id": rel_id, "presence": state})

    # --------------------------------------------------------------- invites
    def invite(self, key: str, rel_id: str) -> dict:
        me = self.participants[key]
        target_key = me.friends.get(rel_id)
        if not target_key:
            raise CoordinatorError("stale_relationship", "That friend link is no longer available.")
        if me.interaction_id:
            raise CoordinatorError("busy", "End the current conversation before inviting a friend.")
        if target_key in me.blocked:
            raise CoordinatorError("unavailable", "This friend is not available.")
        if self.presence(target_key) != "available":
            raise CoordinatorError("unavailable", "Your friend is busy or offline right now.")
        # Crossed invitations converge on one interaction.
        for invite in list(self.invites.values()):
            if invite.sender == target_key and invite.target == key:
                return self.respond_invite(key, invite.id, True)
            if invite.sender == key and invite.target == target_key:
                return {"invite_id": invite.id, "state": "sent"}
        invite = Invite(id=_handle("iv"), sender=key, target=target_key, relationship_id=rel_id,
                        expires=time.monotonic() + INVITE_SECONDS)
        invite.timer = self._later(INVITE_SECONDS, self._expire_invite, invite.id)
        self.invites[invite.id] = invite
        target = self.participants[target_key]
        self.emit(target_key, "invite.received", {
            "invite_id": invite.id,
            "relationship_id": self._relationship_between(target, me) or rel_id,
            "from": me.friend_dto(),
            "expires_in": int(INVITE_SECONDS),
        })
        return {"invite_id": invite.id, "state": "sent", "expires_in": int(INVITE_SECONDS)}

    def respond_invite(self, key: str, invite_id: str, accept: bool) -> dict:
        invite = self.invites.get(invite_id)
        if not invite or invite.target != key or invite.expires < time.monotonic():
            raise CoordinatorError("stale_invite", "That invitation has expired.")
        if not accept:
            self._close_invite(invite, "declined")
            return {"state": "declined"}
        sender = self.participants.get(invite.sender)
        target = self.participants.get(key)
        if not sender or not target or sender.interaction_id or target.interaction_id \
                or not sender.conn or not target.conn or invite.sender in target.blocked:
            self._close_invite(invite, "unavailable")
            raise CoordinatorError("unavailable", "Your friend is no longer available.")
        self._close_invite(invite, "accepted", notify=False)
        for p in (sender, target):
            if p.queue_joined is not None:
                self._leave_queue(p)
        interaction = self._start_interaction(sender, target, "invite")
        return {"state": "accepted", "interaction_id": interaction.id}

    def cancel_invite(self, key: str, invite_id: str) -> None:
        invite = self.invites.get(invite_id)
        if invite and invite.sender == key:
            self._close_invite(invite, "cancelled")

    def _expire_invite(self, invite_id: str) -> None:
        invite = self.invites.get(invite_id)
        if invite:
            self._close_invite(invite, "expired")

    def _close_invite(self, invite: Invite, state: str, notify: bool = True) -> None:
        if self.invites.pop(invite.id, None) is None:
            return
        if invite.timer:
            invite.timer.cancel()
        if notify:
            for key in (invite.sender, invite.target):
                self.emit(key, "invite.closed", {"invite_id": invite.id, "state": state})

    def _cancel_invites_for(self, key: str) -> None:
        for invite in list(self.invites.values()):
            if key in (invite.sender, invite.target):
                self._close_invite(invite, "closed")

    # ----------------------------------------------------------------- audio
    def _ice_config(self, call: Call, key: str) -> dict:
        servers: list[dict] = []
        stun = [u.strip() for u in self.settings.stun_urls.split(",") if u.strip()]
        if stun and not self.settings.audio_require_relay:
            servers.append({"urls": stun})
        turn = [u.strip() for u in self.settings.turn_urls.split(",") if u.strip()]
        if turn and self.settings.turn_shared_secret:
            # coturn "use-auth-secret" REST credentials, unique per participant/call.
            expiry = int(time.time()) + TURN_CREDENTIAL_SECONDS
            username = f"{expiry}:{call.id}:{secrets.token_hex(4)}"
            digest = hmac.new(self.settings.turn_shared_secret.encode(), username.encode(), hashlib.sha1).digest()
            servers.append({"urls": turn, "username": username,
                            "credential": base64.b64encode(digest).decode()})
        policy = "relay" if self.settings.audio_require_relay else "all"
        return {"ice_servers": servers, "ice_transport_policy": policy}

    def call_request(self, key: str, interaction_id: str) -> dict:
        if not self.settings.audio_enabled:
            raise CoordinatorError("audio_unavailable", "Audio calls are not available right now.")
        if self.settings.audio_require_relay and not (self.settings.turn_urls and self.settings.turn_shared_secret):
            raise CoordinatorError("audio_unavailable", "Audio relay is not configured.")
        interaction = self._interaction_for(key, interaction_id)
        if interaction.interrupted:
            raise CoordinatorError("interrupted", "Wait for the connection to recover.")
        if interaction.call:
            raise CoordinatorError("call_active", "A call is already in progress.")
        me = self.participants[key]
        if me.call_cooldown_until > time.monotonic():
            raise CoordinatorError("cooldown", "Please wait a few seconds before calling again.")
        active = sum(1 for c in self.calls.values() if c.state != "ended")
        if active >= self.settings.max_calls:
            raise CoordinatorError("capacity", "All audio slots are busy. Try again shortly.")
        call = Call(id=_handle("c"), interaction_id=interaction.id, caller=key, callee=interaction.other(key))
        interaction.call = call
        self.calls[call.id] = call
        call.timer = self._later(CALL_RING_SECONDS, self._call_timeout, call.id, "ringing")
        metrics.incr("calls_attempted")
        self.emit(call.callee, "call.incoming", {"call_id": call.id, "interaction_id": interaction.id,
                                                 "expires_in": int(CALL_RING_SECONDS)})
        return {"call_id": call.id, "state": "ringing", "expires_in": int(CALL_RING_SECONDS)}

    def _call_for(self, key: str, call_id: str) -> Call:
        call = self.calls.get(call_id)
        if not call or key not in (call.caller, call.callee) or call.state == "ended":
            raise CoordinatorError("stale_call", "That call has ended.")
        interaction = self.interactions.get(call.interaction_id)
        if not interaction or interaction.call is not call:
            raise CoordinatorError("stale_call", "That call has ended.")
        return call

    def call_respond(self, key: str, call_id: str, accept: bool) -> dict:
        call = self._call_for(key, call_id)
        if key != call.callee or call.state != "ringing":
            raise CoordinatorError("stale_call", "That call request is no longer pending.")
        if not accept:
            self._end_call(call, "declined", cooldown=True)
            return {"state": "declined"}
        live = sum(1 for c in self.calls.values() if c.state in ("connecting", "connected"))
        if live >= self.settings.max_calls:
            self._end_call(call, "capacity", cooldown=False)
            raise CoordinatorError("capacity", "All audio slots are busy.")
        call.state = "connecting"
        if call.timer:
            call.timer.cancel()
        call.timer = self._later(CALL_SETUP_SECONDS, self._call_timeout, call.id, "connecting")
        for participant_key, role in ((call.caller, "offerer"), (call.callee, "answerer")):
            self.emit(participant_key, "call.authorized", {
                "call_id": call.id, "interaction_id": call.interaction_id, "role": role,
                **self._ice_config(call, participant_key)})
        return {"state": "connecting"}

    def call_signal(self, key: str, call_id: str, kind: str, payload: dict) -> None:
        call = self._call_for(key, call_id)
        if call.state not in ("connecting", "connected"):
            raise CoordinatorError("stale_call", "The call is not negotiating.")
        revision = payload["revision"]
        if revision < call.revisions.get(f"{key}:{kind}", 0):
            raise CoordinatorError("stale_signal", "Outdated negotiation revision.")
        call.revisions[f"{key}:{kind}"] = revision
        relay = self.settings.audio_require_relay
        try:
            if kind == "sdp":
                if (payload["sdp_type"] == "offer") != (key == call.caller):
                    raise CoordinatorError("invalid_sdp", "Unexpected SDP direction.")
                validate_sdp(payload["sdp"], relay)
            else:
                payload["candidate"] = validate_candidate(payload["candidate"], relay)
        except ProtocolError as exc:
            raise CoordinatorError(exc.code, exc.message) from None
        other = call.callee if key == call.caller else call.caller
        self.emit(other, f"call.{kind}", {"call_id": call.id, **payload})

    def call_state(self, key: str, call_id: str, state: str) -> None:
        call = self._call_for(key, call_id)
        if state == "failed":
            self._end_call(call, "failed")
            return
        call.connected_reports.add(key)
        if call.state == "connecting" and call.connected_reports >= {call.caller, call.callee}:
            call.state = "connected"
            call.connected_at = time.monotonic()
            if call.timer:
                call.timer.cancel()
                call.timer = None
            metrics.incr("calls_connected")
            metrics.observe("call_setup_ms", (call.connected_at - call.created) * 1000)
            for k in (call.caller, call.callee):
                self.emit(k, "call.connected", {"call_id": call.id})

    def call_refresh(self, key: str, call_id: str) -> dict:
        call = self._call_for(key, call_id)
        if call.state not in ("connecting", "connected"):
            raise CoordinatorError("stale_call", "The call is not active.")
        return {"call_id": call.id, **self._ice_config(call, key)}

    def call_end(self, key: str, call_id: str, reason: str) -> None:
        call = self.calls.get(call_id)
        if not call or key not in (call.caller, call.callee) or call.state == "ended":
            return  # idempotent
        self._end_call(call, reason, cooldown=(call.state == "ringing" and key == call.caller))

    def _call_timeout(self, call_id: str, expected_state: str) -> None:
        call = self.calls.get(call_id)
        if call and call.state == expected_state:
            self._end_call(call, "timeout" if expected_state == "ringing" else "setup_timeout",
                           cooldown=expected_state == "ringing")

    def _end_call(self, call: Call, reason: str, cooldown: bool = False) -> None:
        if call.state == "ended":
            return
        was_connected = call.state == "connected"
        call.state = "ended"
        if call.timer:
            call.timer.cancel()
        self.calls.pop(call.id, None)
        interaction = self.interactions.get(call.interaction_id)
        if interaction and interaction.call is call:
            interaction.call = None
        if not was_connected and reason not in ("declined", "timeout", "cancel"):
            metrics.incr("calls_failed")
        if was_connected and call.connected_at:
            seconds = time.monotonic() - call.connected_at
            metrics.add("call_seconds", seconds)
            metrics.add("participant_seconds", seconds * 2)
        if cooldown:
            caller = self.participants.get(call.caller)
            if caller:
                caller.call_cooldown_until = time.monotonic() + CALL_COOLDOWN_SECONDS
        for k in (call.caller, call.callee):
            self.emit(k, "call.ended", {"call_id": call.id, "reason": reason})

    # -------------------------------------------------------------- snapshot
    def state_snapshot(self, key: str) -> dict:
        p = self.participants[key]
        state = "idle"
        interaction_dto = None
        if p.queue_joined is not None:
            state = "searching"
        if p.interaction_id and p.interaction_id in self.interactions:
            state = "in_interaction"
            interaction = self.interactions[p.interaction_id]
            other = self.participants.get(interaction.other(key))
            rel_id = self._relationship_between(p, other) if other else None
            friend_state = "friends" if rel_id else (
                "requested_by_me" if key in interaction.friend_requests else
                "requested_by_peer" if interaction.other(key) in interaction.friend_requests else "none")
            call = interaction.call
            interaction_dto = {
                "interaction_id": interaction.id,
                "source": interaction.source,
                "started_at": interaction.started_at,
                "peer": other.peer_dto(interaction.handles[key]) if other else None,
                "peer_interrupted": interaction.other(key) in interaction.interrupted,
                "friend_state": friend_state,
                "relationship_id": rel_id,
                "friend_request_id": interaction.friend_requests.get(interaction.other(key)),
                "messages": [
                    {"message_id": m.id, "seq": m.seq, "mine": m.sender == key, "body": m.body,
                     "sent_at": m.sent_at, "delivered": m.delivered}
                    for m in interaction.ring
                ],
                # Audio never resumes automatically after a reconnect.
                "call": None if not call or call.state != "ringing" else {
                    "call_id": call.id, "state": "ringing", "incoming": call.callee == key},
            }
        invites = [
            {"invite_id": i.id, "from": self.participants[i.sender].friend_dto(),
             "relationship_id": i.relationship_id,
             "expires_in": max(0, int(i.expires - time.monotonic()))}
            for i in self.invites.values() if i.target == key and i.sender in self.participants
        ]
        return {
            "state": state,
            "identity": {
                "kind": p.kind,
                "display_name": p.display_name,
                "gender": p.gender,
                "topic_id": p.topic_id,
                "premium": p.premium,
                "gender_preference": p.gender_preference,
            },
            "interaction": interaction_dto,
            "invites": invites,
            "features": {"audio": self.settings.audio_enabled},
        }


coordinator = Coordinator()
