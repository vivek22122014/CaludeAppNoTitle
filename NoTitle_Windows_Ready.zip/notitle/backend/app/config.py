"""Runtime configuration.

All settings come from environment variables (or the project ``.env`` file that
``scripts/setup.ps1`` generates).  Secrets are never given defaults that would be
usable in production: when ``APP_ENV=production`` the validator refuses weak or
missing values instead of silently falling back.
"""

from __future__ import annotations

import base64
from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

BACKEND_DIR = Path(__file__).resolve().parent.parent
PROJECT_DIR = BACKEND_DIR.parent


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=(str(PROJECT_DIR / ".env"),),
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    app_env: Literal["development", "test", "production"] = "development"
    app_name: str = "NoTitle"

    # Network ---------------------------------------------------------------
    public_host: str = "127.0.0.1"
    public_port: int = 8080
    private_host: str = "127.0.0.1"
    private_port: int = 8081
    public_origin: str = "http://localhost:8080"
    private_origin: str = "http://localhost:8081"
    # Extra origins allowed to call the API (e.g. Next.js dev servers).
    extra_public_origins: str = "http://127.0.0.1:8080,http://localhost:3000,http://127.0.0.1:3000"
    extra_private_origins: str = "http://127.0.0.1:8081,http://localhost:3001,http://127.0.0.1:3001"

    # Database --------------------------------------------------------------
    database_url: str = "postgresql://notitle_app:notitle_app@127.0.0.1:5433/notitle"
    # Owner/migrator connection.  Falls back to database_url when unset.
    database_migrator_url: str | None = None
    # Superuser/admin connection used only by `cli db-bootstrap`.
    database_admin_url: str | None = None
    db_pool_min: int = 2
    db_pool_max: int = 15
    db_statement_timeout_ms: int = 5000

    # Secrets (base64url, 32 bytes each) ----------------------------------------
    hmac_key: str = ""
    wrapping_key: str = ""
    journal_key: str = ""
    payment_webhook_secret: str = ""  # simulator webhook signing secret

    # Cookies ---------------------------------------------------------------
    cookie_secure: bool = False

    # Static exports ----------------------------------------------------------
    public_static_dir: str = str(PROJECT_DIR / "frontend" / "public" / "out")
    admin_static_dir: str = str(PROJECT_DIR / "frontend" / "admin" / "out")

    # Local state (journal, exports) -----------------------------------------
    data_dir: str = str(PROJECT_DIR / ".local")

    # Feature gates ---------------------------------------------------------
    admission_open: bool = True
    audio_enabled: bool = True
    payments_enabled: bool = True
    payment_provider: Literal["simulator", "cashfree", "disabled"] = "simulator"

    # Audio / TURN ------------------------------------------------------------
    turn_urls: str = ""  # comma separated, e.g. "turn:turn.example.com:3478?transport=udp"
    turn_shared_secret: str = ""
    stun_urls: str = ""
    audio_require_relay: bool = False

    # Cashfree ----------------------------------------------------------------
    cashfree_env: Literal["sandbox", "production"] = "sandbox"
    cashfree_client_id: str = ""
    cashfree_client_secret: str = ""
    cashfree_api_version: str = "2025-01-01"

    # Capacity budgets (blueprint chapter 07) -------------------------------------
    max_connected: int = 200
    max_waiting: int = 100
    max_calls: int = 25
    max_guests: int = 1000

    log_level: str = "INFO"

    @field_validator("public_origin", "private_origin")
    @classmethod
    def _strip_slash(cls, value: str) -> str:
        return value.rstrip("/")

    @model_validator(mode="after")
    def _check_production(self) -> "Settings":
        if self.app_env == "production":
            problems = []
            for name in ("hmac_key", "wrapping_key", "journal_key"):
                if len(_decode_key(getattr(self, name))) != 32:
                    problems.append(f"{name.upper()} must be a 32-byte base64url key")
            if not self.cookie_secure:
                problems.append("COOKIE_SECURE must be true in production")
            if self.payment_provider == "simulator":
                problems.append("PAYMENT_PROVIDER=simulator is development-only")
            if self.audio_enabled and not self.audio_require_relay:
                problems.append("AUDIO_REQUIRE_RELAY must be true in production")
            if not self.public_origin.startswith("https://"):
                problems.append("PUBLIC_ORIGIN must use https in production")
            if problems:
                raise ValueError("; ".join(problems))
        return self

    # Derived -----------------------------------------------------------------
    @property
    def is_dev(self) -> bool:
        return self.app_env in ("development", "test")

    @property
    def migrator_url(self) -> str:
        return self.database_migrator_url or self.database_url

    @property
    def public_origins(self) -> set[str]:
        return {self.public_origin} | _split(self.extra_public_origins)

    @property
    def private_origins(self) -> set[str]:
        return {self.private_origin} | _split(self.extra_private_origins)

    def key_bytes(self, name: str) -> bytes:
        raw = _decode_key(getattr(self, name))
        if len(raw) != 32:
            if self.is_dev:
                # Deterministic per-name development key so tests are reproducible.
                # setup.ps1 always writes real random keys into .env.
                import hashlib

                return hashlib.sha256(f"notitle-dev-only::{name}".encode()).digest()
            raise RuntimeError(f"{name} is not configured")
        return raw

    @property
    def data_path(self) -> Path:
        path = Path(self.data_dir)
        path.mkdir(parents=True, exist_ok=True)
        return path

    def cookie_name(self, base: str) -> str:
        # The __Host- prefix requires the Secure attribute (HTTPS).  Locally over
        # plain http we use the bare name so every browser accepts the cookie.
        return f"__Host-{base}" if self.cookie_secure else base


def _split(value: str) -> set[str]:
    return {item.strip().rstrip("/") for item in value.split(",") if item.strip()}


def _decode_key(value: str) -> bytes:
    if not value:
        return b""
    try:
        padded = value + "=" * (-len(value) % 4)
        return base64.urlsafe_b64decode(padded)
    except Exception:  # noqa: BLE001 - invalid keys are reported as missing
        return b""


@lru_cache
def get_settings() -> Settings:
    return Settings()

