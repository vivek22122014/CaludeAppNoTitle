"""ASGI application factories.

Two separate applications share one process and one service container:

* public  – user API, WebSocket, webhooks and the public static site
* private – staff API (/internal/v1) and the private static site

The public app never mounts /internal routes; the private app never mounts
the public API.  Both have their own OpenAPI documents (disabled in production).
"""

from __future__ import annotations

from fastapi import FastAPI

from app import db
from app.config import get_settings
from app.http.errors import install_handlers, ok
from app.http.middleware import EdgeMiddleware
from app.realtime.coordinator import coordinator
from app.static_site import StaticSite


def _docs(settings) -> dict:
    if settings.app_env == "production":
        return {"docs_url": None, "redoc_url": None, "openapi_url": None}
    return {}


def create_public_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(title="NoTitle public API", version="1.0.0", **_docs(settings))
    install_handlers(app)

    from app.api.public import auth, billing, core, me, privacy, safety, social, support

    for module in (core, auth, me, social, safety, support, privacy, billing):
        app.include_router(module.router)

    @app.get("/health/live", include_in_schema=False)
    async def live():
        return ok({"status": "live"})

    @app.get("/health/ready", include_in_schema=False)
    async def ready():
        db_ok = await db.ping()
        status = "ready" if db_ok and coordinator.owner_epoch and not coordinator.draining else "not_ready"
        response = ok({"status": status, "database": db_ok, "owner_epoch": coordinator.owner_epoch,
                       "runtime": coordinator.counts()})
        if status != "ready":
            response.status_code = 503
        return response

    cashfree = settings.payment_provider == "cashfree"
    site = StaticSite(settings.public_static_dir, "public",
                      extra_script_src=("https://sdk.cashfree.com",) if cashfree else (),
                      extra_connect_src=("https://*.cashfree.com",) if cashfree else (),
                      frame_src=("https://*.cashfree.com",) if cashfree else ())
    app.mount("/", site, name="public-site")
    app.add_middleware(EdgeMiddleware, allowed_origins=lambda: settings.public_origins, surface="public")
    return app


def create_private_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(title="NoTitle private staff API", version="1.0.0", **_docs(settings))
    install_handlers(app)

    from app.api.private import routes

    app.include_router(routes.router)

    @app.get("/health/live", include_in_schema=False)
    async def live():
        return ok({"status": "live", "surface": "private"})

    site = StaticSite(settings.admin_static_dir, "admin")
    app.mount("/", site, name="admin-site")
    app.add_middleware(EdgeMiddleware, allowed_origins=lambda: settings.private_origins, surface="private")
    return app

