"""Operator CLI: ``python -m app.cli <command>``.

Commands
  check            Validate configuration and database connectivity
  db-bootstrap     Create the database and least-privilege roles (needs DATABASE_ADMIN_URL)
  migrate          Apply pending migrations (runtime must be stopped)
  migrate-status   Show applied/pending migrations
  create-staff     Create a staff account (prints TOTP secret + recovery codes once)
  dev-totp         Print the next valid TOTP code for a staff user (development only)
  backup           Write a plain SQL backup + journal copy into .local/backups
  restore          Restore a backup into a NEW, empty database
  lint-policies    Check policy publication rules
  verify-journal   Verify the privacy journal chain
"""

from __future__ import annotations

import argparse
import asyncio
import getpass
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit

import psycopg
from psycopg import sql

from app import migrations, policies
from app.config import get_settings


def _run_async(coro):
    return asyncio.run(coro, loop_factory=asyncio.SelectorEventLoop)


def _redact(url: str) -> str:
    parts = urlsplit(url)
    if parts.password:
        netloc = parts.netloc.replace(f":{parts.password}@", ":****@")
        return urlunsplit(parts._replace(netloc=netloc))
    return url


def cmd_check(_: argparse.Namespace) -> int:
    s = get_settings()
    print(f"APP_ENV           {s.app_env}")
    print(f"Public origin     {s.public_origin}  (listen {s.public_host}:{s.public_port})")
    print(f"Private origin    {s.private_origin}  (listen {s.private_host}:{s.private_port})")
    print(f"Database          {_redact(s.database_url)}")
    print(f"Payments          {s.payment_provider} (enabled={s.payments_enabled})")
    print(f"Audio             enabled={s.audio_enabled} relay_only={s.audio_require_relay}")
    for name in ("hmac_key", "wrapping_key", "journal_key"):
        print(f"{name:<17} {'configured' if len(getattr(s, name)) >= 40 else 'MISSING (development fallback in use)'}")
    try:
        with psycopg.connect(s.database_url, connect_timeout=5) as conn:
            version = conn.execute("SHOW server_version").fetchone()[0]
        print(f"PostgreSQL        reachable (server {version})")
    except psycopg.Error as exc:
        print(f"PostgreSQL        NOT reachable: {str(exc).splitlines()[0]}")
        return 1
    pending = [m["id"] for m in migrations.status(s.database_url) if not m["applied"]]
    print(f"Migrations        {'up to date' if not pending else 'pending: ' + ', '.join(pending)}")
    return 0 if not pending else 1


def cmd_db_bootstrap(args: argparse.Namespace) -> int:
    s = get_settings()
    admin = args.admin_url or s.database_admin_url
    if not admin:
        print("DATABASE_ADMIN_URL is not set.", file=sys.stderr)
        return 2
    app_url, owner_url = urlsplit(s.database_url), urlsplit(s.migrator_url)
    dbname = app_url.path.lstrip("/")
    roles = [(owner_url.username, owner_url.password), (app_url.username, app_url.password)]
    with psycopg.connect(admin, autocommit=True) as conn:
        for user, password in roles:
            if not user or not password:
                continue
            exists = conn.execute("SELECT 1 FROM pg_roles WHERE rolname = %s", (user,)).fetchone()
            if exists:
                conn.execute(sql.SQL("ALTER ROLE {} WITH LOGIN PASSWORD {}").format(sql.Identifier(user), sql.Literal(password)))
            else:
                conn.execute(sql.SQL("CREATE ROLE {} WITH LOGIN PASSWORD {}").format(sql.Identifier(user), sql.Literal(password)))
            print(f"role ready: {user}")
        exists = conn.execute("SELECT 1 FROM pg_database WHERE datname = %s", (dbname,)).fetchone()
        if not exists:
            conn.execute(sql.SQL("CREATE DATABASE {} OWNER {} ENCODING 'UTF8' TEMPLATE template0").format(
                sql.Identifier(dbname), sql.Identifier(owner_url.username)))
            print(f"database created: {dbname}")
        else:
            print(f"database exists: {dbname}")
        conn.execute(sql.SQL("REVOKE ALL ON DATABASE {} FROM PUBLIC").format(sql.Identifier(dbname)))
        for user, _ in roles:
            if user:
                conn.execute(sql.SQL("GRANT CONNECT ON DATABASE {} TO {}").format(sql.Identifier(dbname), sql.Identifier(user)))
    db_admin = urlunsplit(urlsplit(admin)._replace(path="/" + dbname))
    with psycopg.connect(db_admin, autocommit=True) as conn:
        conn.execute(sql.SQL("ALTER SCHEMA public OWNER TO {}").format(sql.Identifier(owner_url.username)))
        conn.execute("REVOKE CREATE ON SCHEMA public FROM PUBLIC")
    print("bootstrap complete")
    return 0


def cmd_migrate(_: argparse.Namespace) -> int:
    s = get_settings()
    app_user = urlsplit(s.database_url).username
    owner_user = urlsplit(s.migrator_url).username
    applied = migrations.migrate(s.migrator_url, app_role=app_user if app_user != owner_user else None)
    print("applied: " + (", ".join(applied) if applied else "nothing (already up to date)"))
    return 0


def cmd_migrate_status(_: argparse.Namespace) -> int:
    for item in migrations.status(get_settings().migrator_url):
        state = "applied" if item["applied"] else "PENDING"
        check = "" if item["checksum_ok"] in (None, True) else "  CHECKSUM MISMATCH"
        print(f"{item['id']:<36} {state}{check}")
    return 0


def cmd_create_staff(args: argparse.Namespace) -> int:
    from app import db
    from app.services import staff

    password = os.environ.get("NOTITLE_STAFF_PASSWORD") or ""
    if not password:
        password = getpass.getpass("Staff password (min 12 chars): ")
        if password != getpass.getpass("Repeat password: "):
            print("Passwords do not match.", file=sys.stderr)
            return 2

    async def go() -> dict:
        await db.open_pool()
        try:
            return await staff.create_staff(args.username, password, args.roles)
        finally:
            await db.close_pool()

    try:
        result = _run_async(go())
    except Exception as exc:  # noqa: BLE001
        print(f"Could not create staff account: {getattr(exc, 'message', exc)}", file=sys.stderr)
        return 1
    out_dir = get_settings().data_path / "staff"
    out_dir.mkdir(parents=True, exist_ok=True)
    enrol = out_dir / f"{result['username']}-enrollment.txt"
    enrol.write_text(
        "NoTitle staff enrollment – KEEP PRIVATE, then delete this file\n"
        f"username: {result['username']}\nroles: {', '.join(result['roles'])}\n"
        f"TOTP secret: {result['totp_secret']}\notpauth URI: {result['otpauth_uri']}\n"
        "Recovery codes (each works once):\n" + "\n".join(result["recovery_codes"]) + "\n", encoding="utf-8")
    print(f"Staff account '{result['username']}' created with roles {', '.join(result['roles'])}.")
    print(f"TOTP secret (add to an authenticator app): {result['totp_secret']}")
    print(f"Enrollment file with recovery codes: {enrol}")
    return 0


def cmd_dev_totp(args: argparse.Namespace) -> int:
    from app import db
    from app.services import staff

    if get_settings().app_env == "production":
        print("dev-totp is disabled in production.", file=sys.stderr)
        return 2

    async def go() -> str:
        await db.open_pool()
        try:
            return await staff.current_totp_for_dev(args.username)
        finally:
            await db.close_pool()

    try:
        print(_run_async(go()))
    except LookupError as exc:
        print(str(exc), file=sys.stderr)
        return 1
    return 0


def _pg_tool(name: str) -> list[str] | None:
    local = shutil.which(name)
    if local:
        return [local]
    bundled = Path(get_settings().data_path).parent / ".tools" / "pgsql" / "bin" / f"{name}.exe"
    if bundled.exists():
        return [str(bundled)]
    container = os.environ.get("NOTITLE_DB_CONTAINER", "notitle-postgres")
    if shutil.which("docker"):
        probe = subprocess.run(["docker", "inspect", "-f", "{{.State.Running}}", container], capture_output=True, text=True)
        if probe.returncode == 0 and probe.stdout.strip() == "true":
            return ["docker", "exec", "-i", container, name]
    return None


def _container_url(url: str, tool: list[str]) -> str:
    """Inside the container the server listens on localhost:5432."""
    if tool[0] != "docker":
        return url
    parts = urlsplit(url)
    netloc = parts.netloc.rsplit("@", 1)
    host = f"{netloc[0]}@127.0.0.1:5432" if len(netloc) == 2 else "127.0.0.1:5432"
    return urlunsplit(parts._replace(netloc=host))


def cmd_backup(_: argparse.Namespace) -> int:
    s = get_settings()
    tool = _pg_tool("pg_dump")
    if tool is None:
        print("pg_dump not found (install PostgreSQL client tools or run the Docker database).", file=sys.stderr)
        return 2
    out_dir = s.data_path / "backups"
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    target = out_dir / f"notitle-{stamp}.sql"
    with target.open("wb") as fh:
        result = subprocess.run([*tool, "--no-owner", "--no-privileges", "--dbname", _container_url(s.migrator_url, tool)],
                                stdout=fh, stderr=subprocess.PIPE)
    if result.returncode != 0:
        target.unlink(missing_ok=True)
        print("pg_dump failed: " + result.stderr.decode(errors="replace")[:400], file=sys.stderr)
        return 1
    journal = s.data_path / "journal" / "privacy-journal.jsonl"
    if journal.exists():
        shutil.copy2(journal, out_dir / f"privacy-journal-{stamp}.jsonl")
    status = {"backup": target.name, "completed_at": datetime.now(timezone.utc).isoformat(),
              "bytes": target.stat().st_size, "verified": target.stat().st_size > 1000}
    (out_dir / "status.json").write_text(json.dumps(status, indent=2), encoding="utf-8")
    print(f"backup written: {target} ({status['bytes']} bytes)")
    print("Note: backups contain encrypted support data; keep .env keys safe separately or the backup is unreadable.")
    return 0


def cmd_restore(args: argparse.Namespace) -> int:
    s = get_settings()
    admin = s.database_admin_url
    if not admin:
        print("DATABASE_ADMIN_URL is required to create the restore target.", file=sys.stderr)
        return 2
    tool = _pg_tool("psql")
    if tool is None:
        print("psql not found.", file=sys.stderr)
        return 2
    target_db = args.target_db
    with psycopg.connect(admin, autocommit=True) as conn:
        if conn.execute("SELECT 1 FROM pg_database WHERE datname = %s", (target_db,)).fetchone():
            print(f"Database {target_db} already exists; restore only into a new empty database.", file=sys.stderr)
            return 2
        owner = urlsplit(s.migrator_url).username
        conn.execute(sql.SQL("CREATE DATABASE {} OWNER {}").format(sql.Identifier(target_db), sql.Identifier(owner)))
    url = urlunsplit(urlsplit(s.migrator_url)._replace(path="/" + target_db))
    with open(args.file, "rb") as fh:
        result = subprocess.run([*tool, "-v", "ON_ERROR_STOP=1", "--quiet", "--dbname", _container_url(url, tool)],
                                stdin=fh, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    if result.returncode != 0:
        print("restore failed: " + result.stderr.decode(errors="replace")[:400], file=sys.stderr)
        return 1
    app_user = urlsplit(s.database_url).username
    with psycopg.connect(url, autocommit=True) as conn:
        migrations.grant_runtime_role(conn, app_user)
    print(f"restored into new database '{target_db}'. To use it, point DATABASE_URL/DATABASE_MIGRATOR_URL at it;")
    print("the runtime replays the privacy journal at startup so earlier deletions are re-applied.")
    return 0


def cmd_lint_policies(_: argparse.Namespace) -> int:
    problems = policies.lint()
    for kind, p in policies.all_policies().items():
        print(f"{kind:<12} {p.version:<22} {p.state:<8} sha256={p.digest[:16]}…")
    for problem in problems:
        print("PROBLEM: " + problem)
    return 1 if problems else 0


def cmd_verify_journal(_: argparse.Namespace) -> int:
    from app.services.journal import JournalError, journal

    try:
        journal.load()
    except JournalError as exc:
        print(f"journal INVALID: {exc}")
        return 1
    print(f"journal OK: {journal.status()}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m app.cli", description="NoTitle operator commands")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("check").set_defaults(fn=cmd_check)
    p = sub.add_parser("db-bootstrap")
    p.add_argument("--admin-url")
    p.set_defaults(fn=cmd_db_bootstrap)
    sub.add_parser("migrate").set_defaults(fn=cmd_migrate)
    sub.add_parser("migrate-status").set_defaults(fn=cmd_migrate_status)
    p = sub.add_parser("create-staff")
    p.add_argument("--username", required=True)
    p.add_argument("--roles", nargs="+", default=["owner"], choices=["owner", "moderator", "billing", "privacy", "analyst"])
    p.set_defaults(fn=cmd_create_staff)
    p = sub.add_parser("dev-totp")
    p.add_argument("--username", required=True)
    p.set_defaults(fn=cmd_dev_totp)
    sub.add_parser("backup").set_defaults(fn=cmd_backup)
    p = sub.add_parser("restore")
    p.add_argument("--file", required=True)
    p.add_argument("--target-db", required=True)
    p.set_defaults(fn=cmd_restore)
    sub.add_parser("lint-policies").set_defaults(fn=cmd_lint_policies)
    sub.add_parser("verify-journal").set_defaults(fn=cmd_verify_journal)
    args = parser.parse_args(argv)
    return args.fn(args)


if __name__ == "__main__":
    sys.exit(main())
