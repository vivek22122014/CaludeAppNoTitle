"""Retention sweeps, obligation clocks and reconciliation scheduling (chapter 37).

Every sweep is bounded, idempotent and respects active legal holds.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone

from app import db
from app.services import jobs, keys

log = logging.getLogger("notitle.retention")
BATCH = 500


async def mark_overdue() -> int:
    return await db.execute(
        """UPDATE case_obligations SET status = 'overdue'
           WHERE status IN ('open','acknowledged')
             AND (act_by < now() OR (acknowledged_at IS NULL AND acknowledge_by < now()))""")


async def reconcile_pending() -> None:
    bucket = int(datetime.now(timezone.utc).timestamp() // 300)
    async with db.transaction() as conn:
        rows = await (await conn.execute(
            """SELECT id FROM purchases WHERE state IN ('created','pending')
               AND created_at < now() - interval '1 minute' AND created_at > now() - interval '24 hours'
               ORDER BY created_at LIMIT 50""")).fetchall()
        for row in rows:
            await jobs.enqueue(conn, "payment.reconcile", f"sweep:{row['id']}:{bucket}", {"purchase_id": str(row["id"])})
        stale = await (await conn.execute(
            """UPDATE purchases SET state = 'needs_review', updated_at = now()
               WHERE state = 'pending' AND created_at < now() - interval '24 hours' RETURNING id""")).fetchall()
        if stale:
            log.warning("%s purchases moved to needs_review after 24 hours pending", len(stale))
        refunds = await (await conn.execute(
            "SELECT id FROM refunds WHERE state IN ('submitting','pending','needs_review') LIMIT 50")).fetchall()
        for row in refunds:
            await jobs.enqueue(conn, "refund.submit", f"refund:{row['id']}:{bucket}", {"refund_id": str(row["id"])})


async def sweep() -> dict:
    out: dict[str, int] = {}
    # Closed support cases (90 days) and safety cases (180 days), unless held.
    async with db.transaction() as conn:
        rows = await (await conn.execute(
            """SELECT c.id, c.key_id FROM support_cases c
               WHERE c.status = 'closed'
                 AND c.closed_at < now() - CASE WHEN c.category = 'safety' THEN interval '180 days' ELSE interval '90 days' END
                 AND NOT EXISTS (SELECT 1 FROM legal_holds h WHERE h.state = 'active'
                                 AND h.scope IN ('support_cases','safety_reports','all')
                                 AND h.subject_ref IN (SELECT subject_ref FROM reports r WHERE r.case_id = c.id))
               LIMIT %s""", (BATCH,))).fetchall()
        for row in rows:
            reports = await (await conn.execute("SELECT id, key_id FROM reports WHERE case_id = %s", (row["id"],))).fetchall()
            for report in reports:
                await conn.execute("UPDATE moderation_decisions SET report_id = NULL WHERE report_id = %s", (report["id"],))
                await conn.execute("DELETE FROM reports WHERE id = %s", (report["id"],))
                await keys.destroy_key(conn, report["key_id"])
            await conn.execute("UPDATE moderation_decisions SET case_id = NULL WHERE case_id = %s", (row["id"],))
            await conn.execute("UPDATE moderation_decisions SET appeal_case_id = NULL WHERE appeal_case_id = %s", (row["id"],))
            await conn.execute("UPDATE support_cases SET parent_case_id = NULL WHERE parent_case_id = %s", (row["id"],))
            await conn.execute("DELETE FROM privacy_requests WHERE case_id = %s", (row["id"],))
            await conn.execute("DELETE FROM scoped_receipts WHERE kind = 'case' AND scope_ref = %s", (str(row["id"]),))
            await conn.execute("DELETE FROM support_cases WHERE id = %s", (row["id"],))
            await keys.destroy_key(conn, row["key_id"])
        out["support_cases"] = len(rows)
    simple = {
        "exports": """UPDATE privacy_exports SET status = 'expired', package_ct = NULL
                      WHERE status = 'ready' AND expires_at < now()""",
        "operation_results": "DELETE FROM operation_results WHERE expires_at < now()",
        "account_sessions": "DELETE FROM account_sessions WHERE absolute_expires_at < now() - interval '1 day' OR revoked_at < now() - interval '1 day'",
        "staff_sessions": "DELETE FROM staff_sessions WHERE absolute_expires_at < now() - interval '1 day' OR revoked_at < now() - interval '1 day'",
        "scoped_sessions": "DELETE FROM scoped_sessions WHERE absolute_expires_at < now() - interval '1 day'",
        "previews": "DELETE FROM sensitive_previews WHERE expires_at < now() - interval '1 day'",
        "webhook_inbox": "DELETE FROM webhook_inbox WHERE received_at < now() - interval '30 days'",
        "access_audit": "DELETE FROM access_audit WHERE created_at < now() - interval '180 days'",
        "consent_proof": "DELETE FROM consent_records WHERE account_id IS NULL AND recorded_at < now() - interval '180 days'",
        "jobs": "DELETE FROM durable_jobs WHERE state = 'done' AND updated_at < now() - interval '7 days'",
        "agg_minute": "DELETE FROM aggregate_buckets WHERE level = 'minute' AND bucket_start < now() - interval '7 days'",
        "agg_hour": "DELETE FROM aggregate_buckets WHERE level = 'hour' AND bucket_start < now() - interval '30 days'",
        "agg_day": "DELETE FROM aggregate_buckets WHERE level = 'day' AND bucket_start < now() - interval '90 days'",
        "agg_month": "DELETE FROM aggregate_buckets WHERE level = 'month' AND bucket_start < now() - interval '365 days'",
        "agg_batches": "DELETE FROM aggregate_batches WHERE received_at < now() - interval '7 days'",
    }
    for name, sql in simple.items():
        out[name] = await db.execute(sql)
    log.info("retention sweep %s", {k: v for k, v in out.items() if v})
    return out
