"""Durable background jobs with leases (SELECT … FOR UPDATE SKIP LOCKED).

Payloads carry references only.  Each claimed job commits its lease before
external work, records its result afterwards and retries with backoff up to
``max_attempts``; malformed jobs end in ``failed`` rather than looping forever.
Periodic maintenance (metrics flush, rollups, retention, reconciliation sweep,
obligation clocks, guest expiry) runs from the same supervisor.
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Awaitable, Callable

from app import db

log = logging.getLogger("notitle.jobs")

LEASE = timedelta(minutes=2)
MAX_ACTIVE = 4
Handler = Callable[[dict], Awaitable[None]]
HANDLERS: dict[str, Handler] = {}


def handler(kind: str):
    def wrap(fn: Handler) -> Handler:
        HANDLERS[kind] = fn
        return fn
    return wrap


async def enqueue(conn: Any, kind: str, dedupe_key: str, payload: dict, delay_seconds: int = 0) -> None:
    await conn.execute(
        """INSERT INTO durable_jobs (kind, dedupe_key, payload, available_at)
           VALUES (%s, %s, %s, now() + make_interval(secs => %s)) ON CONFLICT (dedupe_key) DO NOTHING""",
        (kind, dedupe_key, json.dumps(payload), delay_seconds))


async def claim(limit: int = MAX_ACTIVE) -> list[dict]:
    async with db.transaction() as conn:
        rows = await (await conn.execute(
            """SELECT id, kind, payload, attempts, max_attempts FROM durable_jobs
               WHERE (state IN ('ready','retry') AND available_at <= now())
                  OR (state = 'running' AND lease_until < now())
               ORDER BY available_at LIMIT %s FOR UPDATE SKIP LOCKED""", (limit,))).fetchall()
        for row in rows:
            await conn.execute(
                "UPDATE durable_jobs SET state = 'running', lease_until = %s, attempts = attempts + 1, updated_at = now() WHERE id = %s",
                (datetime.now(timezone.utc) + LEASE, row["id"]))
    return rows


async def run_one(job: dict) -> None:
    fn = HANDLERS.get(job["kind"])
    try:
        if fn is None:
            raise ValueError(f"no handler for {job['kind']}")
        await fn(job["payload"])
        await db.execute("UPDATE durable_jobs SET state = 'done', lease_until = NULL, updated_at = now() WHERE id = %s",
                         (job["id"],))
    except RetryLater as exc:
        await db.execute(
            """UPDATE durable_jobs SET state = 'retry', available_at = now() + make_interval(secs => %s),
                      attempts = greatest(attempts - 1, 0), lease_until = NULL, updated_at = now() WHERE id = %s""",
            (exc.seconds, job["id"]))
    except Exception as exc:  # noqa: BLE001
        attempts = job["attempts"] + 1
        final = attempts >= job["max_attempts"]
        log.warning("job %s (%s) failed attempt %s: %s", job["id"], job["kind"], attempts, type(exc).__name__)
        await db.execute(
            """UPDATE durable_jobs SET state = %s, available_at = now() + make_interval(secs => %s),
                      last_error = %s, lease_until = NULL, updated_at = now() WHERE id = %s""",
            ("failed" if final else "retry", min(3600, 2 ** attempts * 5), type(exc).__name__[:100], job["id"]))


class RetryLater(Exception):
    def __init__(self, seconds: int) -> None:
        super().__init__(seconds)
        self.seconds = seconds


# ---------------------------------------------------------------------------
# Handlers
# ---------------------------------------------------------------------------


@handler("payment.reconcile")
async def _reconcile(payload: dict) -> None:
    from app.services import billing

    state = await billing.reconcile(payload["purchase_id"])
    if state in ("pending", "created"):
        raise RetryLater(60)


@handler("refund.submit")
async def _refund(payload: dict) -> None:
    from app.services import billing

    state = await billing.submit_refund(payload["refund_id"])
    if state in ("pending", "needs_review", "submitting"):
        raise RetryLater(300)


@handler("export.build")
async def _export(payload: dict) -> None:
    from app.services import privacy

    await privacy.build_export(payload["export_id"])


@handler("deletion.purge")
async def _purge(payload: dict) -> None:
    from app.services import privacy

    await privacy.purge(payload["deletion_id"])


# ---------------------------------------------------------------------------
# Supervisor
# ---------------------------------------------------------------------------


class Supervisor:
    def __init__(self) -> None:
        self.tasks: list[asyncio.Task] = []
        self.stopping = False
        self.last_runs: dict[str, float] = {}

    def start(self) -> None:
        self.tasks = [
            asyncio.create_task(self._job_loop(), name="jobs"),
            asyncio.create_task(self._periodic(), name="maintenance"),
            asyncio.create_task(self._loop_lag(), name="loop-lag"),
        ]

    async def stop(self) -> None:
        self.stopping = True
        for task in self.tasks:
            task.cancel()
        for task in self.tasks:
            try:
                await task
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass
        from app.services import analytics

        try:
            await analytics.flush()
        except Exception:  # noqa: BLE001
            pass

    async def _job_loop(self) -> None:
        while not self.stopping:
            try:
                jobs = await claim()
                if jobs:
                    await asyncio.gather(*(run_one(j) for j in jobs))
                    continue
            except Exception:  # noqa: BLE001
                log.exception("job loop error")
            await asyncio.sleep(2)

    async def _loop_lag(self) -> None:
        from app.services.analytics import metrics

        while not self.stopping:
            start = time.perf_counter()
            await asyncio.sleep(1)
            metrics.observe("loop_lag_ms", max(0.0, (time.perf_counter() - start - 1) * 1000))

    async def _every(self, name: str, seconds: float, fn: Callable[[], Awaitable[Any]]) -> None:
        now = time.monotonic()
        if now - self.last_runs.get(name, 0) >= seconds:
            self.last_runs[name] = now
            try:
                await fn()
            except Exception:  # noqa: BLE001
                log.exception("periodic task %s failed", name)

    async def _periodic(self) -> None:
        from app.services import analytics, retention

        await asyncio.sleep(5)
        while not self.stopping:
            await self._every("metrics.flush", 60, analytics.flush)
            await self._every("analytics.rollup", 600, analytics.rollup)
            await self._every("guests.sweep", 60, _sweep_guests)
            await self._every("obligations.overdue", 60, retention.mark_overdue)
            await self._every("payments.sweep", 120, retention.reconcile_pending)
            await self._every("retention.sweep", 3600, retention.sweep)
            await asyncio.sleep(5)


async def _sweep_guests() -> None:
    from app.services import identity

    identity.guests.sweep()


async def backlog() -> dict:
    row = await db.fetch_one(
        """SELECT count(*) FILTER (WHERE state IN ('ready','retry')) AS due,
                  count(*) FILTER (WHERE state = 'running') AS running,
                  count(*) FILTER (WHERE state = 'failed') AS failed FROM durable_jobs""")
    return {k: int(v) for k, v in row.items()} if row else {}


supervisor = Supervisor()
