"""Premium one-time passes, verified captures, FIFO ledger, receipts, remedies (chapters 15, 30, 31).

Invariants enforced here and by SQL constraints:

* granted = consumed + available + held + revoked for every lot (CHECK).
* One lot per purchase and one fact per provider payment ID (UNIQUE).
* Time is granted only after the server independently fetches a successful
  capture matching order, amount and currency – never from a redirect alone.
* Paid time elapses in wall-clock order across available lots (grant_seq);
  held lots do not elapse.  A hold touches only the origin purchase's lot.
* No voluntary refunds.  Staff may only authorise payment_error,
  statutory_remedy or provider_bank_direction remedies, via preview/confirm.
* Lock order: financial_subject → purchase → lots → refund.  No provider call
  happens while those locks are held.
"""

from __future__ import annotations

import logging
import re
import time
import uuid
from datetime import datetime, timezone
from typing import Any

from app import db, policies
from app.config import get_settings
from app.http.errors import ApiError, conflict, invalid, not_found
from app.security import crypto
from app.services.payments.base import (
    ProviderRejected, ProviderUnavailable, normalize_refund_status,
)

log = logging.getLogger("notitle.billing")

REMEDY_BASES = ("payment_error", "statutory_remedy", "provider_bank_direction")
_provider = None


def provider():
    global _provider
    if _provider is None:
        name = get_settings().payment_provider
        if name == "simulator":
            from app.services.payments.simulator import SimulatorProvider

            _provider = SimulatorProvider()
        elif name == "cashfree":
            from app.services.payments.cashfree import CashfreeProvider

            _provider = CashfreeProvider()
        else:
            raise ApiError(503, "payments_unavailable", "Purchases are not available right now.")
    return _provider


def sales_open() -> bool:
    s = get_settings()
    if not s.payments_enabled or s.payment_provider == "disabled":
        return False
    if s.payment_provider == "cashfree" and not (s.cashfree_client_id and s.cashfree_client_secret):
        return False
    if s.payment_provider == "simulator" and s.app_env == "production":
        return False
    return True


def _now() -> datetime:
    return datetime.now(timezone.utc)


# ---------------------------------------------------------------------------
# Catalog
# ---------------------------------------------------------------------------

PLAN_TEXT = {
    "Short3": "3-day pass",
    "Week7": "7-day pass",
    "Month30": "30-day pass",
    "Annual365": "365-day pass",
}


async def plans() -> list[dict]:
    rows = await db.fetch_all(
        """SELECT DISTINCT ON (code) code, version, gross_paise, duration_seconds, currency, enabled, tax_note
           FROM plan_versions ORDER BY code, version DESC""")
    order = ["Short3", "Week7", "Month30", "Annual365"]
    rows.sort(key=lambda r: order.index(r["code"]))
    refund = policies.get("refund")
    out = []
    for r in rows:
        available = bool(r["enabled"] and sales_open())
        out.append({
            "code": r["code"], "version": r["version"], "label": PLAN_TEXT[r["code"]],
            "price_paise": r["gross_paise"], "price_display": f"₹{r['gross_paise'] // 100}",
            "currency": r["currency"], "duration_seconds": r["duration_seconds"],
            "duration_days": r["duration_seconds"] // 86400, "available": available,
            "unavailable_reason": None if available else (
                "Unavailable until a provider-approved late-remedy route is verified." if r["code"] == "Annual365"
                else "Purchases are currently closed."),
            "tax_note": r["tax_note"], "auto_renews": False,
        })
    return [{**p, "refund_policy_version": refund.version} for p in out]


# ---------------------------------------------------------------------------
# Ledger accounting
# ---------------------------------------------------------------------------


async def subject_for(conn: Any, account_id: str) -> dict:
    row = await (await conn.execute("SELECT * FROM financial_subjects WHERE account_id = %s FOR UPDATE",
                                    (account_id,))).fetchone()
    if row is None:
        row = await (await conn.execute(
            """INSERT INTO financial_subjects (account_id) VALUES (%s)
               ON CONFLICT (account_id) DO UPDATE SET account_id = EXCLUDED.account_id RETURNING *""",
            (account_id,))).fetchone()
    return row


async def advance(conn: Any, subject: dict, now: datetime | None = None) -> None:
    """Consume elapsed wall-clock time FIFO across available lots (subject row must be locked)."""
    now = now or _now()
    elapsed = int((now - subject["last_accounted_at"]).total_seconds())
    if elapsed < 0:
        log.warning("clock moved backwards for financial subject; clamping")
        elapsed = 0
    if elapsed:
        lots = await (await conn.execute(
            """SELECT id, available_seconds FROM entitlement_lots WHERE subject_id = %s AND available_seconds > 0
               ORDER BY grant_seq FOR UPDATE""", (subject["id"],))).fetchall()
        for lot in lots:
            if elapsed <= 0:
                break
            take = min(elapsed, lot["available_seconds"])
            await conn.execute(
                """UPDATE entitlement_lots SET available_seconds = available_seconds - %s,
                          consumed_seconds = consumed_seconds + %s, revision = revision + 1,
                          first_paid_use_at = coalesce(first_paid_use_at, %s)
                   WHERE id = %s""", (take, take, subject["last_accounted_at"], lot["id"]))
            elapsed -= take
    await conn.execute("UPDATE financial_subjects SET last_accounted_at = %s WHERE id = %s", (now, subject["id"]))
    subject["last_accounted_at"] = now


async def premium_until(account_id: str) -> float:
    """Unix time when available paid time runs out (pure read; 0 when none)."""
    row = await db.fetch_one(
        """SELECT s.last_accounted_at, coalesce(sum(l.available_seconds), 0) AS available
           FROM financial_subjects s LEFT JOIN entitlement_lots l ON l.subject_id = s.id
           WHERE s.account_id = %s GROUP BY s.id""", (account_id,))
    if row is None or not row["available"]:
        return 0.0
    return row["last_accounted_at"].timestamp() + int(row["available"])


async def entitlement(account_id: str) -> dict:
    async with db.transaction() as conn:
        subject = await subject_for(conn, account_id)
        await advance(conn, subject)
        lots = await (await conn.execute(
            """SELECT l.*, p.public_ref, p.plan_code FROM entitlement_lots l JOIN purchases p ON p.id = l.purchase_id
               WHERE l.subject_id = %s ORDER BY l.grant_seq""", (subject["id"],))).fetchall()
    available = sum(l["available_seconds"] for l in lots)
    held = sum(l["held_seconds"] for l in lots)
    now = _now()
    expires = datetime.fromtimestamp(now.timestamp() + available, timezone.utc) if available else None
    return {
        "active": available > 0,
        "available_seconds": available,
        "held_seconds": held,
        "expires_at": expires.isoformat() if expires else None,
        "revision": subject["ledger_revision"],
        "lots": [{
            "purchase_ref": l["public_ref"], "plan_code": l["plan_code"], "grant_seq": l["grant_seq"],
            "granted_seconds": l["granted_seconds"], "consumed_seconds": l["consumed_seconds"],
            "available_seconds": l["available_seconds"], "held_seconds": l["held_seconds"],
            "revoked_seconds": l["revoked_seconds"], "granted_at": l["granted_at"].isoformat(),
        } for l in lots],
        "note": "Paid time elapses in wall-clock time, including while you are logged out. Unused time is not refundable.",
    }


# ---------------------------------------------------------------------------
# Purchases
# ---------------------------------------------------------------------------

_PHONE = re.compile(r"^[6-9]\d{9}$")


def _purchase_dto(p: dict) -> dict:
    messages = {
        "created": "Waiting for checkout to open.",
        "pending": "Payment pending. Do not pay again – check status or contact Chat with Moderator.",
        "paid": "Payment verified. Your pass is active.",
        "failed": "Payment did not complete. No time was granted.",
        "needs_review": "This payment needs review. Do not pay again; a billing reviewer will reconcile it.",
    }
    return {
        "purchase_ref": p["public_ref"], "plan_code": p["plan_code"], "plan_version": p["plan_version"],
        "amount_paise": p["amount_paise"], "currency": p["currency"], "duration_seconds": p["duration_seconds"],
        "state": p["state"], "message": messages[p["state"]], "provider": p["provider"],
        "created_at": p["created_at"].isoformat(),
        "captured_at": p["captured_at"].isoformat() if p["captured_at"] else None,
    }


async def create_purchase(account_id: str, plan_code: str, plan_version: int, policy_version: str,
                          policy_accepted: bool, client_nonce: str, payment_phone: str) -> dict:
    if not sales_open():
        raise ApiError(503, "payments_unavailable", "Purchases are not available right now.", retryable=True)
    if not policy_accepted:
        raise invalid("policy_accepted", "Please acknowledge the no-voluntary-refund terms.")
    refund_policy = policies.get("refund")
    if policy_version != refund_policy.version:
        raise conflict("The billing policy changed. Review it again before paying.", code="policy_changed",
                       current_version=refund_policy.version)
    phone = re.sub(r"\D", "", payment_phone)[-10:]
    if not _PHONE.match(phone):
        raise invalid("payment_phone", "Enter the 10-digit mobile number required by the payment provider.")
    plan = await db.fetch_one("SELECT * FROM plan_versions WHERE code = %s AND version = %s", (plan_code, plan_version))
    if plan is None or not plan["enabled"]:
        raise invalid("plan_code", "That pass is not available.")
    latest = await db.fetch_one("SELECT max(version) AS v FROM plan_versions WHERE code = %s", (plan_code,))
    if latest["v"] != plan_version:
        raise conflict("The price changed. Review the current pass.", code="stale_plan")
    prov = provider()
    async with db.transaction() as conn:
        subject = await subject_for(conn, account_id)
        existing = await (await conn.execute(
            "SELECT * FROM purchases WHERE financial_subject_id = %s AND client_nonce = %s", (subject["id"], client_nonce))).fetchone()
        if existing:
            if existing["plan_code"] != plan_code or existing["plan_version"] != plan_version:
                raise conflict("This purchase request id was already used for another pass.", code="nonce_conflict")
            purchase = existing
        else:
            purchase = await (await conn.execute(
                """INSERT INTO purchases (public_ref, financial_subject_id, plan_code, plan_version, amount_paise,
                                          duration_seconds, provider, environment, merchant_order_id, client_nonce,
                                          policy_version, policy_digest, policy_accepted_at)
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, now()) RETURNING *""",
                (crypto.new_ref("pu"), subject["id"], plan_code, plan_version, plan["gross_paise"],
                 plan["duration_seconds"], prov.name, prov.environment, "nt_" + uuid.uuid4().hex[:24], client_nonce,
                 refund_policy.version, refund_policy.digest))).fetchone()
    if purchase["state"] != "created":
        return {**_purchase_dto(purchase), "checkout": _checkout(purchase)}
    return await _open_checkout(purchase, account_id, phone)


def _checkout(purchase: dict) -> dict | None:
    if purchase["state"] not in ("created", "pending") or not purchase["payment_session_id"]:
        return None
    s = get_settings()
    if purchase["provider"] == "simulator":
        return {"provider": "simulator", "url": f"/api/v1/dev/simulator/checkout/{purchase['merchant_order_id']}"}
    return {"provider": "cashfree", "payment_session_id": purchase["payment_session_id"],
            "mode": "production" if s.cashfree_env == "production" else "sandbox"}


async def _open_checkout(purchase: dict, account_id: str, phone: str) -> dict:
    s = get_settings()
    prov = provider()
    return_url = f"{s.public_origin}/payment/status/?ref={purchase['public_ref']}"
    notify_url = f"{s.public_origin}/api/v1/webhooks/{prov.name}"
    customer_ref = "c" + crypto.b64u(crypto.hmac_digest(account_id, purpose="provider-customer"))[:20].replace("-", "x").replace("_", "y")
    try:
        result = await prov.create_order(purchase["merchant_order_id"], purchase["amount_paise"], customer_ref, phone,
                                         return_url, notify_url)
    except ProviderUnavailable:
        # Unknown outcome: fetch the stable merchant order before anything else.
        try:
            state = await prov.fetch_order(purchase["merchant_order_id"])
        except ProviderUnavailable:
            state = None
        if state is None:
            raise ApiError(503, "provider_unavailable",
                           "The payment provider did not respond. Nothing was charged; retry the same purchase.",
                           retryable=True, extra={"purchase_ref": purchase["public_ref"]}) from None
        await db.execute("UPDATE purchases SET state = 'pending', updated_at = now() WHERE id = %s", (purchase["id"],))
        purchase = await db.fetch_one("SELECT * FROM purchases WHERE id = %s", (purchase["id"],))
        return {**_purchase_dto(purchase), "checkout": None}
    except ProviderRejected as exc:
        raise ApiError(422, "provider_rejected", f"The payment provider rejected the request: {exc}") from None
    purchase = await db.fetch_one(
        """UPDATE purchases SET provider_order_id = %s, payment_session_id = %s, state = 'pending', updated_at = now()
           WHERE id = %s RETURNING *""", (result.provider_order_id, result.payment_session_id, purchase["id"]))
    dto = {**_purchase_dto(purchase), "checkout": _checkout(purchase)}
    if result.checkout_url and dto["checkout"]:
        dto["checkout"]["url"] = result.checkout_url
    return dto


async def get_purchase(account_id: str, ref: str, reconcile_now: bool = True) -> dict:
    purchase = await db.fetch_one(
        """SELECT p.* FROM purchases p JOIN financial_subjects s ON s.id = p.financial_subject_id
           WHERE p.public_ref = %s AND s.account_id = %s""", (ref, account_id))
    if purchase is None:
        raise not_found()
    if reconcile_now and purchase["state"] in ("created", "pending"):
        last = purchase["last_reconciled_at"]
        if last is None or (_now() - last).total_seconds() > 5:
            await reconcile(str(purchase["id"]))
            purchase = await db.fetch_one("SELECT * FROM purchases WHERE id = %s", (purchase["id"],))
    return {**_purchase_dto(purchase), "checkout": _checkout(purchase)}


async def list_purchases(account_id: str) -> list[dict]:
    rows = await db.fetch_all(
        """SELECT p.* FROM purchases p JOIN financial_subjects s ON s.id = p.financial_subject_id
           WHERE s.account_id = %s ORDER BY p.created_at DESC LIMIT 50""", (account_id,))
    return [_purchase_dto(r) for r in rows]


async def reconcile(purchase_id: str) -> str:
    """Independently verify provider state and grant at most one lot."""
    purchase = await db.fetch_one("SELECT * FROM purchases WHERE id = %s", (purchase_id,))
    if purchase is None or purchase["state"] in ("paid", "failed"):
        return purchase["state"] if purchase else "missing"
    prov = provider()
    try:
        payments = await prov.fetch_payments(purchase["merchant_order_id"])
        order = await prov.fetch_order(purchase["merchant_order_id"])
    except ProviderUnavailable:
        await db.execute("UPDATE purchases SET last_reconciled_at = now() WHERE id = %s", (purchase_id,))
        return purchase["state"]
    matching = [p for p in payments if p.status == "success" and p.amount_paise == purchase["amount_paise"]
                and p.currency == "INR"]
    async with db.transaction() as conn:
        subject = await (await conn.execute(
            "SELECT * FROM financial_subjects WHERE id = %s FOR UPDATE", (purchase["financial_subject_id"],))).fetchone()
        current = await (await conn.execute("SELECT * FROM purchases WHERE id = %s FOR UPDATE", (purchase_id,))).fetchone()
        if current["state"] in ("paid", "failed"):
            return current["state"]
        await conn.execute("UPDATE purchases SET last_reconciled_at = now() WHERE id = %s", (purchase_id,))
        mismatched = [p for p in payments if p.status == "success" and p not in matching]
        if len(matching) > 1 or mismatched:
            await conn.execute("UPDATE purchases SET state = 'needs_review', updated_at = now() WHERE id = %s",
                               (purchase_id,))
            for p in payments:
                await _record_attempt(conn, purchase_id, p, prov.environment)
            return "needs_review"
        if matching:
            fact = matching[0]
            await _record_attempt(conn, purchase_id, fact, prov.environment)
            await advance(conn, subject)  # time before the grant must not consume the new lot
            seq = await (await conn.execute(
                "SELECT coalesce(max(grant_seq), 0) + 1 AS n FROM entitlement_lots WHERE subject_id = %s",
                (subject["id"],))).fetchone()
            lot = await (await conn.execute(
                """INSERT INTO entitlement_lots (purchase_id, subject_id, grant_seq, granted_seconds, available_seconds)
                   VALUES (%s, %s, %s, %s, %s) RETURNING id""",
                (purchase_id, subject["id"], seq["n"], current["duration_seconds"], current["duration_seconds"]))).fetchone()
            await conn.execute(
                """INSERT INTO ledger_adjustments (subject_id, lot_id, kind, delta_available, origin_ref, reason)
                   VALUES (%s, %s, 'grant', %s, %s, 'verified capture')""",
                (subject["id"], lot["id"], current["duration_seconds"], f"grant:{purchase_id}"))
            await conn.execute(
                "UPDATE purchases SET state = 'paid', captured_at = now(), updated_at = now() WHERE id = %s",
                (purchase_id,))
            await conn.execute("UPDATE financial_subjects SET ledger_revision = ledger_revision + 1 WHERE id = %s",
                               (subject["id"],))
            await conn.execute(
                "INSERT INTO receipts (public_ref, subject_id, purchase_id, facts) VALUES (%s, %s, %s, %s)",
                (crypto.new_ref("rc"), subject["id"], purchase_id, _receipt_facts(current, fact.payment_id)))
            account_id = subject["account_id"]
            state = "paid"
        elif order and order.status.upper() in ("EXPIRED", "TERMINATED", "FAILED") or (
                payments and all(p.status in ("failed", "user_dropped", "cancelled") for p in payments)
                and order and order.status.upper() != "ACTIVE"):
            for p in payments:
                await _record_attempt(conn, purchase_id, p, prov.environment)
            await conn.execute("UPDATE purchases SET state = 'failed', updated_at = now() WHERE id = %s", (purchase_id,))
            return "failed"
        else:
            return current["state"]
    if account_id:
        from app.realtime.coordinator import coordinator

        coordinator.update_entitlement(str(account_id), await premium_until(str(account_id)))
    return state


def _receipt_facts(purchase: dict, payment_id: str) -> str:
    import json

    return json.dumps({
        "plan_code": purchase["plan_code"], "plan_version": purchase["plan_version"],
        "description": PLAN_TEXT[purchase["plan_code"]] + " (one-time, no automatic renewal)",
        "amount_paise": purchase["amount_paise"], "currency": purchase["currency"],
        "duration_seconds": purchase["duration_seconds"], "merchant_order_id": purchase["merchant_order_id"],
        "provider": purchase["provider"], "provider_payment_ref": payment_id[-8:],
        "policy_version": purchase["policy_version"], "policy_digest": purchase["policy_digest"],
        "tax_treatment": "Pending operator/accountant review – this is a payment receipt, not a tax invoice.",
        "merchant": "Operator details pending review (see Legal page)",
        "issued_at": _now().isoformat(),
    })


async def _record_attempt(conn: Any, purchase_id: str, fact: Any, environment: str) -> None:
    await conn.execute(
        """INSERT INTO payment_attempts (purchase_id, provider_payment_id, status, amount_paise, currency, environment)
           VALUES (%s, %s, %s, %s, %s, %s) ON CONFLICT (provider_payment_id) DO NOTHING""",
        (purchase_id, fact.payment_id, fact.status, fact.amount_paise, fact.currency, environment))


# ---------------------------------------------------------------------------
# Webhooks
# ---------------------------------------------------------------------------


async def ingest_webhook(provider_name: str, raw: bytes, headers: dict[str, str]) -> bool:
    prov = provider()
    if prov.name != provider_name:
        return False
    if not prov.verify_webhook(raw, headers):
        raise ApiError(401, "invalid_signature", "Webhook signature is invalid.")
    ts = headers.get("x-webhook-timestamp", "0")
    try:
        if int(ts) > time.time() + 300:
            log.warning("webhook timestamp is in the future; accepting for reconciliation only")
    except ValueError:
        pass
    try:
        event = prov.parse_webhook(raw)
    except (ValueError, KeyError):
        raise ApiError(400, "bad_request", "Unreadable webhook.") from None
    digest = crypto.hmac_digest(raw, purpose="webhook-dedupe")
    async with db.transaction() as conn:
        inserted = await (await conn.execute(
            """INSERT INTO webhook_inbox (provider, dedupe_digest, event_type, merchant_order_id, provider_payment_id,
                                          reported_status, amount_paise)
               VALUES (%s, %s, %s, %s, %s, %s, %s) ON CONFLICT (dedupe_digest) DO NOTHING RETURNING id""",
            (provider_name, digest, event.event_type, event.merchant_order_id, event.payment_id, event.status,
             event.amount_paise))).fetchone()
        purchase = None
        if event.merchant_order_id:
            purchase = await (await conn.execute("SELECT id FROM purchases WHERE merchant_order_id = %s",
                                                 (event.merchant_order_id,))).fetchone()
        if inserted and purchase:
            from app.services import jobs

            await jobs.enqueue(conn, "payment.reconcile", f"reconcile:{purchase['id']}:{inserted['id']}",
                               {"purchase_id": str(purchase["id"])})
    return True


# ---------------------------------------------------------------------------
# Receipts and complaints
# ---------------------------------------------------------------------------


async def list_receipts(account_id: str) -> list[dict]:
    rows = await db.fetch_all(
        """SELECT r.public_ref, r.receipt_number, r.issued_at, r.facts, p.public_ref AS purchase_ref
           FROM receipts r JOIN financial_subjects s ON s.id = r.subject_id JOIN purchases p ON p.id = r.purchase_id
           WHERE s.account_id = %s ORDER BY r.issued_at DESC LIMIT 50""", (account_id,))
    return [{"receipt_ref": r["public_ref"], "receipt_number": r["receipt_number"],
             "issued_at": r["issued_at"].isoformat(), "purchase_ref": r["purchase_ref"], "facts": r["facts"]}
            for r in rows]


async def get_receipt(account_id: str, ref: str) -> dict:
    for r in await list_receipts(account_id):
        if r["receipt_ref"] == ref:
            refunds = await db.fetch_all(
                """SELECT f.public_ref, f.amount_paise, f.state, f.remedy_basis, f.created_at FROM refunds f
                   JOIN purchases p ON p.id = f.purchase_id WHERE p.public_ref = %s ORDER BY f.created_at""",
                (r["purchase_ref"],))
            return {**r, "remedies": [{**f, "created_at": f["created_at"].isoformat()} for f in refunds]}
    raise not_found()


# ---------------------------------------------------------------------------
# Required remedies (staff)
# ---------------------------------------------------------------------------


async def remedy_preview_data(purchase_ref: str, amount_paise: int, revoke_seconds: int, basis: str) -> dict:
    if basis not in REMEDY_BASES:
        raise invalid("remedy_basis", "Only payment_error, statutory_remedy or provider_bank_direction are allowed.")
    purchase = await db.fetch_one("SELECT * FROM purchases WHERE public_ref = %s", (purchase_ref,))
    if purchase is None:
        raise not_found()
    if purchase["state"] != "paid":
        raise conflict("Only verified captured purchases can receive a remedy.", code="not_captured")
    committed = await db.fetch_one(
        """SELECT coalesce(sum(amount_paise), 0) AS n FROM refunds
           WHERE purchase_id = %s AND state IN ('held','submitting','pending','needs_review','succeeded')""",
        (purchase["id"],))
    remaining_money = purchase["amount_paise"] - int(committed["n"])
    if amount_paise < 1 or amount_paise > remaining_money:
        raise invalid("amount_paise", f"Amount must be between 1 and {remaining_money} paise.")
    lot = await db.fetch_one("SELECT * FROM entitlement_lots WHERE purchase_id = %s", (purchase["id"],))
    max_revoke = (lot["available_seconds"] + lot["held_seconds"]) if lot else 0
    if revoke_seconds < 0 or revoke_seconds > max_revoke:
        raise invalid("revoke_seconds", f"Time adjustment must be between 0 and {max_revoke} seconds.")
    return {"purchase": purchase, "lot": lot, "remaining_money": remaining_money, "max_revoke": max_revoke}


async def execute_remedy(conn: Any, staff_id: str, payload: dict) -> dict:
    """Inside the confirm transaction: hold origin-lot time and record the refund intent."""
    purchase = await (await conn.execute("SELECT * FROM purchases WHERE public_ref = %s", (payload["purchase_ref"],))).fetchone()
    subject = await (await conn.execute("SELECT * FROM financial_subjects WHERE id = %s FOR UPDATE",
                                        (purchase["financial_subject_id"],))).fetchone()
    purchase = await (await conn.execute("SELECT * FROM purchases WHERE id = %s FOR UPDATE", (purchase["id"],))).fetchone()
    committed = await (await conn.execute(
        """SELECT coalesce(sum(amount_paise), 0) AS n FROM refunds
           WHERE purchase_id = %s AND state IN ('held','submitting','pending','needs_review','succeeded')""",
        (purchase["id"],))).fetchone()
    if payload["amount_paise"] > purchase["amount_paise"] - int(committed["n"]):
        raise conflict("The remedy amount now exceeds the verified capture.", code="stale_preview")
    await advance(conn, subject)
    lot = await (await conn.execute("SELECT * FROM entitlement_lots WHERE purchase_id = %s FOR UPDATE",
                                    (purchase["id"],))).fetchone()
    hold = 0
    if lot and payload["revoke_seconds"]:
        hold = min(payload["revoke_seconds"], lot["available_seconds"])
        if hold:
            await conn.execute(
                """UPDATE entitlement_lots SET available_seconds = available_seconds - %s,
                          held_seconds = held_seconds + %s, revision = revision + 1 WHERE id = %s""",
                (hold, hold, lot["id"]))
    refund_ref = crypto.new_ref("rf")
    provider_refund_id = "ntrf_" + uuid.uuid4().hex[:24]
    row = await (await conn.execute(
        """INSERT INTO refunds (public_ref, purchase_id, lot_id, amount_paise, revoke_seconds, held_seconds, state,
                                remedy_basis, evidence_ref, decision_reason, provider_refund_id, staff_id)
           VALUES (%s, %s, %s, %s, %s, %s, 'submitting', %s, %s, %s, %s, %s) RETURNING id""",
        (refund_ref, purchase["id"], lot["id"] if lot else None, payload["amount_paise"], payload["revoke_seconds"],
         hold, payload["remedy_basis"], payload["evidence_ref"], payload["reason"], provider_refund_id, staff_id))).fetchone()
    if hold:
        await conn.execute(
            """INSERT INTO ledger_adjustments (subject_id, lot_id, kind, delta_available, delta_held, origin_ref, reason)
               VALUES (%s, %s, 'hold', %s, %s, %s, %s)""",
            (subject["id"], lot["id"], -hold, hold, f"hold:{row['id']}", payload["remedy_basis"]))
    await conn.execute("UPDATE financial_subjects SET ledger_revision = ledger_revision + 1 WHERE id = %s", (subject["id"],))
    return {"refund_id": str(row["id"]), "refund_ref": refund_ref, "held_seconds": hold,
            "account_id": str(subject["account_id"]) if subject["account_id"] else None}


async def submit_refund(refund_id: str) -> str:
    """Contact the provider outside all locks, then settle idempotently."""
    refund = await db.fetch_one(
        """SELECT f.*, p.merchant_order_id FROM refunds f JOIN purchases p ON p.id = f.purchase_id WHERE f.id = %s""",
        (refund_id,))
    if refund is None or refund["state"] in ("succeeded", "failed", "cancelled"):
        return refund["state"] if refund else "missing"
    prov = provider()
    try:
        if refund["state"] == "submitting":
            status = await prov.create_refund(refund["merchant_order_id"], refund["provider_refund_id"],
                                              refund["amount_paise"], f"Remedy {refund['remedy_basis']}")
        else:
            status = await prov.fetch_refund(refund["merchant_order_id"], refund["provider_refund_id"])
    except ProviderUnavailable:
        # A timeout never authorises a second refund: fetch first next time.
        status = None
        try:
            status = await prov.fetch_refund(refund["merchant_order_id"], refund["provider_refund_id"])
        except ProviderUnavailable:
            pass
        if status is None:
            await db.execute("UPDATE refunds SET state = 'needs_review', updated_at = now() WHERE id = %s AND state = 'submitting'",
                             (refund_id,))
            return "needs_review"
    except ProviderRejected:
        status = "REJECTED"
    return await settle_refund(refund_id, normalize_refund_status(status))


async def settle_refund(refund_id: str, outcome: str) -> str:
    async with db.transaction() as conn:
        refund = await (await conn.execute("SELECT * FROM refunds WHERE id = %s", (refund_id,))).fetchone()
        purchase = await (await conn.execute("SELECT * FROM purchases WHERE id = %s", (refund["purchase_id"],))).fetchone()
        subject = await (await conn.execute("SELECT * FROM financial_subjects WHERE id = %s FOR UPDATE",
                                            (purchase["financial_subject_id"],))).fetchone()
        refund = await (await conn.execute("SELECT * FROM refunds WHERE id = %s FOR UPDATE", (refund_id,))).fetchone()
        if refund["state"] in ("succeeded", "failed", "cancelled"):
            return refund["state"]
        await advance(conn, subject)
        lot = None
        if refund["lot_id"]:
            lot = await (await conn.execute("SELECT * FROM entitlement_lots WHERE id = %s FOR UPDATE",
                                            (refund["lot_id"],))).fetchone()
        if outcome == "succeeded":
            if lot:
                # Revoke only the authorised origin time: held first, then any still-available remainder.
                held = min(refund["held_seconds"], lot["held_seconds"])
                extra = min(max(0, refund["revoke_seconds"] - held), lot["available_seconds"])
                await conn.execute(
                    """UPDATE entitlement_lots SET held_seconds = held_seconds - %s, available_seconds = available_seconds - %s,
                              revoked_seconds = revoked_seconds + %s, revision = revision + 1 WHERE id = %s""",
                    (held, extra, held + extra, lot["id"]))
                await conn.execute(
                    """INSERT INTO ledger_adjustments (subject_id, lot_id, kind, delta_available, delta_held, delta_revoked,
                                                       origin_ref, reason) VALUES (%s, %s, 'revoke', %s, %s, %s, %s, %s)
                       ON CONFLICT (origin_ref) DO NOTHING""",
                    (subject["id"], lot["id"], -extra, -held, held + extra, f"revoke:{refund_id}", refund["remedy_basis"]))
            await conn.execute("UPDATE refunds SET state = 'succeeded', verified_at = now(), updated_at = now() WHERE id = %s",
                               (refund_id,))
        elif outcome in ("failed", "cancelled"):
            if lot and refund["held_seconds"]:
                # Return held time to availability; consumption resumes from now, never retroactively.
                release = min(refund["held_seconds"], lot["held_seconds"])
                await conn.execute(
                    """UPDATE entitlement_lots SET held_seconds = held_seconds - %s, available_seconds = available_seconds + %s,
                              revision = revision + 1 WHERE id = %s""", (release, release, lot["id"]))
                await conn.execute(
                    """INSERT INTO ledger_adjustments (subject_id, lot_id, kind, delta_available, delta_held, origin_ref, reason)
                       VALUES (%s, %s, 'release', %s, %s, %s, %s) ON CONFLICT (origin_ref) DO NOTHING""",
                    (subject["id"], lot["id"], release, -release, f"release:{refund_id}", outcome))
            await conn.execute("UPDATE refunds SET state = %s, updated_at = now() WHERE id = %s", (outcome, refund_id))
        else:
            await conn.execute("UPDATE refunds SET state = %s, updated_at = now() WHERE id = %s",
                               ("pending" if outcome == "pending" else "needs_review", refund_id))
        await conn.execute("UPDATE financial_subjects SET ledger_revision = ledger_revision + 1 WHERE id = %s", (subject["id"],))
        account_id = subject["account_id"]
    if account_id:
        from app.realtime.coordinator import coordinator

        coordinator.update_entitlement(str(account_id), await premium_until(str(account_id)))
    return outcome


async def staff_purchases(state: str | None) -> list[dict]:
    rows = await db.fetch_all(
        f"""SELECT p.*, (SELECT count(*) FROM refunds f WHERE f.purchase_id = p.id) AS refund_count
            FROM purchases p {"WHERE p.state = %s" if state else ""} ORDER BY p.created_at DESC LIMIT 100""",
        (state,) if state else None)
    return [{**_purchase_dto(r), "merchant_order_id": r["merchant_order_id"], "refund_count": r["refund_count"]}
            for r in rows]


async def staff_refunds() -> list[dict]:
    rows = await db.fetch_all(
        """SELECT f.public_ref, f.amount_paise, f.revoke_seconds, f.held_seconds, f.state, f.remedy_basis, f.evidence_ref,
                  f.decision_reason, f.created_at, p.public_ref AS purchase_ref, s.username
           FROM refunds f JOIN purchases p ON p.id = f.purchase_id JOIN staff_accounts s ON s.id = f.staff_id
           ORDER BY f.created_at DESC LIMIT 100""")
    return [{**r, "created_at": r["created_at"].isoformat()} for r in rows]
