"""Privacy-focused aggregate analytics (blueprint chapters 39–40).

* A fixed catalog of 26 metric series; no dynamic labels, no per-person data.
* Runtime counters/histograms live in bounded memory and flush once a minute
  as an idempotent batch (batch id + keyed digest) into minute buckets.
* Rollups minute→hour→day→month *replace* derived buckets deterministically.
* Small historical values (<10) are suppressed in the admin API.
"""

from __future__ import annotations

import logging
import threading
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

log = logging.getLogger("notitle.analytics")

METRICS: dict[str, tuple[int, str]] = {
    "registrations": (1, "counter"),
    "matches": (2, "counter"),
    "searches_started": (3, "counter"),
    "searches_cancelled": (4, "counter"),
    "text_accepted": (5, "counter"),
    "friend_acceptances": (6, "counter"),
    "calls_attempted": (7, "counter"),
    "calls_connected": (8, "counter"),
    "calls_failed": (9, "counter"),
    "call_seconds": (10, "integral"),
    "participant_seconds": (11, "integral"),
    "support_created": (12, "counter"),
    "support_replies": (13, "counter"),
    "match_wait_ms": (14, "histogram"),
    "api_latency_ms": (15, "histogram"),
    "call_setup_ms": (16, "histogram"),
    "requests_total": (17, "counter"),
    "server_errors": (18, "counter"),
    "auth_denials": (19, "counter"),
    "loop_lag_ms": (20, "histogram"),
    "db_latency_ms": (21, "histogram"),
    "professional_enabled": (22, "counter"),
    "professional_disabled": (23, "counter"),
    "repeat_matches": (24, "counter"),
    "searches_abandoned": (25, "counter"),
    "metric_samples_dropped": (26, "counter"),
}
CODE_TO_NAME = {code: name for name, (code, _) in METRICS.items()}
BOUNDS = [5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000, 10000, 30000]  # + overflow = 13 bins
SUPPRESS_BELOW = 10


def _bin(value: float) -> int:
    for i, bound in enumerate(BOUNDS):
        if value <= bound:
            return i
    return len(BOUNDS)


class Metrics:
    """Thread-safe bounded accumulator (only 26 fixed keys can ever exist)."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._reset()

    def _reset(self) -> None:
        self.values: dict[str, float] = {}
        self.counts: dict[str, int] = {}
        self.bins: dict[str, list[int]] = {}

    def incr(self, name: str, amount: float = 1) -> None:
        self.add(name, amount)

    def add(self, name: str, amount: float) -> None:
        if name not in METRICS or amount < 0:
            return
        with self._lock:
            self.values[name] = self.values.get(name, 0.0) + amount
            self.counts[name] = self.counts.get(name, 0) + 1

    def observe(self, name: str, value: float) -> None:
        if name not in METRICS or METRICS[name][1] != "histogram":
            return
        value = max(0.0, value)
        with self._lock:
            bins = self.bins.setdefault(name, [0] * (len(BOUNDS) + 1))
            bins[_bin(value)] += 1
            self.values[name] = self.values.get(name, 0.0) + value
            self.counts[name] = self.counts.get(name, 0) + 1

    def drain(self) -> dict[str, dict[str, Any]]:
        with self._lock:
            out = {
                name: {"sum": self.values.get(name, 0.0), "count": self.counts.get(name, 0),
                       "bins": list(self.bins.get(name, []))}
                for name in set(self.values) | set(self.bins)
            }
            self._reset()
        return out

    def restore(self, drained: dict[str, dict[str, Any]]) -> None:
        """Put back a batch that failed to flush (bounded: one batch only)."""
        with self._lock:
            for name, item in drained.items():
                self.values[name] = self.values.get(name, 0.0) + item["sum"]
                self.counts[name] = self.counts.get(name, 0) + item["count"]
                if item["bins"]:
                    bins = self.bins.setdefault(name, [0] * (len(BOUNDS) + 1))
                    for i, n in enumerate(item["bins"]):
                        bins[i] += n


metrics = Metrics()


def floor_minute(ts: datetime) -> datetime:
    return ts.replace(second=0, microsecond=0)


async def flush(now: datetime | None = None) -> str | None:
    """Write the drained runtime window as one idempotent batch."""
    from app import db
    from app.security.crypto import payload_digest

    drained = metrics.drain()
    if not drained:
        return None
    now = now or datetime.now(timezone.utc)
    bucket = floor_minute(now)
    batch_id = str(uuid.uuid4())
    digest = payload_digest({"bucket": bucket.isoformat(), "data": drained}, purpose="analytics-batch")
    try:
        async with db.transaction() as conn:
            await conn.execute(
                "INSERT INTO aggregate_batches (batch_id, keyed_digest, source_kind) VALUES (%s, %s, 'runtime')",
                (batch_id, digest),
            )
            for name, item in drained.items():
                code, kind = METRICS[name]
                bins = item["bins"] if kind == "histogram" and item["bins"] else []
                await conn.execute(
                    """
                    INSERT INTO aggregate_buckets (level, bucket_start, metric_code, value_sum, sample_count, bins)
                    VALUES ('minute', %s, %s, %s, %s, %s)
                    ON CONFLICT (level, bucket_start, metric_code) DO UPDATE SET
                      value_sum = aggregate_buckets.value_sum + EXCLUDED.value_sum,
                      sample_count = aggregate_buckets.sample_count + EXCLUDED.sample_count,
                      bins = CASE WHEN cardinality(EXCLUDED.bins) = 0 THEN aggregate_buckets.bins
                                  WHEN cardinality(aggregate_buckets.bins) = 0 THEN EXCLUDED.bins
                                  ELSE (SELECT array_agg(x + y ORDER BY i) FROM unnest(aggregate_buckets.bins, EXCLUDED.bins)
                                        WITH ORDINALITY AS t(x, y, i)) END
                    """,
                    (bucket, code, round(item["sum"], 3), item["count"], bins),
                )
        return batch_id
    except Exception:  # noqa: BLE001
        log.warning("analytics flush failed; keeping one window in memory", exc_info=True)
        metrics.restore(drained)
        return None


async def record_exact(name: str, amount: int = 1, conn: Any = None) -> None:
    """Exact transactional contributions (registrations, support) written with the business row."""
    from app import db

    code, _ = METRICS[name]
    bucket = floor_minute(datetime.now(timezone.utc))
    sql = """
        INSERT INTO aggregate_buckets (level, bucket_start, metric_code, value_sum, sample_count)
        VALUES ('minute', %s, %s, %s, 1)
        ON CONFLICT (level, bucket_start, metric_code) DO UPDATE SET
          value_sum = aggregate_buckets.value_sum + EXCLUDED.value_sum,
          sample_count = aggregate_buckets.sample_count + 1
    """
    await db.execute(sql, (bucket, code, amount), conn=conn)


LEVELS = [("minute", "hour"), ("hour", "day"), ("day", "month")]


def _truncate(level: str, ts: datetime) -> datetime:
    if level == "hour":
        return ts.replace(minute=0, second=0, microsecond=0)
    if level == "day":
        return ts.replace(hour=0, minute=0, second=0, microsecond=0)
    if level == "month":
        return ts.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    return floor_minute(ts)


async def rollup(now: datetime | None = None) -> int:
    """Replace derived buckets for complete intervals (idempotent)."""
    from app import db

    now = now or datetime.now(timezone.utc)
    total = 0
    for source, target in LEVELS:
        complete_before = _truncate(target, now)
        async with db.transaction() as conn:
            await conn.execute("SELECT pg_advisory_xact_lock(7331101)")
            cur = await conn.execute(
                """
                SELECT date_trunc(%s, bucket_start) AS start, metric_code,
                       sum(value_sum) AS value_sum, sum(sample_count) AS sample_count
                FROM aggregate_buckets
                WHERE level = %s AND bucket_start < %s AND bucket_start >= %s
                GROUP BY 1, 2
                """,
                (target, source, complete_before, complete_before - _span(target) * 3),
            )
            rows = await cur.fetchall()
            for row in rows:
                bins_cur = await conn.execute(
                    """
                    SELECT bins FROM aggregate_buckets
                    WHERE level = %s AND metric_code = %s AND bucket_start >= %s AND bucket_start < %s
                      AND cardinality(bins) = 13
                    """,
                    (source, row["metric_code"], row["start"], row["start"] + _span(target)),
                )
                merged = [0] * 13
                for b in await bins_cur.fetchall():
                    merged = [x + y for x, y in zip(merged, b["bins"])]
                await conn.execute(
                    """
                    INSERT INTO aggregate_buckets (level, bucket_start, metric_code, value_sum, sample_count, bins, complete)
                    VALUES (%s, %s, %s, %s, %s, %s, true)
                    ON CONFLICT (level, bucket_start, metric_code) DO UPDATE SET
                      value_sum = EXCLUDED.value_sum, sample_count = EXCLUDED.sample_count,
                      bins = EXCLUDED.bins, complete = true
                    """,
                    (target, row["start"], row["metric_code"], row["value_sum"], row["sample_count"],
                     merged if any(merged) else []),
                )
                total += 1
            await conn.execute(
                """
                INSERT INTO aggregate_checkpoints (source_level, rolled_before, updated_at) VALUES (%s, %s, now())
                ON CONFLICT (source_level) DO UPDATE SET rolled_before = EXCLUDED.rolled_before, updated_at = now()
                """,
                (source, complete_before),
            )
    return total


def _span(level: str) -> timedelta:
    return {"hour": timedelta(hours=1), "day": timedelta(days=1), "month": timedelta(days=31)}[level]


def suppress(value: float | None, kind: str) -> Any:
    if value is None:
        return None
    if kind == "counter" and 0 < value < SUPPRESS_BELOW:
        return "<10"
    return round(float(value), 3)


async def summary() -> dict:
    from app import db
    from app.realtime.coordinator import coordinator

    since = datetime.now(timezone.utc) - timedelta(hours=24)
    rows = await db.fetch_all(
        """
        SELECT metric_code, sum(value_sum) AS value_sum, sum(sample_count) AS sample_count
        FROM aggregate_buckets WHERE level = 'minute' AND bucket_start >= %s GROUP BY metric_code
        """,
        (since,),
    )
    totals = {}
    for row in rows:
        name = CODE_TO_NAME.get(row["metric_code"])
        if not name:
            continue
        kind = METRICS[name][1]
        if kind == "histogram":
            count = float(row["sample_count"])
            totals[name] = {"count": suppress(count, "counter"),
                            "mean": round(float(row["value_sum"]) / count, 1) if count >= SUPPRESS_BELOW else None}
        else:
            totals[name] = suppress(float(row["value_sum"]), "counter" if kind == "counter" else "integral")
    accounts = await db.fetch_one("SELECT count(*) AS n FROM accounts WHERE status = 'active'")
    counts = coordinator.counts()
    requests = totals.get("requests_total")
    errors = totals.get("server_errors")
    return {
        "window": "last_24_hours_utc",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "current": {
            "active_now": counts["connected"],
            "searching_now": counts["waiting"],
            "conversations_now": counts["interactions"],
            "calls_now": counts["calls"],
            "current_accounts": suppress(float(accounts["n"]) if accounts else 0, "counter"),
            "note": "Active now counts admitted identities, including guests; it is not a unique-person count.",
        },
        "totals_24h": totals,
        "error_rate": (round(float(errors) / float(requests), 4)
                       if isinstance(requests, float) and isinstance(errors, float) and requests else None),
        "completeness": "Runtime counters flush once a minute; an unflushed minute can be lost on restart.",
    }


async def series(metric_code: int, start: datetime, end: datetime, resolution: str) -> dict:
    from app import db

    if metric_code not in CODE_TO_NAME:
        raise ValueError("unknown metric")
    if resolution not in ("minute", "hour", "day"):
        raise ValueError("resolution must be minute, hour or day")
    span = end - start
    limits = {"minute": timedelta(hours=24), "hour": timedelta(days=31), "day": timedelta(days=90)}
    if span <= timedelta(0) or span > limits[resolution]:
        raise ValueError("range too large for resolution")
    name = CODE_TO_NAME[metric_code]
    kind = METRICS[name][1]
    if resolution == "minute":
        rows = await db.fetch_all(
            """SELECT bucket_start, value_sum, sample_count FROM aggregate_buckets
               WHERE level = 'minute' AND metric_code = %s AND bucket_start >= %s AND bucket_start < %s
               ORDER BY bucket_start LIMIT 2000""",
            (metric_code, start, end),
        )
    else:
        # Prefer rolled buckets; fall back to live aggregation of finer levels for recent data.
        rows = await db.fetch_all(
            """SELECT date_trunc(%s, bucket_start) AS bucket_start, sum(value_sum) AS value_sum,
                      sum(sample_count) AS sample_count
               FROM aggregate_buckets
               WHERE level = 'minute' AND metric_code = %s AND bucket_start >= %s AND bucket_start < %s
               GROUP BY 1 ORDER BY 1 LIMIT 2000""",
            (resolution, metric_code, start, end),
        )
    points = []
    for row in rows:
        value = float(row["value_sum"])
        count = float(row["sample_count"])
        if kind == "histogram":
            points.append({"t": row["bucket_start"].isoformat(), "count": suppress(count, "counter"),
                           "mean": round(value / count, 1) if count >= SUPPRESS_BELOW else None})
        else:
            points.append({"t": row["bucket_start"].isoformat(), "value": suppress(value, "counter" if kind == "counter" else "integral")})
    return {"metric_id": metric_code, "name": name, "kind": kind, "resolution": resolution,
            "points": points, "suppression": f"Values below {SUPPRESS_BELOW} are shown as <10."}
