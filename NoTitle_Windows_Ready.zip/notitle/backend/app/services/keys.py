"""Per-record data keys (wrapped in PostgreSQL, unwrapped only in memory)."""

from __future__ import annotations

from collections import OrderedDict
from typing import Any

from app import db
from app.security.crypto import WRAPPING_KEY_VERSION, DataKey, generate_data_key, unwrap_key, wrap_key

_cache: OrderedDict[str, DataKey] = OrderedDict()
_CACHE_MAX = 2048


async def new_key(conn: Any, purpose: str) -> DataKey:
    raw = generate_data_key()
    row = await (await conn.execute(
        "INSERT INTO data_keys (purpose, wrapped_key, wrapping_key_version) VALUES (%s, %s, %s) RETURNING id",
        (purpose, wrap_key(raw, purpose), WRAPPING_KEY_VERSION),
    )).fetchone()
    key = DataKey(id=str(row["id"]), purpose=purpose, key=raw)
    _remember(key)
    return key


async def get_key(key_id: Any, conn: Any = None) -> DataKey:
    key_id = str(key_id)
    cached = _cache.get(key_id)
    if cached:
        _cache.move_to_end(key_id)
        return cached
    row = await db.fetch_one("SELECT id, purpose, wrapped_key FROM data_keys WHERE id = %s AND retired_at IS NULL",
                             (key_id,), conn=conn)
    if row is None:
        raise LookupError("data key unavailable")
    key = DataKey(id=key_id, purpose=row["purpose"], key=unwrap_key(bytes(row["wrapped_key"]), row["purpose"]))
    _remember(key)
    return key


async def destroy_key(conn: Any, key_id: Any) -> None:
    """Crypto-erasure of the active copy: drop the wrapped key (backups age out separately)."""
    _cache.pop(str(key_id), None)
    await conn.execute("UPDATE data_keys SET wrapped_key = '\\x00'::bytea, retired_at = now() WHERE id = %s", (key_id,))


def _remember(key: DataKey) -> None:
    _cache[key.id] = key
    while len(_cache) > _CACHE_MAX:
        _cache.popitem(last=False)
