"""Access audit: metadata only (actor, purpose, object, action, decision)."""

from __future__ import annotations

from typing import Any

from app import db
from app.http.errors import request_id_var


async def record(actor_ref: str, purpose: str, object_type: str, object_ref: str, action: str,
                 decision: str = "allowed", conn: Any = None) -> None:
    await db.execute(
        """INSERT INTO access_audit (actor_ref, purpose, object_type, object_ref, action, decision, request_id)
           VALUES (%s, %s, %s, %s, %s, %s, %s)""",
        (actor_ref, purpose, object_type, object_ref, action, decision, request_id_var.get()),
        conn=conn,
    )
