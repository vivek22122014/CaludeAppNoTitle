"""Development-only payment provider.

It behaves like a hosted checkout so the whole purchase → webhook →
independent verification → ledger grant pipeline can be exercised locally
without merchant credentials.  It is refused when ``APP_ENV=production``.
State lives in ``simulated_provider_orders`` (never read by business logic
other than through this adapter).
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import time

from app import db
from app.config import get_settings
from app.services.payments.base import (
    OrderResult, OrderState, PaymentFact, ProviderRejected, WebhookEvent, paise_to_decimal,
)


def _secret() -> bytes:
    s = get_settings()
    return s.payment_webhook_secret.encode() if s.payment_webhook_secret else s.key_bytes("hmac_key")


class SimulatorProvider:
    name = "simulator"
    environment = "simulator"

    def __init__(self) -> None:
        if get_settings().app_env == "production":
            raise RuntimeError("The payment simulator cannot run in production")

    async def create_order(self, merchant_order_id: str, amount_paise: int, customer_ref: str, phone: str,
                           return_url: str, notify_url: str) -> OrderResult:
        if not phone.isdigit() or len(phone) != 10:
            raise ProviderRejected("customer_phone must be 10 digits")
        order_id = "sim_" + secrets.token_hex(8)
        row = await db.fetch_one(
            """INSERT INTO simulated_provider_orders (order_id, merchant_order_id, amount_paise)
               VALUES (%s, %s, %s) ON CONFLICT (merchant_order_id) DO UPDATE SET updated_at = now()
               RETURNING order_id""",
            (order_id, merchant_order_id, amount_paise))
        order_id = row["order_id"]
        return OrderResult(provider_order_id=order_id, payment_session_id="simsession_" + secrets.token_hex(8),
                           checkout_url=f"/api/v1/dev/simulator/checkout/{merchant_order_id}")

    async def fetch_order(self, merchant_order_id: str) -> OrderState | None:
        row = await db.fetch_one("SELECT * FROM simulated_provider_orders WHERE merchant_order_id = %s",
                                 (merchant_order_id,))
        if row is None:
            return None
        return OrderState(status=row["status"], amount_paise=row["amount_paise"])

    async def fetch_payments(self, merchant_order_id: str) -> list[PaymentFact]:
        row = await db.fetch_one("SELECT * FROM simulated_provider_orders WHERE merchant_order_id = %s",
                                 (merchant_order_id,))
        if row is None or row["payment_id"] is None:
            return []
        status = "success" if row["status"] == "PAID" else "failed"
        return [PaymentFact(payment_id=row["payment_id"], status=status, amount_paise=row["amount_paise"], currency="INR")]

    async def create_refund(self, merchant_order_id: str, refund_id: str, amount_paise: int, note: str) -> str:
        row = await db.fetch_one("SELECT refunds FROM simulated_provider_orders WHERE merchant_order_id = %s",
                                 (merchant_order_id,))
        if row is None:
            raise ProviderRejected("order not found")
        refunds = list(row["refunds"] or [])
        if not any(r["refund_id"] == refund_id for r in refunds):
            refunds.append({"refund_id": refund_id, "amount_paise": amount_paise, "status": "SUCCESS"})
            await db.execute("UPDATE simulated_provider_orders SET refunds = %s, updated_at = now() WHERE merchant_order_id = %s",
                             (json.dumps(refunds), merchant_order_id))
        return "SUCCESS"

    async def fetch_refund(self, merchant_order_id: str, refund_id: str) -> str | None:
        row = await db.fetch_one("SELECT refunds FROM simulated_provider_orders WHERE merchant_order_id = %s",
                                 (merchant_order_id,))
        for r in (row["refunds"] if row else []) or []:
            if r["refund_id"] == refund_id:
                return r["status"]
        return None

    # ------------------------------------------------------- hosted checkout
    async def complete(self, merchant_order_id: str, outcome: str) -> tuple[bytes, dict[str, str]] | None:
        """Simulate the user paying (or failing) on the hosted page; returns a signed webhook."""
        payment_id = "simpay_" + secrets.token_hex(8)
        status = "PAID" if outcome == "pay" else "FAILED"
        row = await db.fetch_one(
            """UPDATE simulated_provider_orders SET status = %s, payment_id = coalesce(payment_id, %s), updated_at = now()
               WHERE merchant_order_id = %s AND status = 'ACTIVE' RETURNING payment_id, amount_paise""",
            (status, payment_id, merchant_order_id))
        if row is None:
            return None
        body = json.dumps({
            "type": "PAYMENT_SUCCESS_WEBHOOK" if status == "PAID" else "PAYMENT_FAILED_WEBHOOK",
            "data": {
                "order": {"order_id": merchant_order_id},
                "payment": {"cf_payment_id": row["payment_id"],
                            "payment_status": "SUCCESS" if status == "PAID" else "FAILED",
                            "payment_amount": float(paise_to_decimal(row["amount_paise"])),
                            "payment_currency": "INR"},
            },
        }).encode()
        timestamp = str(int(time.time()))
        signature = base64.b64encode(hmac.new(_secret(), timestamp.encode() + body, hashlib.sha256).digest()).decode()
        return body, {"x-webhook-signature": signature, "x-webhook-timestamp": timestamp}

    def verify_webhook(self, raw: bytes, headers: dict[str, str]) -> bool:
        signature = headers.get("x-webhook-signature", "")
        timestamp = headers.get("x-webhook-timestamp", "")
        if not signature or not timestamp:
            return False
        expected = base64.b64encode(hmac.new(_secret(), timestamp.encode() + raw, hashlib.sha256).digest())
        return hmac.compare_digest(expected, signature.encode())

    def parse_webhook(self, raw: bytes) -> WebhookEvent:
        from app.services.payments.base import decimal_to_paise

        data = json.loads(raw.decode("utf-8"))
        inner = data.get("data", {})
        payment = inner.get("payment", {})
        return WebhookEvent(
            event_type=str(data.get("type", "unknown")),
            merchant_order_id=inner.get("order", {}).get("order_id"),
            payment_id=payment.get("cf_payment_id"),
            status=payment.get("payment_status"),
            amount_paise=decimal_to_paise(payment["payment_amount"]) if "payment_amount" in payment else None,
        )
