"""Cashfree Payment Gateway adapter (hosted checkout, PG API).

Endpoints, headers and the webhook signature scheme follow Cashfree's public
PG documentation.  Sandbox and production use separate credentials/hosts.
The API version is configurable (``CASHFREE_API_VERSION``) and must be
contract-tested against the merchant's sandbox before enabling sales.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json

import httpx

from app.config import get_settings
from app.services.payments.base import (
    OrderResult, OrderState, PaymentFact, ProviderRejected, ProviderUnavailable, WebhookEvent, decimal_to_paise,
    normalize_payment_status, paise_to_decimal,
)

HOSTS = {"sandbox": "https://sandbox.cashfree.com/pg", "production": "https://api.cashfree.com/pg"}


class CashfreeProvider:
    name = "cashfree"

    def __init__(self) -> None:
        s = get_settings()
        self.environment = s.cashfree_env
        self.base = HOSTS[s.cashfree_env]
        self.client_id = s.cashfree_client_id
        self.secret = s.cashfree_client_secret
        self.api_version = s.cashfree_api_version
        if not self.client_id or not self.secret:
            raise RuntimeError("Cashfree credentials are not configured")

    def _headers(self, idempotency_key: str | None = None) -> dict[str, str]:
        headers = {"x-client-id": self.client_id, "x-client-secret": self.secret,
                   "x-api-version": self.api_version, "content-type": "application/json",
                   "accept": "application/json"}
        if idempotency_key:
            headers["x-idempotency-key"] = idempotency_key
        return headers

    async def _request(self, method: str, path: str, body: dict | None = None,
                       idempotency_key: str | None = None) -> tuple[int, dict]:
        timeout = httpx.Timeout(10.0, connect=5.0)
        try:
            async with httpx.AsyncClient(timeout=timeout, follow_redirects=False) as client:
                response = await client.request(method, self.base + path, headers=self._headers(idempotency_key),
                                                content=json.dumps(body) if body is not None else None)
        except httpx.HTTPError as exc:
            raise ProviderUnavailable(str(type(exc).__name__)) from None
        if response.status_code >= 500:
            raise ProviderUnavailable(f"HTTP {response.status_code}")
        try:
            data = response.json()
        except ValueError:
            data = {}
        return response.status_code, data if isinstance(data, (dict, list)) else {}

    async def create_order(self, merchant_order_id: str, amount_paise: int, customer_ref: str, phone: str,
                           return_url: str, notify_url: str) -> OrderResult:
        body = {
            "order_id": merchant_order_id,
            "order_amount": float(paise_to_decimal(amount_paise)),
            "order_currency": "INR",
            "customer_details": {"customer_id": customer_ref, "customer_phone": phone},
            "order_meta": {"return_url": return_url, "notify_url": notify_url},
        }
        status, data = await self._request("POST", "/orders", body, idempotency_key=merchant_order_id)
        if status in (200, 201):
            return OrderResult(provider_order_id=str(data.get("cf_order_id") or merchant_order_id),
                               payment_session_id=data.get("payment_session_id"))
        if status == 409:  # order already exists: fetch-before-retry
            raise ProviderUnavailable("order exists")
        raise ProviderRejected(str(data.get("message") or status)[:200])

    async def fetch_order(self, merchant_order_id: str) -> OrderState | None:
        status, data = await self._request("GET", f"/orders/{merchant_order_id}")
        if status == 404:
            return None
        if status != 200:
            raise ProviderUnavailable(f"HTTP {status}")
        return OrderState(status=str(data.get("order_status", "")), amount_paise=decimal_to_paise(data.get("order_amount", 0)))

    async def fetch_payments(self, merchant_order_id: str) -> list[PaymentFact]:
        status, data = await self._request("GET", f"/orders/{merchant_order_id}/payments")
        if status == 404:
            return []
        if status != 200 or not isinstance(data, list):
            raise ProviderUnavailable(f"HTTP {status}")
        return [PaymentFact(payment_id=str(p.get("cf_payment_id")), status=normalize_payment_status(p.get("payment_status")),
                            amount_paise=decimal_to_paise(p.get("payment_amount", 0)),
                            currency=str(p.get("payment_currency", "")))
                for p in data if p.get("cf_payment_id") is not None]

    async def create_refund(self, merchant_order_id: str, refund_id: str, amount_paise: int, note: str) -> str:
        body = {"refund_amount": float(paise_to_decimal(amount_paise)), "refund_id": refund_id,
                "refund_note": note[:100]}
        status, data = await self._request("POST", f"/orders/{merchant_order_id}/refunds", body,
                                           idempotency_key=refund_id)
        if status in (200, 201):
            return str(data.get("refund_status", "PENDING"))
        if status == 409:
            raise ProviderUnavailable("refund exists")
        raise ProviderRejected(str(data.get("message") or status)[:200])

    async def fetch_refund(self, merchant_order_id: str, refund_id: str) -> str | None:
        status, data = await self._request("GET", f"/orders/{merchant_order_id}/refunds/{refund_id}")
        if status == 404:
            return None
        if status != 200:
            raise ProviderUnavailable(f"HTTP {status}")
        return str(data.get("refund_status", ""))

    def verify_webhook(self, raw: bytes, headers: dict[str, str]) -> bool:
        signature = headers.get("x-webhook-signature", "")
        timestamp = headers.get("x-webhook-timestamp", "")
        if not signature or not timestamp:
            return False
        expected = base64.b64encode(hmac.new(self.secret.encode(), timestamp.encode() + raw, hashlib.sha256).digest())
        return hmac.compare_digest(expected, signature.encode())

    def parse_webhook(self, raw: bytes) -> WebhookEvent:
        data = json.loads(raw.decode("utf-8"))
        inner = data.get("data", {}) if isinstance(data, dict) else {}
        order = inner.get("order", {}) or {}
        payment = inner.get("payment", {}) or {}
        amount = payment.get("payment_amount")
        return WebhookEvent(
            event_type=str(data.get("type", "unknown"))[:64],
            merchant_order_id=order.get("order_id"),
            payment_id=str(payment["cf_payment_id"]) if payment.get("cf_payment_id") is not None else None,
            status=payment.get("payment_status"),
            amount_paise=decimal_to_paise(amount) if amount is not None else None,
        )
