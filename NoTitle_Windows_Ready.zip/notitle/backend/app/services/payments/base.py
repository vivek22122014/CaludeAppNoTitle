"""Hosted-payment provider interface.

The application never handles card/UPI credentials: the provider's hosted
checkout does.  The server creates a stable merchant order first, and grants
time only after *independently fetching* a successful payment from the
provider (a browser redirect or webhook alone is never trusted).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


class ProviderUnavailable(Exception):
    """Network/timeout or 5xx: the outcome of a mutation is unknown."""


class ProviderRejected(Exception):
    """The provider definitively refused the request (4xx)."""


@dataclass
class OrderResult:
    provider_order_id: str
    payment_session_id: str | None
    checkout_url: str | None = None


@dataclass
class PaymentFact:
    payment_id: str
    status: str  # success | failed | pending | user_dropped | cancelled | unknown
    amount_paise: int
    currency: str


@dataclass
class OrderState:
    status: str  # ACTIVE | PAID | EXPIRED | TERMINATED | ...
    amount_paise: int


@dataclass
class WebhookEvent:
    event_type: str
    merchant_order_id: str | None
    payment_id: str | None
    status: str | None
    amount_paise: int | None


class Provider(Protocol):
    name: str
    environment: str

    async def create_order(self, merchant_order_id: str, amount_paise: int, customer_ref: str, phone: str,
                           return_url: str, notify_url: str) -> OrderResult: ...

    async def fetch_order(self, merchant_order_id: str) -> OrderState | None: ...

    async def fetch_payments(self, merchant_order_id: str) -> list[PaymentFact]: ...

    async def create_refund(self, merchant_order_id: str, refund_id: str, amount_paise: int, note: str) -> str: ...

    async def fetch_refund(self, merchant_order_id: str, refund_id: str) -> str | None: ...

    def verify_webhook(self, raw: bytes, headers: dict[str, str]) -> bool: ...

    def parse_webhook(self, raw: bytes) -> WebhookEvent: ...


def paise_to_decimal(paise: int) -> str:
    """Exact decimal string, never binary floating point."""
    return f"{paise // 100}.{paise % 100:02d}"


def decimal_to_paise(value: object) -> int:
    from decimal import Decimal, ROUND_HALF_UP

    return int((Decimal(str(value)) * 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def normalize_refund_status(status: str | None) -> str:
    mapping = {"SUCCESS": "succeeded", "PENDING": "pending", "PENDING_APPROVAL": "pending", "ONHOLD": "pending",
               "CANCELLED": "cancelled", "REJECTED": "failed", "FAILED": "failed"}
    return mapping.get((status or "").upper(), "needs_review")


def normalize_payment_status(status: str | None) -> str:
    mapping = {"SUCCESS": "success", "FAILED": "failed", "PENDING": "pending", "USER_DROPPED": "user_dropped",
               "CANCELLED": "cancelled", "NOT_ATTEMPTED": "pending", "FLAGGED": "pending", "VOID": "cancelled"}
    return mapping.get((status or "").upper(), "unknown")
