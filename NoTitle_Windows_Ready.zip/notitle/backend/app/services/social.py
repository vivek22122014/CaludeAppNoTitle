"""Durable friendships and blocks (blueprint chapters 13, 24, 27)."""

from __future__ import annotations

import psycopg

from app import db
from app.realtime.coordinator import FRIEND_CAP, coordinator, relationship_id_for
from app.security import crypto


def relationship_id(a: str, b: str) -> str:
    return relationship_id_for(a, b)


async def persist_friendship(a: str, b: str) -> bool:
    """Commit a normalised account pair once.  Blocks and the 100 cap win."""
    low, high = sorted((a, b))
    async with db.transaction() as conn:
        # Lock both accounts in a deterministic order.
        await conn.execute("SELECT id FROM accounts WHERE id = ANY(%s) ORDER BY id FOR UPDATE", ([low, high],))
        blocked = await (await conn.execute(
            "SELECT 1 FROM blocks WHERE (blocker_id = %s AND blocked_id = %s) OR (blocker_id = %s AND blocked_id = %s)",
            (low, high, high, low))).fetchone()
        if blocked:
            return False
        for account in (low, high):
            count = await (await conn.execute(
                """SELECT count(*) AS n FROM friendships WHERE state = 'active'
                   AND (low_account_id = %s OR high_account_id = %s)""", (account, account))).fetchone()
            if count["n"] >= FRIEND_CAP:
                return False
        await conn.execute(
            """INSERT INTO friendships (low_account_id, high_account_id) VALUES (%s, %s)
               ON CONFLICT (low_account_id, high_account_id) DO UPDATE
               SET state = 'active', revision = friendships.revision + 1, accepted_at = now(), removed_at = NULL""",
            (low, high),
        )
    return True


async def compensate_friendship(a: str, b: str) -> None:
    low, high = sorted((a, b))
    await db.execute(
        """UPDATE friendships SET state = 'removed', removed_at = now(), revision = revision + 1
           WHERE low_account_id = %s AND high_account_id = %s AND state = 'active'""",
        (low, high),
    )


async def list_friends(principal) -> list[dict]:
    """Accepted friends with coarse presence; at most 100."""
    out: list[dict] = []
    if principal.kind == "account":
        account_id = principal.account_id
        rows = await db.fetch_all(
            """SELECT a.id, a.display_name, a.gender, a.topic_id, a.bio, f.revision, f.accepted_at
               FROM friendships f JOIN accounts a
                 ON a.id = CASE WHEN f.low_account_id = %s THEN f.high_account_id ELSE f.low_account_id END
               WHERE f.state = 'active' AND (f.low_account_id = %s OR f.high_account_id = %s) AND a.status = 'active'
               ORDER BY f.accepted_at DESC LIMIT 100""",
            (account_id, account_id, account_id),
        )
        for row in rows:
            other_key = f"a:{row['id']}"
            out.append({
                "relationship_id": relationship_id(account_id, str(row["id"])),
                "state": "saved",
                "revision": row["revision"],
                "presence": coordinator.presence(other_key),
                "friend": {"display_name": row["display_name"], "gender": row["gender"],
                           "topic_id": row["topic_id"], "bio": row["bio"]},
                "since": row["accepted_at"].isoformat(),
            })
    me = coordinator.participants.get(principal.key)
    saved_ids = {item["relationship_id"] for item in out}
    if me:
        for rel_id, peer in me.friends.items():
            if rel_id in saved_ids:
                continue
            other = coordinator.participants.get(peer)
            if other is None:
                continue
            out.append({
                "relationship_id": rel_id,
                "state": "saving" if rel_id not in coordinator.temp_relationships else "temporary",
                "revision": 1,
                "presence": coordinator.presence(peer),
                "friend": other.friend_dto(),
                "since": None,
            })
    else:
        for rel_id, peer in coordinator.temporary_relationships_for(principal.key):
            other = coordinator.participants.get(peer)
            out.append({
                "relationship_id": rel_id, "state": "temporary", "revision": 1,
                "presence": coordinator.presence(peer),
                "friend": other.friend_dto() if other else {"display_name": "Guest", "gender": "other",
                                                            "topic_id": "general", "bio": ""},
                "since": None,
            })
    return out[:100]


async def remove_friend(principal, rel_id: str, expected_revision: int | None) -> bool:
    if rel_id in coordinator.temp_relationships:
        a, b = coordinator.temp_relationships[rel_id]
        if principal.key not in (a, b):
            return False
        coordinator.remove_relationship(principal.key, rel_id)
        return True
    if principal.kind != "account":
        return False
    account_id = principal.account_id
    rows = await db.fetch_all(
        """SELECT low_account_id, high_account_id, revision FROM friendships
           WHERE state = 'active' AND (low_account_id = %s OR high_account_id = %s)""",
        (account_id, account_id),
    )
    for row in rows:
        other = str(row["high_account_id"] if str(row["low_account_id"]) == account_id else row["low_account_id"])
        if relationship_id(account_id, other) != rel_id:
            continue
        if expected_revision is not None and expected_revision != row["revision"]:
            from app.http.errors import conflict

            raise conflict("This friendship changed. Reload and try again.", code="stale_revision")
        await db.execute(
            """UPDATE friendships SET state = 'removed', removed_at = now(), revision = revision + 1
               WHERE low_account_id = %s AND high_account_id = %s""",
            (row["low_account_id"], row["high_account_id"]),
        )
        coordinator.remove_relationship(principal.key, rel_id)
        return True
    return False


async def persist_block(blocker: str, blocked: str) -> str:
    ref = crypto.new_ref("blk")
    try:
        row = await db.fetch_one(
            """INSERT INTO blocks (public_ref, blocker_id, blocked_id) VALUES (%s, %s, %s)
               ON CONFLICT (blocker_id, blocked_id) DO UPDATE SET blocker_id = EXCLUDED.blocker_id
               RETURNING public_ref""",
            (ref, blocker, blocked),
        )
        return row["public_ref"] if row else ref
    except psycopg.errors.ForeignKeyViolation:
        return ref


async def create_block(principal, peer_key: str) -> dict:
    """Immediate fence first, then durable persistence where both sides are accounts."""
    durable = principal.kind == "account" and peer_key.startswith("a:")
    coordinator.apply_block(principal.key, peer_key, durable=durable)
    if durable:
        ref = await _insert_block(principal.account_id, peer_key[2:])
        await compensate_friendship(principal.account_id, peer_key[2:])
        return {"block_ref": ref, "scope": "account", "persisted": True}
    return {"block_ref": "ram_" + crypto.b64u(crypto.hmac_digest(principal.key, peer_key, purpose="ram-block"))[:22],
            "scope": "identity", "persisted": False,
            "note": "This block protects this temporary identity only; a new guest identity is not linked to it."}


async def _insert_block(blocker: str, blocked: str) -> str:
    async with db.transaction() as conn:
        row = await (await conn.execute(
            """INSERT INTO blocks (public_ref, blocker_id, blocked_id) VALUES (%s, %s, %s)
               ON CONFLICT (blocker_id, blocked_id) DO NOTHING RETURNING public_ref""",
            (crypto.new_ref("blk"), blocker, blocked))).fetchone()
        if row is None:
            row = await (await conn.execute(
                "SELECT public_ref FROM blocks WHERE blocker_id = %s AND blocked_id = %s", (blocker, blocked))).fetchone()
        await conn.execute("UPDATE accounts SET safety_revision = safety_revision + 1 WHERE id = ANY(%s)",
                           ([blocker, blocked],))
    return row["public_ref"]


async def list_blocks(principal, cursor: str | None, limit: int = 20) -> dict:
    items: list[dict] = []
    if principal.kind == "account":
        params: list = [principal.account_id]
        where = ""
        if cursor:
            where = "AND created_at < %s"
            params.append(cursor)
        params.append(limit + 1)
        rows = await db.fetch_all(
            f"""SELECT public_ref, created_at FROM blocks WHERE blocker_id = %s {where}
                ORDER BY created_at DESC LIMIT %s""", params)
        for row in rows[:limit]:
            items.append({"block_ref": row["public_ref"], "label": "Blocked contact",
                          "created_at": row["created_at"].isoformat(), "scope": "account"})
        next_cursor = rows[limit - 1]["created_at"].isoformat() if len(rows) > limit else None
    else:
        next_cursor = None
    from datetime import datetime, timezone

    for blocked, created in coordinator.ram_blocks_by(principal.key):
        items.append({"block_ref": "ram_" + crypto.b64u(crypto.hmac_digest(principal.key, blocked, purpose="ram-block"))[:22],
                      "label": "Blocked contact (this identity only)",
                      "created_at": datetime.fromtimestamp(created, timezone.utc).isoformat(), "scope": "identity"})
    return {"items": items, "next_cursor": next_cursor}


async def remove_block(principal, ref: str) -> bool:
    if ref.startswith("ram_"):
        for blocked, _ in coordinator.ram_blocks_by(principal.key):
            if "ram_" + crypto.b64u(crypto.hmac_digest(principal.key, blocked, purpose="ram-block"))[:22] == ref:
                coordinator.lift_block(principal.key, blocked)
                return True
        return False
    if principal.kind != "account":
        return False
    row = await db.fetch_one(
        "DELETE FROM blocks WHERE public_ref = %s AND blocker_id = %s RETURNING blocked_id",
        (ref, principal.account_id),
    )
    if row is None:
        return False
    # Unblocking only removes the outbound restriction; it restores nothing.
    other = f"a:{row['blocked_id']}"
    reverse = await db.fetch_one("SELECT 1 FROM blocks WHERE blocker_id = %s AND blocked_id = %s",
                                 (row["blocked_id"], principal.account_id))
    if not reverse:
        for key, peer in ((principal.key, other), (other, principal.key)):
            p = coordinator.participants.get(key)
            if p:
                p.blocked.discard(peer)
    return True
