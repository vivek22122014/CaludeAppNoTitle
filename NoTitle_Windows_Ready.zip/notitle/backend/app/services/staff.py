"""Private staff identities, grants, MFA sessions and signed previews (chapter 29).

* Staff accounts are separate from user accounts; password + TOTP always.
* Grants are rechecked on every request through ``role_version``.
* Sensitive actions use a two-step preview → confirm.  The preview is bound
  to actor, object and payload digest, expires in two minutes and is consumed
  exactly once; confirm requires a fresh TOTP.
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

from app import db
from app.http.errors import ApiError, conflict, forbidden, gone, invalid
from app.security import crypto
from app.security.passwords import hash_password, validate_password, verify_password
from app.security.totp import new_totp_secret, provisioning_uri, verify_totp
from app.services import audit, keys

PERMISSIONS = (
    "cases.queue", "cases.read", "cases.claim", "cases.assign", "cases.reply", "cases.manage", "cases.notes",
    "cases.legal", "reports.read", "decisions.make", "appeals.review", "billing.read", "billing.remedy",
    "privacy.manage", "analytics.read", "audit.read", "staff.manage", "release.read",
)
ROLES: dict[str, tuple[str, ...]] = {
    "owner": PERMISSIONS,
    "moderator": ("cases.queue", "cases.read", "cases.claim", "cases.reply", "cases.manage", "cases.notes",
                  "reports.read", "decisions.make", "appeals.review"),
    "billing": ("cases.queue", "cases.read", "cases.claim", "cases.reply", "cases.notes", "billing.read",
                "billing.remedy"),
    "privacy": ("cases.queue", "cases.read", "cases.claim", "cases.reply", "cases.notes", "cases.legal",
                "privacy.manage", "audit.read"),
    "analyst": ("analytics.read",),
}
IDLE = timedelta(minutes=15)
ABSOLUTE = timedelta(hours=4)
FRESH_MFA = timedelta(minutes=5)
PREVIEW_TTL = timedelta(minutes=2)


def _now() -> datetime:
    return datetime.now(timezone.utc)


async def create_staff(username: str, password: str, roles: list[str]) -> dict:
    """Create a staff account.  Returns the TOTP secret and recovery codes ONCE."""
    username = username.strip().lower()
    import re

    if not re.fullmatch(r"[a-z0-9_.-]{3,32}", username):
        raise invalid("username", "Use 3–32 lowercase letters, numbers, dot, dash or underscore.")
    problem = validate_password(password)
    if problem:
        raise invalid("password", problem)
    unknown = [r for r in roles if r not in ROLES]
    if unknown or not roles:
        raise invalid("roles", f"Roles must be chosen from {', '.join(ROLES)}.")
    secret = new_totp_secret()
    recovery = [crypto.new_secret_code(groups=5) for _ in range(10)]
    password_hash = await hash_password(password)
    async with db.transaction() as conn:
        exists = await (await conn.execute("SELECT 1 FROM staff_accounts WHERE username = %s", (username,))).fetchone()
        if exists:
            raise conflict("A staff account with that username already exists.", code="exists")
        key = await keys.new_key(conn, "staff")
        staff_id = str(uuid.uuid4())
        await conn.execute(
            """INSERT INTO staff_accounts (id, username, password_hash, totp_secret_ct, totp_key_id)
               VALUES (%s, %s, %s, %s, %s)""",
            (staff_id, username, password_hash, key.encrypt(secret, f"staff_accounts|{staff_id}|totp"), key.id))
        for permission in sorted({p for r in roles for p in ROLES[r]}):
            await conn.execute("INSERT INTO staff_grants (staff_id, permission) VALUES (%s, %s)", (staff_id, permission))
        for code in recovery:
            await conn.execute("INSERT INTO staff_recovery_codes (staff_id, verifier) VALUES (%s, %s)",
                               (staff_id, crypto.code_verifier(code, "staff-recovery")))
    return {"staff_id": staff_id, "username": username, "totp_secret": secret,
            "otpauth_uri": provisioning_uri(secret, username), "recovery_codes": recovery,
            "roles": roles}


async def _totp_secret(staff: dict) -> str:
    key = await keys.get_key(staff["totp_key_id"])
    return key.decrypt(bytes(staff["totp_secret_ct"]), f"staff_accounts|{staff['id']}|totp")


async def check_totp(staff_id: str, code: str) -> bool:
    """Verify and atomically advance the replay counter."""
    staff = await db.fetch_one("SELECT * FROM staff_accounts WHERE id = %s", (staff_id,))
    if not staff:
        return False
    counter = verify_totp(await _totp_secret(staff), code, staff["last_totp_counter"])
    if counter is None:
        return False
    row = await db.fetch_one(
        """UPDATE staff_accounts SET last_totp_counter = %s
           WHERE id = %s AND (last_totp_counter IS NULL OR last_totp_counter < %s) RETURNING id""",
        (counter, staff_id, counter))
    return row is not None


async def _new_session(staff: dict) -> str:
    token = crypto.new_token()
    now = _now()
    await db.execute(
        """INSERT INTO staff_sessions (staff_id, token_hmac, role_version, mfa_at, expires_at, absolute_expires_at)
           VALUES (%s, %s, %s, %s, %s, %s)""",
        (staff["id"], crypto.token_verifier(token, "staff-session"), staff["role_version"], now, now + IDLE,
         now + ABSOLUTE))
    return token


async def login(username: str, password: str, totp_code: str) -> str:
    staff = await db.fetch_one("SELECT * FROM staff_accounts WHERE username = %s AND status = 'active'",
                               (username.strip().lower(),))
    valid, _ = await verify_password(staff["password_hash"] if staff else None, password)
    generic = ApiError(401, "invalid_credentials", "Username, password or authenticator code is incorrect.")
    if not staff or not valid:
        await audit.record(f"staff_login:{username[:32]}", "authentication", "staff", "-", "login", "denied")
        raise generic
    if not await check_totp(str(staff["id"]), totp_code):
        await audit.record(f"staff:{staff['id']}", "authentication", "staff", str(staff["id"]), "login_mfa", "denied")
        raise generic
    await audit.record(f"staff:{staff['id']}", "authentication", "staff", str(staff["id"]), "login")
    return await _new_session(staff)


async def recovery_login(username: str, password: str, recovery_code: str) -> str:
    staff = await db.fetch_one("SELECT * FROM staff_accounts WHERE username = %s AND status = 'active'",
                               (username.strip().lower(),))
    valid, _ = await verify_password(staff["password_hash"] if staff else None, password)
    if not staff or not valid:
        raise ApiError(401, "invalid_credentials", "Username, password or recovery code is incorrect.")
    row = await db.fetch_one(
        """UPDATE staff_recovery_codes SET consumed_at = now()
           WHERE staff_id = %s AND verifier = %s AND consumed_at IS NULL RETURNING id""",
        (staff["id"], crypto.code_verifier(recovery_code, "staff-recovery")))
    if row is None:
        raise ApiError(401, "invalid_credentials", "Username, password or recovery code is incorrect.")
    await audit.record(f"staff:{staff['id']}", "authentication", "staff", str(staff["id"]), "login_recovery_code")
    return await _new_session(staff)


async def resolve(token: str | None) -> dict | None:
    if not token:
        return None
    row = await db.fetch_one(
        """SELECT s.id AS session_id, s.mfa_at, s.expires_at, s.absolute_expires_at, s.role_version AS session_role_version,
                  s.last_active_at, a.id, a.username, a.status, a.role_version
           FROM staff_sessions s JOIN staff_accounts a ON a.id = s.staff_id
           WHERE s.token_hmac = %s AND s.revoked_at IS NULL""",
        (crypto.token_verifier(token, "staff-session"),))
    now = _now()
    if (row is None or row["status"] != "active" or row["expires_at"] < now or row["absolute_expires_at"] < now
            or row["session_role_version"] != row["role_version"]):
        return None
    grants = await db.fetch_all("SELECT permission FROM staff_grants WHERE staff_id = %s", (row["id"],))
    row["permissions"] = sorted(g["permission"] for g in grants)
    if (now - row["last_active_at"]).total_seconds() > 30:
        await db.execute("UPDATE staff_sessions SET last_active_at = %s, expires_at = least(%s, absolute_expires_at) WHERE id = %s",
                         (now, now + IDLE, row["session_id"]))
    return row


def require(staff: dict, permission: str) -> None:
    if permission not in staff["permissions"]:
        raise forbidden("Your staff role does not include this permission.")


def require_fresh_mfa(staff: dict) -> None:
    if _now() - staff["mfa_at"] > FRESH_MFA:
        raise ApiError(403, "mfa_required", "Confirm with your authenticator code to continue.")


async def step_up(staff: dict, code: str) -> None:
    if not await check_totp(str(staff["id"]), code):
        raise ApiError(401, "invalid_mfa", "Authenticator code is incorrect or already used.")
    await db.execute("UPDATE staff_sessions SET mfa_at = now() WHERE id = %s", (staff["session_id"],))
    staff["mfa_at"] = _now()


async def logout(staff: dict) -> None:
    await db.execute("UPDATE staff_sessions SET revoked_at = now() WHERE id = %s", (staff["session_id"],))


async def create_preview(staff: dict, kind: str, object_ref: str, payload: dict, summary: dict) -> dict:
    nonce = str(uuid.uuid4())
    digest = crypto.payload_digest({"kind": kind, "object": object_ref, "payload": payload}, purpose="preview")
    expires = _now() + PREVIEW_TTL
    await db.execute(
        """INSERT INTO sensitive_previews (nonce, staff_id, kind, object_ref, payload, payload_digest, expires_at)
           VALUES (%s, %s, %s, %s, %s, %s, %s)""",
        (nonce, staff["id"], kind, object_ref, json.dumps(payload, default=str), digest, expires))
    return {"nonce": nonce, "kind": kind, "object_ref": object_ref, "expires_at": expires.isoformat(),
            "summary": summary, "requires": "fresh authenticator code"}


async def consume_preview(conn: Any, staff: dict, nonce: str, kind: str) -> dict:
    """Lock and consume an unexpired preview owned by this staff member."""
    try:
        row = await (await conn.execute("SELECT * FROM sensitive_previews WHERE nonce = %s FOR UPDATE",
                                        (nonce,))).fetchone()
    except Exception:  # noqa: BLE001 - malformed UUID
        row = None
    if row is None or str(row["staff_id"]) != str(staff["id"]) or row["kind"] != kind:
        raise gone("The preview is invalid. Create a new preview.")
    if row["consumed_at"] is not None:
        raise conflict("This preview was already confirmed.", code="preview_consumed")
    if row["expires_at"] < _now():
        raise gone("The preview expired. Create a new preview.")
    digest = crypto.payload_digest({"kind": row["kind"], "object": row["object_ref"], "payload": row["payload"]},
                                   purpose="preview")
    if bytes(row["payload_digest"]) != digest:
        raise conflict("The preview does not match its signed contents.", code="preview_tampered")
    await conn.execute("UPDATE sensitive_previews SET consumed_at = now() WHERE nonce = %s", (nonce,))
    return row


async def list_staff() -> list[dict]:
    rows = await db.fetch_all(
        """SELECT a.username, a.status, a.created_at, array_agg(g.permission ORDER BY g.permission) AS permissions
           FROM staff_accounts a LEFT JOIN staff_grants g ON g.staff_id = a.id
           GROUP BY a.id ORDER BY a.username""")
    return [{"username": r["username"], "status": r["status"], "created_at": r["created_at"].isoformat(),
             "permissions": [p for p in r["permissions"] if p]} for r in rows]


async def set_roles(username: str, roles: list[str]) -> dict:
    unknown = [r for r in roles if r not in ROLES]
    if unknown:
        raise invalid("roles", "Unknown role.")
    async with db.transaction() as conn:
        staff = await (await conn.execute("SELECT id FROM staff_accounts WHERE username = %s FOR UPDATE",
                                          (username,))).fetchone()
        if staff is None:
            raise invalid("username", "Unknown staff member.")
        await conn.execute("DELETE FROM staff_grants WHERE staff_id = %s", (staff["id"],))
        for permission in sorted({p for r in roles for p in ROLES[r]}):
            await conn.execute("INSERT INTO staff_grants (staff_id, permission) VALUES (%s, %s)", (staff["id"], permission))
        # Increment role_version: every existing session must sign in again.
        await conn.execute("UPDATE staff_accounts SET role_version = role_version + 1 WHERE id = %s", (staff["id"],))
    return {"username": username, "roles": roles}


async def set_status(username: str, status: str) -> None:
    await db.execute("UPDATE staff_accounts SET status = %s, role_version = role_version + 1 WHERE username = %s",
                     (status, username))


async def current_totp_for_dev(username: str) -> str:
    """Development helper only (CLI refuses in production)."""
    import time

    import pyotp

    staff = await db.fetch_one("SELECT * FROM staff_accounts WHERE username = %s", (username,))
    if staff is None:
        raise LookupError("unknown staff")
    totp = pyotp.TOTP(await _totp_secret(staff))
    current = int(time.time() // 30)
    last = staff["last_totp_counter"]
    # Next code the verifier will still accept (replay protection rejects reused counters).
    for counter in (current, current + 1):
        if last is None or counter > last:
            return totp.generate_otp(counter)
    raise LookupError("all codes in the current window are used; wait 30 seconds")
