"""Exports, deletion, rights requests and legal holds (chapters 17, 37, 38)."""

from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta, timezone
from typing import Any

from app import db
from app.http.errors import ApiError, conflict, invalid, not_found
from app.realtime.coordinator import coordinator
from app.security import crypto
from app.services import identity, jobs, keys, support
from app.services.journal import JournalError, journal

log = logging.getLogger("notitle.privacy")
EXPORT_TTL = timedelta(hours=24)
RIGHTS_DEADLINE = timedelta(days=30)
RETAINED = ["Verified payment and receipt records (statutory financial retention)",
            "Submitted safety reports and decisions (180 days after closure)",
            "Saved support cases (90 days after closure)",
            "Minimal consent and deletion proof (180 days)"]


def _now() -> datetime:
    return datetime.now(timezone.utc)


# ---------------------------------------------------------------------------
# Export
# ---------------------------------------------------------------------------


async def request_export(account_id: str) -> dict:
    pending = await db.fetch_one(
        "SELECT public_ref FROM privacy_exports WHERE account_id = %s AND status = 'pending'", (account_id,))
    if pending:
        return await export_status(account_id, pending["public_ref"])
    async with db.transaction() as conn:
        row = await (await conn.execute(
            "INSERT INTO privacy_exports (public_ref, account_id) VALUES (%s, %s) RETURNING id, public_ref",
            (crypto.new_ref("ex"), account_id))).fetchone()
        await jobs.enqueue(conn, "export.build", f"export:{row['id']}", {"export_id": str(row["id"])})
    return await export_status(account_id, row["public_ref"])


async def export_status(account_id: str, ref: str) -> dict:
    row = await db.fetch_one(
        "SELECT public_ref, status, created_at, ready_at, expires_at, downloaded_at FROM privacy_exports WHERE public_ref = %s AND account_id = %s",
        (ref, account_id))
    if row is None:
        raise not_found()
    status = row["status"]
    if status == "ready" and row["expires_at"] and row["expires_at"] < _now():
        status = "expired"
    return {"export_ref": row["public_ref"], "status": status, "created_at": row["created_at"].isoformat(),
            "ready_at": row["ready_at"].isoformat() if row["ready_at"] else None,
            "expires_at": row["expires_at"].isoformat() if row["expires_at"] else None}


async def list_exports(account_id: str) -> list[dict]:
    rows = await db.fetch_all("SELECT public_ref FROM privacy_exports WHERE account_id = %s ORDER BY created_at DESC LIMIT 5",
                              (account_id,))
    return [await export_status(account_id, r["public_ref"]) for r in rows]


async def _collect(account_id: str) -> dict:
    account = await db.fetch_one(
        "SELECT username, display_name, gender, topic_id, bio, created_at, updated_at FROM accounts WHERE id = %s",
        (account_id,))
    profile = await identity.load_profile(account_id)
    consents = await db.fetch_all(
        "SELECT purpose, choice, policy_kind, policy_version, recorded_at FROM consent_records WHERE account_id = %s ORDER BY recorded_at",
        (account_id,))
    friends = await db.fetch_all(
        """SELECT a.display_name, f.accepted_at FROM friendships f JOIN accounts a
             ON a.id = CASE WHEN f.low_account_id = %s THEN f.high_account_id ELSE f.low_account_id END
           WHERE f.state = 'active' AND (f.low_account_id = %s OR f.high_account_id = %s)""",
        (account_id, account_id, account_id))
    blocks = await db.fetch_all("SELECT created_at FROM blocks WHERE blocker_id = %s", (account_id,))
    purchases = await db.fetch_all(
        """SELECT p.public_ref, p.plan_code, p.amount_paise, p.state, p.created_at, p.captured_at
           FROM purchases p JOIN financial_subjects s ON s.id = p.financial_subject_id WHERE s.account_id = %s""",
        (account_id,))
    receipts = await db.fetch_all(
        """SELECT r.public_ref, r.receipt_number, r.issued_at, r.facts FROM receipts r
           JOIN financial_subjects s ON s.id = r.subject_id WHERE s.account_id = %s""", (account_id,))
    cases = await db.fetch_all("SELECT * FROM support_cases WHERE account_id = %s", (account_id,))
    case_data = []
    for case in cases:
        dto = await support.case_dto(case)
        msgs = await support.messages(case, 0, None, 50, "user")
        case_data.append({**dto, "messages": msgs["items"]})
    notices = await db.fetch_all("SELECT kind, safe_payload, issued_at, seen_at FROM account_notices WHERE account_id = %s",
                                 (account_id,))

    def ser(rows: list[dict]) -> list[dict]:
        return [{k: (v.isoformat() if isinstance(v, datetime) else v) for k, v in r.items()} for r in rows]

    return {
        "format": "notitle-personal-data-export/1",
        "generated_at": _now().isoformat(),
        "account": {k: (v.isoformat() if isinstance(v, datetime) else v) for k, v in (account or {}).items()},
        "preferences": profile["preferences"],
        "professional_profile": profile["professional"],
        "consents": ser(consents),
        "friends": ser(friends),
        "blocks": {"count": len(blocks), "created": [b["created_at"].isoformat() for b in blocks]},
        "purchases": ser(purchases),
        "receipts": ser(receipts),
        "support_cases": case_data,
        "notices": ser(notices),
        "not_included": ["Ordinary chat (never stored)", "Other people's private data", "Staff internal notes",
                         "Secrets and credential verifiers"],
    }


async def build_export(export_id: str) -> None:
    row = await db.fetch_one("SELECT * FROM privacy_exports WHERE id = %s", (export_id,))
    if row is None or row["status"] != "pending" or row["account_id"] is None:
        return
    data = json.dumps(await _collect(str(row["account_id"])), indent=2, default=str)
    async with db.transaction() as conn:
        key = await keys.new_key(conn, "export")
        await conn.execute(
            """UPDATE privacy_exports SET status = 'ready', package_ct = %s, key_id = %s, ready_at = now(),
                      expires_at = %s WHERE id = %s""",
            (key.encrypt(data, f"privacy_exports|{export_id}|package"), key.id, _now() + EXPORT_TTL, export_id))


async def download_export(account_id: str, ref: str) -> str:
    row = await db.fetch_one(
        "SELECT * FROM privacy_exports WHERE public_ref = %s AND account_id = %s", (ref, account_id))
    if row is None or row["status"] != "ready" or row["package_ct"] is None:
        raise not_found()
    if row["expires_at"] < _now():
        raise ApiError(410, "expired", "This export expired. Request a new one.")
    key = await keys.get_key(row["key_id"])
    data = key.decrypt(bytes(row["package_ct"]), f"privacy_exports|{row['id']}|package")
    await db.execute("UPDATE privacy_exports SET downloaded_at = now() WHERE id = %s", (row["id"],))
    return data


# ---------------------------------------------------------------------------
# Deletion
# ---------------------------------------------------------------------------


async def delete_account(principal: Any, boot: str, reservation_id: str, secret: str, saved: bool,
                         confirm: bool) -> dict:
    if not confirm:
        raise invalid("confirm", "Confirm that you want to delete your account.")
    if not saved:
        raise invalid("saved", "Save the deletion receipt before continuing.")
    identity.require_reauth(principal.account)
    prep = identity.prepared.peek(reservation_id, principal.scope, "deletion_receipt", secret)
    account_id = principal.account_id
    subject_ref = principal.subject_ref
    # 1. Fence live participation immediately.
    coordinator.end_identity(principal.key, "account_deleted")
    verifier = crypto.code_verifier(prep.secret, "deletion-receipt")
    # 2. Durable independent instruction before claiming acceptance.
    try:
        entry = journal.append("deletion", account_id=account_id, subject_ref=subject_ref, reference=prep.reference,
                               receipt_verifier=verifier.hex())
    except (JournalError, OSError):
        log.exception("journal append failed")
        raise ApiError(503, "deletion_pending",
                       "Your request could not be recorded durably yet. Your access was paused; please retry.",
                       retryable=True) from None
    # 3. Disable the account and bind the journal sequence.
    async with db.transaction() as conn:
        await conn.execute(
            "UPDATE accounts SET status = 'disabled', auth_generation = auth_generation + 1, updated_at = now() WHERE id = %s",
            (account_id,))
        await conn.execute("UPDATE account_sessions SET revoked_at = now() WHERE account_id = %s AND revoked_at IS NULL",
                           (account_id,))
        row = await (await conn.execute(
            """INSERT INTO deletion_requests (public_ref, account_id, subject_ref, journal_seq)
               VALUES (%s, %s, %s, %s) RETURNING id, requested_at""",
            (prep.reference, account_id, subject_ref, entry["seq"]))).fetchone()
        await conn.execute(
            "INSERT INTO scoped_receipts (public_ref, kind, scope_ref, verifier) VALUES (%s, 'deletion', %s, %s)",
            (prep.reference, str(row["id"]), verifier))
        await conn.execute(
            """INSERT INTO journal_checkpoints (stream_id, applied_seq, head_hash) VALUES ('privacy', %s, %s)
               ON CONFLICT (stream_id) DO UPDATE SET applied_seq = EXCLUDED.applied_seq, head_hash = EXCLUDED.head_hash,
               updated_at = now()""", (journal.seq, journal.head))
        await jobs.enqueue(conn, "deletion.purge", f"purge:{row['id']}", {"deletion_id": str(row["id"])})
    identity.prepared.consume(reservation_id)
    return {"deletion_ref": prep.reference, "state": "accepted", "requested_at": row["requested_at"].isoformat(),
            "retained_categories": RETAINED,
            "note": "Access is disabled now. Profile minimisation completes within 30 days; restricted records may remain."}


async def _active_hold(subject_ref: str, scopes: tuple[str, ...]) -> bool:
    row = await db.fetch_one(
        """SELECT 1 FROM legal_holds WHERE subject_ref = %s AND state = 'active' AND scope = ANY(%s)
           AND (expires_at IS NULL OR expires_at > now())""", (subject_ref, list(scopes)))
    return row is not None


async def purge(deletion_id: str) -> None:
    deletion = await db.fetch_one("SELECT * FROM deletion_requests WHERE id = %s", (deletion_id,))
    if deletion is None or deletion["state"] == "completed" or deletion["account_id"] is None:
        return
    account_id = str(deletion["account_id"])
    if await _active_hold(deletion["subject_ref"], ("account_profile", "all")):
        await db.execute("UPDATE deletion_requests SET state = 'restricted', retained_categories = %s WHERE id = %s",
                         (RETAINED + ["Account profile (under a documented legal hold)"], deletion_id))
        return
    async with db.transaction() as conn:
        await conn.execute("UPDATE deletion_requests SET state = 'processing' WHERE id = %s", (deletion_id,))
        await conn.execute("SELECT id FROM accounts WHERE id = %s FOR UPDATE", (account_id,))
        for sql in (
            "DELETE FROM professional_profiles WHERE account_id = %s",
            "DELETE FROM matching_preferences WHERE account_id = %s",
            "DELETE FROM account_sessions WHERE account_id = %s",
            "DELETE FROM recovery_credentials WHERE account_id = %s",
            "DELETE FROM account_notices WHERE account_id = %s",
            "DELETE FROM privacy_exports WHERE account_id = %s",
            "DELETE FROM blocks WHERE blocker_id = %s OR blocked_id = %s",
            "DELETE FROM friendships WHERE low_account_id = %s OR high_account_id = %s",
            "UPDATE consent_records SET account_id = NULL WHERE account_id = %s",
            "UPDATE financial_subjects SET account_id = NULL WHERE account_id = %s",
            "UPDATE support_cases SET account_id = NULL WHERE account_id = %s",
            "UPDATE reports SET subject_account_id = NULL WHERE subject_account_id = %s",
            "UPDATE privacy_requests SET account_id = NULL WHERE account_id = %s",
        ):
            await conn.execute(sql, (account_id,) * sql.count("%s"))
        await conn.execute(
            """UPDATE accounts SET username = %s, password_hash = NULL, display_name = 'Deleted user', bio = '',
                      status = 'deleted', deleted_at = now(), updated_at = now() WHERE id = %s""",
            ("deleted_" + account_id.replace("-", ""), account_id))
        await conn.execute(
            "UPDATE deletion_requests SET state = 'completed', completed_at = now(), retained_categories = %s, account_id = NULL WHERE id = %s",
            (RETAINED, deletion_id))


async def deletion_status(token: str | None) -> dict:
    scope = await support.receipt_scope(token, "deletion")
    if scope is None:
        raise ApiError(401, "unauthenticated", "Open the status page with your deletion receipt.")
    row = await db.fetch_one("SELECT * FROM deletion_requests WHERE id = %s", (scope["scope_ref"],))
    if row is None:
        raise not_found()
    return {"deletion_ref": row["public_ref"], "state": row["state"], "requested_at": row["requested_at"].isoformat(),
            "completed_at": row["completed_at"].isoformat() if row["completed_at"] else None,
            "retained_categories": list(row["retained_categories"] or RETAINED)}


# ---------------------------------------------------------------------------
# Rights requests
# ---------------------------------------------------------------------------


async def create_request(principal: Any, kind: str, details: str, client_nonce: str) -> dict:
    details = support.check_body(details or f"Rights request: {kind}", "details")
    async with db.transaction() as conn:
        case = await support.create_case(conn, account_id=principal.account_id, category="privacy",
                                         subject=f"Privacy request: {kind}", body=details, client_nonce=client_nonce)
        row = await (await conn.execute(
            """INSERT INTO privacy_requests (public_ref, account_id, kind, case_id, deadline_at)
               VALUES (%s, %s, %s, %s, %s) RETURNING public_ref, deadline_at""",
            (crypto.new_ref("pr"), principal.account_id, kind, case["case_id"], _now() + RIGHTS_DEADLINE))).fetchone()
    return {"request_ref": row["public_ref"], "case_ref": case["case_ref"], "status": "received",
            "deadline_at": row["deadline_at"].isoformat()}


async def staff_requests() -> list[dict]:
    rows = await db.fetch_all(
        """SELECT r.public_ref, r.kind, r.status, r.deadline_at, r.created_at, c.public_ref AS case_ref
           FROM privacy_requests r JOIN support_cases c ON c.id = r.case_id ORDER BY r.deadline_at LIMIT 100""")
    return [{**r, "deadline_at": r["deadline_at"].isoformat(), "created_at": r["created_at"].isoformat(),
             "overdue": r["status"] not in ("completed", "rejected") and r["deadline_at"] < _now()} for r in rows]


async def staff_set_request_status(ref: str, status: str) -> dict:
    if status not in ("in_review", "completed", "rejected"):
        raise invalid("status", "Unknown status.")
    row = await db.fetch_one(
        "UPDATE privacy_requests SET status = %s, updated_at = now() WHERE public_ref = %s RETURNING public_ref, status",
        (status, ref))
    if row is None:
        raise not_found()
    return row


async def staff_deletions() -> list[dict]:
    rows = await db.fetch_all(
        "SELECT public_ref, state, journal_seq, requested_at, completed_at FROM deletion_requests ORDER BY requested_at DESC LIMIT 100")
    return [{**r, "requested_at": r["requested_at"].isoformat(),
             "completed_at": r["completed_at"].isoformat() if r["completed_at"] else None} for r in rows]


# ---------------------------------------------------------------------------
# Legal holds
# ---------------------------------------------------------------------------


async def subject_ref_for_target(target: str) -> str:
    """Accept a username, case ref or report ref and resolve the subject reference."""
    target = target.strip()
    if target.startswith(("subj_", "gsubj_")):
        return target
    if target.startswith("cs_"):
        row = await db.fetch_one("SELECT account_id FROM support_cases WHERE public_ref = %s", (target,))
        if row and row["account_id"]:
            return identity.subject_ref_for_account(str(row["account_id"]))
    elif target.startswith("rp_"):
        row = await db.fetch_one("SELECT subject_ref FROM reports WHERE public_ref = %s", (target,))
        if row:
            return row["subject_ref"]
    else:
        row = await db.fetch_one("SELECT id FROM accounts WHERE username = %s", (target.lower(),))
        if row:
            return identity.subject_ref_for_account(str(row["id"]))
    raise invalid("target", "No subject matches that reference.")


async def place_hold(conn: Any, staff_id: str, payload: dict) -> dict:
    entry = journal.append("hold", subject_ref=payload["subject_ref"], scope=payload["scope"])
    row = await (await conn.execute(
        """INSERT INTO legal_holds (public_ref, subject_ref, scope, basis, approver_staff_id, review_at, expires_at, journal_seq)
           VALUES (%s, %s, %s, %s, %s, %s, %s, %s) RETURNING public_ref""",
        (crypto.new_ref("lh"), payload["subject_ref"], payload["scope"], payload["basis"], staff_id,
         payload["review_at"], payload.get("expires_at"), entry["seq"]))).fetchone()
    return {"hold_ref": row["public_ref"], "journal_seq": entry["seq"]}


async def release_hold(conn: Any, hold_ref: str) -> dict:
    row = await (await conn.execute(
        "UPDATE legal_holds SET state = 'released', released_at = now() WHERE public_ref = %s AND state = 'active' RETURNING subject_ref",
        (hold_ref,))).fetchone()
    if row is None:
        raise conflict("That hold is not active.", code="not_active")
    journal.append("hold_release", subject_ref=row["subject_ref"], hold_ref=hold_ref)
    return {"hold_ref": hold_ref, "state": "released"}


async def list_holds() -> list[dict]:
    rows = await db.fetch_all(
        """SELECT h.public_ref, h.subject_ref, h.scope, h.basis, h.state, h.review_at, h.expires_at, h.created_at, s.username
           FROM legal_holds h JOIN staff_accounts s ON s.id = h.approver_staff_id ORDER BY h.created_at DESC LIMIT 100""")
    return [{**r, **{k: (r[k].isoformat() if r[k] else None) for k in ("review_at", "expires_at", "created_at")}}
            for r in rows]
