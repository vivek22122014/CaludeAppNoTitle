"""Independent deletion/hold journal (blueprint chapter 38).

An append-only JSON-lines file outside PostgreSQL.  Every entry is HMAC-chained
to its predecessor and fsynced before the database transaction that relies on
it.  At startup the chain is verified and replayed, so deletions survive a
restore of an older database backup.  Tampering or a database checkpoint that
is ahead of the file (lost continuity) blocks startup.

Production should mirror this file to versioned, write-once object storage;
the local file is the first, independent copy.
"""

from __future__ import annotations

import json
import logging
import os
import threading
from datetime import datetime, timezone
from pathlib import Path

from app.config import get_settings
from app.security.crypto import constant_equals, journal_mac

log = logging.getLogger("notitle.journal")
GENESIS = "0" * 64
CAPACITY_WARN = 8500
CAPACITY = 10000


class JournalError(RuntimeError):
    pass


class Journal:
    def __init__(self, path: Path | None = None) -> None:
        self.path = path or (get_settings().data_path / "journal" / "privacy-journal.jsonl")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self.seq = 0
        self.head = GENESIS
        self.entries: list[dict] = []

    def load(self) -> list[dict]:
        self.entries, self.seq, self.head = [], 0, GENESIS
        if not self.path.exists():
            return []
        with self.path.open("r", encoding="utf-8") as fh:
            for lineno, line in enumerate(fh, 1):
                if not line.strip():
                    continue
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    raise JournalError(f"journal line {lineno} is corrupt") from None
                mac = entry.pop("mac", "")
                body = json.dumps(entry, sort_keys=True, separators=(",", ":")).encode()
                if entry.get("prev") != self.head or entry.get("seq") != self.seq + 1:
                    raise JournalError(f"journal chain broken at line {lineno}")
                if not constant_equals(mac, journal_mac(body)):
                    raise JournalError(f"journal entry {lineno} failed authentication (tampered or wrong JOURNAL_KEY)")
                self.seq = entry["seq"]
                self.head = mac
                self.entries.append(entry)
        return self.entries

    def append(self, kind: str, **fields: object) -> dict:
        with self._lock:
            if self.seq >= CAPACITY:
                raise JournalError("journal capacity reached; rotate the journal before accepting deletions")
            entry = {"seq": self.seq + 1, "prev": self.head, "kind": kind,
                     "at": datetime.now(timezone.utc).isoformat(), **fields}
            body = json.dumps(entry, sort_keys=True, separators=(",", ":")).encode()
            mac = journal_mac(body)
            line = json.dumps({**entry, "mac": mac}, sort_keys=True, separators=(",", ":")) + "\n"
            with self.path.open("a", encoding="utf-8") as fh:
                fh.write(line)
                fh.flush()
                os.fsync(fh.fileno())
            self.seq = entry["seq"]
            self.head = mac
            self.entries.append(entry)
            if self.seq >= CAPACITY_WARN:
                log.warning("privacy journal at %s/%s entries", self.seq, CAPACITY)
            return entry

    def status(self) -> dict:
        return {"entries": self.seq, "capacity": CAPACITY, "path": str(self.path), "head": self.head[:16]}


journal = Journal()


async def replay() -> dict:
    """Verify the chain, compare with the DB checkpoint and re-apply deletions/holds."""
    from app import db

    entries = journal.load()
    checkpoint = await db.fetch_one("SELECT applied_seq, head_hash FROM journal_checkpoints WHERE stream_id = 'privacy'")
    if checkpoint and checkpoint["applied_seq"] > journal.seq:
        raise JournalError(
            "the database records more journal entries than the journal file contains; "
            "restore the journal file before starting (deletions may otherwise be lost)")
    reapplied = 0
    for entry in entries:
        if entry["kind"] == "deletion":
            row = await db.fetch_one("SELECT status FROM accounts WHERE id = %s", (entry["account_id"],))
            if row and row["status"] == "active":
                # A restore brought back an account whose deletion was already accepted.
                await db.execute("UPDATE accounts SET status = 'disabled', auth_generation = auth_generation + 1 WHERE id = %s",
                                 (entry["account_id"],))
                await db.execute("UPDATE account_sessions SET revoked_at = now() WHERE account_id = %s AND revoked_at IS NULL",
                                 (entry["account_id"],))
                exists = await db.fetch_one("SELECT id FROM deletion_requests WHERE public_ref = %s", (entry["reference"],))
                if exists is None:
                    async with db.transaction() as conn:
                        row = await (await conn.execute(
                            """INSERT INTO deletion_requests (public_ref, account_id, subject_ref, journal_seq)
                               VALUES (%s, %s, %s, %s) RETURNING id""",
                            (entry["reference"], entry["account_id"], entry["subject_ref"], entry["seq"]))).fetchone()
                        if entry.get("receipt_verifier"):
                            await conn.execute(
                                """INSERT INTO scoped_receipts (public_ref, kind, scope_ref, verifier)
                                   VALUES (%s, 'deletion', %s, decode(%s, 'hex')) ON CONFLICT DO NOTHING""",
                                (entry["reference"], str(row["id"]), entry["receipt_verifier"]))
                        from app.services import jobs

                        await jobs.enqueue(conn, "deletion.purge", f"purge:{row['id']}", {"deletion_id": str(row["id"])})
                reapplied += 1
    await db.execute(
        """INSERT INTO journal_checkpoints (stream_id, applied_seq, head_hash) VALUES ('privacy', %s, %s)
           ON CONFLICT (stream_id) DO UPDATE SET applied_seq = EXCLUDED.applied_seq, head_hash = EXCLUDED.head_hash,
           updated_at = now()""", (journal.seq, journal.head))
    return {"entries": journal.seq, "reapplied": reapplied}
