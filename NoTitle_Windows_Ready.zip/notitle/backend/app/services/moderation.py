"""Reports read, moderation decisions, restrictions and independent appeals (chapter 27)."""

from __future__ import annotations

import json
import time
from datetime import datetime, timedelta, timezone
from typing import Any

from app import db
from app.http.errors import conflict, forbidden, invalid, not_found
from app.realtime.coordinator import coordinator
from app.security import crypto
from app.services import identity, keys

ACTIONS = ("dismiss", "warn", "suspend", "ban")


async def read_report(report_ref: str) -> dict:
    report = await db.fetch_one(
        """SELECT r.*, c.public_ref AS case_ref FROM reports r JOIN support_cases c ON c.id = r.case_id
           WHERE r.public_ref = %s""", (report_ref,))
    if report is None:
        raise not_found()
    key = await keys.get_key(report["key_id"])
    evidence = await db.fetch_all(
        "SELECT server_message_id, sender_role, sent_at, body_ct FROM report_evidence WHERE report_id = %s ORDER BY sent_at",
        (report["id"],))
    decisions = await db.fetch_all(
        """SELECT d.public_ref, d.action, d.reason_code, d.starts_at, d.ends_at, d.appeal_outcome, s.username
           FROM moderation_decisions d JOIN staff_accounts s ON s.id = d.staff_id WHERE d.report_id = %s
           ORDER BY d.created_at""", (report["id"],))
    prior = await db.fetch_one("SELECT count(*) AS n FROM reports WHERE subject_ref = %s AND id <> %s",
                               (report["subject_ref"], report["id"]))
    return {
        "report_ref": report["public_ref"],
        "case_ref": report["case_ref"],
        "reason": report["reason"],
        "reporter_kind": report["reporter_kind"],
        "subject_kind": report["subject_kind"],
        "subject_ref": report["subject_ref"],
        "blocked": report["blocked"],
        "evidence_state": report["evidence_state"],
        "submitted_at": report["submitted_at"].isoformat(),
        "allegation": key.decrypt(bytes(report["allegation_ct"]), f"reports|{report['id']}|allegation"),
        "allegation_note": "The allegation is the reporter's own account, not server-observed evidence.",
        "evidence": [{
            "message_id": e["server_message_id"],
            "sender": e["sender_role"],
            "sent_at": e["sent_at"].isoformat(),
            "body": key.decrypt(bytes(e["body_ct"]), f"report_evidence|{report['id']}|{e['server_message_id']}"),
            "source": "server_snapshot",
        } for e in evidence],
        "other_reports_about_subject": int(prior["n"]) if prior else 0,
        "decisions": [{**d, "starts_at": d["starts_at"].isoformat(),
                       "ends_at": d["ends_at"].isoformat() if d["ends_at"] else None} for d in decisions],
    }


async def decision_target(report_ref: str) -> dict:
    row = await db.fetch_one("SELECT id, case_id, subject_kind, subject_ref, subject_account_id FROM reports WHERE public_ref = %s",
                             (report_ref,))
    if row is None:
        raise not_found()
    return row


def validate_decision(action: str, duration_hours: int | None) -> None:
    if action not in ACTIONS:
        raise invalid("action", "Unknown action.")
    if action == "suspend" and not (duration_hours and 1 <= duration_hours <= 24 * 90):
        raise invalid("duration_hours", "Suspensions need a duration between 1 hour and 90 days.")


async def apply_decision(conn: Any, staff_id: str, report: dict, action: str, reason_code: str,
                         duration_hours: int | None) -> dict:
    ref = crypto.new_ref("dc")
    ends_at = (datetime.now(timezone.utc) + timedelta(hours=duration_hours)) if action == "suspend" else None
    row = await (await conn.execute(
        """INSERT INTO moderation_decisions (public_ref, report_id, case_id, subject_kind, subject_ref, action,
                                             reason_code, ends_at, staff_id)
           VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s) RETURNING id""",
        (ref, report["id"], report["case_id"], report["subject_kind"], report["subject_ref"], action, reason_code,
         ends_at, staff_id))).fetchone()
    if action in ("suspend", "ban"):
        await conn.execute(
            """INSERT INTO restrictions (subject_kind, subject_ref, kind, ends_at, reason_code, decision_id)
               VALUES (%s, %s, %s, %s, %s, %s)""",
            (report["subject_kind"], report["subject_ref"], action, ends_at, reason_code, row["id"]))
    if report["subject_account_id"] and action != "dismiss":
        await conn.execute(
            """INSERT INTO account_notices (public_ref, account_id, kind, safe_payload) VALUES (%s, %s, 'safety', %s)""",
            (crypto.new_ref("nt"), report["subject_account_id"],
             json.dumps({
                 "decision_ref": ref, "action": action, "reason_code": reason_code,
                 "ends_at": ends_at.isoformat() if ends_at else None,
                 "appeal": "You can appeal through Chat with Moderator → Appeal, quoting this decision reference.",
             })))
    return {"decision_ref": ref, "action": action, "ends_at": ends_at.isoformat() if ends_at else None,
            "decision_id": str(row["id"])}


def fence_subject(report: dict, action: str, ends_at: str | None) -> None:
    """Apply a confirmed restriction to the live runtime immediately."""
    if action not in ("suspend", "ban"):
        return
    until = float("inf") if action == "ban" else datetime.fromisoformat(ends_at).timestamp() if ends_at else time.time()
    if report["subject_account_id"]:
        coordinator.set_restriction(f"a:{report['subject_account_id']}", until)
        return
    for guest in list(identity.guests.by_id.values()):
        if identity.subject_ref_for_guest(guest.id) == report["subject_ref"]:
            coordinator.set_restriction(guest.key, until)


async def resolve_appeal(staff_id: str, decision_ref: str, outcome: str, reason: str) -> dict:
    if outcome not in ("upheld", "overturned"):
        raise invalid("outcome", "Choose upheld or overturned.")
    async with db.transaction() as conn:
        decision = await (await conn.execute(
            "SELECT * FROM moderation_decisions WHERE public_ref = %s FOR UPDATE", (decision_ref,))).fetchone()
        if decision is None:
            raise not_found()
        if str(decision["staff_id"]) == str(staff_id):
            raise forbidden("Appeals need an independent reviewer; you made the original decision.")
        if decision["appeal_outcome"]:
            raise conflict("This appeal was already decided.", code="already_decided")
        await conn.execute("UPDATE moderation_decisions SET appeal_outcome = %s WHERE id = %s",
                           (outcome, decision["id"]))
        if outcome == "overturned":
            await conn.execute("UPDATE restrictions SET lifted_at = now() WHERE decision_id = %s AND lifted_at IS NULL",
                               (decision["id"],))
        if decision["case_id"]:
            await conn.execute(
                "INSERT INTO case_events (case_id, actor_ref, kind, new_value, reason) VALUES (%s, %s, 'appeal_decided', %s, %s)",
                (decision["case_id"], f"staff:{staff_id}", outcome, reason[:200]))
    if outcome == "overturned":
        subject_account = await db.fetch_one("SELECT subject_account_id FROM reports WHERE id = %s",
                                             (decision["report_id"],)) if decision["report_id"] else None
        if subject_account and subject_account["subject_account_id"]:
            coordinator.set_restriction(f"a:{subject_account['subject_account_id']}", None)
    return {"decision_ref": decision_ref, "appeal_outcome": outcome}
