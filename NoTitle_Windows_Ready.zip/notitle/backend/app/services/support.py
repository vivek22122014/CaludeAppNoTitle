"""Chat with Moderator: durable, encrypted support cases (blueprint chapters 16, 28, 29).

Support is the intentional exception to temporary chat: subjects and messages
are AES-GCM encrypted with a per-case data key; staff content reads are
audited *before* plaintext is returned; internal notes never join public
history.  Every message has a client nonce: identical retries return the
committed sequence, conflicting retries return 409.
"""

from __future__ import annotations

import json
import re
from datetime import datetime, timedelta, timezone
from typing import Any

import psycopg

from app import db
from app.config import BACKEND_DIR
from app.http.errors import ApiError, conflict, invalid, not_found
from app.security import crypto
from app.services import audit, keys
from app.services.analytics import record_exact

SUBJECT_MAX = 120
BODY_MAX = 4000
BODY_BYTES = 8192
MESSAGE_CAP = 1000
REOPEN_WINDOW = timedelta(days=30)
URGENT_REASONS = {"threats", "underage", "sexual_misconduct", "doxxing"}
_EMAILISH = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
_SECRET_REQUEST = re.compile(r"\b(password|recovery code|otp|cvv|card number|upi pin)\b", re.I)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def check_subject(subject: str) -> str:
    subject = subject.strip()
    if not 1 <= len(subject) <= SUBJECT_MAX:
        raise invalid("subject", f"Subject must be 1–{SUBJECT_MAX} characters.")
    return subject


def check_body(body: str, field: str = "body") -> str:
    if not body.strip():
        raise invalid(field, "Message cannot be empty.")
    if len(body) > BODY_MAX or len(body.encode("utf-8")) > BODY_BYTES:
        raise invalid(field, f"Message must be at most {BODY_MAX} characters.")
    return body


def _legal_rules() -> list[dict]:
    path = BACKEND_DIR / "policies" / "legal_rules.json"
    return json.loads(path.read_text(encoding="utf-8"))["rules"]


async def _create_obligations(conn: Any, case_id: str, category: str, urgent: bool, received_at: datetime) -> None:
    wanted = f"{category}:urgent" if urgent and category == "safety" else category
    for rule in _legal_rules():
        if wanted in rule["categories"]:
            await conn.execute(
                """INSERT INTO case_obligations (case_id, rule_id, rule_version, received_at, acknowledge_by, act_by)
                   VALUES (%s, %s, %s, %s, %s, %s)""",
                (case_id, rule["id"], rule["version"], received_at,
                 received_at + timedelta(seconds=rule["acknowledge_seconds"]),
                 received_at + timedelta(seconds=rule["act_seconds"])),
            )


def _aad(case_id: Any, field: str, extra: str = "") -> str:
    return f"support_cases|{case_id}|{field}|{extra}"


async def create_case(conn: Any, *, account_id: str | None, category: str, subject: str, body: str,
                      client_nonce: str, case_ref: str | None = None, receipt_secret: str | None = None,
                      urgent: bool = False, related_ref: str | None = None, parent_case_id: str | None = None,
                      sender_kind: str = "user") -> dict:
    subject = check_subject(subject)
    body = check_body(body)
    key = await keys.new_key(conn, "support")
    ref = case_ref or crypto.new_ref("cs")
    row = await (await conn.execute(
        """INSERT INTO support_cases (public_ref, account_id, category, subject_ct, key_id, urgent, related_ref,
                                      parent_case_id, last_sequence, seen_user_sequence, version)
           VALUES (%s, %s, %s, '\\x00'::bytea, %s, %s, %s, %s, 1, %s, 1) RETURNING id, created_at""",
        (ref, account_id, category, key.id, urgent, related_ref, parent_case_id, 1 if sender_kind == "user" else 0),
    )).fetchone()
    case_id = str(row["id"])
    await conn.execute("UPDATE support_cases SET subject_ct = %s WHERE id = %s",
                       (key.encrypt(subject, _aad(case_id, "subject")), case_id))
    await conn.execute(
        """INSERT INTO case_messages (case_id, sequence, sender_kind, sender_ref, body_ct, client_nonce, payload_digest)
           VALUES (%s, 1, %s, %s, %s, %s, %s)""",
        (case_id, sender_kind, None, key.encrypt(body, _aad(case_id, "message", "1")), client_nonce,
         crypto.payload_digest({"body": body}, purpose="case-message")),
    )
    await conn.execute("INSERT INTO case_events (case_id, actor_ref, kind, new_value) VALUES (%s, 'user', 'created', 'open')",
                       (case_id,))
    if parent_case_id:
        # Continuations inherit the root case's obligation clocks.
        await conn.execute(
            """INSERT INTO case_obligations (case_id, rule_id, rule_version, received_at, acknowledge_by, act_by,
                                             acknowledged_at, status)
               SELECT %s, rule_id, rule_version, received_at, acknowledge_by, act_by, acknowledged_at, status
               FROM case_obligations WHERE case_id = %s AND status <> 'completed'""",
            (case_id, parent_case_id))
    else:
        await _create_obligations(conn, case_id, category, urgent, row["created_at"])
    if receipt_secret:
        await conn.execute(
            "INSERT INTO scoped_receipts (public_ref, kind, scope_ref, verifier) VALUES (%s, 'case', %s, %s)",
            (ref, case_id, crypto.code_verifier(receipt_secret, "case-receipt")),
        )
    await record_exact("support_created", 1, conn=conn)
    return {"case_id": case_id, "case_ref": ref, "sequence": 1, "status": "open", "version": 1,
            "created_at": row["created_at"].isoformat()}


# ---------------------------------------------------------------------------
# Access (account owner or exact receipt session)
# ---------------------------------------------------------------------------

SUPPORT_IDLE = timedelta(minutes=30)
SUPPORT_ABSOLUTE = timedelta(hours=24)


async def open_receipt_session(kind: str, reference: str, secret: str) -> str:
    row = await db.fetch_one(
        "SELECT id, verifier FROM scoped_receipts WHERE public_ref = %s AND kind = %s AND revoked_at IS NULL",
        (reference.strip(), kind),
    )
    supplied = crypto.code_verifier(secret, f"{kind}-receipt")
    if row is None or not crypto.constant_equals(bytes(row["verifier"]), supplied):
        raise ApiError(401, "invalid_receipt", "Reference or secret is incorrect.")
    token = crypto.new_token()
    now = _now()
    await db.execute(
        """INSERT INTO scoped_sessions (receipt_id, token_hmac, expires_at, absolute_expires_at)
           VALUES (%s, %s, %s, %s)""",
        (row["id"], crypto.token_verifier(token, "scoped-session"), now + SUPPORT_IDLE, now + SUPPORT_ABSOLUTE),
    )
    return token


async def receipt_scope(token: str | None, kind: str) -> dict | None:
    if not token:
        return None
    row = await db.fetch_one(
        """SELECT s.id AS session_id, s.expires_at, s.absolute_expires_at, r.scope_ref, r.public_ref, r.kind
           FROM scoped_sessions s JOIN scoped_receipts r ON r.id = s.receipt_id
           WHERE s.token_hmac = %s AND s.revoked_at IS NULL AND r.revoked_at IS NULL AND r.kind = %s""",
        (crypto.token_verifier(token, "scoped-session"), kind),
    )
    now = _now()
    if row is None or row["expires_at"] < now or row["absolute_expires_at"] < now:
        return None
    await db.execute("UPDATE scoped_sessions SET last_active_at = %s, expires_at = least(%s, absolute_expires_at) WHERE id = %s",
                     (now, now + SUPPORT_IDLE, row["session_id"]))
    return row


async def authorize_case(case_ref: str, account_id: str | None, support_token: str | None) -> dict:
    case = await db.fetch_one("SELECT * FROM support_cases WHERE public_ref = %s", (case_ref,))
    if case is None:
        raise not_found()
    if account_id and case["account_id"] and str(case["account_id"]) == account_id:
        return case
    scope = await receipt_scope(support_token, "case")
    if scope and scope["scope_ref"] == str(case["id"]):
        return case
    raise not_found()  # identical shape for unknown and inaccessible


async def case_dto(case: dict, viewer: str = "user") -> dict:
    key = await keys.get_key(case["key_id"])
    obligations = await db.fetch_all(
        "SELECT rule_id, acknowledge_by, act_by, status, acknowledged_at FROM case_obligations WHERE case_id = %s",
        (case["id"],))
    unread = case["last_sequence"] - (case["seen_user_sequence"] if viewer == "user" else case["seen_staff_sequence"])
    return {
        "case_ref": case["public_ref"],
        "category": case["category"],
        "subject": key.decrypt(bytes(case["subject_ct"]), _aad(case["id"], "subject")),
        "status": case["status"],
        "version": case["version"],
        "last_sequence": case["last_sequence"],
        "seen_user_sequence": case["seen_user_sequence"],
        "seen_staff_sequence": case["seen_staff_sequence"],
        "staff_seen": case["seen_staff_sequence"] > 0,
        "unread": max(0, unread),
        "created_at": case["created_at"].isoformat(),
        "updated_at": case["updated_at"].isoformat(),
        "closed_at": case["closed_at"].isoformat() if case["closed_at"] else None,
        "reopen_until": (case["closed_at"] + REOPEN_WINDOW).isoformat() if case["closed_at"] else None,
        "obligation_status": "on_track" if all(o["status"] != "overdue" for o in obligations) else "under_review",
    }


async def list_cases(account_id: str, cursor: str | None, limit: int) -> dict:
    limit = max(1, min(limit, 20))
    params: list = [account_id]
    where = ""
    if cursor:
        where = "AND updated_at < %s"
        params.append(cursor)
    params.append(limit + 1)
    rows = await db.fetch_all(
        f"""SELECT * FROM support_cases WHERE account_id = %s {where} ORDER BY updated_at DESC LIMIT %s""", params)
    items = [await case_dto(r) for r in rows[:limit]]
    return {"items": items, "next_cursor": rows[limit - 1]["updated_at"].isoformat() if len(rows) > limit else None}


async def messages(case: dict, after: int, before: int | None, limit: int, viewer: str) -> dict:
    limit = max(1, min(limit, 50))
    if before is not None:
        rows = await db.fetch_all(
            """SELECT * FROM (SELECT * FROM case_messages WHERE case_id = %s AND sequence < %s
               ORDER BY sequence DESC LIMIT %s) t ORDER BY sequence""", (case["id"], before, limit))
    else:
        rows = await db.fetch_all(
            "SELECT * FROM case_messages WHERE case_id = %s AND sequence > %s ORDER BY sequence LIMIT %s",
            (case["id"], after, limit))
    key = await keys.get_key(case["key_id"])
    items = []
    for r in rows:
        if viewer == "user":
            role = "You" if r["sender_kind"] == "user" else "Moderator" if r["sender_kind"] == "staff" else "NoTitle"
        else:
            role = "User" if r["sender_kind"] == "user" else "Staff" if r["sender_kind"] == "staff" else "System"
        items.append({
            "sequence": r["sequence"],
            "sender_kind": r["sender_kind"],
            "display_role": role,
            "body": key.decrypt(bytes(r["body_ct"]), _aad(case["id"], "message", str(r["sequence"]))),
            "created_at": r["created_at"].isoformat(),
        })
    more = len(rows) == limit
    return {"items": items, "high_water_sequence": case["last_sequence"],
            "next_after": items[-1]["sequence"] if items and more and before is None else None}


async def post_message(case_ref: str, *, sender_kind: str, sender_ref: str | None, body: str, client_nonce: str,
                       staff_check: Any = None) -> tuple[dict, bool]:
    """Returns (result, created).  Commits before the caller may say Sent."""
    body = check_body(body)
    digest = crypto.payload_digest({"body": body}, purpose="case-message")
    if sender_kind == "staff":
        if _EMAILISH.search(body):
            raise invalid("body", "Staff replies cannot include email addresses.")
        if _SECRET_REQUEST.search(body) and "never" not in body.lower():
            raise invalid("body", "Do not ask users for passwords, recovery codes or payment secrets.")
    async with db.transaction() as conn:
        case = await (await conn.execute("SELECT * FROM support_cases WHERE public_ref = %s FOR UPDATE",
                                         (case_ref,))).fetchone()
        if case is None:
            raise not_found()
        existing = await (await conn.execute(
            "SELECT sequence, payload_digest, created_at FROM case_messages WHERE case_id = %s AND sender_kind = %s AND client_nonce = %s",
            (case["id"], sender_kind, client_nonce))).fetchone()
        if existing:
            if bytes(existing["payload_digest"]) != digest:
                raise conflict("This message id was already used for different text.", code="nonce_conflict")
            return {"sequence": existing["sequence"], "created_at": existing["created_at"].isoformat(),
                    "status": "sent"}, False
        if case["status"] == "closed":
            raise conflict("This case is closed. Reopen it or start a linked continuation.", code="case_closed")
        if case["last_sequence"] >= MESSAGE_CAP:
            raise conflict("This case reached its message limit. Start a linked continuation.",
                           code="continuation_required")
        if staff_check:
            await staff_check(conn, case)
        seq = case["last_sequence"] + 1
        key = await keys.get_key(case["key_id"], conn=conn)
        row = await (await conn.execute(
            """INSERT INTO case_messages (case_id, sequence, sender_kind, sender_ref, body_ct, client_nonce, payload_digest)
               VALUES (%s, %s, %s, %s, %s, %s, %s) RETURNING created_at""",
            (case["id"], seq, sender_kind, sender_ref, key.encrypt(body, _aad(case["id"], "message", str(seq))),
             client_nonce, digest))).fetchone()
        new_status = case["status"]
        if sender_kind == "user" and case["status"] in ("resolved", "waiting_user"):
            new_status = "open" if case["status"] == "resolved" else "in_progress"
        await conn.execute(
            """UPDATE support_cases SET last_sequence = %s, version = version + 1, status = %s, updated_at = now(),
                      seen_user_sequence = CASE WHEN %s = 'user' THEN %s ELSE seen_user_sequence END,
                      seen_staff_sequence = CASE WHEN %s = 'staff' THEN %s ELSE seen_staff_sequence END
               WHERE id = %s""",
            (seq, new_status, sender_kind, seq, sender_kind, seq, case["id"]))
        if sender_kind == "staff":
            # First moderator reply acknowledges open clocks.
            await conn.execute(
                """UPDATE case_obligations SET acknowledged_at = now(), status = CASE WHEN status = 'open' THEN 'acknowledged' ELSE status END
                   WHERE case_id = %s AND acknowledged_at IS NULL""", (case["id"],))
            await record_exact("support_replies", 1, conn=conn)
    return {"sequence": seq, "created_at": row["created_at"].isoformat(), "status": "sent"}, True


async def mark_seen(case: dict, seen_through: int, viewer: str) -> int:
    if seen_through < 0 or seen_through > case["last_sequence"]:
        raise invalid("seen_through", "Cannot mark unseen future messages.")
    column = "seen_user_sequence" if viewer == "user" else "seen_staff_sequence"
    row = await db.fetch_one(
        f"UPDATE support_cases SET {column} = greatest({column}, %s) WHERE id = %s RETURNING {column} AS seen",
        (seen_through, case["id"]))
    return row["seen"]


async def reopen(case: dict, expected_version: int, reason: str) -> dict:
    if case["status"] != "closed":
        raise conflict("The case is not closed.", code="not_closed")
    if case["closed_at"] and _now() - case["closed_at"] > REOPEN_WINDOW:
        raise conflict("Cases can be reopened within 30 days. Start a linked continuation.",
                       code="continuation_required")
    async with db.transaction() as conn:
        row = await (await conn.execute(
            """UPDATE support_cases SET status = 'open', closed_at = NULL, version = version + 1, updated_at = now()
               WHERE id = %s AND version = %s AND status = 'closed' RETURNING version""",
            (case["id"], expected_version))).fetchone()
        if row is None:
            raise conflict("The case changed. Reload and try again.", code="stale_version")
        await conn.execute(
            "INSERT INTO case_events (case_id, actor_ref, kind, old_value, new_value, reason) VALUES (%s, 'user', 'reopened', 'closed', 'open', %s)",
            (case["id"], reason[:200]))
    return {"status": "open", "version": row["version"]}


# ---------------------------------------------------------------------------
# Staff side
# ---------------------------------------------------------------------------

STAFF_STATUSES = ("open", "in_progress", "waiting_user", "resolved", "closed")


async def staff_queue(status: str | None, category: str | None, assigned: str | None, staff_id: str,
                      cursor: str | None, limit: int) -> dict:
    limit = max(1, min(limit, 50))
    clauses, params = [], []
    if status:
        clauses.append("c.status = %s")
        params.append(status)
    if category:
        clauses.append("c.category = %s")
        params.append(category)
    if assigned == "me":
        clauses.append("c.assigned_staff_id = %s")
        params.append(staff_id)
    elif assigned == "unassigned":
        clauses.append("c.assigned_staff_id IS NULL")
    if cursor:
        clauses.append("c.updated_at < %s")
        params.append(cursor)
    where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
    params.append(limit + 1)
    rows = await db.fetch_all(
        f"""SELECT c.public_ref, c.category, c.status, c.urgent, c.version, c.last_sequence, c.seen_staff_sequence,
                   c.updated_at, c.created_at, s.username AS assigned_to,
                   (SELECT min(act_by) FROM case_obligations o WHERE o.case_id = c.id AND o.status <> 'completed') AS due_at,
                   (SELECT bool_or(o.status = 'overdue') FROM case_obligations o WHERE o.case_id = c.id) AS overdue
            FROM support_cases c LEFT JOIN staff_accounts s ON s.id = c.assigned_staff_id
            {where} ORDER BY c.urgent DESC, c.updated_at DESC LIMIT %s""", params)
    items = [{
        "case_ref": r["public_ref"], "category": r["category"], "status": r["status"], "urgent": r["urgent"],
        "version": r["version"], "unread": max(0, r["last_sequence"] - r["seen_staff_sequence"]),
        "assigned_to": r["assigned_to"], "updated_at": r["updated_at"].isoformat(),
        "created_at": r["created_at"].isoformat(),
        "due_at": r["due_at"].isoformat() if r["due_at"] else None, "overdue": bool(r["overdue"]),
    } for r in rows[:limit]]
    return {"items": items, "next_cursor": rows[limit - 1]["updated_at"].isoformat() if len(rows) > limit else None}


async def staff_case_summary(case_ref: str) -> dict:
    case = await db.fetch_one("SELECT * FROM support_cases WHERE public_ref = %s", (case_ref,))
    if case is None:
        raise not_found()
    obligations = await db.fetch_all(
        """SELECT id, rule_id, rule_version, received_at, acknowledge_by, act_by, acknowledged_at, status, completed_at, outcome
           FROM case_obligations WHERE case_id = %s ORDER BY act_by""", (case["id"],))
    assigned = None
    if case["assigned_staff_id"]:
        s = await db.fetch_one("SELECT username FROM staff_accounts WHERE id = %s", (case["assigned_staff_id"],))
        assigned = s["username"] if s else None
    report = await db.fetch_one("SELECT public_ref, reason, evidence_state, blocked FROM reports WHERE case_id = %s",
                                (case["id"],))
    events = await db.fetch_all(
        "SELECT actor_ref, kind, old_value, new_value, reason, created_at FROM case_events WHERE case_id = %s ORDER BY id DESC LIMIT 50",
        (case["id"],))
    return {
        "case": case,
        "summary": {
            "case_ref": case["public_ref"], "category": case["category"], "status": case["status"],
            "urgent": case["urgent"], "version": case["version"], "assigned_to": assigned,
            "account_owned": case["account_id"] is not None, "last_sequence": case["last_sequence"],
            "seen_staff_sequence": case["seen_staff_sequence"], "related_ref": case["related_ref"],
            "created_at": case["created_at"].isoformat(), "updated_at": case["updated_at"].isoformat(),
            "closed_at": case["closed_at"].isoformat() if case["closed_at"] else None,
            "report": report,
            "obligations": [{**o, "id": str(o["id"]),
                             **{k: (o[k].isoformat() if o[k] else None) for k in
                                ("received_at", "acknowledge_by", "act_by", "acknowledged_at", "completed_at")}}
                            for o in obligations],
            "events": [{**e, "created_at": e["created_at"].isoformat()} for e in events],
        },
    }


async def staff_claim(case_ref: str, staff_id: str, expected_version: int) -> dict:
    async with db.transaction() as conn:
        row = await (await conn.execute(
            """UPDATE support_cases SET assigned_staff_id = %s, version = version + 1, updated_at = now(),
                      status = CASE WHEN status = 'open' THEN 'in_progress' ELSE status END
               WHERE public_ref = %s AND version = %s AND assigned_staff_id IS NULL RETURNING id, version""",
            (staff_id, case_ref, expected_version))).fetchone()
        if row is None:
            latest = await (await conn.execute(
                "SELECT c.version, s.username FROM support_cases c LEFT JOIN staff_accounts s ON s.id = c.assigned_staff_id WHERE c.public_ref = %s",
                (case_ref,))).fetchone()
            if latest is None:
                raise not_found()
            raise conflict("Someone else changed this case.", code="stale_version",
                           version=latest["version"], assigned_to=latest["username"])
        await conn.execute("INSERT INTO case_events (case_id, actor_ref, kind, new_value) VALUES (%s, %s, 'claimed', %s)",
                           (row["id"], f"staff:{staff_id}", staff_id))
    return {"version": row["version"], "assigned_to_me": True}


async def staff_assign(case_ref: str, actor_id: str, target_username: str | None, expected_version: int,
                       reason: str) -> dict:
    target_id = None
    if target_username:
        target = await db.fetch_one("SELECT id FROM staff_accounts WHERE username = %s AND status = 'active'",
                                    (target_username,))
        if target is None:
            raise invalid("staff_username", "Unknown staff member.")
        target_id = target["id"]
    async with db.transaction() as conn:
        row = await (await conn.execute(
            """UPDATE support_cases SET assigned_staff_id = %s, version = version + 1, updated_at = now()
               WHERE public_ref = %s AND version = %s RETURNING id, version""",
            (target_id, case_ref, expected_version))).fetchone()
        if row is None:
            raise conflict("The case changed. Reload and try again.", code="stale_version")
        await conn.execute(
            "INSERT INTO case_events (case_id, actor_ref, kind, new_value, reason) VALUES (%s, %s, 'assigned', %s, %s)",
            (row["id"], f"staff:{actor_id}", target_username or "unassigned", reason[:200]))
    return {"version": row["version"]}


async def staff_status(case_ref: str, actor_id: str, target: str, expected_version: int, reason: str) -> dict:
    if target not in STAFF_STATUSES:
        raise invalid("target_status", "Unknown status.")
    async with db.transaction() as conn:
        case = await (await conn.execute("SELECT * FROM support_cases WHERE public_ref = %s FOR UPDATE",
                                         (case_ref,))).fetchone()
        if case is None:
            raise not_found()
        if case["version"] != expected_version:
            raise conflict("The case changed. Reload and try again.", code="stale_version", version=case["version"])
        if target == "closed":
            pending = await (await conn.execute(
                "SELECT count(*) AS n FROM case_obligations WHERE case_id = %s AND status <> 'completed'",
                (case["id"],))).fetchone()
            if pending["n"]:
                raise conflict("Complete the case obligations before closing it.", code="obligations_open")
        row = await (await conn.execute(
            """UPDATE support_cases SET status = %s, version = version + 1, updated_at = now(),
                      closed_at = CASE WHEN %s = 'closed' THEN now() ELSE NULL END
               WHERE id = %s RETURNING version""", (target, target, case["id"]))).fetchone()
        await conn.execute(
            "INSERT INTO case_events (case_id, actor_ref, kind, old_value, new_value, reason) VALUES (%s, %s, 'status', %s, %s, %s)",
            (case["id"], f"staff:{actor_id}", case["status"], target, reason[:200]))
    return {"status": target, "version": row["version"]}


async def staff_notes(case_id: Any, key_id: Any) -> list[dict]:
    key = await keys.get_key(key_id)
    rows = await db.fetch_all(
        """SELECT n.id, n.body_ct, n.created_at, s.username FROM case_internal_notes n
           JOIN staff_accounts s ON s.id = n.staff_id WHERE n.case_id = %s ORDER BY n.created_at""", (case_id,))
    return [{"note_id": str(r["id"]), "author": r["username"], "created_at": r["created_at"].isoformat(),
             "body": key.decrypt(bytes(r["body_ct"]), _aad(case_id, "note", str(r["id"])))} for r in rows]


async def staff_add_note(case: dict, staff_id: str, body: str) -> dict:
    body = check_body(body)
    key = await keys.get_key(case["key_id"])
    async with db.transaction() as conn:
        row = await (await conn.execute(
            "INSERT INTO case_internal_notes (case_id, staff_id, body_ct) VALUES (%s, %s, '\\x00'::bytea) RETURNING id, created_at",
            (case["id"], staff_id))).fetchone()
        await conn.execute("UPDATE case_internal_notes SET body_ct = %s WHERE id = %s",
                           (key.encrypt(body, _aad(case["id"], "note", str(row["id"]))), row["id"]))
    return {"note_id": str(row["id"]), "created_at": row["created_at"].isoformat()}


async def complete_obligation(case: dict, obligation_id: str, staff_id: str, outcome: str, evidence_ref: str) -> dict:
    try:
        row = await db.fetch_one(
            """UPDATE case_obligations SET status = 'completed', completed_at = now(), outcome = %s, evidence_ref = %s,
                      acknowledged_at = coalesce(acknowledged_at, now())
               WHERE id = %s AND case_id = %s AND status <> 'completed' RETURNING id""",
            (outcome[:200], evidence_ref[:200], obligation_id, case["id"]))
    except psycopg.errors.InvalidTextRepresentation:
        row = None
    if row is None:
        raise not_found()
    await db.execute(
        "INSERT INTO case_events (case_id, actor_ref, kind, new_value, reason) VALUES (%s, %s, 'obligation_completed', %s, %s)",
        (case["id"], f"staff:{staff_id}", obligation_id, outcome[:200]))
    return {"completed": True}


async def audited_read(staff_id: str, purpose: str, object_type: str, object_ref: str, action: str) -> None:
    """The audit row must commit before plaintext is returned; failure denies access."""
    try:
        await audit.record(f"staff:{staff_id}", purpose, object_type, object_ref, action)
    except Exception:  # noqa: BLE001
        raise ApiError(503, "audit_unavailable", "Content access is unavailable because auditing failed.",
                       retryable=True) from None

