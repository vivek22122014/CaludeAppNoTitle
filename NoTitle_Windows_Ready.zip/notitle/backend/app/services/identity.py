"""Identity: guests (RAM), accounts (PostgreSQL), sessions, recovery and consent.

Blueprint chapters 10, 20 and 21.  Highlights:

* Guests live only in memory (30 min idle / 24 h absolute) and vanish on restart.
* Account sessions are opaque 256-bit tokens; only keyed HMAC verifiers are stored.
* At most five account sessions; a sixth valid login gets a short-lived
  challenge that can only revoke-one-and-create-one.
* Registration and recovery use *prepared* secrets: the code is shown first,
  the user confirms it was saved, then the account change commits.
* Login errors are generic and take equal time for unknown usernames.
"""

from __future__ import annotations

import secrets
import time
import unicodedata
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any

from app import db
from app import policies as policy_registry
from app.catalogs import GENDERS, GENERAL_TOPIC, TOPIC_IDS
from app.http.errors import ApiError, conflict, gone, invalid, unauthenticated
from app.security import crypto
from app.security.passwords import hash_password, validate_password, verify_password

GUEST_IDLE = 30 * 60
GUEST_ABSOLUTE = 24 * 3600
ACCOUNT_IDLE = timedelta(days=7)
ACCOUNT_ABSOLUTE = timedelta(days=30)
REAUTH_WINDOW = timedelta(minutes=5)
MAX_SESSIONS = 5
PREPARE_TTL = 600
PREPARE_GLOBAL = 512
PREPARE_PER_SCOPE = 4
CHALLENGE_TTL = 300
RESERVED_NAMES = {"admin", "administrator", "staff", "moderator", "mod", "support", "notitle", "system",
                  "root", "owner", "help", "official", "security", "billing", "privacy", "grievance"}
DECEPTIVE = ("moderator", "admin", "staff", "notitle", "official", "support team")


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


def normalize_username(value: str) -> str:
    username = value.strip().lower()
    import re

    if not re.fullmatch(r"[a-z0-9_-]{4,24}", username):
        raise invalid("username", "Use 4–24 lowercase letters, numbers, - or _.")
    if username in RESERVED_NAMES or username.startswith("deleted_"):
        raise invalid("username", "That username is reserved. Choose another.")
    return username


def clean_display_name(value: str) -> str:
    name = unicodedata.normalize("NFC", value.strip())
    if not 2 <= len(name) <= 24:
        raise invalid("display_name", "Display name must be 2–24 characters.")
    if any(unicodedata.category(ch).startswith("C") for ch in name):
        raise invalid("display_name", "Display name contains unsupported characters.")
    lowered = name.lower()
    if any(word in lowered for word in DECEPTIVE):
        raise invalid("display_name", "Display names cannot imitate staff or the service.")
    return name


def clean_bio(value: str) -> str:
    bio = unicodedata.normalize("NFC", value.strip())
    if len(bio) > 160:
        raise invalid("bio", "Bio must be at most 160 characters.")
    if any(unicodedata.category(ch) == "Cc" and ch not in "\n" for ch in bio):
        raise invalid("bio", "Bio contains unsupported characters.")
    return bio


def check_gender(value: str) -> str:
    if value not in GENDERS:
        raise invalid("gender", "Choose Male, Female or Other.")
    return value


def check_topic(value: str) -> str:
    if value not in TOPIC_IDS:
        raise invalid("topic_id", "Choose a topic from the list.")
    return value


def check_password(field_name: str, value: str) -> None:
    problem = validate_password(value)
    if problem:
        raise invalid(field_name, problem)


def subject_ref_for_account(account_id: str) -> str:
    return "subj_" + crypto.b64u(crypto.hmac_digest(str(account_id), purpose="subject"))[:32]


def subject_ref_for_guest(guest_id: str) -> str:
    return "gsubj_" + crypto.b64u(crypto.hmac_digest(guest_id, purpose="guest-subject"))[:32]


# ---------------------------------------------------------------------------
# Consent
# ---------------------------------------------------------------------------


def validate_consents(consents: dict[str, bool], versions: dict[str, str]) -> dict[str, dict]:
    """Return proof records; raise 409 with the current versions on a policy change."""
    current = policy_registry.current_versions()
    changed = {k: current[k] for k in ("terms", "privacy") if versions.get(k) != current.get(k)}
    if changed:
        raise conflict("A policy changed while you were reading. Please review and accept the current version.",
                       code="policy_changed", current_versions=current)
    for purpose in policy_registry.REQUIRED_PURPOSES:
        if consents.get(purpose) is not True:
            raise invalid(f"consents.{purpose}", "This confirmation is required to continue.")
    proof = {}
    for purpose in ("adult", "terms", "core", "professional"):
        kind = policy_registry.CONSENT_POLICY[purpose]
        policy = policy_registry.get(kind)
        proof[purpose] = {
            "choice": bool(consents.get(purpose, False)),
            "policy_kind": kind,
            "policy_version": policy.version,
            "text_digest": policy.digest,
            "recorded_at": now_utc().isoformat(),
        }
    return proof


async def ensure_policy_rows(conn: Any) -> None:
    for policy in policy_registry.all_policies().values():
        await conn.execute(
            """INSERT INTO policy_versions (kind, version, content_sha256, publication_state)
               VALUES (%s, %s, %s, %s) ON CONFLICT (kind, version) DO NOTHING""",
            (policy.kind, policy.version, policy.digest, policy.state),
        )


async def record_consents(conn: Any, account_id: str | None, subject_ref: str, proof: dict[str, dict]) -> None:
    await ensure_policy_rows(conn)
    for purpose, item in proof.items():
        await conn.execute(
            """INSERT INTO consent_records (account_id, subject_ref, purpose, choice, policy_kind, policy_version, text_digest)
               VALUES (%s, %s, %s, %s, %s, %s, %s)""",
            (account_id, subject_ref, purpose, item["choice"], item["policy_kind"], item["policy_version"],
             item["text_digest"]),
        )


async def current_consents(account_id: str) -> dict[str, dict]:
    rows = await db.fetch_all(
        """SELECT DISTINCT ON (purpose) purpose, choice, policy_version, recorded_at
           FROM consent_records WHERE account_id = %s ORDER BY purpose, recorded_at DESC, id DESC""",
        (account_id,),
    )
    return {r["purpose"]: {"choice": r["choice"], "policy_version": r["policy_version"],
                           "recorded_at": r["recorded_at"].isoformat()} for r in rows}


# ---------------------------------------------------------------------------
# Guests (memory only)
# ---------------------------------------------------------------------------

_ADJECTIVES = ["Calm", "Bright", "Quiet", "Steady", "Clever", "Kind", "Brave", "Swift", "Gentle", "Keen",
               "Bold", "Merry", "Witty", "Sunny", "Lucid", "Noble", "Plucky", "Sage", "Vivid", "Zesty"]
_NOUNS = ["Otter", "Falcon", "Maple", "Comet", "Harbor", "Lynx", "Cedar", "Robin", "Pebble", "Orchid",
          "Badger", "Heron", "Willow", "Quartz", "Panda", "Tiger", "Lotus", "Koala", "Raven", "Bison"]


def generate_pseudonym() -> str:
    return f"{secrets.choice(_ADJECTIVES)}{secrets.choice(_NOUNS)}{secrets.randbelow(90) + 10}"


@dataclass
class Guest:
    id: str
    token_hmac: bytes
    display_name: str
    gender: str
    topic_id: str
    consents: dict[str, dict]
    bio: str = ""
    professional: dict | None = None
    preferences: dict = field(default_factory=lambda: {"gender_preference": "everyone", "professional_enabled": True,
                                                        "industry_ids": [], "role_ids": [], "experience_ids": [],
                                                        "interest_ids": [], "topic_ids": []})
    profile_version: int = 1
    preference_version: int = 1
    created: float = field(default_factory=time.time)
    last_active: float = field(default_factory=time.time)

    @property
    def key(self) -> str:
        return f"g:{self.id}"

    @property
    def expires_at(self) -> float:
        return min(self.last_active + GUEST_IDLE, self.created + GUEST_ABSOLUTE)


class GuestRegistry:
    def __init__(self, capacity: int = 1000) -> None:
        self.capacity = capacity
        self.by_id: dict[str, Guest] = {}
        self.by_token: dict[bytes, str] = {}

    def create(self, gender: str, topic_id: str, consents: dict[str, dict], professional: dict | None) -> tuple[Guest, str]:
        self.sweep()
        if len(self.by_id) >= self.capacity:
            raise ApiError(503, "guest_capacity", "Guest entry is at capacity. Please try again later or register.",
                           retryable=True, retry_after=30)
        token = crypto.new_token()
        guest = Guest(
            id=uuid.uuid4().hex,
            token_hmac=crypto.token_verifier(token, "guest-session"),
            display_name=generate_pseudonym(),
            gender=gender,
            topic_id=topic_id,
            consents=consents,
            professional=professional if consents.get("professional", {}).get("choice") else None,
        )
        self.by_id[guest.id] = guest
        self.by_token[guest.token_hmac] = guest.id
        return guest, token

    def resolve(self, token: str | None, touch: bool = False) -> Guest | None:
        if not token:
            return None
        guest_id = self.by_token.get(crypto.token_verifier(token, "guest-session"))
        guest = self.by_id.get(guest_id) if guest_id else None
        if guest is None:
            return None
        if guest.expires_at < time.time():
            self.remove(guest.id)
            return None
        if touch and time.time() - guest.last_active > 60:
            guest.last_active = time.time()
        return guest

    def remove(self, guest_id: str) -> Guest | None:
        guest = self.by_id.pop(guest_id, None)
        if guest:
            self.by_token.pop(guest.token_hmac, None)
            from app.realtime.coordinator import coordinator

            coordinator.forget_guest(guest.key)
        return guest

    def touch(self, guest: Guest) -> None:
        guest.last_active = time.time()

    def sweep(self) -> int:
        now = time.time()
        expired = [g.id for g in self.by_id.values() if g.expires_at < now]
        for guest_id in expired:
            from app.realtime.coordinator import coordinator

            # A guest in a live conversation is kept until it ends.
            p = coordinator.participants.get(f"g:{guest_id}")
            if p and p.interaction_id:
                continue
            self.remove(guest_id)
        return len(expired)


guests = GuestRegistry()


# ---------------------------------------------------------------------------
# Prepared one-time secrets
# ---------------------------------------------------------------------------

PREFIXES = {"registration": None, "recovery": None, "recovery_rotation": None,
            "case_receipt": "cs", "deletion_receipt": "dl", "financial_receipt": "fr"}


@dataclass
class Prepared:
    id: str
    kind: str
    scope: str
    secret: str
    reference: str | None
    expires: float


class PreparedOperations:
    def __init__(self) -> None:
        self.items: dict[str, Prepared] = {}

    def _sweep(self) -> None:
        now = time.time()
        for rid, item in list(self.items.items()):
            if item.expires < now:
                del self.items[rid]

    def prepare(self, kind: str, scope: str) -> Prepared:
        if kind not in PREFIXES:
            raise invalid("kind", "Unknown preparation kind.")
        self._sweep()
        if len(self.items) >= PREPARE_GLOBAL:
            raise ApiError(503, "busy", "Too many pending preparations. Try again shortly.", retryable=True, retry_after=10)
        mine = [i for i in self.items.values() if i.scope == scope]
        if len(mine) >= PREPARE_PER_SCOPE:
            oldest = min(mine, key=lambda i: i.expires)
            del self.items[oldest.id]
        prefix = PREFIXES[kind]
        item = Prepared(
            id="prep_" + secrets.token_urlsafe(16),
            kind=kind,
            scope=scope,
            secret=crypto.new_secret_code(),
            reference=crypto.new_ref(prefix) if prefix else None,
            expires=time.time() + PREPARE_TTL,
        )
        self.items[item.id] = item
        return item

    def peek(self, reservation_id: str, scope: str, kind: str, secret: str) -> Prepared:
        item = self.items.get(reservation_id)
        if item is None or item.expires < time.time():
            raise gone()
        if item.scope != scope or item.kind != kind:
            raise gone()
        if not crypto.constant_equals(crypto.normalize_code(secret), crypto.normalize_code(item.secret)):
            raise invalid("secret", "The code you confirmed does not match the one shown. Copy it again.")
        return item

    def consume(self, reservation_id: str) -> None:
        self.items.pop(reservation_id, None)


prepared = PreparedOperations()


# ---------------------------------------------------------------------------
# Account sessions
# ---------------------------------------------------------------------------


async def create_session(conn: Any, account_id: str, auth_generation: int, reauth: bool = True) -> tuple[str, str]:
    token = crypto.new_token()
    now = now_utc()
    row = await (await conn.execute(
        """INSERT INTO account_sessions (account_id, token_hmac, auth_generation, expires_at, absolute_expires_at, reauth_at)
           VALUES (%s, %s, %s, %s, %s, %s) RETURNING id""",
        (account_id, crypto.token_verifier(token, "account-session"), auth_generation,
         now + ACCOUNT_IDLE, now + ACCOUNT_ABSOLUTE, now if reauth else None),
    )).fetchone()
    return token, str(row["id"])


async def resolve_session(token: str | None, touch: bool = True) -> dict | None:
    if not token:
        return None
    row = await db.fetch_one(
        """SELECT s.id AS session_id, s.auth_generation AS session_generation, s.expires_at, s.absolute_expires_at,
                  s.reauth_at, s.last_active_at, a.*
           FROM account_sessions s JOIN accounts a ON a.id = s.account_id
           WHERE s.token_hmac = %s AND s.revoked_at IS NULL""",
        (crypto.token_verifier(token, "account-session"),),
    )
    if row is None:
        return None
    now = now_utc()
    if (row["expires_at"] < now or row["absolute_expires_at"] < now
            or row["session_generation"] != row["auth_generation"] or row["status"] != "active"):
        return None
    if touch and (now - row["last_active_at"]).total_seconds() > 60:
        await db.execute(
            "UPDATE account_sessions SET last_active_at = %s, expires_at = least(%s, absolute_expires_at) WHERE id = %s",
            (now, now + ACCOUNT_IDLE, row["session_id"]),
        )
    return row


async def active_sessions(account_id: str, conn: Any = None) -> list[dict]:
    return await db.fetch_all(
        """SELECT s.id, s.created_at, s.last_active_at, s.expires_at FROM account_sessions s
           JOIN accounts a ON a.id = s.account_id
           WHERE s.account_id = %s AND s.revoked_at IS NULL AND s.expires_at > now()
             AND s.absolute_expires_at > now() AND s.auth_generation = a.auth_generation
           ORDER BY s.created_at""",
        (account_id,), conn=conn,
    )


@dataclass
class Challenge:
    id: str
    account_id: str
    boot: str
    auth_generation: int
    expires: float


class ChallengeStore:
    def __init__(self) -> None:
        self.items: dict[str, Challenge] = {}

    def create(self, account_id: str, boot: str, auth_generation: int) -> Challenge:
        now = time.time()
        for cid, item in list(self.items.items()):
            if item.expires < now or item.boot == boot:
                del self.items[cid]
        if len(self.items) >= 64:
            raise ApiError(503, "busy", "Please try signing in again shortly.", retryable=True, retry_after=10)
        challenge = Challenge("ch_" + secrets.token_urlsafe(16), account_id, boot, auth_generation, now + CHALLENGE_TTL)
        self.items[challenge.id] = challenge
        return challenge

    def get(self, challenge_id: str, boot: str) -> Challenge:
        item = self.items.get(challenge_id)
        if not item or item.expires < time.time() or item.boot != boot:
            raise gone("The sign-in choice expired. Sign in again.")
        return item

    def consume(self, challenge_id: str) -> None:
        self.items.pop(challenge_id, None)


challenges = ChallengeStore()


# ---------------------------------------------------------------------------
# Account operations
# ---------------------------------------------------------------------------


async def username_taken(username: str) -> bool:
    return await db.fetch_one("SELECT 1 FROM accounts WHERE username = %s", (username,)) is not None


async def register(*, boot: str, reservation_id: str, recovery_code: str, saved: bool, username: str,
                   password: str, display_name: str, gender: str, topic_id: str, consents: dict[str, bool],
                   policy_versions: dict[str, str], guest: Guest | None, professional: dict | None) -> dict:
    if not saved:
        raise invalid("saved", "Confirm that you saved your recovery code.")
    username = normalize_username(username)
    check_password("password", password)
    display_name = clean_display_name(display_name)
    check_gender(gender)
    check_topic(topic_id)
    proof = validate_consents(consents, policy_versions)
    prep = prepared.peek(reservation_id, boot, "registration", recovery_code)
    if await username_taken(username):
        raise invalid("username", "That username is not available.")
    password_hash = await hash_password(password)
    try:
        async with db.transaction() as conn:
            row = await (await conn.execute(
                """INSERT INTO accounts (username, password_hash, display_name, gender, topic_id)
                   VALUES (%s, %s, %s, %s, %s) RETURNING id, auth_generation""",
                (username, password_hash, display_name, gender, topic_id),
            )).fetchone()
            account_id = str(row["id"])
            await conn.execute(
                "INSERT INTO recovery_credentials (account_id, verifier) VALUES (%s, %s)",
                (account_id, crypto.code_verifier(prep.secret, "recovery-code")),
            )
            await conn.execute("INSERT INTO matching_preferences (account_id) VALUES (%s)", (account_id,))
            await record_consents(conn, account_id, subject_ref_for_account(account_id), proof)
            if proof["professional"]["choice"] and professional:
                await upsert_professional(conn, account_id, professional)
            token, session_id = await create_session(conn, account_id, row["auth_generation"])
            from app.services.analytics import record_exact

            await record_exact("registrations", 1, conn=conn)
    except Exception as exc:  # unique violation race
        import psycopg

        if isinstance(exc, psycopg.errors.UniqueViolation):
            raise invalid("username", "That username is not available.") from None
        raise
    prepared.consume(reservation_id)
    return {"account_id": account_id, "token": token, "session_id": session_id}


async def upsert_professional(conn: Any, account_id: str, prof: dict) -> None:
    await conn.execute(
        """INSERT INTO professional_profiles (account_id, industry_id, role_id, experience_id, interest_ids, topic_ids, updated_at)
           VALUES (%s, %s, %s, %s, %s, %s, now())
           ON CONFLICT (account_id) DO UPDATE SET industry_id = EXCLUDED.industry_id, role_id = EXCLUDED.role_id,
             experience_id = EXCLUDED.experience_id, interest_ids = EXCLUDED.interest_ids,
             topic_ids = EXCLUDED.topic_ids, updated_at = now()""",
        (account_id, prof.get("industry_id"), prof.get("role_id"), prof.get("experience_id"),
         prof.get("interest_ids") or [], prof.get("topic_ids") or []),
    )


async def authenticate(username: str, password: str) -> dict | None:
    try:
        username = username.strip().lower()
    except AttributeError:
        return None
    row = await db.fetch_one("SELECT * FROM accounts WHERE username = %s AND status = 'active'", (username,))
    valid, rehash = await verify_password(row["password_hash"] if row else None, password)
    if not valid or row is None:
        return None
    if rehash:
        await db.execute("UPDATE accounts SET password_hash = %s WHERE id = %s", (await hash_password(password), row["id"]))
    return row


async def login(*, boot: str, username: str, password: str) -> dict:
    account = await authenticate(username, password)
    if account is None:
        raise ApiError(401, "invalid_credentials", "Username or password is incorrect.")
    account_id = str(account["id"])
    async with db.transaction() as conn:
        await conn.execute("SELECT 1 FROM accounts WHERE id = %s FOR UPDATE", (account_id,))
        sessions = await active_sessions(account_id, conn=conn)
        if len(sessions) >= MAX_SESSIONS:
            challenge = challenges.create(account_id, boot, account["auth_generation"])
            raise conflict("You are signed in on five devices. Sign one out to continue.",
                           code="session_limit", challenge_id=challenge.id)
        token, session_id = await create_session(conn, account_id, account["auth_generation"])
    return {"account_id": account_id, "token": token, "session_id": session_id}


async def resolve_session_limit(*, boot: str, challenge_id: str, revoke_session_id: str) -> dict:
    challenge = challenges.get(challenge_id, boot)
    async with db.transaction() as conn:
        account = await (await conn.execute(
            "SELECT auth_generation, status FROM accounts WHERE id = %s FOR UPDATE", (challenge.account_id,))).fetchone()
        if not account or account["status"] != "active" or account["auth_generation"] != challenge.auth_generation:
            challenges.consume(challenge_id)
            raise gone("The sign-in choice expired. Sign in again.")
        revoked = await conn.execute(
            "UPDATE account_sessions SET revoked_at = now() WHERE id = %s AND account_id = %s AND revoked_at IS NULL",
            (revoke_session_id, challenge.account_id),
        )
        if revoked.rowcount != 1:
            raise invalid("session", "That session is no longer active.")
        sessions = await active_sessions(challenge.account_id, conn=conn)
        if len(sessions) >= MAX_SESSIONS:
            raise conflict("Still at the session limit.", code="session_limit", challenge_id=challenge_id)
        token, session_id = await create_session(conn, challenge.account_id, challenge.auth_generation)
    challenges.consume(challenge_id)
    return {"account_id": challenge.account_id, "token": token, "session_id": session_id}


async def recover(*, boot: str, username: str, old_code: str, new_password: str, reservation_id: str,
                  new_code: str, saved: bool) -> dict:
    if not saved:
        raise invalid("saved", "Confirm that you saved your new recovery code.")
    check_password("new_password", new_password)
    prep = prepared.peek(reservation_id, boot, "recovery", new_code)
    username = username.strip().lower()
    row = await db.fetch_one(
        """SELECT a.id, r.verifier FROM accounts a LEFT JOIN recovery_credentials r ON r.account_id = a.id
           WHERE a.username = %s AND a.status = 'active'""",
        (username,),
    )
    supplied = crypto.code_verifier(old_code, "recovery-code")
    if row is None or row["verifier"] is None or not crypto.constant_equals(bytes(row["verifier"]), supplied):
        await verify_password(None, new_password)  # equalise timing
        raise ApiError(401, "invalid_recovery", "Username or recovery code is incorrect.")
    password_hash = await hash_password(new_password)
    async with db.transaction() as conn:
        updated = await (await conn.execute(
            """UPDATE recovery_credentials SET verifier = %s, rotated_at = now()
               WHERE account_id = %s AND verifier = %s RETURNING account_id""",
            (crypto.code_verifier(prep.secret, "recovery-code"), row["id"], supplied),
        )).fetchone()
        if updated is None:  # concurrent recovery consumed the old code
            raise ApiError(401, "invalid_recovery", "Username or recovery code is incorrect.")
        acct = await (await conn.execute(
            """UPDATE accounts SET password_hash = %s, auth_generation = auth_generation + 1, updated_at = now()
               WHERE id = %s RETURNING auth_generation""",
            (password_hash, row["id"]),
        )).fetchone()
        await conn.execute("UPDATE account_sessions SET revoked_at = now() WHERE account_id = %s AND revoked_at IS NULL",
                           (row["id"],))
        token, session_id = await create_session(conn, str(row["id"]), acct["auth_generation"])
    prepared.consume(reservation_id)
    from app.realtime.coordinator import coordinator

    coordinator.end_identity(f"a:{row['id']}", "credentials_changed")
    return {"account_id": str(row["id"]), "token": token, "session_id": session_id}


def require_reauth(session_row: dict) -> None:
    reauth_at = session_row.get("reauth_at")
    if not reauth_at or now_utc() - reauth_at > REAUTH_WINDOW:
        raise ApiError(403, "reauth_required", "Please confirm your password to continue.")


async def reauth(session_row: dict, password: str) -> None:
    valid, _ = await verify_password(session_row["password_hash"], password)
    if not valid:
        raise ApiError(401, "invalid_credentials", "Password is incorrect.")
    await db.execute("UPDATE account_sessions SET reauth_at = now() WHERE id = %s", (session_row["session_id"],))


async def change_password(session_row: dict, current: str, new: str) -> dict:
    check_password("new_password", new)
    valid, _ = await verify_password(session_row["password_hash"], current)
    if not valid:
        raise invalid("current_password", "Current password is incorrect.")
    password_hash = await hash_password(new)
    account_id = str(session_row["id"])
    async with db.transaction() as conn:
        acct = await (await conn.execute(
            """UPDATE accounts SET password_hash = %s, auth_generation = auth_generation + 1, updated_at = now()
               WHERE id = %s RETURNING auth_generation""", (password_hash, account_id))).fetchone()
        await conn.execute("UPDATE account_sessions SET revoked_at = now() WHERE account_id = %s AND revoked_at IS NULL",
                           (account_id,))
        token, session_id = await create_session(conn, account_id, acct["auth_generation"])
    from app.realtime.coordinator import coordinator

    coordinator.end_identity(f"a:{account_id}", "credentials_changed")
    return {"token": token, "session_id": session_id}


async def rotate_recovery(session_row: dict, boot: str, reservation_id: str, code: str, saved: bool) -> None:
    require_reauth(session_row)
    if not saved:
        raise invalid("saved", "Confirm that you saved your new recovery code.")
    prep = prepared.peek(reservation_id, f"session:{session_row['session_id']}", "recovery_rotation", code)
    await db.execute(
        "UPDATE recovery_credentials SET verifier = %s, rotated_at = now() WHERE account_id = %s",
        (crypto.code_verifier(prep.secret, "recovery-code"), session_row["id"]),
    )
    prepared.consume(reservation_id)


async def logout(session_row: dict, everywhere: bool) -> None:
    account_id = str(session_row["id"])
    if everywhere:
        async with db.transaction() as conn:
            await conn.execute("UPDATE accounts SET auth_generation = auth_generation + 1 WHERE id = %s", (account_id,))
            await conn.execute("UPDATE account_sessions SET revoked_at = now() WHERE account_id = %s AND revoked_at IS NULL",
                               (account_id,))
    else:
        await db.execute("UPDATE account_sessions SET revoked_at = now() WHERE id = %s", (session_row["session_id"],))
    from app.realtime.coordinator import coordinator

    p = coordinator.participants.get(f"a:{account_id}")
    # Only this session's socket is known to the coordinator; logout-all fences every socket.
    if p and (everywhere or (p.conn and getattr(p.conn, "session_id", None) == str(session_row["session_id"]))):
        coordinator.end_identity(f"a:{account_id}", "logged_out")


# ---------------------------------------------------------------------------
# Owner DTOs
# ---------------------------------------------------------------------------


async def load_profile(account_id: str) -> dict:
    prefs = await db.fetch_one("SELECT * FROM matching_preferences WHERE account_id = %s", (account_id,))
    prof = await db.fetch_one("SELECT * FROM professional_profiles WHERE account_id = %s", (account_id,))
    return {
        "preferences": _prefs_dto(prefs) if prefs else _prefs_dto({}),
        "professional": _prof_dto(prof) if prof else None,
    }


def _prefs_dto(row: dict) -> dict:
    return {
        "gender_preference": row.get("gender_preference", "everyone"),
        "professional_enabled": row.get("professional_enabled", True),
        "industry_ids": list(row.get("industry_ids") or []),
        "role_ids": list(row.get("role_ids") or []),
        "experience_ids": list(row.get("experience_ids") or []),
        "interest_ids": list(row.get("interest_ids") or []),
        "topic_ids": list(row.get("topic_ids") or []),
        "version": row.get("version", 1),
    }


def _prof_dto(row: dict) -> dict:
    return {
        "industry_id": row.get("industry_id"),
        "role_id": row.get("role_id"),
        "experience_id": row.get("experience_id"),
        "interest_ids": list(row.get("interest_ids") or []),
        "topic_ids": list(row.get("topic_ids") or []),
    }


def effective_preferences(prefs: dict, premium: bool, topic_id: str, professional_consent: bool) -> dict:
    return {
        "gender_preference": prefs["gender_preference"] if premium else "everyone",
        "professional_relevance": bool(premium and prefs["professional_enabled"] and professional_consent
                                       and topic_id != GENERAL_TOPIC),
        "note": None if premium else "Free access always matches with Everyone; Premium enables a gender choice and very soft professional relevance.",
    }
