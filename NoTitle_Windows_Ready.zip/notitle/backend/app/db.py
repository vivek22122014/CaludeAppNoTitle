"""PostgreSQL access: one async connection pool plus small helpers.

All SQL is parameterised (psycopg placeholders); no string interpolation of
values ever reaches the database.  Rows are returned as dicts.
"""

from __future__ import annotations

import asyncio
import logging
import sys
import time
from contextlib import asynccontextmanager
from typing import Any, AsyncIterator

import psycopg
from psycopg.rows import dict_row
from psycopg_pool import AsyncConnectionPool

from app.config import get_settings

log = logging.getLogger("notitle.db")

_pool: AsyncConnectionPool | None = None


def ensure_selector_loop_policy() -> None:
    """psycopg async cannot run on Windows' default ProactorEventLoop."""
    if sys.platform == "win32":
        policy = asyncio.get_event_loop_policy()
        if not isinstance(policy, asyncio.WindowsSelectorEventLoopPolicy):  # type: ignore[attr-defined]
            asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())  # type: ignore[attr-defined]


async def _configure(conn: psycopg.AsyncConnection) -> None:
    settings = get_settings()
    await conn.execute(f"SET statement_timeout = {int(settings.db_statement_timeout_ms)}")
    await conn.execute("SET lock_timeout = 2000")
    await conn.execute("SET TIME ZONE 'UTC'")
    await conn.commit()


async def open_pool(url: str | None = None) -> AsyncConnectionPool:
    global _pool
    if _pool is not None:
        return _pool
    settings = get_settings()
    pool = AsyncConnectionPool(
        conninfo=url or settings.database_url,
        min_size=settings.db_pool_min,
        max_size=settings.db_pool_max,
        kwargs={"row_factory": dict_row, "autocommit": False},
        configure=_configure,
        open=False,
        timeout=10,
        name="notitle",
    )
    await pool.open(wait=True, timeout=15)
    _pool = pool
    return pool


async def close_pool() -> None:
    global _pool
    if _pool is not None:
        await _pool.close()
        _pool = None


def pool() -> AsyncConnectionPool:
    if _pool is None:
        raise RuntimeError("database pool is not open")
    return _pool


def pool_open() -> bool:
    return _pool is not None


@asynccontextmanager
async def transaction() -> AsyncIterator[psycopg.AsyncConnection]:
    """Connection inside one transaction; commits on success, rolls back on error."""
    async with pool().connection() as conn:
        async with conn.transaction():
            yield conn


async def fetch_one(sql: str, params: Any = None, conn: psycopg.AsyncConnection | None = None) -> dict | None:
    if conn is not None:
        cur = await conn.execute(sql, params)
        return await cur.fetchone()
    started = time.perf_counter()
    async with pool().connection() as c:
        cur = await c.execute(sql, params)
        row = await cur.fetchone()
        await c.commit()  # helpers own their connection: commit writes (e.g. RETURNING)
    _observe(started)
    return row


async def fetch_all(sql: str, params: Any = None, conn: psycopg.AsyncConnection | None = None) -> list[dict]:
    if conn is not None:
        cur = await conn.execute(sql, params)
        return await cur.fetchall()
    started = time.perf_counter()
    async with pool().connection() as c:
        cur = await c.execute(sql, params)
        rows = await cur.fetchall()
        await c.commit()
    _observe(started)
    return rows


async def execute(sql: str, params: Any = None, conn: psycopg.AsyncConnection | None = None) -> int:
    if conn is not None:
        cur = await conn.execute(sql, params)
        return cur.rowcount
    started = time.perf_counter()
    async with pool().connection() as c:
        cur = await c.execute(sql, params)
        await c.commit()
        count = cur.rowcount
    _observe(started)
    return count


def _observe(started: float) -> None:
    try:
        from app.services.analytics import metrics

        metrics.observe("db_latency_ms", (time.perf_counter() - started) * 1000)
    except Exception:  # noqa: BLE001 - metrics must never break queries
        pass


async def ping() -> bool:
    try:
        row = await fetch_one("SELECT 1 AS ok")
        return bool(row and row["ok"] == 1)
    except Exception:  # noqa: BLE001
        return False
