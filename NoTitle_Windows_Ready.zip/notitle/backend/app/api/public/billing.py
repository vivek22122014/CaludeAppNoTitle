"""Premium passes, purchases, receipts, billing complaints, webhooks and the dev checkout."""

from __future__ import annotations

import html
from typing import Literal
from uuid import UUID

from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from pydantic import BaseModel, ConfigDict, Field

from app import db
from app.config import get_settings
from app.http import auth, ratelimit
from app.http.errors import ApiError, not_found, ok
from app.services import billing, support

router = APIRouter(prefix="/api/v1", tags=["billing"])


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class PurchaseIn(Strict):
    plan_code: Literal["Short3", "Week7", "Month30", "Annual365"]
    plan_version: int
    policy_version: str = Field(max_length=64)
    policy_accepted: bool
    client_nonce: UUID
    payment_phone: str = Field(max_length=20)


class ComplaintIn(Strict):
    purchase_ref: str = Field(max_length=64)
    reason: Literal["duplicate_charge", "not_granted", "wrong_amount", "payment_error", "statutory_remedy", "other"]
    details: str = Field(max_length=9000)
    client_nonce: UUID


@router.get("/billing/plans")
async def plans():
    return ok({"plans": await billing.plans(), "sales_open": billing.sales_open(),
               "no_voluntary_refunds": True, "auto_renewal": False})


@router.get("/billing/entitlement")
async def entitlement(request: Request):
    principal = await auth.require_account(request)
    return ok(await billing.entitlement(principal.account_id or ""))


@router.get("/billing/purchases")
async def purchases(request: Request):
    principal = await auth.require_account(request)
    return ok({"items": await billing.list_purchases(principal.account_id or "")})


@router.post("/billing/purchases")
async def purchase(body: PurchaseIn, request: Request, _: str = Depends(auth.mutation)):
    principal = await auth.require_account(request)
    ratelimit.check("purchase", principal.key)
    result = await billing.create_purchase(principal.account_id or "", body.plan_code, body.plan_version,
                                           body.policy_version, body.policy_accepted, str(body.client_nonce),
                                           body.payment_phone)
    return ok(result, status=201)


@router.get("/billing/purchases/{ref}")
async def get_purchase(ref: str, request: Request):
    principal = await auth.require_account(request)
    return ok(await billing.get_purchase(principal.account_id or "", ref))


@router.get("/billing/receipts")
async def receipts(request: Request):
    principal = await auth.require_account(request)
    return ok({"items": await billing.list_receipts(principal.account_id or "")})


@router.get("/billing/receipts/{ref}")
async def receipt(ref: str, request: Request):
    principal = await auth.require_account(request)
    return ok(await billing.get_receipt(principal.account_id or "", ref))


@router.post("/billing/refund-requests")
async def complaint(body: ComplaintIn, request: Request, _: str = Depends(auth.mutation)):
    """A billing issue opens a durable case for required-remedy review – never an automatic refund or hold."""
    principal = await auth.require_account(request)
    await billing.get_purchase(principal.account_id or "", body.purchase_ref, reconcile_now=False)
    async with db.transaction() as conn:
        case = await support.create_case(
            conn, account_id=principal.account_id, category="payment",
            subject=f"Billing issue: {body.reason.replace('_', ' ')} ({body.purchase_ref})",
            body=support.check_body(body.details), client_nonce=str(body.client_nonce), related_ref=body.purchase_ref)
    return ok({"case_ref": case["case_ref"], "received_at": case["created_at"],
               "note": "A reviewer checks verified payment records. This request does not pause your pass or guarantee a refund."},
              status=201)


@router.post("/webhooks/{provider_name}")
async def webhook(provider_name: str, request: Request):
    raw = await request.body()
    headers = {k.lower(): v for k, v in request.headers.items()}
    if not await billing.ingest_webhook(provider_name, raw, headers):
        raise not_found()
    return ok({"received": True})


# ---------------------------------------------------------------------------
# Development checkout page (simulator only)
# ---------------------------------------------------------------------------


def _require_simulator() -> None:
    s = get_settings()
    if s.payment_provider != "simulator" or s.app_env == "production":
        raise not_found()


@router.get("/dev/simulator/checkout/{merchant_order_id}", response_class=HTMLResponse)
async def simulator_page(merchant_order_id: str, request: Request):
    _require_simulator()
    row = await db.fetch_one(
        """SELECT o.status, o.amount_paise, p.public_ref, p.plan_code FROM simulated_provider_orders o
           JOIN purchases p ON p.merchant_order_id = o.merchant_order_id WHERE o.merchant_order_id = %s""",
        (merchant_order_id,))
    if row is None:
        raise not_found()
    boot, _ = auth.boot_value(request)
    amount = f"₹{row['amount_paise'] // 100}.{row['amount_paise'] % 100:02d}"
    order = html.escape(merchant_order_id)
    csrf = html.escape(auth.csrf_for(boot))
    disabled = "" if row["status"] == "ACTIVE" else "disabled"
    page = f"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Simulated checkout</title>
<style>body{{font-family:system-ui,sans-serif;background:#f4f6f6;margin:0;padding:24px;color:#1b2626}}
main{{max-width:440px;margin:40px auto;background:#fff;border-radius:12px;padding:28px;box-shadow:0 2px 12px #0001}}
.warn{{background:#fff4d6;border:1px solid #e0b84d;padding:10px 12px;border-radius:8px;font-size:14px}}
button{{min-height:44px;padding:0 18px;border-radius:8px;border:0;font-size:16px;cursor:pointer;margin-right:8px}}
.pay{{background:#0f6e6e;color:#fff}}.fail{{background:#e9eded;color:#1b2626}}</style></head><body><main>
<h1>Simulated payment</h1>
<p class="warn"><strong>Development only.</strong> No real money moves. This page stands in for the provider's hosted checkout.</p>
<p>Order <code>{order}</code><br>Pass <strong>{html.escape(row['plan_code'])}</strong> — total <strong>{amount}</strong></p>
<p>Status: <strong>{html.escape(row['status'])}</strong></p>
<form method="post" action="/api/v1/dev/simulator/checkout/{order}">
<input type="hidden" name="csrf" value="{csrf}">
<button class="pay" name="outcome" value="pay" {disabled}>Pay {amount}</button>
<button class="fail" name="outcome" value="fail" {disabled}>Simulate failure</button></form>
<p><a href="/payment/status/?ref={html.escape(row['public_ref'])}">Back to payment status</a></p>
</main></body></html>"""
    resp = HTMLResponse(page, headers={"Cache-Control": "no-store"})
    auth.set_boot(resp, boot)
    return resp


@router.post("/dev/simulator/checkout/{merchant_order_id}")
async def simulator_complete(merchant_order_id: str, request: Request):
    _require_simulator()
    from urllib.parse import parse_qs

    form = {k: v[0] for k, v in parse_qs((await request.body()).decode("utf-8", "replace")).items()}
    boot = auth.require_boot(request)
    from app.security import crypto

    if not crypto.constant_equals(str(form.get("csrf", "")), auth.csrf_for(boot)):
        raise ApiError(403, "csrf_failed", "Reload the checkout page.")
    outcome = "pay" if form.get("outcome") == "pay" else "fail"
    prov = billing.provider()
    signed = await prov.complete(merchant_order_id, outcome)  # type: ignore[attr-defined]
    row = await db.fetch_one("SELECT public_ref FROM purchases WHERE merchant_order_id = %s", (merchant_order_id,))
    if signed:
        body, headers = signed
        # Deliver the signed notification through the same verification path as a real provider,
        # then reconcile now (still by independently fetching provider state) so the status page is current.
        await billing.ingest_webhook("simulator", body, headers)
        purchase = await db.fetch_one("SELECT id FROM purchases WHERE merchant_order_id = %s", (merchant_order_id,))
        if purchase:
            await billing.reconcile(str(purchase["id"]))
    return RedirectResponse(f"/payment/status/?ref={row['public_ref'] if row else ''}", status_code=303)
