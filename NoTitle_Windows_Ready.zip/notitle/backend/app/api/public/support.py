"""Public Chat with Moderator routes."""

from __future__ import annotations

from typing import Literal
from uuid import UUID

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, ConfigDict, Field

from app import db
from app.http import auth, idempotency, ratelimit
from app.http.errors import invalid, ok, unauthenticated
from app.services import identity, support

router = APIRouter(prefix="/api/v1/support", tags=["support"])


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class CaseIn(Strict):
    category: Literal["general", "payment", "safety", "privacy", "appeal", "security"]
    subject: str = Field(max_length=400)
    body: str = Field(max_length=9000)
    client_nonce: UUID
    reservation_id: str | None = Field(default=None, max_length=80)
    receipt_secret: str | None = Field(default=None, max_length=100)
    saved: bool = False
    related_ref: str | None = Field(default=None, max_length=64)


class MessageIn(Strict):
    body: str = Field(max_length=9000)
    client_nonce: UUID


class SeenIn(Strict):
    seen_through: int = Field(ge=0)


class ReopenIn(Strict):
    expected_version: int
    reason: str = Field(default="", max_length=400)


class AccessIn(Strict):
    reference: str = Field(max_length=64)
    secret: str = Field(max_length=100)


async def _viewer(request: Request) -> tuple[str | None, str | None]:
    principal = await auth.optional_principal(request)
    account_id = principal.account_id if principal and principal.kind == "account" else None
    return account_id, auth.cookie(request, auth.SUPPORT)


async def create_case_common(request: Request, boot: str, body: CaseIn, parent: dict | None = None) -> dict:
    principal = await auth.optional_principal(request)
    identity_key = auth.identity_label(principal, request)
    ratelimit.check("support_create", identity_key)
    account_id = principal.account_id if principal and principal.kind == "account" else None
    scope = principal.key if principal else f"boot:{boot}"
    payload = body.model_dump(mode="json", exclude={"receipt_secret", "saved"})
    previous = await idempotency.lookup(scope, "support.create", str(body.client_nonce), payload)
    if previous:
        return previous
    case_ref = secret = None
    if account_id is None:
        # Unbound case: a prepared, saved receipt is required before commit.
        if not body.reservation_id or not body.receipt_secret:
            raise invalid("receipt", "Prepare and save a case receipt first.")
        if not body.saved:
            raise invalid("saved", "Confirm that you saved the case reference and secret.")
        prep = identity.prepared.peek(body.reservation_id, f"boot:{boot}", "case_receipt", body.receipt_secret)
        case_ref, secret = prep.reference, prep.secret
    async with db.transaction() as conn:
        result = await support.create_case(
            conn, account_id=account_id, category=body.category, subject=body.subject, body=body.body,
            client_nonce=str(body.client_nonce), case_ref=case_ref, receipt_secret=secret,
            urgent=body.category == "security", related_ref=body.related_ref,
            parent_case_id=str(parent["id"]) if parent else None)
        result.pop("case_id")
        await idempotency.store(conn, scope, "support.create", str(body.client_nonce), payload, result)
    if body.reservation_id:
        identity.prepared.consume(body.reservation_id)
    return result


@router.post("/cases")
async def create_case(body: CaseIn, request: Request, boot: str = Depends(auth.mutation)):
    result = await create_case_common(request, boot, body)
    resp = ok(result, status=201)
    principal = await auth.optional_principal(request)
    if principal is None or principal.kind != "account":
        # Open the exact-case session immediately so the guest sees the saved thread.
        token = await support.open_receipt_session("case", result["case_ref"], body.receipt_secret or "")
        auth.set_cookie(resp, auth.SUPPORT, token, int(support.SUPPORT_ABSOLUTE.total_seconds()))
    return resp


@router.post("/access")
async def access(body: AccessIn, request: Request, _: str = Depends(auth.mutation)):
    ratelimit.check("login", auth.identity_label(None, request))
    token = await support.open_receipt_session("case", body.reference, body.secret)
    resp = ok({"case_ref": body.reference.strip(), "scope": "single_case"})
    auth.set_cookie(resp, auth.SUPPORT, token, int(support.SUPPORT_ABSOLUTE.total_seconds()))
    return resp


@router.get("/cases")
async def list_cases(request: Request, cursor: str | None = None, limit: int = 20):
    principal = await auth.optional_principal(request)
    items: dict = {"items": [], "next_cursor": None}
    if principal and principal.kind == "account":
        items = await support.list_cases(principal.account_id or "", cursor, limit)
    scope = await support.receipt_scope(auth.cookie(request, auth.SUPPORT), "case")
    if scope:
        case = await db.fetch_one("SELECT * FROM support_cases WHERE id = %s", (scope["scope_ref"],))
        if case and all(i["case_ref"] != case["public_ref"] for i in items["items"]):
            items["items"].insert(0, {**(await support.case_dto(case)), "access": "receipt"})
    if principal is None and scope is None:
        raise unauthenticated("Sign in or open a case with its saved receipt.")
    return ok(items)


@router.get("/cases/{ref}")
async def get_case(ref: str, request: Request):
    account_id, token = await _viewer(request)
    case = await support.authorize_case(ref, account_id, token)
    return ok(await support.case_dto(case))


@router.get("/cases/{ref}/messages")
async def get_messages(ref: str, request: Request, after_sequence: int = 0, before_sequence: int | None = None,
                       limit: int = 50):
    account_id, token = await _viewer(request)
    case = await support.authorize_case(ref, account_id, token)
    return ok(await support.messages(case, after_sequence, before_sequence, limit, "user"))


@router.post("/cases/{ref}/messages")
async def post_message(ref: str, body: MessageIn, request: Request, _: str = Depends(auth.mutation)):
    account_id, token = await _viewer(request)
    case = await support.authorize_case(ref, account_id, token)
    ratelimit.check("support_write", f"case:{case['id']}")
    result, created = await support.post_message(ref, sender_kind="user", sender_ref=None, body=body.body,
                                                 client_nonce=str(body.client_nonce))
    return ok(result, status=201 if created else 200)


@router.post("/cases/{ref}/seen")
async def seen(ref: str, body: SeenIn, request: Request, _: str = Depends(auth.mutation)):
    account_id, token = await _viewer(request)
    case = await support.authorize_case(ref, account_id, token)
    return ok({"seen_user_sequence": await support.mark_seen(case, body.seen_through, "user")})


@router.post("/cases/{ref}/reopen")
async def reopen(ref: str, body: ReopenIn, request: Request, _: str = Depends(auth.mutation)):
    account_id, token = await _viewer(request)
    case = await support.authorize_case(ref, account_id, token)
    return ok(await support.reopen(case, body.expected_version, body.reason))


@router.post("/cases/{ref}/continuations")
async def continuation(ref: str, body: CaseIn, request: Request, boot: str = Depends(auth.mutation)):
    account_id, token = await _viewer(request)
    parent = await support.authorize_case(ref, account_id, token)
    result = await create_case_common(request, boot, body, parent=parent)
    resp = ok({**result, "parent_case_ref": ref}, status=201)
    if account_id is None:
        session = await support.open_receipt_session("case", result["case_ref"], body.receipt_secret or "")
        auth.set_cookie(resp, auth.SUPPORT, session, int(support.SUPPORT_ABSOLUTE.total_seconds()))
    return resp
