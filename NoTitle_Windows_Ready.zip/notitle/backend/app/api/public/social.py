"""Friends, blocks and the HTTP safety fallback for ending a conversation."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, ConfigDict, Field, model_validator

from app.http import auth
from app.http.errors import invalid, not_found, ok
from app.realtime.coordinator import coordinator
from app.services import social

router = APIRouter(prefix="/api/v1", tags=["social"])


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class BlockIn(Strict):
    interaction_id: str | None = Field(default=None, max_length=64)
    relationship_id: str | None = Field(default=None, max_length=64)

    @model_validator(mode="after")
    def _one(self) -> "BlockIn":
        if bool(self.interaction_id) == bool(self.relationship_id):
            raise ValueError("Provide exactly one of interaction_id or relationship_id")
        return self


class EndIn(Strict):
    interaction_id: str = Field(max_length=64)


@router.get("/friends")
async def friends(request: Request):
    principal = await auth.require_principal(request)
    return ok({"items": await social.list_friends(principal), "limit": 100})


@router.delete("/friends/{ref}")
async def remove_friend(ref: str, request: Request, expected_revision: int | None = None,
                        _: str = Depends(auth.mutation)):
    principal = await auth.require_principal(request)
    if not await social.remove_friend(principal, ref, expected_revision):
        raise not_found()
    return ok({"removed": True})


@router.get("/blocks")
async def blocks(request: Request, cursor: str | None = None):
    principal = await auth.require_principal(request)
    return ok(await social.list_blocks(principal, cursor))


@router.post("/blocks")
async def block(body: BlockIn, request: Request, _: str = Depends(auth.mutation)):
    principal = await auth.require_principal(request)
    peer = None
    if body.interaction_id:
        peer = coordinator.peer_key_for(principal.key, body.interaction_id)
    else:
        me = coordinator.participants.get(principal.key)
        if me and body.relationship_id in me.friends:
            peer = me.friends[body.relationship_id]
        elif body.relationship_id in coordinator.temp_relationships:
            a, b = coordinator.temp_relationships[body.relationship_id]
            peer = b if a == principal.key else a if b == principal.key else None
        elif principal.kind == "account":
            peer = await _account_key_for_relationship(principal.account_id, body.relationship_id)
    if not peer:
        raise invalid("interaction_id", "That conversation or friend can no longer be blocked from here.")
    return ok(await social.create_block(principal, peer), status=201)


async def _account_key_for_relationship(account_id: str | None, rel_id: str | None) -> str | None:
    from app import db

    rows = await db.fetch_all(
        """SELECT CASE WHEN low_account_id = %s THEN high_account_id ELSE low_account_id END AS other
           FROM friendships WHERE state = 'active' AND (low_account_id = %s OR high_account_id = %s)""",
        (account_id, account_id, account_id))
    for row in rows:
        if social.relationship_id(account_id or "", str(row["other"])) == rel_id:
            return f"a:{row['other']}"
    return None


@router.delete("/blocks/{ref}")
async def unblock(ref: str, request: Request, _: str = Depends(auth.mutation)):
    principal = await auth.require_principal(request)
    if not await social.remove_block(principal, ref):
        raise not_found()
    return ok({"removed": True, "note": "Unblocking does not restore a friendship or start a conversation."})


@router.post("/interactions/end")
async def end_interaction(body: EndIn, request: Request, _: str = Depends(auth.mutation)):
    """Safety teardown that does not depend on a healthy WebSocket (idempotent)."""
    principal = await auth.require_principal(request)
    ended = coordinator.end_interaction(principal.key, body.interaction_id, "ended")
    return ok({"ended": True, "already_ended": not ended})
