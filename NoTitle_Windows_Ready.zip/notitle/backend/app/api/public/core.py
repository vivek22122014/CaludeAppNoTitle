"""Bootstrap, catalogs and policy metadata."""

from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Request

from app import catalogs, policies
from app.config import get_settings
from app.http import auth
from app.http.errors import not_found, ok
from app.realtime.coordinator import coordinator

router = APIRouter(prefix="/api/v1", tags=["core"])


@router.get("/bootstrap")
async def bootstrap(request: Request):
    settings = get_settings()
    boot, new_boot = auth.boot_value(request)
    principal = await auth.optional_principal(request)
    owner = None
    if principal:
        owner = {"kind": principal.kind}
        if principal.account:
            owner.update(username=principal.account["username"], display_name=principal.account["display_name"])
        elif principal.guest:
            owner.update(display_name=principal.guest.display_name,
                         expires_at=datetime.fromtimestamp(principal.guest.expires_at, timezone.utc).isoformat())
    from app.services import billing

    result = ok({
        "csrf_token": auth.csrf_for(boot),
        "server_time": datetime.now(timezone.utc).isoformat(),
        "owner": owner,
        "policies": {k: p.summary() for k, p in policies.all_policies().items()},
        "features": {
            "admission": settings.admission_open and not coordinator.draining,
            "audio": settings.audio_enabled,
            "payments": billing.sales_open(),
            "payment_provider": settings.payment_provider,
            "environment": settings.app_env,
        },
    })
    if new_boot:
        auth.set_boot(result, boot)
    return result


@router.get("/catalogs")
async def catalog_list():
    return ok(catalogs.as_dict(), headers={"Cache-Control": "public, max-age=300", "ETag": f'"{catalogs.CATALOG_VERSION}"'})


@router.get("/policies")
async def policy_list():
    return ok({k: p.summary() for k, p in policies.all_policies().items()})


@router.get("/policies/{kind}")
async def policy_detail(kind: str):
    policy = policies.all_policies().get(kind)
    if policy is None:
        raise not_found()
    return ok({**policy.summary(), "body": policy.body})
