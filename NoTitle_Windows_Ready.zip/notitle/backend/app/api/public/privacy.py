"""Privacy: exports, deletion, rights requests, deletion status and retention schedule."""

from __future__ import annotations

from typing import Literal
from uuid import UUID

from fastapi import APIRouter, Depends, Request
from fastapi.responses import Response
from pydantic import BaseModel, ConfigDict, Field

from app import db
from app.http import auth, ratelimit
from app.http.errors import ok
from app.services import identity, privacy, support

router = APIRouter(prefix="/api/v1/privacy", tags=["privacy"])


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class DeleteIn(Strict):
    reservation_id: str = Field(max_length=80)
    receipt_secret: str = Field(max_length=100)
    saved: bool
    confirm: bool


class RightsIn(Strict):
    kind: Literal["access", "correction", "erasure", "objection", "grievance", "other"]
    details: str = Field(max_length=9000)
    client_nonce: UUID


class AccessIn(Strict):
    reference: str = Field(max_length=64)
    secret: str = Field(max_length=100)


@router.post("/exports")
async def create_export(request: Request, _: str = Depends(auth.mutation)):
    principal = await auth.require_account(request)
    identity.require_reauth(principal.account)  # type: ignore[arg-type]
    ratelimit.check("export", principal.key)
    return ok(await privacy.request_export(principal.account_id or ""), status=202)


@router.get("/exports")
async def exports(request: Request):
    principal = await auth.require_account(request)
    return ok({"items": await privacy.list_exports(principal.account_id or "")})


@router.get("/exports/{ref}")
async def export_status(ref: str, request: Request):
    principal = await auth.require_account(request)
    return ok(await privacy.export_status(principal.account_id or "", ref))


@router.get("/exports/{ref}/download")
async def export_download(ref: str, request: Request):
    principal = await auth.require_account(request)
    data = await privacy.download_export(principal.account_id or "", ref)
    return Response(data, media_type="application/json", headers={
        "Content-Disposition": 'attachment; filename="notitle-data-export.json"', "Cache-Control": "no-store"})


@router.post("/delete")
async def delete(body: DeleteIn, request: Request, boot: str = Depends(auth.mutation)):
    principal = await auth.require_account(request)
    result = await privacy.delete_account(principal, boot, body.reservation_id, body.receipt_secret, body.saved,
                                          body.confirm)
    resp = ok(result, status=202)
    for name in (auth.ACCOUNT, auth.SUPPORT):
        auth.clear_cookie(resp, name)
    token = await support.open_receipt_session("deletion", result["deletion_ref"], body.receipt_secret)
    auth.set_cookie(resp, auth.RECEIPT, token, int(support.SUPPORT_ABSOLUTE.total_seconds()))
    return resp


@router.post("/status/access")
async def status_access(body: AccessIn, request: Request, _: str = Depends(auth.mutation)):
    ratelimit.check("login", auth.identity_label(None, request))
    token = await support.open_receipt_session("deletion", body.reference, body.secret)
    resp = ok({"deletion_ref": body.reference.strip()})
    auth.set_cookie(resp, auth.RECEIPT, token, int(support.SUPPORT_ABSOLUTE.total_seconds()))
    return resp


@router.get("/status")
async def status(request: Request):
    return ok(await privacy.deletion_status(auth.cookie(request, auth.RECEIPT)))


@router.post("/requests")
async def rights_request(body: RightsIn, request: Request, _: str = Depends(auth.mutation)):
    principal = await auth.require_account(request)
    return ok(await privacy.create_request(principal, body.kind, body.details, str(body.client_nonce)), status=201)


@router.get("/retention")
async def retention():
    rows = await db.fetch_all("SELECT category, duration_days, trigger_event, description FROM retention_registry ORDER BY category")
    return ok({"items": rows, "ordinary_chat": "Never stored: memory only, cleared when a conversation ends."})
