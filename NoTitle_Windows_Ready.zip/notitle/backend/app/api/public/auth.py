"""Identity routes: preparations, guest entry, registration, login, recovery, tickets."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Literal

from fastapi import APIRouter, Depends, Request, WebSocket
from pydantic import BaseModel, ConfigDict, Field, field_validator

from app import catalogs, db
from app.http import auth, ratelimit
from app.http.errors import ApiError, conflict, ok, unauthenticated
from app.realtime import connection
from app.realtime.coordinator import CoordinatorError, coordinator
from app.services import identity

router = APIRouter(prefix="/api/v1", tags=["identity"])


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Consents(Strict):
    adult: bool = False
    terms: bool = False
    core: bool = False
    professional: bool = False


class PolicyVersions(Strict):
    terms: str = Field(max_length=64)
    privacy: str = Field(max_length=64)


class Professional(Strict):
    industry_id: str | None = None
    role_id: str | None = None
    experience_id: str | None = None
    interest_ids: list[str] = Field(default_factory=list, max_length=10)
    topic_ids: list[str] = Field(default_factory=list, max_length=5)

    @field_validator("industry_id")
    @classmethod
    def _industry(cls, v: str | None) -> str | None:
        if v is not None and v not in catalogs.INDUSTRY_IDS:
            raise ValueError("Unknown industry")
        return v

    @field_validator("role_id")
    @classmethod
    def _role(cls, v: str | None) -> str | None:
        if v is not None and v not in catalogs.ROLE_IDS:
            raise ValueError("Unknown role")
        return v

    @field_validator("experience_id")
    @classmethod
    def _experience(cls, v: str | None) -> str | None:
        if v is not None and v not in catalogs.EXPERIENCE_IDS:
            raise ValueError("Unknown experience band")
        return v

    @field_validator("interest_ids")
    @classmethod
    def _interests(cls, v: list[str]) -> list[str]:
        if not set(v) <= catalogs.INTEREST_IDS:
            raise ValueError("Unknown interest")
        return sorted(set(v))

    @field_validator("topic_ids")
    @classmethod
    def _topics(cls, v: list[str]) -> list[str]:
        if not set(v) <= catalogs.TOPIC_IDS:
            raise ValueError("Unknown topic")
        return sorted(set(v))


class PrepareIn(Strict):
    kind: Literal["registration", "recovery", "recovery_rotation", "case_receipt", "deletion_receipt",
                  "financial_receipt"]


class GuestIn(Strict):
    gender: str
    topic_id: str
    consents: Consents
    policy_versions: PolicyVersions
    professional: Professional | None = None


class RegisterIn(Strict):
    reservation_id: str = Field(max_length=80)
    recovery_code: str = Field(max_length=100)
    saved: bool
    username: str = Field(max_length=64)
    password: str = Field(max_length=600)
    display_name: str = Field(max_length=64)
    gender: str
    topic_id: str
    consents: Consents
    policy_versions: PolicyVersions
    convert_guest: bool = False
    professional: Professional | None = None


class LoginIn(Strict):
    username: str = Field(max_length=64)
    password: str = Field(max_length=600)
    confirm_end_guest: bool = False


class SessionLimitIn(Strict):
    challenge_id: str = Field(max_length=80)
    session_id: str = Field(max_length=64)


class RecoverIn(Strict):
    username: str = Field(max_length=64)
    recovery_code: str = Field(max_length=100)
    new_password: str = Field(max_length=600)
    reservation_id: str = Field(max_length=80)
    new_recovery_code: str = Field(max_length=100)
    saved: bool


class ReauthIn(Strict):
    password: str = Field(max_length=600)


class TicketIn(Strict):
    takeover: bool = False


BOOT_SCOPED = {"registration", "recovery", "case_receipt"}


def _account_cookie(response, token: str) -> None:
    auth.set_cookie(response, auth.ACCOUNT, token, int(identity.ACCOUNT_ABSOLUTE.total_seconds()))


@router.post("/operations/prepare")
async def prepare(body: PrepareIn, request: Request, boot: str = Depends(auth.mutation)):
    principal = await auth.optional_principal(request)
    if body.kind in BOOT_SCOPED:
        scope = f"boot:{boot}"
    else:
        if principal is None or principal.kind != "account":
            raise unauthenticated("Sign in to prepare this receipt.")
        scope = principal.scope
    item = identity.prepared.prepare(body.kind, scope)
    return ok({
        "reservation_id": item.id,
        "kind": item.kind,
        "secret": item.secret,
        "reference": item.reference,
        "expires_at": datetime.fromtimestamp(item.expires, timezone.utc).isoformat(),
    })


@router.post("/auth/guest")
async def guest_entry(body: GuestIn, request: Request, boot: str = Depends(auth.mutation)):
    ratelimit.check("guest", auth.identity_label(None, request))
    existing = await auth.optional_principal(request)
    if existing is not None:
        raise conflict("You are already signed in.", code="already_signed_in")
    identity.check_gender(body.gender)
    identity.check_topic(body.topic_id)
    proof = identity.validate_consents(body.consents.model_dump(), body.policy_versions.model_dump())
    guest, token = identity.guests.create(body.gender, body.topic_id, proof,
                                          body.professional.model_dump() if body.professional else None)
    resp = ok(_guest_dto(guest), status=201)
    auth.set_cookie(resp, auth.GUEST, token, identity.GUEST_ABSOLUTE)
    return resp


def _guest_dto(guest: identity.Guest) -> dict:
    return {
        "kind": "guest",
        "display_name": guest.display_name,
        "gender": guest.gender,
        "topic_id": guest.topic_id,
        "expires_at": datetime.fromtimestamp(guest.expires_at, timezone.utc).isoformat(),
    }


@router.post("/auth/register")
async def register(body: RegisterIn, request: Request, boot: str = Depends(auth.mutation)):
    ratelimit.check("register", auth.identity_label(None, request))
    current = await auth.optional_principal(request)
    if current is not None and current.kind == "account":
        raise conflict("You are already signed in.", code="already_signed_in")
    guest = current.guest if current and current.kind == "guest" else None
    result = await identity.register(
        boot=f"boot:{boot}", reservation_id=body.reservation_id, recovery_code=body.recovery_code,
        saved=body.saved, username=body.username, password=body.password, display_name=body.display_name,
        gender=body.gender, topic_id=body.topic_id, consents=body.consents.model_dump(),
        policy_versions=body.policy_versions.model_dump(), guest=guest,
        professional=body.professional.model_dump() if body.professional else (
            guest.professional if guest and body.consents.professional else None),
    )
    converted = False
    if guest is not None:
        if body.convert_guest:
            converted = await _convert_guest(guest, result["account_id"], result["session_id"])
        else:
            identity.guests.remove(guest.id)
    resp = ok({"kind": "account", "username": identity.normalize_username(body.username),
               "converted_guest": converted}, status=201)
    _account_cookie(resp, result["token"])
    auth.clear_cookie(resp, auth.GUEST)
    return resp


async def _convert_guest(guest: identity.Guest, account_id: str, session_id: str) -> bool:
    """Carry the live participant, safety restrictions and eligible links to the new account."""
    from app.realtime import participants
    from app.services import social

    profile = await participants.for_account(account_id)
    outcome = coordinator.convert_guest(guest.key, f"a:{account_id}", profile, session_id)
    for blocked_account in outcome["blocks"]:
        await social.persist_block(account_id, blocked_account)
    for other_account in outcome["promote"]:
        if await social.persist_friendship(account_id, other_account):
            coordinator.add_saved_friend(f"a:{account_id}", f"a:{other_account}",
                                         social.relationship_id(account_id, other_account))
    await db.execute(
        """INSERT INTO restrictions (subject_kind, subject_ref, kind, starts_at, ends_at, reason_code, decision_id)
           SELECT 'account', %s, kind, starts_at, ends_at, reason_code, decision_id FROM restrictions
           WHERE subject_ref = %s AND lifted_at IS NULL AND (ends_at IS NULL OR ends_at > now())""",
        (identity.subject_ref_for_account(account_id), identity.subject_ref_for_guest(guest.id)),
    )
    identity.guests.by_id.pop(guest.id, None)
    identity.guests.by_token.pop(guest.token_hmac, None)
    coordinator.emit(f"a:{account_id}", "identity.converted", {"kind": "account"})
    return True


@router.post("/auth/login")
async def login(body: LoginIn, request: Request, boot: str = Depends(auth.mutation)):
    ratelimit.check("login", auth.identity_label(None, request))
    current = await auth.optional_principal(request)
    if current and current.kind == "guest" and not body.confirm_end_guest:
        raise conflict("Signing in ends your guest conversation and temporary friend links.",
                       code="guest_active")
    try:
        result = await identity.login(boot=boot, username=body.username, password=body.password)
    except ApiError as exc:
        if exc.code == "session_limit":
            sessions = await identity.active_sessions(
                identity.challenges.get(exc.extra["challenge_id"], boot).account_id)
            exc.extra["sessions"] = [_session_dto(s, None) for s in sessions]
        raise
    if current and current.guest:
        identity.guests.remove(current.guest.id)
    resp = ok({"kind": "account"})
    _account_cookie(resp, result["token"])
    auth.clear_cookie(resp, auth.GUEST)
    return resp


def _session_dto(row: dict, current_id: str | None) -> dict:
    return {
        "session_id": str(row["id"]),
        "is_current": current_id is not None and str(row["id"]) == current_id,
        "created_at": row["created_at"].isoformat(),
        "last_active_at": row["last_active_at"].isoformat(),
        "expires_at": row["expires_at"].isoformat(),
    }


@router.post("/auth/session-limit/resolve")
async def session_limit_resolve(body: SessionLimitIn, request: Request, boot: str = Depends(auth.mutation)):
    result = await identity.resolve_session_limit(boot=boot, challenge_id=body.challenge_id,
                                                  revoke_session_id=body.session_id)
    resp = ok({"kind": "account"})
    _account_cookie(resp, result["token"])
    return resp


@router.post("/auth/recover")
async def recover(body: RecoverIn, request: Request, boot: str = Depends(auth.mutation)):
    ratelimit.check("login", auth.identity_label(None, request))
    result = await identity.recover(boot=f"boot:{boot}", username=body.username, old_code=body.recovery_code,
                                    new_password=body.new_password, reservation_id=body.reservation_id,
                                    new_code=body.new_recovery_code, saved=body.saved)
    resp = ok({"kind": "account", "recovered": True})
    _account_cookie(resp, result["token"])
    auth.clear_cookie(resp, auth.GUEST)
    return resp


@router.post("/auth/reauth")
async def reauth(body: ReauthIn, request: Request, _: str = Depends(auth.mutation)):
    principal = await auth.require_account(request)
    ratelimit.check("login", principal.key)
    await identity.reauth(principal.account, body.password)  # type: ignore[arg-type]
    return ok({"reauth_valid_seconds": int(identity.REAUTH_WINDOW.total_seconds())})


@router.post("/auth/logout")
async def logout(request: Request, _: str = Depends(auth.mutation)):
    principal = await auth.optional_principal(request)
    if principal and principal.account:
        await identity.logout(principal.account, everywhere=False)
    elif principal and principal.guest:
        identity.guests.remove(principal.guest.id)
    resp = ok({"signed_out": True})
    for name in (auth.ACCOUNT, auth.GUEST, auth.SUPPORT, auth.RECEIPT):
        auth.clear_cookie(resp, name)
    return resp


@router.post("/auth/logout-all")
async def logout_all(request: Request, _: str = Depends(auth.mutation)):
    principal = await auth.require_account(request)
    await identity.logout(principal.account, everywhere=True)  # type: ignore[arg-type]
    resp = ok({"signed_out": True, "all_sessions": True})
    for name in (auth.ACCOUNT, auth.GUEST, auth.SUPPORT, auth.RECEIPT):
        auth.clear_cookie(resp, name)
    return resp


@router.post("/ws/ticket")
async def ws_ticket(body: TicketIn, request: Request, _: str = Depends(auth.mutation)):
    principal = await auth.require_principal(request)
    ratelimit.check("ticket", principal.key)
    try:
        ticket, ttl = connection.tickets.issue(principal.key, principal.kind, principal.session_id, body.takeover)
    except CoordinatorError as exc:
        raise ApiError(503, exc.code, exc.message, retryable=True, retry_after=5) from None
    return ok({"ticket": ticket, "expires_in": ttl, "path": "/api/v1/ws"})


@router.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    await connection.serve(ws)
