"""Owner routes: profile, preferences, consents, sessions, security and notices."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Literal

from fastapi import APIRouter, Depends, Request
from fastapi.responses import Response
from pydantic import BaseModel, ConfigDict, Field, field_validator

from app import catalogs, db, policies
from app.api.public.auth import Professional
from app.http import auth
from app.http.errors import conflict, invalid, not_found, ok
from app.realtime.coordinator import coordinator
from app.services import billing, identity

router = APIRouter(prefix="/api/v1", tags=["me"])


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class ProfileIn(Strict):
    expected_version: int
    display_name: str | None = Field(default=None, max_length=64)
    gender: str | None = None
    topic_id: str | None = None
    bio: str | None = Field(default=None, max_length=400)
    professional: Professional | None = None


class PreferencesIn(Strict):
    expected_version: int
    gender_preference: Literal["everyone", "male", "female", "other"]
    professional_enabled: bool = True
    industry_ids: list[str] = Field(default_factory=list, max_length=5)
    role_ids: list[str] = Field(default_factory=list, max_length=5)
    experience_ids: list[str] = Field(default_factory=list, max_length=5)
    interest_ids: list[str] = Field(default_factory=list, max_length=10)
    topic_ids: list[str] = Field(default_factory=list, max_length=5)

    @field_validator("industry_ids", "role_ids", "experience_ids", "interest_ids", "topic_ids")
    @classmethod
    def _known(cls, value: list[str], info) -> list[str]:
        allowed = {
            "industry_ids": catalogs.INDUSTRY_IDS, "role_ids": catalogs.ROLE_IDS,
            "experience_ids": catalogs.EXPERIENCE_IDS, "interest_ids": catalogs.INTEREST_IDS,
            "topic_ids": catalogs.TOPIC_IDS,
        }[info.field_name]
        if not set(value) <= allowed:
            raise ValueError("Unknown value")
        return sorted(set(value))


class ConsentIn(Strict):
    purpose: Literal["core", "professional"]
    choice: bool
    policy_version: str = Field(max_length=64)


class PasswordIn(Strict):
    current_password: str = Field(max_length=600)
    new_password: str = Field(max_length=600)


class RotateIn(Strict):
    reservation_id: str = Field(max_length=80)
    recovery_code: str = Field(max_length=100)
    saved: bool


async def owner_dto(principal: auth.Principal, boot: str | None = None) -> dict:
    if principal.guest:
        g = principal.guest
        return {
            "kind": "guest",
            "display_name": g.display_name,
            "display_name_editable": False,
            "gender": g.gender,
            "topic_id": g.topic_id,
            "bio": g.bio,
            "profile_version": g.profile_version,
            "consents": {k: {"choice": v["choice"], "policy_version": v["policy_version"]} for k, v in g.consents.items()},
            "professional": g.professional,
            "preferences": {"saved": {**g.preferences, "version": g.preference_version},
                            "effective": identity.effective_preferences(
                                {**g.preferences}, False, g.topic_id, bool(g.consents.get("professional", {}).get("choice")))},
            "premium": {"active": False, "eligible": False},
            "expires_at": datetime.fromtimestamp(g.expires_at, timezone.utc).isoformat(),
            "csrf_token": auth.csrf_for(boot) if boot else None,
        }
    a = principal.account
    assert a
    account_id = str(a["id"])
    profile = await identity.load_profile(account_id)
    consents = await identity.current_consents(account_id)
    entitlement = await billing.entitlement(account_id)
    professional_ok = consents.get("professional", {}).get("choice", False)
    return {
        "kind": "account",
        "username": a["username"],
        "display_name": a["display_name"],
        "display_name_editable": True,
        "gender": a["gender"],
        "topic_id": a["topic_id"],
        "bio": a["bio"],
        "profile_version": a["profile_version"],
        "created_at": a["created_at"].isoformat(),
        "consents": consents,
        "professional": profile["professional"] if professional_ok else None,
        "preferences": {
            "saved": profile["preferences"],
            "effective": identity.effective_preferences(profile["preferences"], entitlement["active"], a["topic_id"],
                                                        professional_ok),
        },
        "premium": {"active": entitlement["active"], "eligible": True, "expires_at": entitlement["expires_at"]},
        "csrf_token": auth.csrf_for(boot) if boot else None,
    }


@router.get("/me")
async def me(request: Request):
    principal = await auth.require_principal(request)
    boot = auth.cookie(request, auth.BOOT)
    return ok(await owner_dto(principal, boot))


@router.patch("/me/profile")
async def update_profile(body: ProfileIn, request: Request, _: str = Depends(auth.mutation)):
    principal = await auth.require_principal(request)
    if principal.guest:
        g = principal.guest
        if body.expected_version != g.profile_version:
            raise conflict("Your profile changed in another tab. Reload and retry.", code="stale_version")
        if body.display_name is not None and body.display_name != g.display_name:
            raise invalid("display_name", "Guest pseudonyms are generated and cannot be edited.")
        if body.gender is not None:
            g.gender = identity.check_gender(body.gender)
        if body.topic_id is not None:
            g.topic_id = identity.check_topic(body.topic_id)
        if body.bio is not None:
            g.bio = identity.clean_bio(body.bio)
        if body.professional is not None:
            if not g.consents.get("professional", {}).get("choice"):
                raise invalid("professional", "Turn on optional professional processing first.")
            g.professional = body.professional.model_dump()
        g.profile_version += 1
        coordinator.update_profile(g.key, gender=g.gender, topic_id=g.topic_id, bio=g.bio, professional=g.professional)
        return ok(await owner_dto(principal))
    a = principal.account
    assert a
    account_id = str(a["id"])
    fields = {
        "display_name": identity.clean_display_name(body.display_name) if body.display_name is not None else a["display_name"],
        "gender": identity.check_gender(body.gender) if body.gender is not None else a["gender"],
        "topic_id": identity.check_topic(body.topic_id) if body.topic_id is not None else a["topic_id"],
        "bio": identity.clean_bio(body.bio) if body.bio is not None else a["bio"],
    }
    consents = await identity.current_consents(account_id)
    if body.professional is not None and not consents.get("professional", {}).get("choice"):
        raise invalid("professional", "Turn on optional professional processing first.")
    async with db.transaction() as conn:
        row = await (await conn.execute(
            """UPDATE accounts SET display_name = %s, gender = %s, topic_id = %s, bio = %s,
                      profile_version = profile_version + 1, updated_at = now()
               WHERE id = %s AND profile_version = %s RETURNING profile_version""",
            (fields["display_name"], fields["gender"], fields["topic_id"], fields["bio"], account_id,
             body.expected_version),
        )).fetchone()
        if row is None:
            raise conflict("Your profile changed in another tab. Reload and retry.", code="stale_version")
        if body.professional is not None:
            await identity.upsert_professional(conn, account_id, body.professional.model_dump())
    coordinator.update_profile(principal.key, **fields,
                               **({"professional": body.professional.model_dump()} if body.professional else {}))
    refreshed = await auth.require_principal(request)
    return ok(await owner_dto(refreshed))


@router.patch("/me/preferences")
async def update_preferences(body: PreferencesIn, request: Request, _: str = Depends(auth.mutation)):
    principal = await auth.require_principal(request)
    data = body.model_dump(exclude={"expected_version"})
    wanted = {k: data[k] for k in ("industry_ids", "role_ids", "experience_ids", "interest_ids", "topic_ids")}
    if principal.guest:
        g = principal.guest
        if body.expected_version != g.preference_version:
            raise conflict("Preferences changed in another tab. Reload and retry.", code="stale_version")
        if body.gender_preference != "everyone":
            raise invalid("gender_preference", "Guests always match with Everyone. Register and use Premium for a gender choice.")
        g.preferences = data
        g.preference_version += 1
        coordinator.update_profile(g.key, wanted=wanted)
        return ok(await owner_dto(principal))
    account_id = principal.account_id
    row = await db.fetch_one(
        """UPDATE matching_preferences SET gender_preference = %s, professional_enabled = %s, industry_ids = %s,
                  role_ids = %s, experience_ids = %s, interest_ids = %s, topic_ids = %s,
                  version = version + 1, updated_at = now()
           WHERE account_id = %s AND version = %s RETURNING version""",
        (data["gender_preference"], data["professional_enabled"], data["industry_ids"], data["role_ids"],
         data["experience_ids"], data["interest_ids"], data["topic_ids"], account_id, body.expected_version),
    )
    if row is None:
        raise conflict("Preferences changed in another tab. Reload and retry.", code="stale_version")
    consents = await identity.current_consents(account_id or "")
    coordinator.update_profile(principal.key, gender_preference=data["gender_preference"],
                               professional_enabled=bool(data["professional_enabled"]
                                                         and consents.get("professional", {}).get("choice")),
                               wanted=wanted)
    return ok(await owner_dto(principal))


@router.post("/me/consents")
async def change_consent(body: ConsentIn, request: Request, _: str = Depends(auth.mutation)):
    principal = await auth.require_principal(request)
    policy = policies.get(policies.CONSENT_POLICY[body.purpose])
    if body.policy_version != policy.version:
        raise conflict("The policy changed. Review the current version first.", code="policy_changed",
                       current_versions=policies.current_versions())
    proof = {body.purpose: {"choice": body.choice, "policy_kind": policy.kind, "policy_version": policy.version,
                            "text_digest": policy.digest, "recorded_at": datetime.now(timezone.utc).isoformat()}}
    if principal.guest:
        g = principal.guest
        g.consents[body.purpose] = proof[body.purpose]
        if body.purpose == "professional" and not body.choice:
            g.professional = None
            coordinator.update_profile(g.key, professional=None, professional_enabled=False)
        if body.purpose == "core":
            coordinator.update_profile(g.key, core_consent=body.choice)
            if not body.choice:
                coordinator.end_identity(g.key, "consent_withdrawn")
        return ok(await owner_dto(principal))
    account_id = principal.account_id or ""
    async with db.transaction() as conn:
        await identity.record_consents(conn, account_id, principal.subject_ref, proof)
        if body.purpose == "professional" and not body.choice:
            # Withdrawal clears optional data and its future matching influence.
            await conn.execute("DELETE FROM professional_profiles WHERE account_id = %s", (account_id,))
            await conn.execute(
                """UPDATE matching_preferences SET industry_ids = '{}', role_ids = '{}', experience_ids = '{}',
                          interest_ids = '{}', topic_ids = '{}', version = version + 1 WHERE account_id = %s""",
                (account_id,))
    if body.purpose == "professional" and not body.choice:
        coordinator.update_profile(principal.key, professional=None, professional_enabled=False, wanted={})
    else:
        coordinator.update_profile(principal.key, core_consent=body.choice)
        if not body.choice:
            # Participation ends; deletion, rights and support stay available.
            coordinator.end_identity(principal.key, "consent_withdrawn")
    return ok(await owner_dto(principal))


@router.get("/me/consent-proof")
async def consent_proof(request: Request):
    principal = await auth.require_principal(request)
    if principal.guest:
        data = {"kind": "guest_consent_proof", "pseudonym": principal.guest.display_name,
                "consents": principal.guest.consents,
                "note": "Guest consent proof exists only in memory until the guest identity expires."}
    else:
        rows = await db.fetch_all(
            """SELECT purpose, choice, policy_kind, policy_version, text_digest, recorded_at FROM consent_records
               WHERE account_id = %s ORDER BY recorded_at""", (principal.account_id,))
        data = {"kind": "account_consent_proof", "records": [
            {**r, "recorded_at": r["recorded_at"].isoformat()} for r in rows]}
    return Response(json.dumps(data, indent=2), media_type="application/json",
                    headers={"Content-Disposition": 'attachment; filename="notitle-consent-proof.json"',
                             "Cache-Control": "no-store"})


@router.get("/me/sessions")
async def sessions(request: Request):
    principal = await auth.require_account(request)
    rows = await identity.active_sessions(principal.account_id or "")
    from app.api.public.auth import _session_dto

    return ok({"items": [_session_dto(r, principal.session_id) for r in rows], "limit": identity.MAX_SESSIONS})


@router.delete("/me/sessions/{session_id}")
async def revoke_session(session_id: str, request: Request, _: str = Depends(auth.mutation)):
    principal = await auth.require_account(request)
    identity.require_reauth(principal.account)  # type: ignore[arg-type]
    try:
        count = await db.execute(
            "UPDATE account_sessions SET revoked_at = now() WHERE id = %s AND account_id = %s AND revoked_at IS NULL",
            (session_id, principal.account_id))
    except Exception:  # noqa: BLE001 - malformed UUID
        count = 0
    if count != 1:
        raise not_found()
    return ok({"revoked": True})


@router.post("/me/password")
async def password(body: PasswordIn, request: Request, _: str = Depends(auth.mutation)):
    principal = await auth.require_account(request)
    result = await identity.change_password(principal.account, body.current_password, body.new_password)  # type: ignore[arg-type]
    resp = ok({"changed": True, "other_sessions_signed_out": True})
    auth.set_cookie(resp, auth.ACCOUNT, result["token"], int(identity.ACCOUNT_ABSOLUTE.total_seconds()))
    return resp


@router.post("/me/recovery/rotate")
async def rotate(body: RotateIn, request: Request, boot: str = Depends(auth.mutation)):
    principal = await auth.require_account(request)
    await identity.rotate_recovery(principal.account, boot, body.reservation_id, body.recovery_code, body.saved)  # type: ignore[arg-type]
    return ok({"rotated": True})


@router.get("/me/notices")
async def notices(request: Request, cursor: str | None = None):
    principal = await auth.require_account(request)
    params: list = [principal.account_id]
    where = ""
    if cursor:
        where = "AND issued_at < %s"
        params.append(cursor)
    rows = await db.fetch_all(
        f"""SELECT public_ref, kind, version, safe_payload, issued_at, seen_at FROM account_notices
            WHERE account_id = %s {where} ORDER BY issued_at DESC LIMIT 21""", params)
    items = [{"notice_ref": r["public_ref"], "kind": r["kind"], "version": r["version"], "payload": r["safe_payload"],
              "issued_at": r["issued_at"].isoformat(), "seen_at": r["seen_at"].isoformat() if r["seen_at"] else None}
             for r in rows[:20]]
    return ok({"items": items, "next_cursor": rows[19]["issued_at"].isoformat() if len(rows) > 20 else None})


@router.post("/me/notices/{ref}/seen")
async def notice_seen(ref: str, request: Request, _: str = Depends(auth.mutation)):
    principal = await auth.require_account(request)
    row = await db.fetch_one(
        """UPDATE account_notices SET seen_at = coalesce(seen_at, now())
           WHERE public_ref = %s AND account_id = %s RETURNING seen_at""", (ref, principal.account_id))
    if row is None:
        raise not_found()
    return ok({"seen_at": row["seen_at"].isoformat()})

