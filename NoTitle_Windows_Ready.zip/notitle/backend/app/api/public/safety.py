"""Reports: prepared server snapshots, selected evidence, report-and-block."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Literal
from uuid import UUID

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, ConfigDict, Field

from app import db
from app.http import auth, idempotency, ratelimit
from app.http.errors import ApiError, invalid, ok
from app.realtime.coordinator import CoordinatorError, coordinator
from app.security import crypto
from app.services import identity, keys, social, support

router = APIRouter(prefix="/api/v1/reports", tags=["safety"])

Reason = Literal["harassment", "threats", "doxxing", "confidentiality", "false_accusation", "scam",
                 "impersonation", "underage", "sexual_misconduct", "spam", "other"]


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class PrepareIn(Strict):
    interaction_id: str = Field(max_length=64)


class ReportIn(Strict):
    interaction_id: str = Field(max_length=64)
    snapshot_id: str | None = Field(default=None, max_length=64)
    selected_message_ids: list[str] = Field(default_factory=list, max_length=30)
    reason: Reason
    allegation: str = Field(default="", max_length=9000)
    block: bool = False
    client_nonce: UUID
    confirm_without_evidence: bool = False
    reservation_id: str | None = Field(default=None, max_length=80)
    receipt_secret: str | None = Field(default=None, max_length=100)
    saved: bool = False


@router.post("/prepare")
async def prepare(body: PrepareIn, request: Request, _: str = Depends(auth.mutation)):
    principal = await auth.require_principal(request)
    try:
        snap = coordinator.prepare_snapshot(principal.key, body.interaction_id)
    except CoordinatorError as exc:
        raise invalid("interaction_id", exc.message) from None
    return ok({
        "snapshot_id": snap.id,
        "expires_in": 120,
        "messages": [{k: m[k] for k in ("message_id", "mine", "body", "sent_at")} for m in snap.messages],
        "note": "Only messages you select are copied into a retained safety case. Audio is never recorded.",
    })


@router.post("")
async def submit(body: ReportIn, request: Request, boot: str = Depends(auth.mutation)):
    principal = await auth.require_principal(request)
    ratelimit.check("report", principal.key)
    if body.reason == "other" and not body.allegation.strip():
        raise invalid("allegation", "Please describe what happened when choosing Other.")
    allegation = support.check_body(body.allegation or f"Report: {body.reason}", "allegation")
    payload = body.model_dump(mode="json", exclude={"receipt_secret", "saved"})
    previous = await idempotency.lookup(principal.key, "report.create", str(body.client_nonce), payload)
    if previous:
        return ok(previous)

    snap = coordinator.take_snapshot(principal.key, body.snapshot_id) if body.snapshot_id else None
    subject_key = snap.subject if snap else coordinator.peer_key_for(principal.key, body.interaction_id)
    if subject_key is None:
        raise invalid("interaction_id", "This conversation can no longer be reported. Use Chat with Moderator instead.")
    if body.snapshot_id and snap is None and not body.confirm_without_evidence:
        raise ApiError(409, "evidence_expired",
                       "The message snapshot expired. Only your description and attribution would be saved. Submit anyway?")

    # 1. Safety fence first: block immediately, regardless of persistence outcome.
    block_result = None
    if body.block:
        block_result = await social.create_block(principal, subject_key)

    # 2. Unbound (guest) reporters need a saved case receipt.
    case_ref = secret = None
    if principal.kind != "account":
        if not body.reservation_id or not body.receipt_secret or not body.saved:
            raise ApiError(422, "receipt_required", "Save the case receipt before submitting.",
                           fields={"receipt": "Prepare and save a case receipt first."},
                           extra={"blocked": bool(block_result)})
        prep = identity.prepared.peek(body.reservation_id, f"boot:{boot}", "case_receipt", body.receipt_secret)
        case_ref, secret = prep.reference, prep.secret

    selected = set(body.selected_message_ids)
    evidence = [m for m in (snap.messages if snap else []) if m["message_id"] in selected]
    subject_kind = "account" if subject_key.startswith("a:") else "guest"
    subject_ref = (identity.subject_ref_for_account(subject_key[2:]) if subject_kind == "account"
                   else identity.subject_ref_for_guest(subject_key[2:]))
    try:
        async with db.transaction() as conn:
            case = await support.create_case(
                conn, account_id=principal.account_id, category="safety",
                subject=f"Safety report: {body.reason.replace('_', ' ')}", body=allegation,
                client_nonce=str(body.client_nonce), case_ref=case_ref, receipt_secret=secret,
                urgent=body.reason in support.URGENT_REASONS)
            key = await keys.new_key(conn, "evidence")
            report_ref = crypto.new_ref("rp")
            row = await (await conn.execute(
                """INSERT INTO reports (public_ref, reporter_kind, reporter_ref, subject_kind, subject_ref,
                                        subject_account_id, interaction_ref, reason, allegation_ct, key_id, case_id,
                                        blocked, evidence_state)
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s, '\\x00'::bytea, %s, %s, %s, %s) RETURNING id""",
                (report_ref, principal.kind, principal.subject_ref, subject_kind, subject_ref,
                 subject_key[2:] if subject_kind == "account" else None, body.interaction_id, body.reason,
                 key.id, case["case_id"], bool(block_result), "server_snapshot" if evidence else "allegation_only"))).fetchone()
            report_id = str(row["id"])
            await conn.execute("UPDATE reports SET allegation_ct = %s WHERE id = %s",
                               (key.encrypt(allegation, f"reports|{report_id}|allegation"), report_id))
            await conn.execute("UPDATE support_cases SET related_ref = %s WHERE id = %s", (report_ref, case["case_id"]))
            for m in evidence:
                await conn.execute(
                    """INSERT INTO report_evidence (report_id, server_message_id, sender_role, sent_at, body_ct)
                       VALUES (%s, %s, %s, %s, %s)""",
                    (report_id, m["message_id"], m["sender_role"], datetime.fromisoformat(m["sent_at"]),
                     key.encrypt(m["body"], f"report_evidence|{report_id}|{m['message_id']}")))
            result = {
                "report_ref": report_ref,
                "case_ref": case["case_ref"],
                "evidence_state": "server_snapshot" if evidence else "allegation_only",
                "evidence_count": len(evidence),
                "blocked": bool(block_result),
                "submitted_at": datetime.now(timezone.utc).isoformat(),
            }
            await idempotency.store(conn, principal.key, "report.create", str(body.client_nonce), payload, result)
    except ApiError:
        raise
    except Exception:  # noqa: BLE001 - persistence failure: fence stays, say Not submitted
        import logging

        logging.getLogger("notitle.safety").exception("report persistence failed")
        raise ApiError(503, "not_submitted",
                       "Not submitted. Your block is still active; you can retry safely.", retryable=True,
                       extra={"blocked": bool(block_result)}) from None
    if body.snapshot_id:
        coordinator.drop_snapshot(body.snapshot_id)
    if body.reservation_id:
        identity.prepared.consume(body.reservation_id)
    resp = ok(result, status=201)
    if principal.kind != "account" and case_ref and secret:
        token = await support.open_receipt_session("case", case_ref, secret)
        auth.set_cookie(resp, auth.SUPPORT, token, int(support.SUPPORT_ABSOLUTE.total_seconds()))
    return resp
