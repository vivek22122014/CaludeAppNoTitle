"""Private staff API (served only on the private listener under /internal/v1)."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Literal
from uuid import UUID

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, ConfigDict, Field

from app import db, migrations
from app.config import get_settings
from app.http import ratelimit
from app.http.auth import cookie, csrf_for, set_cookie, clear_cookie
from app.http.errors import ApiError, invalid, not_found, ok, unauthenticated
from app.realtime.coordinator import coordinator
from app.security import crypto
from app.services import analytics, billing, jobs, moderation, privacy, staff, support
from app.services.journal import journal

router = APIRouter(prefix="/internal/v1", tags=["staff"])

ADMIN = "nt_admin"
ADMIN_BOOT = "nt_admin_boot"
PURPOSES = ("case_handling", "safety_review", "billing_review", "privacy_request", "legal_obligation", "appeal_review")


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class LoginIn(Strict):
    username: str = Field(max_length=64)
    password: str = Field(max_length=600)
    totp: str = Field(max_length=12)


class RecoveryIn(Strict):
    username: str = Field(max_length=64)
    password: str = Field(max_length=600)
    recovery_code: str = Field(max_length=60)


class StepUpIn(Strict):
    totp: str = Field(max_length=12)


class Versioned(Strict):
    expected_version: int


class AssignIn(Strict):
    expected_version: int
    staff_username: str | None = Field(default=None, max_length=64)
    reason: str = Field(max_length=400)


class StatusIn(Strict):
    expected_version: int
    target_status: Literal["open", "in_progress", "waiting_user", "resolved", "closed"]
    reason: str = Field(max_length=400)


class MessageIn(Strict):
    body: str = Field(max_length=9000)
    client_nonce: UUID


class NoteIn(Strict):
    body: str = Field(max_length=9000)


class SeenIn(Strict):
    seen_through: int = Field(ge=0)


class ObligationIn(Strict):
    obligation_id: str = Field(max_length=64)
    outcome: str = Field(max_length=400)
    evidence_ref: str = Field(max_length=200)


class DecisionIn(Strict):
    report_ref: str = Field(max_length=64)
    action: Literal["dismiss", "warn", "suspend", "ban"]
    reason_code: str = Field(max_length=64)
    duration_hours: int | None = Field(default=None, ge=1, le=2160)


class ConfirmIn(Strict):
    nonce: str = Field(max_length=64)
    totp: str = Field(max_length=12)


class AppealIn(Strict):
    outcome: Literal["upheld", "overturned"]
    reason: str = Field(max_length=400)


class RefundPreviewIn(Strict):
    purchase_ref: str = Field(max_length=64)
    amount_paise: int = Field(ge=1)
    revoke_seconds: int = Field(ge=0)
    remedy_basis: Literal["payment_error", "statutory_remedy", "provider_bank_direction"]
    evidence_ref: str = Field(min_length=3, max_length=200)
    reason: str = Field(min_length=3, max_length=400)


class HoldPreviewIn(Strict):
    target: str = Field(max_length=64)
    scope: Literal["account_profile", "support_cases", "safety_reports", "financial", "all"]
    basis: str = Field(min_length=5, max_length=400)
    review_days: int = Field(ge=1, le=365)


class HoldReleaseIn(Strict):
    reason: str = Field(min_length=3, max_length=400)


class PrivacyStatusIn(Strict):
    status: Literal["in_review", "completed", "rejected"]


class StaffCreateIn(Strict):
    username: str = Field(max_length=32)
    password: str = Field(max_length=600)
    roles: list[Literal["owner", "moderator", "billing", "privacy", "analyst"]]


class RolesIn(Strict):
    roles: list[Literal["owner", "moderator", "billing", "privacy", "analyst"]]


# ---------------------------------------------------------------------------
# Auth plumbing
# ---------------------------------------------------------------------------


def _boot(request: Request) -> tuple[str, bool]:
    value = cookie(request, ADMIN_BOOT)
    if value and len(value) >= 30:
        return value, False
    return crypto.new_token(), True


def csrf(request: Request) -> None:
    value = cookie(request, ADMIN_BOOT)
    supplied = request.headers.get("x-csrf-token", "")
    if not value or not supplied or not crypto.constant_equals(supplied, csrf_for("admin:" + value)):
        raise ApiError(403, "csrf_failed", "Your page session expired. Reload and try again.")


async def current_staff(request: Request) -> dict:
    found = await staff.resolve(cookie(request, ADMIN))
    if found is None:
        raise unauthenticated("Staff sign-in required.")
    return found


def grant(permission: str):
    async def dep(request: Request) -> dict:
        s = await current_staff(request)
        staff.require(s, permission)
        return s
    return dep


def _staff_dto(s: dict) -> dict:
    return {"username": s["username"], "permissions": s["permissions"],
            "mfa_fresh_until": (s["mfa_at"] + staff.FRESH_MFA).isoformat()}


@router.get("/bootstrap")
async def bootstrap(request: Request):
    boot, new = _boot(request)
    found = await staff.resolve(cookie(request, ADMIN))
    resp = ok({"csrf_token": csrf_for("admin:" + boot), "staff": _staff_dto(found) if found else None,
               "server_time": datetime.now(timezone.utc).isoformat(), "environment": get_settings().app_env})
    if new:
        set_cookie(resp, ADMIN_BOOT, boot, 4 * 3600)
    return resp


@router.post("/auth/login")
async def login(body: LoginIn, request: Request, _: None = Depends(csrf)):
    ratelimit.check("staff_login", request.client.host if request.client else "unknown")
    token = await staff.login(body.username, body.password, body.totp)
    found = await staff.resolve(token)
    resp = ok({"staff": _staff_dto(found)})  # type: ignore[arg-type]
    set_cookie(resp, ADMIN, token, int(staff.ABSOLUTE.total_seconds()))
    return resp


@router.post("/auth/recovery")
async def recovery(body: RecoveryIn, request: Request, _: None = Depends(csrf)):
    ratelimit.check("staff_login", request.client.host if request.client else "unknown")
    token = await staff.recovery_login(body.username, body.password, body.recovery_code)
    found = await staff.resolve(token)
    resp = ok({"staff": _staff_dto(found), "note": "A recovery code was consumed. Re-enrol your authenticator soon."})  # type: ignore[arg-type]
    set_cookie(resp, ADMIN, token, int(staff.ABSOLUTE.total_seconds()))
    return resp


@router.post("/auth/step-up")
async def step_up(body: StepUpIn, request: Request, _: None = Depends(csrf)):
    s = await current_staff(request)
    await staff.step_up(s, body.totp)
    return ok(_staff_dto(s))


@router.post("/auth/logout")
async def logout(request: Request, _: None = Depends(csrf)):
    s = await staff.resolve(cookie(request, ADMIN))
    if s:
        await staff.logout(s)
    resp = ok({"signed_out": True})
    clear_cookie(resp, ADMIN)
    return resp


# ---------------------------------------------------------------------------
# Cases
# ---------------------------------------------------------------------------


@router.get("/cases")
async def cases(request: Request, status: str | None = None, category: str | None = None,
                assigned: str | None = None, cursor: str | None = None, limit: int = 30):
    s = await grant("cases.queue")(request)
    if status and status not in support.STAFF_STATUSES:
        raise invalid("status", "Unknown status.")
    if category and category not in ("general", "payment", "safety", "privacy", "appeal", "security"):
        raise invalid("category", "Unknown category.")
    return ok(await support.staff_queue(status, category, assigned, str(s["id"]), cursor, limit))


@router.get("/cases/{ref}")
async def case_detail(ref: str, request: Request):
    await grant("cases.read")(request)
    data = await support.staff_case_summary(ref)
    return ok(data["summary"])


@router.get("/cases/{ref}/messages")
async def case_messages(ref: str, request: Request, purpose: str, after_sequence: int = 0,
                        before_sequence: int | None = None, limit: int = 50):
    s = await grant("cases.read")(request)
    if purpose not in PURPOSES:
        raise invalid("purpose", "Choose a purpose for reading this case.")
    case = await db.fetch_one("SELECT * FROM support_cases WHERE public_ref = %s", (ref,))
    if case is None:
        raise not_found()
    page = await support.messages(case, after_sequence, before_sequence, limit, "staff")
    if page["items"]:
        # Audit commits before any plaintext leaves the service; failure denies access.
        await support.audited_read(str(s["id"]), purpose, "case_messages", ref,
                                   f"read:{page['items'][0]['sequence']}-{page['items'][-1]['sequence']}")
    return ok(page)


@router.post("/cases/{ref}/seen")
async def case_seen(ref: str, body: SeenIn, request: Request, _: None = Depends(csrf)):
    await grant("cases.read")(request)
    case = await db.fetch_one("SELECT * FROM support_cases WHERE public_ref = %s", (ref,))
    if case is None:
        raise not_found()
    return ok({"seen_staff_sequence": await support.mark_seen(case, body.seen_through, "staff")})


@router.post("/cases/{ref}/claim")
async def claim(ref: str, body: Versioned, request: Request, _: None = Depends(csrf)):
    s = await grant("cases.claim")(request)
    return ok(await support.staff_claim(ref, str(s["id"]), body.expected_version))


@router.post("/cases/{ref}/assignment")
async def assign(ref: str, body: AssignIn, request: Request, _: None = Depends(csrf)):
    s = await grant("cases.assign")(request)
    return ok(await support.staff_assign(ref, str(s["id"]), body.staff_username, body.expected_version, body.reason))


@router.post("/cases/{ref}/status")
async def case_status(ref: str, body: StatusIn, request: Request, _: None = Depends(csrf)):
    s = await grant("cases.manage")(request)
    return ok(await support.staff_status(ref, str(s["id"]), body.target_status, body.expected_version, body.reason))


@router.post("/cases/{ref}/messages")
async def reply(ref: str, body: MessageIn, request: Request, _: None = Depends(csrf)):
    s = await grant("cases.reply")(request)

    async def recheck(conn, case):  # role may have been revoked while the page was open
        fresh = await staff.resolve(cookie(request, ADMIN))
        if fresh is None or "cases.reply" not in fresh["permissions"]:
            raise ApiError(403, "forbidden", "Your permissions changed.")

    result, created = await support.post_message(ref, sender_kind="staff", sender_ref=str(s["id"]), body=body.body,
                                                 client_nonce=str(body.client_nonce), staff_check=recheck)
    await support.audited_read(str(s["id"]), "case_handling", "case", ref, "reply")
    return ok(result, status=201 if created else 200)


@router.get("/cases/{ref}/notes")
async def notes(ref: str, request: Request):
    s = await grant("cases.notes")(request)
    case = await db.fetch_one("SELECT id, key_id FROM support_cases WHERE public_ref = %s", (ref,))
    if case is None:
        raise not_found()
    items = await support.staff_notes(case["id"], case["key_id"])
    if items:
        await support.audited_read(str(s["id"]), "case_handling", "case_notes", ref, "read_notes")
    return ok({"items": items})


@router.post("/cases/{ref}/notes")
async def add_note(ref: str, body: NoteIn, request: Request, _: None = Depends(csrf)):
    s = await grant("cases.notes")(request)
    case = await db.fetch_one("SELECT * FROM support_cases WHERE public_ref = %s", (ref,))
    if case is None:
        raise not_found()
    return ok(await support.staff_add_note(case, str(s["id"]), body.body), status=201)


@router.post("/cases/{ref}/obligations/complete")
async def complete_obligation(ref: str, body: ObligationIn, request: Request, _: None = Depends(csrf)):
    s = await grant("cases.legal")(request)
    case = await db.fetch_one("SELECT * FROM support_cases WHERE public_ref = %s", (ref,))
    if case is None:
        raise not_found()
    return ok(await support.complete_obligation(case, body.obligation_id, str(s["id"]), body.outcome, body.evidence_ref))


# ---------------------------------------------------------------------------
# Reports, decisions, appeals
# ---------------------------------------------------------------------------


@router.get("/reports")
async def reports(request: Request):
    await grant("reports.read")(request)
    rows = await db.fetch_all(
        """SELECT r.public_ref, r.reason, r.evidence_state, r.blocked, r.submitted_at, r.subject_kind,
                  c.public_ref AS case_ref, c.status, c.urgent,
                  (SELECT count(*) FROM moderation_decisions d WHERE d.report_id = r.id) AS decisions
           FROM reports r JOIN support_cases c ON c.id = r.case_id ORDER BY c.urgent DESC, r.submitted_at DESC LIMIT 100""")
    return ok({"items": [{**r, "submitted_at": r["submitted_at"].isoformat()} for r in rows]})


@router.get("/reports/{ref}")
async def report_read(ref: str, request: Request, purpose: str):
    s = await grant("reports.read")(request)
    if purpose not in PURPOSES:
        raise invalid("purpose", "Choose a purpose.")
    await support.audited_read(str(s["id"]), purpose, "report", ref, "read_evidence")
    return ok(await moderation.read_report(ref))


@router.post("/decisions/preview")
async def decision_preview(body: DecisionIn, request: Request, _: None = Depends(csrf)):
    s = await grant("decisions.make")(request)
    moderation.validate_decision(body.action, body.duration_hours)
    await moderation.decision_target(body.report_ref)
    payload = body.model_dump()
    return ok(await staff.create_preview(s, "decision", body.report_ref, payload, {
        "action": body.action, "reason_code": body.reason_code, "duration_hours": body.duration_hours,
        "effect": {"dismiss": "No restriction.", "warn": "A safety notice is sent; no restriction.",
                   "suspend": f"Matching is restricted for {body.duration_hours} hours.",
                   "ban": "Matching is restricted indefinitely (appealable)."}[body.action]}))


@router.post("/decisions/confirm")
async def decision_confirm(body: ConfirmIn, request: Request, _: None = Depends(csrf)):
    s = await grant("decisions.make")(request)
    await staff.step_up(s, body.totp)
    async with db.transaction() as conn:
        preview = await staff.consume_preview(conn, s, body.nonce, "decision")
        payload = preview["payload"]
        report = await moderation.decision_target(payload["report_ref"])
        result = await moderation.apply_decision(conn, str(s["id"]), report, payload["action"], payload["reason_code"],
                                                 payload.get("duration_hours"))
    moderation.fence_subject(report, payload["action"], result["ends_at"])
    await support.audited_read(str(s["id"]), "safety_review", "report", payload["report_ref"], f"decision:{payload['action']}")
    result.pop("decision_id")
    return ok(result)


@router.post("/appeals/{decision_ref}/resolve")
async def appeal(decision_ref: str, body: AppealIn, request: Request, _: None = Depends(csrf)):
    s = await grant("appeals.review")(request)
    staff.require_fresh_mfa(s)
    result = await moderation.resolve_appeal(str(s["id"]), decision_ref, body.outcome, body.reason)
    await support.audited_read(str(s["id"]), "appeal_review", "decision", decision_ref, f"appeal:{body.outcome}")
    return ok(result)


# ---------------------------------------------------------------------------
# Billing
# ---------------------------------------------------------------------------


@router.get("/billing/purchases")
async def billing_purchases(request: Request, state: str | None = None):
    await grant("billing.read")(request)
    return ok({"items": await billing.staff_purchases(state)})


@router.get("/billing/refunds")
async def billing_refunds(request: Request):
    await grant("billing.read")(request)
    return ok({"items": await billing.staff_refunds()})


@router.post("/billing/purchases/{ref}/reconcile")
async def billing_reconcile(ref: str, request: Request, _: None = Depends(csrf)):
    await grant("billing.read")(request)
    row = await db.fetch_one("SELECT id FROM purchases WHERE public_ref = %s", (ref,))
    if row is None:
        raise not_found()
    return ok({"state": await billing.reconcile(str(row["id"]))})


@router.post("/billing/refunds/preview")
async def refund_preview(body: RefundPreviewIn, request: Request, _: None = Depends(csrf)):
    s = await grant("billing.remedy")(request)
    data = await billing.remedy_preview_data(body.purchase_ref, body.amount_paise, body.revoke_seconds, body.remedy_basis)
    return ok(await staff.create_preview(s, "refund", body.purchase_ref, body.model_dump(), {
        "purchase_ref": body.purchase_ref, "amount_paise": body.amount_paise,
        "remaining_refundable_paise": data["remaining_money"], "revoke_seconds": body.revoke_seconds,
        "max_revocable_seconds": data["max_revoke"], "remedy_basis": body.remedy_basis,
        "rule": "Required remedies only – no voluntary refunds. Only the origin purchase's time is affected."}))


@router.post("/billing/refunds/confirm")
async def refund_confirm(body: ConfirmIn, request: Request, _: None = Depends(csrf)):
    s = await grant("billing.remedy")(request)
    await staff.step_up(s, body.totp)
    async with db.transaction() as conn:
        preview = await staff.consume_preview(conn, s, body.nonce, "refund")
        result = await billing.execute_remedy(conn, str(s["id"]), preview["payload"])
        await jobs.enqueue(conn, "refund.submit", f"refund:{result['refund_id']}:initial", {"refund_id": result["refund_id"]})
    state = await billing.submit_refund(result["refund_id"])
    await support.audited_read(str(s["id"]), "billing_review", "purchase", preview["object_ref"], "refund_confirm")
    return ok({"refund_ref": result["refund_ref"], "state": state, "held_seconds": result["held_seconds"]})


# ---------------------------------------------------------------------------
# Privacy
# ---------------------------------------------------------------------------


@router.get("/privacy/requests")
async def privacy_requests(request: Request):
    await grant("privacy.manage")(request)
    return ok({"items": await privacy.staff_requests(), "deletions": await privacy.staff_deletions()})


@router.post("/privacy/requests/{ref}/status")
async def privacy_request_status(ref: str, body: PrivacyStatusIn, request: Request, _: None = Depends(csrf)):
    await grant("privacy.manage")(request)
    return ok(await privacy.staff_set_request_status(ref, body.status))


@router.get("/privacy/holds")
async def holds(request: Request):
    await grant("privacy.manage")(request)
    return ok({"items": await privacy.list_holds()})


@router.post("/privacy/holds/preview")
async def hold_preview(body: HoldPreviewIn, request: Request, _: None = Depends(csrf)):
    s = await grant("privacy.manage")(request)
    subject_ref = await privacy.subject_ref_for_target(body.target)
    review_at = datetime.now(timezone.utc) + timedelta(days=body.review_days)
    payload = {"subject_ref": subject_ref, "scope": body.scope, "basis": body.basis, "review_at": review_at.isoformat()}
    return ok(await staff.create_preview(s, "hold", subject_ref, payload, {
        **payload, "effect": "Matching purges for this scope pause until the hold is released."}))


@router.post("/privacy/holds/confirm")
async def hold_confirm(body: ConfirmIn, request: Request, _: None = Depends(csrf)):
    s = await grant("privacy.manage")(request)
    await staff.step_up(s, body.totp)
    async with db.transaction() as conn:
        preview = await staff.consume_preview(conn, s, body.nonce, "hold")
        result = await privacy.place_hold(conn, str(s["id"]), preview["payload"])
    await support.audited_read(str(s["id"]), "legal_obligation", "hold", result["hold_ref"], "hold_placed")
    return ok(result)


@router.post("/privacy/holds/{ref}/release")
async def hold_release(ref: str, body: HoldReleaseIn, request: Request, _: None = Depends(csrf)):
    s = await grant("privacy.manage")(request)
    staff.require_fresh_mfa(s)
    async with db.transaction() as conn:
        result = await privacy.release_hold(conn, ref)
    await support.audited_read(str(s["id"]), "legal_obligation", "hold", ref, "hold_released")
    return ok(result)


# ---------------------------------------------------------------------------
# Analytics, audit, staff, health
# ---------------------------------------------------------------------------


@router.get("/analytics/summary")
async def analytics_summary(request: Request):
    await grant("analytics.read")(request)
    return ok(await analytics.summary())


@router.get("/analytics/series")
async def analytics_series(request: Request, metric_id: int, start: datetime, end: datetime, resolution: str = "hour"):
    await grant("analytics.read")(request)
    try:
        return ok(await analytics.series(metric_id, start, end, resolution))
    except ValueError as exc:
        raise invalid("metric_id", str(exc)) from None


@router.get("/analytics/catalog")
async def analytics_catalog(request: Request):
    await grant("analytics.read")(request)
    return ok({"metrics": [{"id": code, "name": name, "kind": kind} for name, (code, kind) in analytics.METRICS.items()]})


@router.get("/audit")
async def audit_log(request: Request, cursor: int | None = None, action: str | None = None):
    await grant("audit.read")(request)
    clauses, params = [], []
    if cursor:
        clauses.append("id < %s")
        params.append(cursor)
    if action:
        clauses.append("action LIKE %s")
        params.append(action[:40] + "%")
    where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
    rows = await db.fetch_all(
        f"""SELECT id, actor_ref, purpose, object_type, object_ref, action, decision, request_id, created_at
            FROM access_audit {where} ORDER BY id DESC LIMIT 51""", params)
    return ok({"items": [{**r, "created_at": r["created_at"].isoformat()} for r in rows[:50]],
               "next_cursor": rows[49]["id"] if len(rows) > 50 else None})


@router.get("/staff")
async def staff_list(request: Request):
    await grant("staff.manage")(request)
    return ok({"items": await staff.list_staff(), "roles": {k: list(v) for k, v in staff.ROLES.items()}})


@router.post("/staff")
async def staff_create(body: StaffCreateIn, request: Request, _: None = Depends(csrf)):
    s = await grant("staff.manage")(request)
    staff.require_fresh_mfa(s)
    result = await staff.create_staff(body.username, body.password, list(body.roles))
    await support.audited_read(str(s["id"]), "case_handling", "staff", result["username"], "staff_create")
    result.pop("staff_id")
    return ok({**result, "warning": "Shown once. Hand the TOTP secret and recovery codes over securely."}, status=201)


@router.post("/staff/{username}/roles")
async def staff_roles(username: str, body: RolesIn, request: Request, _: None = Depends(csrf)):
    s = await grant("staff.manage")(request)
    staff.require_fresh_mfa(s)
    result = await staff.set_roles(username, list(body.roles))
    await support.audited_read(str(s["id"]), "case_handling", "staff", username, "roles_changed")
    return ok(result)


@router.get("/health")
async def health(request: Request):
    await grant("release.read")(request)
    s = get_settings()
    db_ok = await db.ping()
    migration_state = []
    try:
        migration_state = migrations.status(s.database_url)
    except Exception:  # noqa: BLE001
        pass
    overdue = await db.fetch_one("SELECT count(*) AS n FROM case_obligations WHERE status = 'overdue'")
    pending = await db.fetch_one("SELECT count(*) AS n FROM purchases WHERE state IN ('pending','needs_review')")
    backup_dir = s.data_path / "backups"
    backups = sorted(backup_dir.glob("*.sql")) if backup_dir.exists() else []
    return ok({
        "database": "ok" if db_ok else "unavailable",
        "migrations": migration_state,
        "owner_epoch": coordinator.owner_epoch,
        "runtime": coordinator.counts(),
        "jobs": await jobs.backlog(),
        "journal": journal.status(),
        "overdue_obligations": int(overdue["n"]) if overdue else None,
        "payments_needing_attention": int(pending["n"]) if pending else None,
        "latest_backup": backups[-1].name if backups else None,
        "gates": {"admission": s.admission_open, "audio": s.audio_enabled, "audio_relay_only": s.audio_require_relay,
                  "payments": billing.sales_open(), "payment_provider": s.payment_provider,
                  "annual365": False, "policies": "draft"},
        "environment": s.app_env,
    })
