"""Checksummed, forward-only SQL migrations.

* Files live in ``backend/migrations/NNNN_name.sql`` and are applied in order.
* Each file runs inside one transaction while the migrator holds a dedicated
  advisory lock, so two migrators can never interleave.
* The SHA-256 of every applied file is recorded; editing an applied migration
  is detected and refused (fix forward with a new file instead).
* The web runtime never applies migrations automatically; it only *verifies*
  that the database contains exactly the packaged set before opening listeners.
"""

from __future__ import annotations

import hashlib
import logging
from dataclasses import dataclass
from pathlib import Path

import psycopg

from app.config import BACKEND_DIR

log = logging.getLogger("notitle.migrations")

MIGRATIONS_DIR = BACKEND_DIR / "migrations"
MIGRATION_LOCK_ID = 7_331_001  # pg_advisory_lock key reserved for migrations


@dataclass(frozen=True)
class Migration:
    id: str
    path: Path
    sql: str
    checksum: str


def packaged() -> list[Migration]:
    items = []
    for path in sorted(MIGRATIONS_DIR.glob("[0-9][0-9][0-9][0-9]_*.sql")):
        raw = path.read_bytes()
        # Normalise line endings so a Git checkout with CRLF has the same checksum.
        normalised = raw.replace(b"\r\n", b"\n")
        items.append(
            Migration(
                id=path.stem,
                path=path,
                sql=normalised.decode("utf-8"),
                checksum=hashlib.sha256(normalised).hexdigest(),
            )
        )
    return items


class MigrationError(RuntimeError):
    pass


def _ensure_table(conn: psycopg.Connection) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS schema_migrations (
            id text PRIMARY KEY,
            checksum text NOT NULL CHECK (length(checksum) = 64),
            applied_at timestamptz NOT NULL DEFAULT now()
        )
        """
    )


def applied(conn: psycopg.Connection) -> dict[str, str]:
    exists = conn.execute("SELECT to_regclass('public.schema_migrations') IS NOT NULL").fetchone()[0]
    if not exists:
        return {}
    return {row[0]: row[1] for row in conn.execute("SELECT id, checksum FROM schema_migrations ORDER BY id")}


def status(url: str) -> list[dict]:
    with psycopg.connect(url) as conn:
        done = applied(conn)
    return [
        {
            "id": m.id,
            "applied": m.id in done,
            "checksum_ok": (done.get(m.id) == m.checksum) if m.id in done else None,
        }
        for m in packaged()
    ]


def migrate(url: str, app_role: str | None = None) -> list[str]:
    """Apply pending migrations.  Returns the IDs applied in this run."""
    migrations = packaged()
    newly: list[str] = []
    with psycopg.connect(url, autocommit=True) as conn:
        conn.execute("SELECT pg_advisory_lock(%s)", (MIGRATION_LOCK_ID,))
        try:
            _ensure_table(conn)
            done = applied(conn)
            known = {m.id for m in migrations}
            unknown = sorted(set(done) - known)
            if unknown:
                raise MigrationError(f"database has migrations this release does not know: {unknown}")
            for m in migrations:
                if m.id in done:
                    if done[m.id] != m.checksum:
                        raise MigrationError(
                            f"checksum mismatch for applied migration {m.id}; never edit applied migrations"
                        )
                    continue
                log.info("applying migration %s", m.id)
                with conn.transaction():
                    conn.execute(m.sql)
                    conn.execute(
                        "INSERT INTO schema_migrations (id, checksum) VALUES (%s, %s)", (m.id, m.checksum)
                    )
                newly.append(m.id)
            if app_role:
                grant_runtime_role(conn, app_role)
        finally:
            conn.execute("SELECT pg_advisory_unlock(%s)", (MIGRATION_LOCK_ID,))
    return newly


def grant_runtime_role(conn: psycopg.Connection, role: str) -> None:
    """Runtime role gets DML only – it cannot create, alter or drop schema objects."""
    from psycopg import sql

    ident = sql.Identifier(role)
    conn.execute(sql.SQL("GRANT USAGE ON SCHEMA public TO {}").format(ident))
    conn.execute(
        sql.SQL("GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO {}").format(ident)
    )
    conn.execute(sql.SQL("GRANT USAGE, SELECT, UPDATE ON ALL SEQUENCES IN SCHEMA public TO {}").format(ident))
    # Migration history is readable but not writable by the runtime.
    conn.execute(sql.SQL("REVOKE INSERT, UPDATE, DELETE ON schema_migrations FROM {}").format(ident))


def verify_runtime(conn_url: str) -> None:
    """Refuse to start when the database schema differs from the packaged set."""
    with psycopg.connect(conn_url) as conn:
        done = applied(conn)
    missing = [m.id for m in packaged() if m.id not in done]
    if missing:
        raise MigrationError(
            f"database is missing migrations {missing}. Run: scripts\\migrate.ps1 (or python -m app.cli migrate)"
        )
    for m in packaged():
        if done[m.id] != m.checksum:
            raise MigrationError(f"checksum mismatch for {m.id}")
    extra = sorted(set(done) - {m.id for m in packaged()})
    if extra:
        raise MigrationError(f"database is newer than this release (unknown migrations {extra})")
