import { execFileSync } from "node:child_process";
import path from "node:path";

import { type Browser, type BrowserContext, type Page, expect } from "@playwright/test";

export const BACKEND = path.resolve(__dirname, "..", "..", "backend");
export const PRIVATE = process.env.E2E_PRIVATE_URL ?? "http://localhost:8081";

export async function newIdentity(browser: Browser): Promise<{ context: BrowserContext; page: Page }> {
  const context = await browser.newContext({ permissions: ["microphone"] });
  const page = await context.newPage();
  return { context, page };
}

export async function joinAsGuest(page: Page, gender: "Male" | "Female" | "Other" = "Male", topic = "Salaries and compensation") {
  await page.goto("/join/");
  await page.getByLabel("Declared gender (shown to peers)").selectOption({ label: gender });
  await page.getByLabel("Topic you want to talk about").selectOption({ label: topic });
  await page.getByLabel("I am 18 or older.").check();
  await page.getByRole("checkbox", { name: /I accept the Terms of Service/ }).check();
  await page.getByRole("checkbox", { name: /I agree to the processing needed/ }).check();
  await page.getByRole("button", { name: "Continue as guest" }).click();
  await expect(page).toHaveURL(/\/chat\/$/);
  await expect(page.getByRole("button", { name: "Search" })).toBeEnabled();
}

export async function matchPair(a: Page, b: Page) {
  await a.getByRole("button", { name: "Search" }).click();
  await expect(a.getByText("Searching for someone to talk to")).toBeVisible();
  await b.getByRole("button", { name: "Search" }).click();
  await expect(a.getByRole("button", { name: "End", exact: true })).toBeVisible();
  await expect(b.getByRole("button", { name: "End", exact: true })).toBeVisible();
}

export async function sendMessage(page: Page, text: string) {
  const box = page.getByRole("textbox", { name: "Message" });
  await box.fill(text);
  await box.press("Enter");
}

export function devTotp(username = "admin"): string {
  const python = path.join(BACKEND, ".venv", "Scripts", "python.exe");
  return execFileSync(python, ["-m", "app.cli", "dev-totp", "--username", username], { cwd: BACKEND, encoding: "utf-8" }).trim();
}

export function randomName(prefix = "e2e"): string {
  return `${prefix}${Math.random().toString(36).slice(2, 10)}`;
}
