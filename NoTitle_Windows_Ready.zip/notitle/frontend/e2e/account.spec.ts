import { expect, test, type Page } from "@playwright/test";

import { newIdentity, randomName } from "./helpers";

const PASSWORD = "correct horse battery staple";

async function register(page: Page, username: string) {
  await page.goto("/register/");
  await page.getByLabel("Username (private, used to sign in)").fill(username);
  await page.getByLabel("Password", { exact: true }).fill(PASSWORD);
  await page.getByLabel("Confirm password").fill(PASSWORD);
  await page.getByLabel("Display name (shown to peers)").fill("Tester " + username.slice(-4));
  await page.getByLabel("Declared gender").selectOption("other");
  await page.getByLabel("I am 18 or older.").check();
  await page.getByRole("checkbox", { name: /I accept the Terms of Service/ }).check();
  await page.getByRole("checkbox", { name: /I agree to the processing needed/ }).check();
  await page.getByRole("button", { name: "Continue" }).click();
  await expect(page.getByRole("heading", { name: "Your recovery code" })).toBeVisible();
  await page.getByRole("button", { name: "Reveal" }).click();
  const code = (await page.locator(".secret-value code").innerText()).trim();
  await page.getByLabel("I have saved my recovery code somewhere safe.").check();
  await page.getByRole("button", { name: "Create account" }).click();
  await expect(page).toHaveURL(/\/chat\/$/);
  return code;
}

test("register, sign out, sign in, edit profile", async ({ browser }) => {
  const { page, context } = await newIdentity(browser);
  const username = randomName("acct");
  const code = await register(page, username);
  expect(code).toMatch(/^[A-Z0-9]{4}(-[A-Z0-9]{4}){12}$/);

  await page.goto("/profile/");
  await page.getByLabel("Bio (optional)").fill("I work in product.");
  await page.getByRole("button", { name: "Save profile" }).click();
  await expect(page.getByText("Saved. Changes apply to your next conversation")).toBeVisible();

  await page.goto("/settings/");
  await page.getByRole("button", { name: "Sign out", exact: true }).click();
  await expect(page).toHaveURL(/\/$/);
  await page.goto("/login/");
  await page.getByLabel("Username").fill(username);
  await page.getByLabel("Password").fill("wrong password value");
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page.getByText("Username or password is incorrect.")).toBeVisible();
  await page.getByLabel("Password").fill(PASSWORD);
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page).toHaveURL(/\/chat\/$/);
  await context.close();
});

test("buy a Premium pass with the payment simulator", async ({ browser }) => {
  const { page, context } = await newIdentity(browser);
  await register(page, randomName("buyer"));
  await page.goto("/premium/");
  await page.getByRole("link", { name: "Choose 3-day pass" }).click();
  await page.getByLabel("Mobile number for the payment provider").fill("9876543210");
  await page.getByRole("checkbox", { name: /no voluntary refunds/ }).check();
  await page.getByRole("button", { name: /Pay ₹99/ }).click();
  await expect(page.getByRole("heading", { name: "Simulated payment" })).toBeVisible();
  await page.getByRole("button", { name: /Pay ₹99/ }).click();
  await expect(page.getByText("Payment verified")).toBeVisible();
  await page.goto("/account/premium/");
  await expect(page.getByRole("heading", { name: "Premium is active" })).toBeVisible();
  await page.goto("/account/receipts/");
  await expect(page.getByText(/3-day pass/)).toBeVisible();
  await context.close();
});

test("policy pages render without JavaScript and unknown pages are real 404s", async ({ request }) => {
  const policy = await request.get("/privacy/");
  expect(policy.status()).toBe(200);
  expect(await policy.text()).toContain("We do not save ordinary chat history.");
  expect(policy.headers()["content-security-policy"]).toContain("script-src 'self' 'sha256-");
  const missing = await request.get("/no-such-page/");
  expect(missing.status()).toBe(404);
});
