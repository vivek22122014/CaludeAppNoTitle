import { expect, test } from "@playwright/test";

import { joinAsGuest, matchPair, newIdentity, sendMessage } from "./helpers";

test("two guests match, chat with delivery state, and End clears text", async ({ browser }) => {
  const A = await newIdentity(browser);
  const B = await newIdentity(browser);
  await joinAsGuest(A.page, "Female");
  await joinAsGuest(B.page, "Male");
  await matchPair(A.page, B.page);

  await sendMessage(A.page, "Hello from A");
  await expect(B.page.getByRole("log", { name: "Messages" })).toContainText("Hello from A");
  await expect(A.page.getByText(/Delivered/)).toBeVisible();

  // Shift+Enter inserts a line break instead of sending.
  const box = B.page.getByRole("textbox", { name: "Message" });
  await box.fill("line one");
  await box.press("Shift+Enter");
  await box.pressSequentially("line two");
  await box.press("Enter");
  await expect(A.page.getByRole("log", { name: "Messages" })).toContainText("line one\nline two");

  await A.page.getByRole("button", { name: "End", exact: true }).click();
  await expect(B.page.getByText("The other person ended the conversation.")).toBeVisible();
  await expect(B.page.getByRole("log", { name: "Messages" })).toHaveCount(0);
  await expect(A.page.getByText("Hello from A")).toHaveCount(0);
  await A.context.close();
  await B.context.close();
});

test("friend request, temporary friendship and invitation", async ({ browser }) => {
  const A = await newIdentity(browser);
  const B = await newIdentity(browser);
  await joinAsGuest(A.page);
  await joinAsGuest(B.page);
  await matchPair(A.page, B.page);
  await A.page.getByRole("button", { name: "Add friend" }).click();
  await B.page.getByRole("button", { name: "Accept friend" }).click();
  await expect(A.page.getByText("Friends (temporary)")).toBeVisible();
  await expect(B.page.getByText("Friends (temporary)")).toBeVisible();
  await A.page.getByRole("button", { name: "End", exact: true }).click();

  await A.page.goto("/friends/");
  await B.page.goto("/friends/");
  await expect(A.page.getByText("Temporary", { exact: true })).toBeVisible();
  // A full page load reconnects the socket; wait until B is back online before inviting.
  await expect(B.page.getByText("Temporary", { exact: true })).toBeVisible();
  await expect(A.page.getByText(/Available · /)).toBeVisible();
  await A.page.waitForTimeout(500);
  await A.page.getByRole("button", { name: "Invite to talk" }).click();
  await expect(B.page.getByRole("group", { name: "Friend invitation" })).toBeVisible();
  await B.page.getByRole("button", { name: "Accept" }).click();
  await expect(A.page).toHaveURL(/\/chat\/$/);
  await expect(B.page).toHaveURL(/\/chat\/$/);
  await expect(A.page.getByText(/compensation · Friend$/)).toBeVisible();
  await A.context.close();
  await B.context.close();
});

test("audio call connects with real WebRTC and ends with the conversation", async ({ browser }) => {
  const A = await newIdentity(browser);
  const B = await newIdentity(browser);
  await joinAsGuest(A.page);
  await joinAsGuest(B.page);
  await matchPair(A.page, B.page);
  await A.page.getByRole("button", { name: "Request audio call" }).click();
  await expect(B.page.getByText("Incoming audio call.")).toBeVisible();
  await B.page.getByRole("button", { name: "Accept" }).click();
  await expect(A.page.getByText("Audio connected")).toBeVisible({ timeout: 25_000 });
  await expect(B.page.getByText("Audio connected")).toBeVisible();
  await A.page.getByRole("button", { name: "Mute" }).click();
  await expect(A.page.getByText("You are muted")).toBeVisible();
  await B.page.getByRole("button", { name: "End", exact: true }).click();
  await expect(A.page.getByRole("region", { name: "Audio call" })).toHaveCount(0);
  await A.context.close();
  await B.context.close();
});

test("report and block from a guest saves a case receipt", async ({ browser }) => {
  const A = await newIdentity(browser);
  const B = await newIdentity(browser);
  await joinAsGuest(A.page);
  await joinAsGuest(B.page);
  await matchPair(A.page, B.page);
  await sendMessage(A.page, "unwanted message");
  await expect(B.page.getByRole("log", { name: "Messages" })).toContainText("unwanted message");
  await B.page.getByRole("button", { name: "Report" }).click();
  const dialog = B.page.getByRole("dialog");
  await dialog.getByLabel("What happened?").selectOption("spam");
  await expect(dialog.getByRole("checkbox", { name: /unwanted message/ })).toBeChecked();
  await dialog.getByLabel("Also block this person").check();
  await dialog.getByLabel("I have saved the case reference and secret.").check();
  await dialog.getByRole("button", { name: "Submit report" }).click();
  await expect(dialog.getByText("Report saved")).toBeVisible();
  await expect(A.page.getByText("The other person ended the conversation.")).toBeVisible();
  await dialog.getByRole("button", { name: "Done" }).click();
  await B.page.goto("/support/");
  await expect(B.page.getByText("Safety report: spam")).toBeVisible();
  await A.context.close();
  await B.context.close();
});
