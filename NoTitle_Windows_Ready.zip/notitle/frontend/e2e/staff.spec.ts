import { expect, test } from "@playwright/test";

import { PRIVATE, devTotp, newIdentity } from "./helpers";

const STAFF_USER = process.env.E2E_STAFF_USER ?? "admin";
const STAFF_PASSWORD = process.env.E2E_STAFF_PASSWORD ?? "";

test("guest opens a saved case, moderator replies from the private site, guest sees the reply", async ({ browser }) => {
  test.skip(!STAFF_PASSWORD, "run through scripts/run_e2e.py (creates the staff account)");
  // Guest: new case with a saved receipt.
  const user = await newIdentity(browser);
  await user.page.goto("/support/?new=1");
  await user.page.getByLabel("Subject").fill("Question about my case");
  await user.page.getByLabel("Message").fill("Can a moderator help me?");
  await user.page.getByLabel("I have saved the case reference and secret.").check();
  await user.page.getByRole("button", { name: "Save case" }).click();
  await expect(user.page.getByRole("heading", { name: "Question about my case" })).toBeVisible();
  const caseRef = new URL(user.page.url()).searchParams.get("case")!;
  expect(caseRef).toMatch(/^cs_/);

  // Staff: password + authenticator code, queue, audited read, reply.
  const staff = await newIdentity(browser);
  await staff.page.goto(PRIVATE + "/");
  await staff.page.getByLabel("Username").fill(STAFF_USER);
  await staff.page.getByLabel("Password").fill(STAFF_PASSWORD);
  await staff.page.getByLabel("Authenticator code").fill(devTotp(STAFF_USER));
  await staff.page.getByRole("button", { name: "Sign in" }).click();
  await expect(staff.page.getByRole("heading", { name: "Overview" })).toBeVisible();
  await staff.page.getByRole("link", { name: "Cases", exact: true }).click();
  await staff.page.getByRole("link", { name: caseRef }).click();
  await staff.page.getByLabel("Purpose of this read").first().selectOption("case_handling");
  await staff.page.getByRole("button", { name: "Load messages" }).click();
  await expect(staff.page.getByText("Can a moderator help me?")).toBeVisible();
  await staff.page.getByLabel("Reply (visible to the user)").fill("Yes — we are looking into it.");
  await staff.page.getByRole("button", { name: "Send reply to user" }).click();
  await expect(staff.page.getByText("Yes — we are looking into it.")).toBeVisible();

  // Guest sees the moderator reply (saved support, not temporary chat).
  await user.page.reload();
  await expect(user.page.getByText("Yes — we are looking into it.")).toBeVisible();
  await expect(user.page.getByText(/^Moderator ·/)).toBeVisible();
  await user.context.close();
  await staff.context.close();
});

test("private API is not reachable from the public site", async ({ request }) => {
  const r = await request.get("/internal/v1/cases");
  expect(r.status()).toBe(404);
});
