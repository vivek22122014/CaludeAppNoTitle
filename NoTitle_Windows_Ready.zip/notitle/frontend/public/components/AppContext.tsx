"use client";

import { createContext, type ReactNode, useCallback, useContext, useEffect, useMemo, useState } from "react";

import { api, type Bootstrap, type Catalogs, type Me } from "@/lib/client";
import { coordinator } from "@/lib/coordinator";

interface AppState {
  boot: Bootstrap | null;
  me: Me | null;
  catalogs: Catalogs | null;
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
  setMe: (me: Me) => void;
}

const Ctx = createContext<AppState | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [boot, setBoot] = useState<Bootstrap | null>(null);
  const [me, setMe] = useState<Me | null>(null);
  const [catalogs, setCatalogs] = useState<Catalogs | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      const b = await api.bootstrap<Bootstrap>();
      setBoot(b);
      setError(null);
      if (b.owner) {
        const m = await api.get<Me>("/api/v1/me");
        setMe(m);
      } else {
        setMe(null);
        coordinator.reset("signed_out");
      }
    } catch (e) {
      setError((e as Error).message || "The service is unavailable.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
    api.get<Catalogs>("/api/v1/catalogs").then(setCatalogs).catch(() => undefined);
  }, [refresh]);

  const value = useMemo(() => ({ boot, me, catalogs, loading, error, refresh, setMe }),
    [boot, me, catalogs, loading, error, refresh]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp(): AppState {
  const value = useContext(Ctx);
  if (!value) throw new Error("useApp outside AppProvider");
  return value;
}

export function policyVersions(boot: Bootstrap | null): { terms: string; privacy: string } {
  return { terms: boot?.policies.terms?.version ?? "", privacy: boot?.policies.privacy?.version ?? "" };
}
