import type { Metadata } from "next";

import { Markdown } from "@/components/Markdown";
import { loadPolicy } from "@/lib/policies";

export function policyMetadata(kind: string): Metadata {
  const p = loadPolicy(kind);
  return {
    title: p.title,
    description: `${p.title} for NoTitle (version ${p.version}).`,
    alternates: { canonical: p.route + "/" },
  };
}

/** Readable without JavaScript: rendered to static HTML at build time. */
export function PolicyPage({ kind }: { kind: string }) {
  const p = loadPolicy(kind);
  return (
    <div className="container page">
      <article className="prose">
        <h1>{p.title}</h1>
        <p className="muted small">
          Version <strong>{p.version}</strong>
          {p.state !== "published" ? <> · <span className="badge badge-warning">Draft pending legal review</span></> : null}
          <br />Content fingerprint (SHA-256): <code className="mono">{p.digest.slice(0, 16)}…</code>
        </p>
        <Markdown source={p.body} />
      </article>
    </div>
  );
}
