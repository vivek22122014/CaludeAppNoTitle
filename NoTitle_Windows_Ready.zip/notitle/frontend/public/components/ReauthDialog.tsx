"use client";

import { type FormEvent, useState } from "react";

import { Button, Dialog, Field, Notice, errorMessage } from "@notitle/shared";

import { api } from "@/lib/client";

/** Fresh password confirmation (valid five minutes) before sensitive account changes. */
export function ReauthDialog({ open, onDone, onClose }: { open: boolean; onDone: () => void; onClose: () => void }) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api.post("/api/v1/auth/reauth", { password });
      setPassword("");
      onDone();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }
  return (
    <Dialog open={open} title="Confirm your password" onClose={onClose}>
      <form onSubmit={submit}>
        <p className="hint">Sensitive changes need a password confirmation from the last five minutes.</p>
        {error ? <Notice kind="error">{error}</Notice> : null}
        <Field label="Password" type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} />
        <Button type="submit" busy={busy}>Confirm</Button>
      </form>
    </Dialog>
  );
}
