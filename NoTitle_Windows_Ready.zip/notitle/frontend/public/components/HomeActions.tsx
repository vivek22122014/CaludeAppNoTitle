"use client";

import Link from "next/link";

import { useApp } from "@/components/AppContext";

export function HomeActions() {
  const { boot, loading, error } = useApp();
  if (error) {
    return <p className="notice notice-error" role="alert">The service is unavailable right now: {error}</p>;
  }
  const signedIn = Boolean(boot?.owner);
  return (
    <div className="row">
      {signedIn ? (
        <Link className="btn btn-primary btn-lg" href="/chat/">Go to Chat</Link>
      ) : (
        <Link className="btn btn-primary btn-lg" href="/join/" aria-disabled={loading || undefined}>Start a Conversation</Link>
      )}
      {!signedIn ? <Link className="btn btn-secondary btn-lg" href="/register/">Register</Link> : null}
      {!signedIn ? <Link className="btn btn-ghost btn-lg" href="/login/">Log in</Link> : null}
      {boot && !boot.features.admission ? (
        <p className="notice notice-warning" style={{ width: "100%" }}>New conversations are paused for maintenance.</p>
      ) : null}
    </div>
  );
}
