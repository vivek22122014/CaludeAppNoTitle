"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

import { useApp } from "@/components/AppContext";

const MAIN = [
  { href: "/chat/", label: "Chat" },
  { href: "/friends/", label: "Friends" },
  { href: "/support/", label: "Support" },
  { href: "/settings/", label: "Account" },
];

function active(path: string, href: string): boolean {
  return path === href || path.startsWith(href) || path + "/" === href;
}

export function Header() {
  const path = usePathname() ?? "/";
  const { boot, me } = useApp();
  const signedIn = Boolean(boot?.owner);
  return (
    <header className="site-header">
      <div className="container">
        <Link href="/" className="brand" aria-label="NoTitle home">No<span>Title</span></Link>
        <nav className="nav desktop-only" aria-label="Main">
          {signedIn
            ? MAIN.map((item) => (
                <Link key={item.href} href={item.href} aria-current={active(path, item.href) ? "page" : undefined}>{item.label}</Link>
              ))
            : <>
                <Link href="/how-it-works/" aria-current={active(path, "/how-it-works/") ? "page" : undefined}>How it works</Link>
                <Link href="/safety/" aria-current={active(path, "/safety/") ? "page" : undefined}>Safety</Link>
                <Link href="/support/" aria-current={active(path, "/support/") ? "page" : undefined}>Support</Link>
                <Link href="/login/">Log in</Link>
                <Link href="/register/">Register</Link>
              </>}
          <Link href="/premium/" aria-current={active(path, "/premium/") ? "page" : undefined}>Premium</Link>
        </nav>
        {signedIn && me ? (
          <span className="small muted desktop-only" style={{ marginLeft: 8 }} title="You are signed in as">
            {me.display_name}{me.kind === "guest" ? " (guest)" : ""}
          </span>
        ) : null}
      </div>
      {signedIn ? (
        <nav className="mobile-nav" aria-label="Main (mobile)">
          {MAIN.map((item) => (
            <Link key={item.href} href={item.href} aria-current={active(path, item.href) ? "page" : undefined}>{item.label}</Link>
          ))}
        </nav>
      ) : null}
    </header>
  );
}
