"use client";

import Link from "next/link";
import { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";

import { ApiError, Button, Loading, Notice, TextArea, errorMessage, formatDateTime, newNonce, titleCase } from "@notitle/shared";

import { api } from "@/lib/client";

export interface CaseDto {
  case_ref: string; category: string; subject: string; status: string; version: number; last_sequence: number;
  seen_user_sequence: number; staff_seen: boolean; unread: number; created_at: string; updated_at: string;
  closed_at: string | null; reopen_until: string | null; obligation_status: string;
}
interface Msg { sequence: number; sender_kind: string; display_role: string; body: string; created_at: string }

export function Thread({ caseRef }: { caseRef: string }) {
  const [info, setInfo] = useState<CaseDto | null>(null);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [body, setBody] = useState("");
  const [nonce, setNonce] = useState(newNonce);
  const [sendState, setSendState] = useState<"idle" | "sending" | "failed">("idle");
  const [reopenReason, setReopenReason] = useState("");
  const after = useRef(0);
  const delay = useRef(30000);
  const seenSent = useRef(0);

  const load = useCallback(async () => {
    try {
      const [c, page] = await Promise.all([
        api.get<CaseDto>(`/api/v1/support/cases/${encodeURIComponent(caseRef)}`),
        api.get<{ items: Msg[] }>(`/api/v1/support/cases/${encodeURIComponent(caseRef)}/messages`, { after_sequence: after.current, limit: 50 }),
      ]);
      setInfo(c);
      if (page.items.length) {
        after.current = page.items[page.items.length - 1].sequence;
        setMessages((prev) => [...prev, ...page.items.filter((m) => !prev.some((p) => p.sequence === m.sequence))]);
      }
      setError(null);
      delay.current = 30000;
    } catch (e) {
      setError(errorMessage(e));
      delay.current = Math.min(120000, delay.current * 2); // back off 30 → 60 → 120 s
    }
  }, [caseRef]);

  useEffect(() => {
    after.current = 0;
    setMessages([]);
    void load();
    let timer: number;
    const tick = () => {
      timer = window.setTimeout(async () => {
        if (!document.hidden) await load(); // hidden tabs stop polling
        tick();
      }, delay.current);
    };
    tick();
    return () => clearTimeout(timer);
  }, [load]);

  // Seen is sent only after the messages have actually rendered.
  useLayoutEffect(() => {
    const last = messages.length ? messages[messages.length - 1].sequence : 0;
    if (last > seenSent.current && !document.hidden) {
      seenSent.current = last;
      api.post(`/api/v1/support/cases/${encodeURIComponent(caseRef)}/seen`, { seen_through: last }).catch(() => undefined);
    }
  }, [messages, caseRef]);

  async function send() {
    if (!body.trim()) return;
    setSendState("sending");
    try {
      await api.post(`/api/v1/support/cases/${encodeURIComponent(caseRef)}/messages`, { body, client_nonce: nonce });
      setBody("");
      setNonce(newNonce()); // a genuinely new message gets a new nonce
      setSendState("idle");
      await load();
    } catch (e) {
      // Keep the same nonce: retrying the same text is safe and never duplicates.
      setSendState("failed");
      setError(errorMessage(e));
      if (e instanceof ApiError && e.code === "case_closed") await load();
    }
  }

  async function reopen() {
    if (!info) return;
    try {
      await api.post(`/api/v1/support/cases/${encodeURIComponent(caseRef)}/reopen`, { expected_version: info.version, reason: reopenReason });
      await load();
    } catch (e) {
      setError(errorMessage(e));
    }
  }

  if (!info && !error) return <Loading />;
  return (
    <div>
      {error ? <Notice kind="error">{error}</Notice> : null}
      {info ? (
        <div className="card" style={{ marginBottom: 16 }}>
          <div className="row-between">
            <h2 style={{ margin: 0 }}>{info.subject}</h2>
            <span className="badge badge-primary">{titleCase(info.status)}</span>
          </div>
          <p className="small muted">
            Case <code className="mono">{info.case_ref}</code> · {titleCase(info.category)} · opened {formatDateTime(info.created_at)}
            {info.staff_seen ? " · seen by a moderator" : " · not yet seen by a moderator"}
          </p>
          <p className="small muted">Moderators are not available around the clock. Do not share passwords, codes or card details here. For immediate danger contact local emergency services.</p>
        </div>
      ) : null}
      <div className="thread" role="log" aria-live="polite" aria-label="Case messages">
        {messages.map((m) => (
          <div key={m.sequence} className={`thread-msg ${m.sender_kind === "staff" ? "staff" : ""}`}>
            <div className="thread-meta">{m.display_role} · {formatDateTime(m.created_at)}</div>
            {m.body}
          </div>
        ))}
      </div>
      {info?.status === "closed" ? (
        <div className="card">
          <h3>This case is closed</h3>
          {info.reopen_until && new Date(info.reopen_until) > new Date() ? (
            <>
              <TextArea label="Why do you want to reopen it?" value={reopenReason} onChange={(e) => setReopenReason(e.target.value)} maxLength={400} />
              <Button onClick={reopen}>Reopen case</Button>
            </>
          ) : <p>Reopening is possible within 30 days of closure. <Link href="/support/?new=1">Start a new case</Link> and mention reference {info.case_ref}.</p>}
        </div>
      ) : (
        <div className="card">
          <TextArea label="Your message" value={body} maxLength={4000} onChange={(e) => { setBody(e.target.value); if (sendState === "failed") setSendState("idle"); }}
            hint="Messages are saved and reviewed by authorised staff. Sent appears only after the server saves your message." />
          <div className="row">
            <Button busy={sendState === "sending"} onClick={send} disabled={!body.trim()}>
              {sendState === "failed" ? "Retry sending" : "Send"}
            </Button>
            {sendState === "failed" ? <span className="small" style={{ color: "var(--danger)" }}>Not sent yet.</span> : null}
          </div>
        </div>
      )}
    </div>
  );
}
