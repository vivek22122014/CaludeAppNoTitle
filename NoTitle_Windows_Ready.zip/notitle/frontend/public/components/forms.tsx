"use client";

import Link from "next/link";
import type { ReactNode } from "react";

import { Checkbox, Loading, MultiSelect, Notice, Select } from "@notitle/shared";

import { useApp } from "@/components/AppContext";
import type { Catalogs, Professional } from "@/lib/client";

export interface ConsentValue { adult: boolean; terms: boolean; core: boolean; professional: boolean }
export const emptyConsents: ConsentValue = { adult: false, terms: false, core: false, professional: false };

/** Four separate, unchecked confirmations; refusing optional processing keeps free entry available. */
export function ConsentFields({ value, onChange, errors }: {
  value: ConsentValue; onChange: (v: ConsentValue) => void; errors: Record<string, string>;
}) {
  const { boot } = useApp();
  const terms = boot?.policies.terms;
  const privacy = boot?.policies.privacy;
  return (
    <fieldset className="field">
      <legend>Confirmations</legend>
      <Checkbox checked={value.adult} onChange={(v) => onChange({ ...value, adult: v })} error={errors["consents.adult"]}
        label="I am 18 or older." />
      <Checkbox checked={value.terms} onChange={(v) => onChange({ ...value, terms: v })} error={errors["consents.terms"]}
        label={<>I accept the <Link href="/terms/" target="_blank">Terms of Service</Link> and <Link href="/community-guidelines/" target="_blank">Community Guidelines</Link> (version {terms?.version ?? "…"}).</>} />
      <Checkbox checked={value.core} onChange={(v) => onChange({ ...value, core: v })} error={errors["consents.core"]}
        label={<>I agree to the processing needed to run conversations, as described in the <Link href="/privacy/" target="_blank">Privacy Policy</Link> (version {privacy?.version ?? "…"}).</>} />
      <Checkbox checked={value.professional} onChange={(v) => onChange({ ...value, professional: v })}
        label="Optional: use the professional details I choose to add for very soft matching relevance."
        description="You can say no and still use every free feature. You can change this later in Privacy settings." />
    </fieldset>
  );
}

export function ProfessionalFields({ value, onChange, catalogs }: {
  value: Professional; onChange: (v: Professional) => void; catalogs: Catalogs;
}) {
  return (
    <div className="card" style={{ marginBottom: 16 }}>
      <h3>Professional details (private, optional)</h3>
      <p className="hint">Never shown to peers. Controlled categories only — no employer names. Not verified.</p>
      <Select label="Industry" placeholder="Not set" options={catalogs.industries} value={value.industry_id ?? ""}
        onChange={(e) => onChange({ ...value, industry_id: e.target.value || null })} />
      <Select label="Role" placeholder="Not set" options={catalogs.roles} value={value.role_id ?? ""}
        onChange={(e) => onChange({ ...value, role_id: e.target.value || null })} />
      <Select label="Experience" placeholder="Not set" options={catalogs.experience} value={value.experience_id ?? ""}
        onChange={(e) => onChange({ ...value, experience_id: e.target.value || null })} />
      <MultiSelect label="Interests (up to 10)" options={catalogs.interests} value={value.interest_ids} max={10}
        onChange={(v) => onChange({ ...value, interest_ids: v })} />
      <MultiSelect label="Discussion topics (up to 5)" options={catalogs.topics.filter((t) => t.id !== "general")}
        value={value.topic_ids} max={5} onChange={(v) => onChange({ ...value, topic_ids: v })} />
    </div>
  );
}

export const emptyProfessional: Professional = { industry_id: null, role_id: null, experience_id: null, interest_ids: [], topic_ids: [] };

/** Gate for pages that need a guest/account identity. */
export function RequireIdentity({ children, account = false, what = "this page" }: {
  children: ReactNode; account?: boolean; what?: string;
}) {
  const { boot, me, loading, error } = useApp();
  if (loading) return <div className="container page"><Loading /></div>;
  if (error) return <div className="container page"><Notice kind="error" title="Service unavailable">{error}</Notice></div>;
  if (!boot?.owner || !me) {
    return (
      <div className="container page narrow">
        <div className="card">
          <h1>Sign in to use {what}</h1>
          <p>Join as a guest for a temporary identity, or log in to your account.</p>
          <div className="row">
            <Link className="btn btn-primary" href="/join/">Join as guest</Link>
            <Link className="btn btn-secondary" href="/login/">Log in</Link>
            <Link className="btn btn-ghost" href="/register/">Register</Link>
          </div>
        </div>
      </div>
    );
  }
  if (account && me.kind !== "account") {
    return (
      <div className="container page narrow">
        <div className="card">
          <h1>An account is needed for {what}</h1>
          <p>Guests are temporary. Register to keep friends, settings, receipts and saved support.</p>
          <div className="row">
            <Link className="btn btn-primary" href="/register/">Register (keeps your current conversation)</Link>
          </div>
        </div>
      </div>
    );
  }
  return <>{children}</>;
}

export function fieldErrors(err: unknown): Record<string, string> {
  return (err as { fields?: Record<string, string> })?.fields ?? {};
}
