"use client";

import { useEffect, useState } from "react";

import { Button } from "@notitle/shared";

import { coordinator, type Invite } from "@/lib/coordinator";

function Countdown({ until }: { until: number }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);
  return <>{Math.max(0, Math.ceil((until - now) / 1000))}s</>;
}

/** Incoming friend invitations: never interrupt a conversation, always need explicit acceptance. */
export function InviteBanner({ invites, busy }: { invites: Invite[]; busy: boolean }) {
  if (!invites.length) return null;
  return (
    <div aria-live="polite">
      {invites.map((inv) => (
        <div key={inv.invite_id} className="invite-bar" role="group" aria-label="Friend invitation">
          <span><strong>{inv.from.display_name}</strong> invites you to talk · expires in <Countdown until={inv.expires_at} /></span>
          <span className="row">
            <Button onClick={() => coordinator.respondInvite(inv.invite_id, true).catch(() => undefined)} disabled={busy}
              title={busy ? "End your current conversation first" : undefined}>Accept</Button>
            <Button variant="secondary" onClick={() => coordinator.respondInvite(inv.invite_id, false).catch(() => undefined)}>Decline</Button>
          </span>
        </div>
      ))}
    </div>
  );
}

export { Countdown };
