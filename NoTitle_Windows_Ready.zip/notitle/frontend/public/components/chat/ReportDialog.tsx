"use client";

import { useEffect, useState } from "react";

import { ApiError, Button, Checkbox, Dialog, Notice, SecretPanel, Select, TextArea, errorMessage, newNonce } from "@notitle/shared";

import { useApp } from "@/components/AppContext";
import { api } from "@/lib/client";

const REASONS = [
  ["harassment", "Harassment"], ["threats", "Threats"], ["doxxing", "Revealing personal information (doxxing)"],
  ["confidentiality", "Sharing confidential material"], ["false_accusation", "Targeted false accusations"],
  ["scam", "Scam or fraud"], ["impersonation", "Impersonation"], ["underage", "Suspected under 18"],
  ["sexual_misconduct", "Sexual misconduct"], ["spam", "Spam"], ["other", "Other (please describe)"],
].map(([id, label]) => ({ id, label }));

interface Snapshot { snapshot_id: string; messages: { message_id: string; mine: boolean; body: string; sent_at: string }[] }
interface Prepared { reservation_id: string; reference: string; secret: string }

/**
 * Report: freezes a server snapshot first, lets the user select evidence, optionally blocks.
 * Shows a saved reference only after the server commits; on failure says "Not submitted".
 */
export function ReportDialog({ open, interactionId, onClose, alsoBlock }: {
  open: boolean; interactionId: string | null; onClose: () => void; alsoBlock: boolean;
}) {
  const { me } = useApp();
  const [snapshot, setSnapshot] = useState<Snapshot | null>(null);
  const [selected, setSelected] = useState<string[]>([]);
  const [reason, setReason] = useState("");
  const [allegation, setAllegation] = useState("");
  const [block, setBlock] = useState(alsoBlock);
  const [receipt, setReceipt] = useState<Prepared | null>(null);
  const [saved, setSaved] = useState(false);
  const [nonce] = useState(newNonce);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<{ case_ref: string; report_ref: string; evidence_count: number } | null>(null);
  const [expired, setExpired] = useState(false);
  const guest = me?.kind !== "account";

  useEffect(() => {
    if (!open || !interactionId) return;
    setBlock(alsoBlock);
    api.post<Snapshot>("/api/v1/reports/prepare", { interaction_id: interactionId })
      .then((s) => { setSnapshot(s); setSelected(s.messages.filter((m) => !m.mine).map((m) => m.message_id)); })
      .catch((e) => setError(errorMessage(e)));
    if (guest) {
      api.post<Prepared>("/api/v1/operations/prepare", { kind: "case_receipt" }).then(setReceipt).catch(() => undefined);
    }
  }, [open, interactionId, alsoBlock, guest]);

  async function submit(confirmWithoutEvidence = false) {
    if (!interactionId) return;
    setBusy(true);
    setError(null);
    try {
      const r = await api.post<{ case_ref: string; report_ref: string; evidence_count: number }>("/api/v1/reports", {
        interaction_id: interactionId, snapshot_id: snapshot?.snapshot_id, selected_message_ids: selected, reason,
        allegation, block, client_nonce: nonce, confirm_without_evidence: confirmWithoutEvidence,
        ...(guest && receipt ? { reservation_id: receipt.reservation_id, receipt_secret: receipt.secret, saved } : {}),
      });
      setResult(r);
    } catch (e) {
      if (e instanceof ApiError && e.code === "evidence_expired") setExpired(true);
      else if (e instanceof ApiError && e.code === "not_submitted") {
        setError("Not submitted. " + e.message);
      } else setError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  }

  const close = () => {
    setSnapshot(null); setResult(null); setReason(""); setAllegation(""); setError(null); setExpired(false);
    onClose();
  };

  return (
    <Dialog open={open} title={block ? "Report and block" : "Report"} onClose={close}
      footer={result ? <Button onClick={close}>Done</Button> : (
        <>
          <Button variant="secondary" onClick={close}>Cancel</Button>
          {expired
            ? <Button variant="danger" busy={busy} onClick={() => submit(true)}>Submit without messages</Button>
            : <Button variant="danger" busy={busy} disabled={!reason || (guest && !saved) || (reason === "other" && !allegation.trim())}
                onClick={() => submit(false)}>Submit report</Button>}
        </>
      )}>
      {result ? (
        <Notice kind="success" title="Report saved">
          Reference <code className="mono">{result.report_ref}</code>. It is linked to safety case <code className="mono">{result.case_ref}</code>
          {" "}({result.evidence_count} message{result.evidence_count === 1 ? "" : "s"} included). You can follow it in Support.
        </Notice>
      ) : (
        <>
          <p className="hint">Only the messages you select and your description are saved into a safety case reviewed by moderators. Everything else stays temporary. Audio is never recorded.</p>
          {error ? <Notice kind="error">{error}</Notice> : null}
          {expired ? <Notice kind="warning">The message snapshot expired (2 minutes). Only your description and the conversation attribution would be saved.</Notice> : null}
          <Select label="What happened?" placeholder="Choose a reason…" options={REASONS} value={reason} onChange={(e) => setReason(e.target.value)} />
          <TextArea label="Describe it in your own words" value={allegation} onChange={(e) => setAllegation(e.target.value)} maxLength={4000}
            hint={reason === "other" ? "Required for Other." : "Optional. This is your account of events."} />
          <fieldset className="field">
            <legend>Messages to include</legend>
            {!snapshot ? <p className="hint">Preparing a snapshot…</p> : snapshot.messages.length === 0
              ? <p className="hint">No messages are available to include.</p>
              : snapshot.messages.map((m) => (
                <Checkbox key={m.message_id} checked={selected.includes(m.message_id)}
                  onChange={(v) => setSelected(v ? [...selected, m.message_id] : selected.filter((x) => x !== m.message_id))}
                  label={<span style={{ whiteSpace: "pre-wrap" }}><strong>{m.mine ? "You" : "Them"}:</strong> {m.body}</span>} />
              ))}
          </fieldset>
          <Checkbox checked={block} onChange={setBlock} label="Also block this person" description="Blocking happens immediately, even before the report is saved." />
          {guest && receipt ? (
            <>
              <SecretPanel title="Case receipt" reference={receipt.reference} secret={receipt.secret} filename="notitle-case-receipt.txt"
                explanation="As a guest you need this receipt to follow the case later in Support → Open a saved case." />
              <Checkbox checked={saved} onChange={setSaved} label="I have saved the case reference and secret." />
            </>
          ) : null}
        </>
      )}
    </Dialog>
  );
}
