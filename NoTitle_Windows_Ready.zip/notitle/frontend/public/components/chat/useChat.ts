"use client";

import { useEffect, useSyncExternalStore } from "react";

import { useApp } from "@/components/AppContext";
import { coordinator, type ChatState } from "@/lib/coordinator";

/** Subscribe to the coordinator; connect while a signed-in user is on a realtime page. */
export function useChat(connect = true): ChatState {
  const { boot } = useApp();
  const state = useSyncExternalStore(coordinator.subscribe, coordinator.getSnapshot, coordinator.getSnapshot);
  const signedIn = Boolean(boot?.owner);
  useEffect(() => {
    if (connect && signedIn) void coordinator.ensureConnected();
  }, [connect, signedIn]);
  return state;
}
