"use client";

import Link from "next/link";
import { type KeyboardEvent, useEffect, useLayoutEffect, useRef, useState } from "react";

import { Button, Dialog, Notice, codePoints, formatTime, labelFor, utf8Bytes } from "@notitle/shared";

import { useApp } from "@/components/AppContext";
import { Countdown, InviteBanner } from "@/components/chat/InviteBanner";
import { ReportDialog } from "@/components/chat/ReportDialog";
import { useChat } from "@/components/chat/useChat";
import { api } from "@/lib/client";
import { CommandFailure, coordinator, endedText, type ChatMessage } from "@/lib/coordinator";

const MAX_CHARS = 2000;
const MAX_BYTES = 6 * 1024;

function useElapsed(since: number | null): string {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    if (!since) return;
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, [since]);
  if (!since) return "";
  const s = Math.max(0, Math.floor((now - since) / 1000));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}

function Bubble({ m }: { m: ChatMessage }) {
  const ref = useRef<HTMLDivElement>(null);
  const acked = useRef(false);
  // Delivered is acknowledged only after the message has actually rendered.
  useLayoutEffect(() => {
    if (!m.mine && m.message_id && !acked.current) {
      acked.current = true;
      coordinator.ackRendered(m.message_id);
    }
  }, [m.mine, m.message_id]);
  const status = m.mine ? ({ pending: "Sending…", accepted: "Sent", delivered: "Delivered", failed: "Not sent", received: "" } as const)[m.status] : "";
  return (
    <div ref={ref} className={`bubble ${m.mine ? "bubble-me" : "bubble-peer"} ${m.status === "failed" ? "bubble-failed" : ""}`}>
      <span className="sr-only">{m.mine ? "You said: " : "They said: "}</span>
      {m.body}
      <span className="bubble-meta">{formatTime(m.sent_at)}{status ? ` · ${status}` : ""}{m.error ? ` (${m.error})` : ""}</span>
    </div>
  );
}

function Composer({ disabled, onSend }: { disabled: boolean; onSend: (text: string) => Promise<void> }) {
  const [text, setText] = useState("");
  const chars = codePoints(text);
  const bytes = utf8Bytes(text);
  const tooLong = chars > MAX_CHARS || bytes > MAX_BYTES;
  const send = async () => {
    const value = text;
    if (!value.trim() || tooLong || disabled) return;
    setText("");
    await onSend(value);
  };
  const onKey = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    // Enter sends, Shift+Enter adds a line; ignore Enter while an IME is composing.
    if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) {
      e.preventDefault();
      void send();
    }
  };
  return (
    <div className="composer">
      <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 4 }}>
        <label htmlFor="composer" className="sr-only">Message</label>
        <textarea id="composer" value={text} onChange={(e) => setText(e.target.value)} onKeyDown={onKey} rows={2}
          placeholder={disabled ? "Sending is paused" : "Type a message (Enter to send, Shift+Enter for a new line)"}
          disabled={disabled} aria-describedby="composer-count" />
        <span id="composer-count" className="counter" aria-live="polite">
          {tooLong ? <span style={{ color: "var(--danger)" }}>Too long: {chars}/{MAX_CHARS} characters</span> : `${chars}/${MAX_CHARS}`}
        </span>
      </div>
      <Button onClick={() => void send()} disabled={disabled || !text.trim() || tooLong}>Send</Button>
    </div>
  );
}

export function ChatScreen() {
  const { me, catalogs, boot } = useApp();
  const s = useChat(true);
  const elapsed = useElapsed(s.phase === "searching" ? s.searchingSince : null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [report, setReport] = useState<{ interactionId: string; block: boolean } | null>(null);
  const [confirmBlock, setConfirmBlock] = useState(false);
  const logRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    logRef.current?.scrollTo({ top: logRef.current.scrollHeight });
  }, [s.messages.length]);

  async function run(fn: () => Promise<unknown>) {
    setBusy(true);
    setError(null);
    try {
      await fn();
    } catch (e) {
      const err = e as CommandFailure;
      if (err.code === "premium_preference_inactive") {
        coordinator.clearNotice();
        setError(null);
        setPremiumPrompt(true);
      } else setError(err.message);
    } finally {
      setBusy(false);
    }
  }
  const [premiumPrompt, setPremiumPrompt] = useState(false);

  async function block() {
    const id = s.interactionId;
    setConfirmBlock(false);
    if (!id) return;
    await run(() => api.post("/api/v1/blocks", { interaction_id: id }));
  }

  const topic = labelFor(catalogs?.topics, s.peer?.topic_id ?? me?.topic_id);
  const inConversation = s.phase === "in_interaction" && s.interactionId;
  const sendingPaused = s.peerInterrupted || s.conn !== "open";

  return (
    <div className="container page">
      <InviteBanner invites={s.invites} busy={Boolean(inConversation)} />
      {s.notice ? <Notice kind={s.notice.kind} live>{s.notice.text}</Notice> : null}
      {error ? <Notice kind="error">{error}</Notice> : null}
      {s.conn === "conflict" ? (
        <Notice kind="warning" title="Open in another tab">
          NoTitle allows one active tab per identity.{" "}
          <Button variant="secondary" onClick={() => coordinator.takeover()}>Use this tab instead</Button>
        </Notice>
      ) : null}
      {s.conn === "reconnecting" ? <Notice kind="warning" live>Reconnecting… Searching and calls never restart automatically.</Notice> : null}
      {boot && !boot.features.admission ? <Notice kind="warning">New conversations are paused for maintenance.</Notice> : null}

      <div className="chat-layout">
        <section className="card chat-panel" aria-label="Conversation">
          {inConversation && s.peer ? (
            <>
              <div className="chat-top">
                <div className="chat-peer">
                  <strong>{s.peer.display_name}</strong>
                  <span className="small muted">
                    {s.peer.gender.charAt(0).toUpperCase() + s.peer.gender.slice(1)} · {labelFor(catalogs?.topics, s.peer.topic_id)}
                    {s.source === "invite" ? " · Friend" : ""}
                  </span>
                  {s.peer.bio ? <span className="small">{s.peer.bio}</span> : null}
                </div>
                <div className="row">
                  <Button variant="secondary" onClick={() => run(() => coordinator.end())} disabled={busy}>End</Button>
                  <Button variant="secondary" onClick={() => run(() => coordinator.next())} disabled={busy}>Next</Button>
                </div>
              </div>
              {s.peerInterrupted ? (
                <Notice kind="warning" live>The other person lost connection. They have {s.graceSeconds} seconds to come back; sending is paused.</Notice>
              ) : null}
              {s.call ? (
                <div className="call-bar" role="region" aria-label="Audio call" aria-live="polite">
                  {s.call.state === "ringing_in" ? (
                    <>
                      <span><strong>Incoming audio call.</strong> Your microphone is used only if you accept.</span>
                      <span className="row">
                        <Button onClick={() => run(() => coordinator.respondCall(true))}>Accept</Button>
                        <Button variant="secondary" onClick={() => run(() => coordinator.respondCall(false))}>Decline</Button>
                      </span>
                    </>
                  ) : (
                    <>
                      <span>
                        {s.call.state === "ringing_out" ? "Calling… waiting for them to accept" :
                         s.call.state === "connecting" ? "Connecting audio…" : "Audio connected"}
                        {s.call.muted ? " · You are muted" : ""}
                      </span>
                      <span className="row">
                        {s.call.state === "connected" || s.call.state === "connecting" ? (
                          <Button variant="secondary" onClick={() => coordinator.toggleMute()} aria-pressed={s.call.muted}>
                            {s.call.muted ? "Unmute" : "Mute"}
                          </Button>
                        ) : null}
                        <Button variant="danger" onClick={() => run(() => coordinator.endCall())}>
                          {s.call.state === "ringing_out" ? "Cancel call" : "End call"}
                        </Button>
                      </span>
                    </>
                  )}
                </div>
              ) : null}
              <div className="chat-log" ref={logRef} role="log" aria-live="polite" aria-relevant="additions" aria-label="Messages">
                <p className="small muted" style={{ textAlign: "center" }}>
                  Messages are temporary: they are not saved and disappear when this conversation ends.
                </p>
                {s.messages.map((m) => <Bubble key={m.key} m={m} />)}
              </div>
              <Composer disabled={sendingPaused} onSend={(t) => coordinator.sendText(t)} />
              <div className="chat-actions">
                {s.friendState === "requested_by_peer" ? (
                  <>
                    <span className="small">They sent a friend request.</span>
                    <Button onClick={() => run(() => coordinator.respondFriend(true))}>Accept friend</Button>
                    <Button variant="secondary" onClick={() => run(() => coordinator.respondFriend(false))}>Decline</Button>
                  </>
                ) : s.friendState === "none" ? (
                  <Button variant="secondary" onClick={() => run(() => coordinator.requestFriend())}>Add friend</Button>
                ) : (
                  <span className="badge badge-primary">
                    {s.friendState === "requested_by_me" ? "Friend request pending" : s.friendState === "saving" ? "Saving friend…"
                      : s.friendState === "temporary" ? "Friends (temporary)" : "Friends (saved)"}
                  </span>
                )}
                {!s.call && s.audioAvailable ? (
                  <Button variant="secondary" onClick={() => run(() => coordinator.requestCall())} disabled={sendingPaused}>Request audio call</Button>
                ) : null}
                <Button variant="danger" onClick={() => setReport({ interactionId: s.interactionId!, block: false })}>Report</Button>
                <Button variant="danger" onClick={() => setConfirmBlock(true)}>Block</Button>
              </div>
            </>
          ) : s.phase === "searching" ? (
            <div className="state-center">
              <span className="spinner" aria-hidden="true" style={{ width: 28, height: 28 }} />
              <h2>Searching for someone to talk to…</h2>
              <p className="muted" aria-live="polite">Waiting {elapsed}. Topic: {topic}. Everyone shares one queue; there is no priority.</p>
              <Button variant="secondary" onClick={() => run(() => coordinator.cancelSearch())} busy={busy}>Cancel search</Button>
            </div>
          ) : (
            <div className="state-center">
              {s.phase === "ended" ? (
                <Notice kind="info" live>{endedText(s.endedReason)} Its temporary messages were cleared.</Notice>
              ) : null}
              {s.pausedReason ? (
                <Notice kind="warning">
                  {s.pausedReason === "restricted" ? "Your access to matching is restricted." :
                    "Search paused: your gender preference needs an active Premium pass."}
                </Notice>
              ) : null}
              <h2>{s.phase === "ended" ? "Start another conversation?" : "Ready when you are"}</h2>
              <p className="muted">
                You appear as <strong>{me?.display_name}</strong> · {labelFor(catalogs?.topics, me?.topic_id)}.{" "}
                <Link href="/profile/">Edit profile</Link> · <Link href="/preferences/">Preferences</Link>
              </p>
              <Button className="btn-lg" onClick={() => run(() => coordinator.search())} busy={busy || s.conn !== "open"}>
                {s.conn === "open" ? "Search" : "Connecting…"}
              </Button>
              {s.outgoingInvite ? (
                <p className="muted">
                  Invitation sent · <Countdown until={s.outgoingInvite.expires_at} />{" "}
                  <Button variant="ghost" onClick={() => run(() => coordinator.cancelInvite())}>Cancel</Button>
                </p>
              ) : null}
            </div>
          )}
        </section>
        <aside className="card small" aria-label="Safety and context">
          <h2>Stay safe</h2>
          <ul>
            <li><strong>End</strong> stops the conversation for both of you.</li>
            <li><strong>Block</strong> stops further contact from this identity.</li>
            <li><strong>Report</strong> saves only the messages you select.</li>
            <li>Never share passwords, codes or confidential employer material.</li>
          </ul>
          <p><Link href="/support/">Chat with Moderator</Link> · <Link href="/friends/">Friends</Link></p>
          {me?.kind === "guest" ? (
            <p className="muted">You are a guest. <Link href="/register/">Register</Link> to keep friends and settings.</p>
          ) : null}
        </aside>
      </div>

      <ReportDialog open={Boolean(report)} interactionId={report?.interactionId ?? null} alsoBlock={report?.block ?? false}
        onClose={() => setReport(null)} />
      <Dialog open={confirmBlock} title="Block this person?" onClose={() => setConfirmBlock(false)}
        footer={<>
          <Button variant="secondary" onClick={() => setConfirmBlock(false)}>Cancel</Button>
          <Button variant="secondary" onClick={() => { setConfirmBlock(false); if (s.interactionId) setReport({ interactionId: s.interactionId, block: true }); }}>Report and block</Button>
          <Button variant="danger" onClick={() => void block()}>Block</Button>
        </>}>
        <p>The conversation ends immediately and you will not be matched again.
          {me?.kind === "guest" ? " As a guest, this protects only your current temporary identity." : " You can review blocks in Settings."}</p>
      </Dialog>
      <Dialog open={premiumPrompt} title="Search with Everyone?" onClose={() => setPremiumPrompt(false)}
        footer={<>
          <Button variant="secondary" onClick={() => setPremiumPrompt(false)}>Not now</Button>
          <Button onClick={() => { setPremiumPrompt(false); void run(() => coordinator.search(true)); }}>Search with Everyone</Button>
        </>}>
        <p>Your saved gender preference needs an active Premium pass. Your saved choice is kept; this search will include everyone.</p>
        <p><Link href="/premium/">See Premium passes</Link></p>
      </Dialog>
    </div>
  );
}
