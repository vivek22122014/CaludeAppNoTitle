import { Fragment, type ReactNode } from "react";

/**
 * Minimal, safe Markdown renderer for the policy documents (build time).
 * Supports ## / ### headings, paragraphs, "- " lists, pipe tables and **bold**.
 * It never injects HTML: everything becomes React text nodes.
 */
function inline(text: string): ReactNode[] {
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return parts.map((part, i) =>
    part.startsWith("**") && part.endsWith("**") ? <strong key={i}>{part.slice(2, -2)}</strong> : <Fragment key={i}>{part}</Fragment>);
}

export function Markdown({ source }: { source: string }) {
  const blocks = source.split(/\n{2,}/);
  return (
    <>
      {blocks.map((block, i) => {
        const lines = block.split("\n");
        if (block.startsWith("### ")) return <h3 key={i}>{inline(block.slice(4))}</h3>;
        if (block.startsWith("## ")) return <h2 key={i}>{inline(block.slice(3))}</h2>;
        if (lines.every((l) => l.startsWith("- "))) {
          return <ul key={i}>{lines.map((l, j) => <li key={j}>{inline(l.slice(2))}</li>)}</ul>;
        }
        if (lines.length >= 2 && lines[0].startsWith("|") && /^\|[-| ]+\|$/.test(lines[1])) {
          const cells = (l: string) => l.replace(/^\||\|$/g, "").split("|").map((c) => c.trim());
          return (
            <table key={i}>
              <thead><tr>{cells(lines[0]).map((c, j) => <th key={j} scope="col">{inline(c)}</th>)}</tr></thead>
              <tbody>{lines.slice(2).map((l, r) => <tr key={r}>{cells(l).map((c, j) => <td key={j}>{inline(c)}</td>)}</tr>)}</tbody>
            </table>
          );
        }
        return <p key={i}>{inline(lines.join(" "))}</p>;
      })}
    </>
  );
}
