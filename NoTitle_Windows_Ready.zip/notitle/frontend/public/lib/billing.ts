export interface Plan {
  code: string;
  version: number;
  label: string;
  price_paise: number;
  price_display: string;
  duration_seconds: number;
  duration_days: number;
  available: boolean;
  unavailable_reason: string | null;
  tax_note: string;
  auto_renews: boolean;
  refund_policy_version: string;
}

export interface Purchase {
  purchase_ref: string;
  plan_code: string;
  plan_version: number;
  amount_paise: number;
  currency: string;
  duration_seconds: number;
  state: "created" | "pending" | "paid" | "failed" | "needs_review";
  message: string;
  provider: string;
  created_at: string;
  captured_at: string | null;
  checkout: null | { provider: "simulator"; url: string } | { provider: "cashfree"; payment_session_id: string; mode: "sandbox" | "production" };
}

export interface Entitlement {
  active: boolean;
  available_seconds: number;
  held_seconds: number;
  expires_at: string | null;
  lots: {
    purchase_ref: string; plan_code: string; grant_seq: number; granted_seconds: number; consumed_seconds: number;
    available_seconds: number; held_seconds: number; revoked_seconds: number; granted_at: string;
  }[];
  note: string;
}

declare global {
  interface Window { Cashfree?: (opts: { mode: string }) => { checkout: (o: { paymentSessionId: string; redirectTarget: string }) => Promise<unknown> } }
}

/** Opens the provider's hosted checkout.  NoTitle never sees card or UPI credentials. */
export async function openCheckout(purchase: Purchase): Promise<void> {
  const checkout = purchase.checkout;
  if (!checkout) return;
  if (checkout.provider === "simulator") {
    window.location.assign(checkout.url);
    return;
  }
  await new Promise<void>((resolve, reject) => {
    if (window.Cashfree) return resolve();
    const script = document.createElement("script");
    script.src = "https://sdk.cashfree.com/js/v3/cashfree.js";
    script.onload = () => resolve();
    script.onerror = () => reject(new Error("Could not load the payment provider."));
    document.head.appendChild(script);
  });
  const cashfree = window.Cashfree!({ mode: checkout.mode });
  await cashfree.checkout({ paymentSessionId: checkout.payment_session_id, redirectTarget: "_self" });
}
