/**
 * One WebRTC audio call.  The microphone is requested only after both people
 * accepted; if the permission prompt resolves after the call was cancelled,
 * every returned track is stopped immediately.  close() always stops tracks and
 * the RTCPeerConnection.  No automatic restart after reconnect.
 */

export interface AudioCallOptions {
  callId: string;
  role: "offerer" | "answerer";
  iceServers: RTCIceServer[];
  iceTransportPolicy: RTCIceTransportPolicy;
  send: (type: string, payload: Record<string, unknown>) => void;
  onConnected: () => void;
  onFailed: (reason: string) => void;
}

export class AudioCall {
  private pc: RTCPeerConnection | null = null;
  private stream: MediaStream | null = null;
  private closed = false;
  private revision = 0;
  private remoteAudio: HTMLAudioElement | null = null;
  private queuedIce: RTCIceCandidateInit[] = [];
  private connectedReported = false;

  constructor(private opts: AudioCallOptions) {}

  async start(): Promise<void> {
    if (!navigator.mediaDevices?.getUserMedia) {
      this.opts.onFailed("unsupported");
      return;
    }
    let stream: MediaStream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true }, video: false });
    } catch {
      if (!this.closed) this.opts.onFailed("permission_denied");
      return;
    }
    if (this.closed) {
      stream.getTracks().forEach((t) => t.stop()); // cancelled while the prompt was open
      return;
    }
    this.stream = stream;
    const pc = new RTCPeerConnection({ iceServers: this.opts.iceServers, iceTransportPolicy: this.opts.iceTransportPolicy,
      bundlePolicy: "max-bundle", rtcpMuxPolicy: "require" });
    this.pc = pc;
    stream.getAudioTracks().forEach((track) => pc.addTrack(track, stream));
    pc.onicecandidate = (ev) => {
      if (ev.candidate && !this.closed) {
        this.opts.send("call.ice", { call_id: this.opts.callId, revision: Math.max(1, this.revision),
          candidate: ev.candidate.candidate, sdp_mid: ev.candidate.sdpMid ?? undefined,
          sdp_mline_index: ev.candidate.sdpMLineIndex ?? undefined });
      }
    };
    pc.ontrack = (ev) => {
      if (!this.remoteAudio) {
        this.remoteAudio = new Audio();
        this.remoteAudio.autoplay = true;
      }
      this.remoteAudio.srcObject = ev.streams[0] ?? new MediaStream([ev.track]);
      void this.remoteAudio.play().catch(() => undefined);
    };
    pc.onconnectionstatechange = () => {
      if (this.closed) return;
      if (pc.connectionState === "connected" && !this.connectedReported) {
        this.connectedReported = true;
        this.opts.onConnected();
      } else if (pc.connectionState === "failed") {
        this.opts.onFailed("failed");
      }
    };
    if (this.opts.role === "offerer") {
      this.revision = 1;
      const offer = await pc.createOffer({ offerToReceiveAudio: true });
      await pc.setLocalDescription(offer);
      this.opts.send("call.sdp", { call_id: this.opts.callId, revision: this.revision, sdp_type: "offer", sdp: offer.sdp ?? "" });
    }
  }

  async signal(type: string, payload: Record<string, unknown>): Promise<void> {
    if (this.closed || payload.call_id !== this.opts.callId) return;
    const pc = this.pc;
    if (!pc) {
      if (type === "call.ice") this.queuedIce.push(this.iceFrom(payload));
      return;
    }
    try {
      if (type === "call.sdp") {
        this.revision = Number(payload.revision) || 1;
        await pc.setRemoteDescription({ type: payload.sdp_type as RTCSdpType, sdp: String(payload.sdp) });
        for (const c of this.queuedIce.splice(0)) await pc.addIceCandidate(c);
        if (payload.sdp_type === "offer") {
          const answer = await pc.createAnswer();
          await pc.setLocalDescription(answer);
          this.opts.send("call.sdp", { call_id: this.opts.callId, revision: this.revision, sdp_type: "answer", sdp: answer.sdp ?? "" });
        }
      } else if (type === "call.ice") {
        const ice = this.iceFrom(payload);
        if (!pc.remoteDescription) this.queuedIce.push(ice);
        else await pc.addIceCandidate(ice);
      }
    } catch {
      /* invalid remote signal: ignore; the setup deadline ends unfinished calls */
    }
  }

  private iceFrom(payload: Record<string, unknown>): RTCIceCandidateInit {
    return { candidate: String(payload.candidate), sdpMid: (payload.sdp_mid as string) ?? null,
      sdpMLineIndex: (payload.sdp_mline_index as number) ?? null };
  }

  setMuted(muted: boolean) {
    this.stream?.getAudioTracks().forEach((t) => { t.enabled = !muted; });
  }

  close(_reason: string) {
    if (this.closed) return;
    this.closed = true;
    this.stream?.getTracks().forEach((t) => t.stop());
    this.stream = null;
    if (this.pc) {
      this.pc.onicecandidate = null;
      this.pc.ontrack = null;
      this.pc.onconnectionstatechange = null;
      this.pc.close();
      this.pc = null;
    }
    if (this.remoteAudio) {
      this.remoteAudio.pause();
      this.remoteAudio.srcObject = null;
      this.remoteAudio = null;
    }
  }
}
