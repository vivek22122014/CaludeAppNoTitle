/**
 * ClientCoordinator — the single browser-side owner of the realtime session.
 *
 * It survives client-side route transitions (module singleton), owns the
 * WebSocket, the current interaction, ephemeral text (memory only, never
 * browser storage), invitations and the microphone lifecycle.  React
 * components subscribe with useSyncExternalStore and dispatch commands; a
 * component mounting never joins a queue or captures media by itself.
 */

import { newNonce } from "@notitle/shared";

import { api, wsUrl } from "@/lib/client";
import { AudioCall } from "@/lib/audio";

export interface Peer { peer_handle: string; display_name: string; gender: string; topic_id: string; bio: string }
export interface ChatMessage {
  key: string;
  message_id?: string;
  mine: boolean;
  body: string;
  sent_at?: string;
  status: "pending" | "accepted" | "delivered" | "failed" | "received";
  error?: string;
}
export interface Invite { invite_id: string; from: { display_name: string }; relationship_id: string; expires_at: number }
export interface CallInfo {
  call_id: string;
  state: "ringing_out" | "ringing_in" | "connecting" | "connected" | "ended";
  muted: boolean;
  error?: string;
}
export type ConnState = "idle" | "connecting" | "open" | "reconnecting" | "conflict" | "closed";
export type FriendState = "none" | "requested_by_me" | "requested_by_peer" | "saving" | "friends" | "temporary";

export interface ChatState {
  conn: ConnState;
  phase: "idle" | "searching" | "in_interaction" | "ended";
  interactionId: string | null;
  source: string | null;
  peer: Peer | null;
  peerInterrupted: boolean;
  graceSeconds: number;
  messages: ChatMessage[];
  friendState: FriendState;
  friendRequestId: string | null;
  relationshipId: string | null;
  endedReason: string | null;
  searchingSince: number | null;
  call: CallInfo | null;
  invites: Invite[];
  outgoingInvite: { invite_id: string; expires_at: number } | null;
  notice: { kind: "info" | "warning" | "error" | "success"; text: string } | null;
  pausedReason: string | null;
  audioAvailable: boolean;
  premium: boolean;
  version: number;
}

const initial: ChatState = {
  conn: "idle", phase: "idle", interactionId: null, source: null, peer: null, peerInterrupted: false,
  graceSeconds: 0, messages: [], friendState: "none", friendRequestId: null, relationshipId: null,
  endedReason: null, searchingSince: null, call: null, invites: [], outgoingInvite: null, notice: null,
  pausedReason: null, audioAvailable: true, premium: false, version: 0,
};

interface Pending { resolve: (v: Record<string, unknown>) => void; reject: (e: CommandFailure) => void; timer: number }

export class CommandFailure extends Error {
  code: string;
  constructor(code: string, message: string) {
    super(message);
    this.code = code;
  }
}

const REASONS: Record<string, string> = {
  ended: "You ended the conversation.",
  next: "You moved on to the next conversation.",
  peer_ended: "The other person ended the conversation.",
  blocked: "The conversation ended because of a block.",
  peer_disconnected: "The other person did not reconnect in time.",
  service_restart: "The service restarted, so the conversation ended.",
  restricted: "The conversation ended because of an account restriction.",
  friend_removed: "The conversation ended because the friendship was removed.",
  logged_out: "You signed out.",
  account_deleted: "Your account was deleted.",
  consent_withdrawn: "You withdrew core processing consent.",
  credentials_changed: "Your sign-in changed on another device.",
};

export function endedText(reason: string | null): string {
  return (reason && REASONS[reason]) || "The conversation ended.";
}

class ClientCoordinator {
  private state: ChatState = { ...initial };
  private listeners = new Set<() => void>();
  private ws: WebSocket | null = null;
  private pending = new Map<string, Pending>();
  private heartbeat: number | null = null;
  private reconnectTimer: number | null = null;
  private attempts = 0;
  private wanted = false; // the user is on a realtime page and signed in
  private audio: AudioCall | null = null;
  private generation = 0;

  subscribe = (fn: () => void) => {
    this.listeners.add(fn);
    return () => { this.listeners.delete(fn); };
  };

  getSnapshot = () => this.state;

  private set(patch: Partial<ChatState>) {
    this.state = { ...this.state, ...patch, version: this.state.version + 1 };
    this.listeners.forEach((fn) => fn());
  }

  /** Called by pages that need realtime (chat, friends).  Never searches by itself. */
  async ensureConnected(takeover = false): Promise<void> {
    this.wanted = true;
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) return;
    await this.open(takeover);
  }

  private async open(takeover: boolean): Promise<void> {
    const generation = ++this.generation;
    this.set({ conn: this.attempts ? "reconnecting" : "connecting" });
    let ticket: { ticket: string };
    try {
      ticket = await api.post<{ ticket: string }>("/api/v1/ws/ticket", { takeover });
    } catch (e) {
      if (generation !== this.generation) return;
      const status = (e as { status?: number }).status;
      if (status === 401) {
        this.set({ conn: "closed", notice: { kind: "warning", text: "Your session ended. Sign in or join again." } });
        this.wanted = false;
        return;
      }
      this.scheduleReconnect();
      return;
    }
    if (generation !== this.generation) return;
    const ws = new WebSocket(wsUrl("/api/v1/ws"));
    this.ws = ws;
    ws.onopen = () => {
      ws.send(JSON.stringify({ v: 2, id: newNonce(), type: "session.hello", payload: { ticket: ticket.ticket } }));
    };
    ws.onmessage = (ev) => {
      if (this.ws !== ws) return; // late frame from a replaced socket
      try {
        this.handle(JSON.parse(String(ev.data)));
      } catch {
        /* ignore malformed frames */
      }
    };
    ws.onclose = (ev) => {
      if (this.ws !== ws) return;
      this.ws = null;
      this.stopHeartbeat();
      this.failPending("connection_lost", "Connection lost.");
      this.teardownAudio("connection_lost");
      if (ev.code === 4409) {
        this.set({ conn: "conflict", notice: { kind: "warning", text: "NoTitle is open in another tab. Use it there, or continue here." } });
        return;
      }
      if (ev.code === 4001) {
        this.set({ conn: "closed", notice: { kind: "info", text: "This conversation moved to another tab." } });
        this.wanted = false;
        return;
      }
      if (ev.code === 4002 || ev.code === 4401) {
        this.set({ conn: "closed" });
        this.wanted = false;
        return;
      }
      if (this.wanted) this.scheduleReconnect();
      else this.set({ conn: "closed" });
    };
  }

  private scheduleReconnect() {
    if (!this.wanted || this.reconnectTimer) return;
    this.attempts += 1;
    const delay = Math.min(15000, 500 * 2 ** Math.min(this.attempts, 5)) + Math.random() * 400;
    this.set({ conn: "reconnecting" });
    this.reconnectTimer = window.setTimeout(() => {
      this.reconnectTimer = null;
      void this.open(false);
    }, delay);
  }

  takeover() {
    this.attempts = 0;
    this.set({ notice: null });
    void this.open(true);
  }

  /** Sign-out, deletion or identity change: clear everything owned in memory. */
  reset(reason = "signed_out") {
    this.wanted = false;
    this.generation += 1;
    if (this.reconnectTimer) { clearTimeout(this.reconnectTimer); this.reconnectTimer = null; }
    this.teardownAudio(reason);
    const ws = this.ws;
    this.ws = null;
    ws?.close(1000);
    this.stopHeartbeat();
    this.failPending("reset", "Session reset.");
    this.attempts = 0;
    this.state = { ...initial, version: this.state.version + 1 };
    this.listeners.forEach((fn) => fn());
  }

  private startHeartbeat() {
    this.stopHeartbeat();
    this.heartbeat = window.setInterval(() => {
      this.raw("heartbeat", { echo: Date.now() % 1_000_000 });
    }, 20000);
  }

  private stopHeartbeat() {
    if (this.heartbeat) clearInterval(this.heartbeat);
    this.heartbeat = null;
  }

  private failPending(code: string, message: string) {
    this.pending.forEach((p) => { clearTimeout(p.timer); p.reject(new CommandFailure(code, message)); });
    this.pending.clear();
  }

  private raw(type: string, payload: Record<string, unknown>): string | null {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return null;
    const id = newNonce();
    this.ws.send(JSON.stringify({ v: 2, id, type, payload }));
    return id;
  }

  command(type: string, payload: Record<string, unknown> = {}, timeoutMs = 10000): Promise<Record<string, unknown>> {
    return new Promise((resolve, reject) => {
      const id = this.raw(type, payload);
      if (!id) {
        reject(new CommandFailure("not_connected", "Not connected. Reconnecting…"));
        return;
      }
      const timer = window.setTimeout(() => {
        this.pending.delete(id);
        reject(new CommandFailure("timeout", "No response from the server."));
      }, timeoutMs);
      this.pending.set(id, { resolve, reject, timer });
    });
  }

  // ------------------------------------------------------------------ events
  private handle(event: { type: string; payload: Record<string, unknown>; reply_to?: string }) {
    const p = event.payload ?? {};
    if (event.reply_to && this.pending.has(event.reply_to)) {
      const pending = this.pending.get(event.reply_to)!;
      if (event.type === "error") {
        clearTimeout(pending.timer);
        this.pending.delete(event.reply_to);
        pending.reject(new CommandFailure(String(p.code), String(p.message)));
        return;
      }
      if (event.type === "command.result") {
        clearTimeout(pending.timer);
        this.pending.delete(event.reply_to);
        pending.resolve(p);
        return;
      }
    }
    switch (event.type) {
      case "session.ready":
        this.attempts = 0;
        this.startHeartbeat();
        this.applySnapshot(p);
        break;
      case "queue.paused":
        this.set({ phase: "idle", searchingSince: null, pausedReason: String(p.reason) });
        break;
      case "interaction.started":
        this.teardownAudio("new_interaction");
        this.set({
          phase: "in_interaction", interactionId: String(p.interaction_id), source: String(p.source),
          peer: p.peer as Peer, peerInterrupted: false, messages: [], endedReason: null, searchingSince: null,
          friendState: p.friend_state === "friends" ? "friends" : "none", friendRequestId: null,
          relationshipId: (p.relationship_id as string) ?? null, call: null, outgoingInvite: null,
          pausedReason: null, notice: null,
          invites: [],
        });
        break;
      case "interaction.ended":
        if (p.interaction_id !== this.state.interactionId) break;
        this.teardownAudio("conversation_ended");
        // Temporary text is cleared immediately: it is never kept after End.
        this.set({ phase: "ended", messages: [], peer: null, interactionId: null, call: null,
          endedReason: String(p.reason), peerInterrupted: false, friendRequestId: null });
        break;
      case "interaction.interrupted":
        this.set({ peerInterrupted: true, graceSeconds: Number(p.grace_seconds ?? 25) });
        break;
      case "interaction.resumed":
        this.set({ peerInterrupted: false });
        break;
      case "text.received": {
        if (p.interaction_id !== this.state.interactionId) break;
        const msg: ChatMessage = { key: String(p.message_id), message_id: String(p.message_id), mine: false,
          body: String(p.body), sent_at: String(p.sent_at), status: "received" };
        this.set({ messages: [...this.state.messages, msg].slice(-30) });
        break;
      }
      case "text.delivery":
        this.set({ messages: this.state.messages.map((m) => m.message_id === p.message_id ? { ...m, status: "delivered" } : m) });
        break;
      case "friend.requested":
        this.set({ friendState: "requested_by_peer", friendRequestId: String(p.request_id) });
        break;
      case "friend.request_closed":
        this.set({ friendState: "none", notice: { kind: "info", text: "The friend request was closed." } });
        break;
      case "friend.saving":
        this.set({ friendState: "saving", relationshipId: String(p.relationship_id) });
        break;
      case "friend.persisted":
        if (p.relationship_id === this.state.relationshipId) this.set({ friendState: "friends" });
        this.set({ notice: { kind: "success", text: "Friend saved." } });
        break;
      case "friend.accepted":
        this.set({ friendState: p.temporary ? "temporary" : "friends", relationshipId: String(p.relationship_id) });
        break;
      case "friend.removed":
        if (p.relationship_id === this.state.relationshipId) this.set({ friendState: "none", relationshipId: null });
        if (p.reason === "not_saved") this.set({ notice: { kind: "warning", text: "The friendship could not be saved." } });
        break;
      case "invite.received":
        this.set({ invites: [...this.state.invites.filter((i) => i.invite_id !== p.invite_id), {
          invite_id: String(p.invite_id), from: p.from as { display_name: string },
          relationship_id: String(p.relationship_id), expires_at: Date.now() + Number(p.expires_in ?? 30) * 1000 }] });
        break;
      case "invite.closed":
        this.set({
          invites: this.state.invites.filter((i) => i.invite_id !== p.invite_id),
          outgoingInvite: this.state.outgoingInvite?.invite_id === p.invite_id ? null : this.state.outgoingInvite,
          notice: p.state === "declined" ? { kind: "info", text: "The invitation was declined." }
            : p.state === "expired" ? { kind: "info", text: "The invitation expired." } : this.state.notice,
        });
        break;
      case "call.incoming":
        this.set({ call: { call_id: String(p.call_id), state: "ringing_in", muted: false } });
        break;
      case "call.authorized":
        void this.startAudio(p);
        break;
      case "call.sdp":
      case "call.ice":
        void this.audio?.signal(event.type, p);
        break;
      case "call.connected":
        if (this.state.call) this.set({ call: { ...this.state.call, state: "connected" } });
        break;
      case "call.ended":
        this.teardownAudio(String(p.reason));
        if (this.state.call?.call_id === p.call_id) {
          const text = p.reason === "declined" ? "The call was declined." : p.reason === "timeout" ? "No answer." :
            p.reason === "setup_timeout" ? "The call could not connect." : null;
          this.set({ call: null, notice: text ? { kind: "info", text } : this.state.notice });
        }
        break;
      case "session.replaced":
        this.set({ notice: { kind: "info", text: String(p.message) } });
        break;
      case "session.ended":
        this.teardownAudio("session_ended");
        this.set({ phase: "idle", messages: [], peer: null, interactionId: null, call: null,
          notice: { kind: "warning", text: endedText(String(p.reason)) } });
        break;
      case "service.draining":
        this.set({ notice: { kind: "warning", text: String(p.message) } });
        break;
      case "entitlement.changed":
        this.set({ premium: Boolean(p.premium) });
        break;
      case "error":
        this.set({ notice: { kind: "error", text: String(p.message) } });
        break;
      default:
        break;
    }
  }

  private applySnapshot(p: Record<string, unknown>) {
    const interaction = p.interaction as Record<string, unknown> | null;
    const features = (p.features as { audio?: boolean }) ?? {};
    const identity = (p.identity as { premium?: boolean }) ?? {};
    const invites = ((p.invites as Array<Record<string, unknown>>) ?? []).map((i) => ({
      invite_id: String(i.invite_id), from: i.from as { display_name: string },
      relationship_id: String(i.relationship_id), expires_at: Date.now() + Number(i.expires_in ?? 0) * 1000 }));
    const base: Partial<ChatState> = { conn: "open", audioAvailable: features.audio !== false,
      premium: Boolean(identity.premium), invites, notice: null };
    if (interaction) {
      const msgs = (interaction.messages as Array<Record<string, unknown>>).map((m) => ({
        key: String(m.message_id), message_id: String(m.message_id), mine: Boolean(m.mine), body: String(m.body),
        sent_at: String(m.sent_at), status: (m.mine ? (m.delivered ? "delivered" : "accepted") : "received") as ChatMessage["status"],
      }));
      const fs = String(interaction.friend_state);
      this.set({ ...base, phase: "in_interaction", interactionId: String(interaction.interaction_id),
        source: String(interaction.source), peer: interaction.peer as Peer,
        peerInterrupted: Boolean(interaction.peer_interrupted), messages: msgs,
        friendState: (["friends", "requested_by_me", "requested_by_peer"].includes(fs) ? fs : "none") as FriendState,
        friendRequestId: (interaction.friend_request_id as string) ?? null,
        relationshipId: (interaction.relationship_id as string) ?? null,
        call: interaction.call ? { call_id: String((interaction.call as { call_id: string }).call_id),
          state: (interaction.call as { incoming: boolean }).incoming ? "ringing_in" : "ringing_out", muted: false } : null,
      });
    } else {
      const searching = p.state === "searching";
      this.set({ ...base, phase: searching ? "searching" : this.state.phase === "ended" ? "ended" : "idle",
        searchingSince: searching ? this.state.searchingSince ?? Date.now() : null,
        interactionId: null, peer: null, messages: [] });
    }
  }

  // --------------------------------------------------------------- actions
  async search(acceptEveryone = false) {
    this.set({ pausedReason: null, notice: null });
    await this.command("queue.join", { accept_everyone: acceptEveryone });
    this.set({ phase: "searching", searchingSince: Date.now(), endedReason: null });
  }

  async cancelSearch() {
    await this.command("queue.cancel");
    this.set({ phase: "idle", searchingSince: null });
  }

  async end() {
    const id = this.state.interactionId;
    if (!id) return;
    this.teardownAudio("ended");
    try {
      await this.command("interaction.end", { interaction_id: id }, 5000);
    } catch {
      // Safety does not depend on a healthy socket: use the HTTP fallback.
      await api.post("/api/v1/interactions/end", { interaction_id: id });
      if (this.state.interactionId === id) this.set({ phase: "ended", messages: [], peer: null, interactionId: null, endedReason: "ended" });
    }
  }

  async next() {
    const id = this.state.interactionId;
    if (!id) return this.search();
    this.teardownAudio("next");
    await this.command("interaction.next", { interaction_id: id });
    this.set({ phase: "searching", searchingSince: Date.now(), messages: [], peer: null, interactionId: null });
  }

  async sendText(body: string) {
    const id = this.state.interactionId;
    if (!id) return;
    const key = newNonce();
    const pending: ChatMessage = { key, mine: true, body, status: "pending" };
    this.set({ messages: [...this.state.messages, pending].slice(-30) });
    try {
      const ack = await this.command("text.send", { interaction_id: id, client_id: key, body });
      this.set({ messages: this.state.messages.map((m) => m.key === key
        ? { ...m, status: "accepted", message_id: String(ack.message_id), sent_at: String(ack.sent_at) } : m) });
    } catch (e) {
      this.set({ messages: this.state.messages.map((m) => m.key === key
        ? { ...m, status: "failed", error: (e as Error).message } : m) });
    }
  }

  /** Called after an incoming message is actually rendered (Delivered ≠ Read). */
  ackRendered(messageId: string) {
    const id = this.state.interactionId;
    if (id) this.raw("text.delivered", { interaction_id: id, message_id: messageId });
  }

  async requestFriend() {
    const id = this.state.interactionId;
    if (!id) return;
    const r = await this.command("friend.request", { interaction_id: id });
    if (r.state === "pending") this.set({ friendState: "requested_by_me" });
    else if (r.state === "saving") this.set({ friendState: "saving", relationshipId: String(r.relationship_id) });
    else if (r.state === "temporary") this.set({ friendState: "temporary", relationshipId: String(r.relationship_id) });
  }

  async respondFriend(accept: boolean) {
    const requestId = this.state.friendRequestId;
    if (!requestId) return;
    const r = await this.command("friend.respond", { request_id: requestId, accept });
    if (!accept) this.set({ friendState: "none", friendRequestId: null });
    else if (r.state === "saving") this.set({ friendState: "saving", relationshipId: String(r.relationship_id) });
    else if (r.state === "temporary") this.set({ friendState: "temporary", relationshipId: String(r.relationship_id) });
  }

  async invite(relationshipId: string) {
    const r = await this.command("friend.invite", { relationship_id: relationshipId });
    if (r.state === "sent") {
      this.set({ outgoingInvite: { invite_id: String(r.invite_id), expires_at: Date.now() + Number(r.expires_in ?? 30) * 1000 } });
    }
    return r;
  }

  async cancelInvite() {
    const inv = this.state.outgoingInvite;
    if (!inv) return;
    await this.command("friend.invite.cancel", { invite_id: inv.invite_id });
    this.set({ outgoingInvite: null });
  }

  async respondInvite(inviteId: string, accept: boolean) {
    this.set({ invites: this.state.invites.filter((i) => i.invite_id !== inviteId) });
    await this.command("friend.invite.respond", { invite_id: inviteId, accept });
  }

  // ----------------------------------------------------------------- audio
  async requestCall() {
    const id = this.state.interactionId;
    if (!id) return;
    const r = await this.command("call.request", { interaction_id: id });
    this.set({ call: { call_id: String(r.call_id), state: "ringing_out", muted: false } });
  }

  async respondCall(accept: boolean) {
    const call = this.state.call;
    if (!call) return;
    if (!accept) this.set({ call: null });
    await this.command("call.respond", { call_id: call.call_id, accept });
  }

  async endCall() {
    const call = this.state.call;
    if (!call) return;
    this.teardownAudio("hangup");
    this.set({ call: null });
    try {
      await this.command("call.end", { call_id: call.call_id, reason: call.state === "ringing_out" ? "cancel" : "hangup" });
    } catch {
      /* the server also ends calls on End/disconnect */
    }
  }

  toggleMute() {
    if (!this.state.call || !this.audio) return;
    const muted = !this.state.call.muted;
    this.audio.setMuted(muted);
    this.set({ call: { ...this.state.call, muted } });
  }

  private async startAudio(p: Record<string, unknown>) {
    const callId = String(p.call_id);
    this.teardownAudio("replaced");
    this.set({ call: { call_id: callId, state: "connecting", muted: false } });
    const audio = new AudioCall({
      callId,
      role: p.role === "offerer" ? "offerer" : "answerer",
      iceServers: (p.ice_servers as RTCIceServer[]) ?? [],
      iceTransportPolicy: p.ice_transport_policy === "relay" ? "relay" : "all",
      send: (type, payload) => { this.raw(type, payload); },
      onConnected: () => {
        this.raw("call.state", { call_id: callId, state: "connected" });
      },
      onFailed: (reason) => {
        this.raw("call.end", { call_id: callId, reason: reason === "permission_denied" ? "permission_denied" : "failed" });
        this.set({ call: null, notice: { kind: "warning", text: reason === "permission_denied"
          ? "Microphone permission was denied, so the call ended. Text continues." : "The call could not connect." } });
        this.teardownAudio(reason);
      },
    });
    this.audio = audio;
    await audio.start();
  }

  private teardownAudio(reason: string) {
    if (this.audio) {
      this.audio.close(reason);
      this.audio = null;
    }
  }

  clearNotice() {
    this.set({ notice: null });
  }

  dismissEnded() {
    this.set({ phase: "idle", endedReason: null });
  }
}

export const coordinator = new ClientCoordinator();

if (typeof window !== "undefined") {
  // Page teardown always releases the microphone and ends calls.
  window.addEventListener("pagehide", () => coordinator.reset("page_closed"));
}
