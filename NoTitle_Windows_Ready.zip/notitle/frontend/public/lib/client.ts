import { ApiClient } from "@notitle/shared";

/** One API client per browser tab; it survives client-side route transitions. */
export const api = new ApiClient({ bootstrapPath: "/api/v1/bootstrap" });

export interface PolicySummary {
  kind: string;
  title: string;
  version: string;
  route: string;
  digest: string;
  publication_state: string;
}

export interface Bootstrap {
  csrf_token: string;
  server_time: string;
  owner: { kind: "guest" | "account"; username?: string; display_name?: string; expires_at?: string } | null;
  policies: Record<string, PolicySummary>;
  features: { admission: boolean; audio: boolean; payments: boolean; payment_provider: string; environment: string };
}

export interface CatalogItem { id: string; label: string }

export interface Catalogs {
  version: string;
  topics: CatalogItem[];
  industries: CatalogItem[];
  roles: CatalogItem[];
  experience: CatalogItem[];
  interests: CatalogItem[];
  genders: CatalogItem[];
  report_reasons: string[];
  case_categories: string[];
}

export interface Preferences {
  gender_preference: string;
  professional_enabled: boolean;
  industry_ids: string[];
  role_ids: string[];
  experience_ids: string[];
  interest_ids: string[];
  topic_ids: string[];
  version: number;
}

export interface Professional {
  industry_id: string | null;
  role_id: string | null;
  experience_id: string | null;
  interest_ids: string[];
  topic_ids: string[];
}

export interface Me {
  kind: "guest" | "account";
  username?: string;
  display_name: string;
  display_name_editable: boolean;
  gender: string;
  topic_id: string;
  bio: string;
  profile_version: number;
  consents: Record<string, { choice: boolean; policy_version: string; recorded_at?: string }>;
  professional: Professional | null;
  preferences: {
    saved: Preferences;
    effective: { gender_preference: string; professional_relevance: boolean; note: string | null };
  };
  premium: { active: boolean; eligible: boolean; expires_at?: string | null };
  expires_at?: string;
  created_at?: string;
}

export function wsUrl(path: string): string {
  const { protocol, hostname, port, host } = window.location;
  const scheme = protocol === "https:" ? "wss" : "ws";
  // `next dev` runs on :3000 and cannot proxy WebSockets; talk to the runtime directly.
  if (port === "3000") return `${scheme}://${hostname}:8080${path}`;
  return `${scheme}://${host}${path}`;
}
