import { createHash } from "node:crypto";
import { readFileSync, readdirSync } from "node:fs";
import path from "node:path";

/**
 * Build-time only: reads the same policy markdown the backend digests
 * (backend/policies/*.md), so the published text and the consent proof agree.
 */
export interface PolicyDoc {
  kind: string;
  title: string;
  version: string;
  route: string;
  state: string;
  body: string;
  digest: string;
}

const DIR = path.resolve(process.cwd(), "..", "..", "backend", "policies");

export function loadPolicies(): Record<string, PolicyDoc> {
  const out: Record<string, PolicyDoc> = {};
  for (const file of readdirSync(DIR).filter((f) => f.endsWith(".md"))) {
    const raw = readFileSync(path.join(DIR, file)).toString("utf-8").replace(/\r\n/g, "\n");
    const match = /^---\n([\s\S]*?)\n---\n([\s\S]*)$/.exec(raw);
    if (!match) throw new Error(`${file}: missing front matter`);
    const meta: Record<string, string> = {};
    for (const line of match[1].split("\n")) {
      const idx = line.indexOf(":");
      if (idx > 0) meta[line.slice(0, idx).trim()] = line.slice(idx + 1).trim();
    }
    out[meta.kind] = {
      kind: meta.kind,
      title: meta.title,
      version: meta.version,
      route: meta.route,
      state: meta.state ?? "draft",
      body: match[2].trim(),
      digest: createHash("sha256").update(raw, "utf-8").digest("hex"),
    };
  }
  return out;
}

export function loadPolicy(kind: string): PolicyDoc {
  const doc = loadPolicies()[kind];
  if (!doc) throw new Error(`unknown policy ${kind}`);
  return doc;
}
