import { PolicyPage, policyMetadata } from "@/components/PolicyPage";

export const metadata = policyMetadata("community");

export default function Page() {
  return <PolicyPage kind="community" />;
}
