"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { type FormEvent, useState } from "react";

import { ApiError, Button, Field, Notice, errorMessage, formatDateTime } from "@notitle/shared";

import { useApp } from "@/components/AppContext";
import { api } from "@/lib/client";
import { coordinator } from "@/lib/coordinator";

interface SessionItem { session_id: string; created_at: string; last_active_at: string }

export default function LoginPage() {
  const { me, refresh } = useApp();
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [confirmGuest, setConfirmGuest] = useState(false);
  const [limit, setLimit] = useState<{ challenge_id: string; sessions: SessionItem[] } | null>(null);

  async function done() {
    coordinator.reset("signed_in");
    await refresh();
    router.push("/chat/");
  }

  async function submit(e: FormEvent, endGuest = false) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api.post("/api/v1/auth/login", { username, password, confirm_end_guest: endGuest });
      await done();
    } catch (err) {
      if (err instanceof ApiError && err.code === "guest_active") setConfirmGuest(true);
      else if (err instanceof ApiError && err.code === "session_limit") {
        setLimit(err.details as { challenge_id: string; sessions: SessionItem[] });
      } else setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  async function revoke(sessionId: string) {
    if (!limit) return;
    setBusy(true);
    try {
      await api.post("/api/v1/auth/session-limit/resolve", { challenge_id: limit.challenge_id, session_id: sessionId });
      await done();
    } catch (err) {
      setError(errorMessage(err));
      if ((err as ApiError).code === "expired") setLimit(null);
    } finally {
      setBusy(false);
    }
  }

  if (me?.kind === "account") {
    return <div className="container page narrow"><Notice kind="info" title="You are signed in"><Link href="/chat/">Go to Chat</Link></Notice></div>;
  }

  return (
    <div className="container page narrow">
      <h1>Log in</h1>
      {error ? <Notice kind="error">{error}</Notice> : null}
      {limit ? (
        <div className="card">
          <h2>Signed in on five devices</h2>
          <p>Choose a session to sign out. Only then is this device signed in.</p>
          <ul className="stack" style={{ listStyle: "none", padding: 0 }}>
            {limit.sessions.map((s) => (
              <li key={s.session_id} className="row-between">
                <span>Started {formatDateTime(s.created_at)} · last active {formatDateTime(s.last_active_at)}</span>
                <Button variant="secondary" busy={busy} onClick={() => revoke(s.session_id)}>Sign that one out</Button>
              </li>
            ))}
          </ul>
          <Button variant="ghost" onClick={() => setLimit(null)}>Cancel</Button>
        </div>
      ) : confirmGuest ? (
        <div className="card">
          <h2>End your guest session?</h2>
          <p>Logging in ends your current guest conversation and discards temporary guest friends. Nothing from the guest identity is imported into your account.</p>
          <div className="row">
            <Button busy={busy} onClick={(e) => submit(e as unknown as FormEvent, true)}>End guest session and log in</Button>
            <Button variant="secondary" onClick={() => setConfirmGuest(false)}>Keep my guest session</Button>
          </div>
        </div>
      ) : (
        <form className="card" onSubmit={(e) => submit(e)}>
          <Field label="Username" value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username" required />
          <Field label="Password" type="password" value={password} onChange={(e) => setPassword(e.target.value)}
            autoComplete="current-password" required />
          <div className="form-actions">
            <Button type="submit" busy={busy}>Log in</Button>
            <Link className="btn btn-ghost" href="/recovery/">Forgot password?</Link>
            <Link className="btn btn-ghost" href="/register/">Create an account</Link>
          </div>
        </form>
      )}
    </div>
  );
}
