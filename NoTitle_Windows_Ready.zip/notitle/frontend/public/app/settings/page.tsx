"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { type FormEvent, useState } from "react";

import {
  ApiError, Button, Checkbox, EmptyState, Field, Loading, Notice, SecretPanel, errorMessage, formatDateTime, useAsync,
} from "@notitle/shared";

import { useApp } from "@/components/AppContext";
import { RequireIdentity } from "@/components/forms";
import { ReauthDialog } from "@/components/ReauthDialog";
import { api } from "@/lib/client";
import { coordinator } from "@/lib/coordinator";

interface SessionItem { session_id: string; is_current: boolean; created_at: string; last_active_at: string; expires_at: string }
interface BlockItem { block_ref: string; label: string; created_at: string; scope: string }

function Blocked() {
  const { data, error, loading, reload } = useAsync(() => api.get<{ items: BlockItem[] }>("/api/v1/blocks"), []);
  const [msg, setMsg] = useState<string | null>(null);
  if (loading && !data) return <Loading />;
  if (error) return <Notice kind="error">{errorMessage(error)}</Notice>;
  return (
    <>
      {msg ? <Notice kind="info" live>{msg}</Notice> : null}
      {!data?.items.length ? <p className="muted">You have not blocked anyone.</p> : (
        <ul style={{ listStyle: "none", padding: 0 }}>
          {data.items.map((b) => (
            <li key={b.block_ref} className="friend-row">
              <span>{b.label} · since {formatDateTime(b.created_at)}</span>
              <Button variant="secondary" onClick={async () => {
                try {
                  await api.delete(`/api/v1/blocks/${encodeURIComponent(b.block_ref)}`);
                  setMsg("Unblocked. This does not restore a friendship or start a conversation.");
                  reload();
                } catch (e) { setMsg(errorMessage(e)); }
              }}>Unblock</Button>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}

function AccountSettings() {
  const { me, refresh } = useApp();
  const router = useRouter();
  const account = me?.kind === "account";
  const sessions = useAsync(() => (account ? api.get<{ items: SessionItem[] }>("/api/v1/me/sessions") : Promise.resolve({ items: [] })), [account]);
  const [reauth, setReauth] = useState<null | (() => Promise<void>)>(null);
  const [pw, setPw] = useState({ current: "", next: "" });
  const [rotation, setRotation] = useState<{ reservation_id: string; secret: string } | null>(null);
  const [rotSaved, setRotSaved] = useState(false);
  const [status, setStatus] = useState<{ kind: "success" | "error"; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  async function withReauth(fn: () => Promise<void>) {
    try {
      await fn();
    } catch (e) {
      if (e instanceof ApiError && e.code === "reauth_required") setReauth(() => fn);
      else setStatus({ kind: "error", text: errorMessage(e) });
    }
  }

  async function signOut(all: boolean) {
    setBusy(true);
    try {
      await api.post(all ? "/api/v1/auth/logout-all" : "/api/v1/auth/logout");
    } finally {
      coordinator.reset("signed_out");
      await refresh();
      setBusy(false);
      router.push("/");
    }
  }

  async function changePassword(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setStatus(null);
    try {
      await api.post("/api/v1/me/password", { current_password: pw.current, new_password: pw.next });
      setPw({ current: "", next: "" });
      setStatus({ kind: "success", text: "Password changed. Your other devices were signed out." });
      sessions.reload();
    } catch (err) {
      setStatus({ kind: "error", text: errorMessage(err) });
    } finally {
      setBusy(false);
    }
  }

  if (!me) return <div className="container page"><Loading /></div>;

  return (
    <div className="container page narrow">
      <h1>Account</h1>
      {status ? <Notice kind={status.kind} live>{status.text}</Notice> : null}
      <div className="grid grid-2" style={{ marginBottom: 16 }}>
        <Link className="card" href="/profile/"><strong>Profile</strong><br /><span className="muted small">Display name, topic, bio</span></Link>
        <Link className="card" href="/preferences/"><strong>Preferences</strong><br /><span className="muted small">Who you match with</span></Link>
        <Link className="card" href="/account/privacy/"><strong>Privacy</strong><br /><span className="muted small">Consents, export, deletion</span></Link>
        {account ? <Link className="card" href="/account/premium/"><strong>Premium & receipts</strong><br /><span className="muted small">Passes and payment records</span></Link> : null}
      </div>
      {account ? (
        <>
          <section className="card" style={{ marginBottom: 16 }}>
            <h2>Signed-in devices</h2>
            {sessions.loading && !sessions.data ? <Loading /> : !sessions.data?.items.length ? <EmptyState title="No active sessions" /> : (
              <ul style={{ listStyle: "none", padding: 0 }}>
                {sessions.data.items.map((s) => (
                  <li key={s.session_id} className="friend-row">
                    <span>{s.is_current ? <strong>This device · </strong> : null}started {formatDateTime(s.created_at)} · active {formatDateTime(s.last_active_at)}</span>
                    {!s.is_current ? (
                      <Button variant="secondary" onClick={() => withReauth(async () => {
                        await api.delete(`/api/v1/me/sessions/${s.session_id}`);
                        sessions.reload();
                      })}>Sign out</Button>
                    ) : null}
                  </li>
                ))}
              </ul>
            )}
            <p className="hint">Up to five devices can be signed in. Sessions expire after 7 days of inactivity or 30 days.</p>
            <Button variant="secondary" busy={busy} onClick={() => signOut(true)}>Sign out everywhere</Button>
          </section>
          <section className="card" style={{ marginBottom: 16 }}>
            <h2>Change password</h2>
            <form onSubmit={changePassword}>
              <Field label="Current password" type="password" autoComplete="current-password" value={pw.current} onChange={(e) => setPw({ ...pw, current: e.target.value })} />
              <Field label="New password" type="password" autoComplete="new-password" value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} hint="At least 12 characters." />
              <Button type="submit" busy={busy}>Change password</Button>
            </form>
          </section>
          <section className="card" style={{ marginBottom: 16 }}>
            <h2>Recovery code</h2>
            {!rotation ? (
              <>
                <p>Create a new recovery code. The old one stops working once you confirm.</p>
                <Button variant="secondary" onClick={() => withReauth(async () => {
                  setRotation(await api.post("/api/v1/operations/prepare", { kind: "recovery_rotation" }));
                })}>Create a new recovery code</Button>
              </>
            ) : (
              <>
                <SecretPanel title="New recovery code" secret={rotation.secret} filename="notitle-recovery-code.txt"
                  explanation="Save this code. It replaces your current code when you confirm." />
                <Checkbox checked={rotSaved} onChange={setRotSaved} label="I have saved the new recovery code." />
                <div className="row">
                  <Button disabled={!rotSaved} onClick={() => withReauth(async () => {
                    await api.post("/api/v1/me/recovery/rotate", { reservation_id: rotation.reservation_id, recovery_code: rotation.secret, saved: rotSaved });
                    setRotation(null);
                    setRotSaved(false);
                    setStatus({ kind: "success", text: "Recovery code replaced." });
                  })}>Replace recovery code</Button>
                  <Button variant="ghost" onClick={() => setRotation(null)}>Cancel</Button>
                </div>
              </>
            )}
          </section>
        </>
      ) : (
        <Notice kind="info" title="You are using a guest identity">
          It expires after 30 minutes of inactivity (24 hours at most). <Link href="/register/">Register</Link> to keep friends, settings and receipts.
          {" "}<a href="/api/v1/me/consent-proof" download>Download consent proof</a>
        </Notice>
      )}
      <section className="card" style={{ marginBottom: 16 }}>
        <h2>Blocked</h2>
        <Blocked />
      </section>
      <Button variant="secondary" busy={busy} onClick={() => signOut(false)}>Sign out</Button>
      <ReauthDialog open={Boolean(reauth)} onClose={() => setReauth(null)} onDone={() => {
        const fn = reauth;
        setReauth(null);
        if (fn) void withReauth(fn);
      }} />
    </div>
  );
}

export default function SettingsPage() {
  return <RequireIdentity what="account settings"><AccountSettings /></RequireIdentity>;
}
