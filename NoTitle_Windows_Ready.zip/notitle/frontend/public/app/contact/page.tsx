import { PolicyPage, policyMetadata } from "@/components/PolicyPage";

export const metadata = policyMetadata("contact");

export default function Page() {
  return <PolicyPage kind="contact" />;
}
