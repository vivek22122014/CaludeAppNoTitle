import { PolicyPage, policyMetadata } from "@/components/PolicyPage";

export const metadata = policyMetadata("processors");

export default function Page() {
  return <PolicyPage kind="processors" />;
}
