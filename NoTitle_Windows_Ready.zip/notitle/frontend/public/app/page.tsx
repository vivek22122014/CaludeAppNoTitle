import Link from "next/link";

import { HomeActions } from "@/components/HomeActions";

export default function Home() {
  return (
    <div className="container">
      <section className="hero">
        <p className="badge badge-primary">Adults only · 18+</p>
        <h1>Talk honestly about work — without your name on it.</h1>
        <p className="lead">
          NoTitle connects you one-to-one with another adult to discuss careers, salaries, hiring, company culture and
          office politics. You stay pseudonymous. Ordinary text is temporary: it is never saved and disappears when the
          conversation ends.
        </p>
        <HomeActions />
      </section>
      <section className="grid grid-3" aria-label="How NoTitle works">
        <div className="card feature">
          <h3>Pick a topic</h3>
          <p>Choose a discussion topic and search when you are ready. Nobody is matched until you press Search.</p>
        </div>
        <div className="card feature">
          <h3>Temporary text</h3>
          <p>Messages live only in server memory during the conversation. End clears them. Audio calls need both people to agree.</p>
        </div>
        <div className="card feature">
          <h3>Safety first</h3>
          <p>End, Block and Report are always one tap away. Reports keep only the messages you select. Moderators can help through Chat with Moderator.</p>
        </div>
      </section>
      <section className="card" style={{ margin: "24px 0 48px" }}>
        <h2>What NoTitle is not</h2>
        <p>
          It is not a dating site, a recruitment marketplace, or a source of verified professional advice. Participants
          declare their own details; nothing is verified. Pseudonymity does not stop someone from identifying themselves
          (or you) through what is written — share carefully.
        </p>
        <p className="row">
          <Link href="/how-it-works/">How it works</Link>
          <Link href="/safety/">Safety</Link>
          <Link href="/premium/">Premium passes</Link>
          <Link href="/community-guidelines/">Community Guidelines</Link>
        </p>
      </section>
    </div>
  );
}
