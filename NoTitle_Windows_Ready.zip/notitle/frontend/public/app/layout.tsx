import "@notitle/shared/src/tokens.css";
import "./public.css";

import type { Metadata, Viewport } from "next";
import Link from "next/link";
import type { ReactNode } from "react";

import { AppProvider } from "@/components/AppContext";
import { Header } from "@/components/Header";

export const metadata: Metadata = {
  title: { default: "NoTitle — pseudonymous conversations about work", template: "%s · NoTitle" },
  description: "Talk one-to-one, pseudonymously, about careers, salaries, hiring and workplace culture. Adults only. Ordinary chat is temporary.",
  robots: { index: false, follow: false },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: "#0b6466",
};

const POLICY_LINKS = [
  ["/privacy/", "Privacy"], ["/terms/", "Terms"], ["/community-guidelines/", "Community Guidelines"],
  ["/refund-policy/", "Refunds & Billing"], ["/cookies/", "Cookies"], ["/data-retention/", "Data Retention"],
  ["/your-rights/", "Your Rights"], ["/grievance/", "Grievance"], ["/contact/", "Contact"], ["/legal/", "Legal"],
  ["/processors/", "Service Providers"], ["/account-deletion/", "Account deletion"],
];

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <a className="skip" href="#main">Skip to content</a>
        <AppProvider>
          <div className="draft-banner" role="note">
            Development build · policies are drafts pending legal review · payments use a simulator unless configured
          </div>
          <Header />
          <main id="main" tabIndex={-1}>{children}</main>
          <footer className="site-footer">
            <div className="container">
              <nav aria-label="Policies">
                {POLICY_LINKS.map(([href, label]) => <Link key={href} href={href}>{label}</Link>)}
              </nav>
              <p>NoTitle is for adults (18+). Ordinary conversations are temporary and not saved. There is no support email: use Chat with Moderator.</p>
            </div>
          </footer>
        </AppProvider>
      </body>
    </html>
  );
}
