"use client";

import { ChatScreen } from "@/components/chat/ChatScreen";
import { RequireIdentity } from "@/components/forms";

export default function ChatPage() {
  return (
    <RequireIdentity what="Chat">
      <ChatScreen />
    </RequireIdentity>
  );
}
