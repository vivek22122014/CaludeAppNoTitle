import { PolicyPage, policyMetadata } from "@/components/PolicyPage";

export const metadata = policyMetadata("refund");

export default function Page() {
  return <PolicyPage kind="refund" />;
}
