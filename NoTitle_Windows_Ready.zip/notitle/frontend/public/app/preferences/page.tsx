"use client";

import Link from "next/link";
import { type FormEvent, useEffect, useState } from "react";

import { Button, Checkbox, Loading, MultiSelect, Notice, Select, errorMessage } from "@notitle/shared";

import { useApp } from "@/components/AppContext";
import { RequireIdentity } from "@/components/forms";
import { api, type Me, type Preferences } from "@/lib/client";

const GENDER_PREFS = [
  { id: "everyone", label: "Everyone" }, { id: "male", label: "Male only" },
  { id: "female", label: "Female only" }, { id: "other", label: "Other only" },
];

function PreferencesForm() {
  const { me, catalogs, setMe } = useApp();
  const [prefs, setPrefs] = useState<Preferences | null>(null);
  const [status, setStatus] = useState<{ kind: "success" | "error"; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (me) setPrefs(me.preferences.saved); }, [me]);
  if (!me || !catalogs || !prefs) return <div className="container page"><Loading /></div>;
  const guest = me.kind === "guest";
  const eff = me.preferences.effective;

  async function save(e: FormEvent) {
    e.preventDefault();
    if (!prefs) return;
    setBusy(true);
    setStatus(null);
    try {
      const { version, ...rest } = prefs;
      const updated = await api.patch<Me>("/api/v1/me/preferences", { expected_version: version, ...rest });
      setMe(updated);
      setStatus({ kind: "success", text: "Preferences saved. A search already in progress keeps its place." });
    } catch (err) {
      setStatus({ kind: "error", text: errorMessage(err) });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="container page narrow">
      <h1>Matching preferences</h1>
      {status ? <Notice kind={status.kind} live>{status.text}</Notice> : null}
      <div className="card" style={{ marginBottom: 16 }}>
        <h2>Currently effective</h2>
        <p>Gender: <strong>{GENDER_PREFS.find((g) => g.id === eff.gender_preference)?.label}</strong> · Professional relevance: <strong>{eff.professional_relevance ? "On (very soft)" : "Off"}</strong></p>
        {eff.note ? <p className="hint">{eff.note}</p> : null}
        {!me.premium.active && !guest ? <p><Link href="/premium/">Premium passes</Link> make saved choices effective. They never add queue priority.</p> : null}
      </div>
      <form className="card" onSubmit={save}>
        <Select label="Who would you like to talk with?" options={GENDER_PREFS} value={prefs.gender_preference}
          disabled={guest} onChange={(e) => setPrefs({ ...prefs, gender_preference: e.target.value })}
          hint={guest ? "Guests always match with everyone." : "A specific choice is used only while you have an active Premium pass. Matching is always mutual."} />
        <Checkbox checked={prefs.professional_enabled} onChange={(v) => setPrefs({ ...prefs, professional_enabled: v })}
          label="Use professional relevance when available"
          description="Very soft: it only nudges ties during the first few seconds of a search and never excludes anyone. General Talk turns it off." />
        <MultiSelect label="Preferred industries (up to 5)" options={catalogs.industries} max={5} value={prefs.industry_ids}
          onChange={(v) => setPrefs({ ...prefs, industry_ids: v })} />
        <MultiSelect label="Preferred roles (up to 5)" options={catalogs.roles} max={5} value={prefs.role_ids}
          onChange={(v) => setPrefs({ ...prefs, role_ids: v })} />
        <MultiSelect label="Preferred experience (up to 5)" options={catalogs.experience} max={5} value={prefs.experience_ids}
          onChange={(v) => setPrefs({ ...prefs, experience_ids: v })} />
        <MultiSelect label="Shared interests (up to 10)" options={catalogs.interests} max={10} value={prefs.interest_ids}
          onChange={(v) => setPrefs({ ...prefs, interest_ids: v })} />
        <Button type="submit" busy={busy}>Save preferences</Button>
      </form>
    </div>
  );
}

export default function PreferencesPage() {
  return <RequireIdentity what="preferences"><PreferencesForm /></RequireIdentity>;
}
