import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "How it works",
  description: "How NoTitle matches people, keeps ordinary chat temporary and protects privacy.",
};

export default function HowItWorks() {
  return (
    <div className="container page narrow">
      <h1>How it works</h1>
      <h2>1. Enter as a guest or with an account</h2>
      <p>
        Guests get a generated pseudonym that lasts at most 24 hours and disappears if the service restarts. An account
        keeps your display name, friends, preferences and saved support cases. There is no email: you get a recovery
        code once, and it is the only way to reset a forgotten password.
      </p>
      <h2>2. Search explicitly</h2>
      <p>
        Everyone — guests, free accounts and Premium — shares one matching pool. Nobody gets queue priority. Matching
        considers how long people have waited, avoids immediately repeating the same pair, and gives a very small,
        short-lived preference to people who picked the same topic.
      </p>
      <h2>3. Talk with temporary text</h2>
      <p>
        Messages are plain text (up to 2,000 characters) and are held only in server memory for the current
        conversation — at most the last 30. <strong>Delivered</strong> means the other browser displayed the message,
        not that a person read it. If either of you disconnects, there are 25 seconds to reconnect before the
        conversation ends. Ending clears everything.
      </p>
      <h2>4. Optional audio</h2>
      <p>
        Either of you can request a voice call. The microphone is used only after both accept. Calls end immediately
        when the conversation ends, someone blocks, or the connection drops. Calls are never recorded.
      </p>
      <h2>5. Friends and invitations</h2>
      <p>
        If both of you agree, you become friends. Between two accounts the friendship is saved; with a guest it is
        temporary. When a friend is available you can invite them to talk; they choose whether to accept.
      </p>
      <h2>6. Premium (optional)</h2>
      <p>
        One-time passes add a gender preference and a very soft professional relevance. They never add priority and do
        not renew automatically. <Link href="/premium/">See Premium</Link>.
      </p>
    </div>
  );
}
