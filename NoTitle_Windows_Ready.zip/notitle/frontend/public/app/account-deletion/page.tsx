"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { type FormEvent, Suspense, useEffect, useState } from "react";

import { Button, Field, Loading, Notice, errorMessage, formatDateTime, titleCase } from "@notitle/shared";

import { api } from "@/lib/client";

interface DeletionStatus { deletion_ref: string; state: string; requested_at: string; completed_at: string | null; retained_categories: string[] }

function Deletion() {
  const submitted = useSearchParams().get("submitted") === "1";
  const [status, setStatus] = useState<DeletionStatus | null>(null);
  const [reference, setReference] = useState("");
  const [secret, setSecret] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function load() {
    try {
      setStatus(await api.get<DeletionStatus>("/api/v1/privacy/status"));
    } catch {
      setStatus(null);
    }
  }
  useEffect(() => { void load(); }, []);

  async function access(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api.post("/api/v1/privacy/status/access", { reference, secret });
      await load();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="container page narrow">
      <h1>Account deletion</h1>
      {submitted ? <Notice kind="success" title="Deletion accepted">Your account is disabled. Keep your deletion receipt to check progress here.</Notice> : null}
      <h2>How to delete an account</h2>
      <ol>
        <li>Sign in and open <Link href="/account/privacy/">Account → Privacy</Link>.</li>
        <li>Choose <strong>Delete my account</strong>, save the deletion receipt and confirm with your password.</li>
        <li>Access stops immediately. Profile minimisation completes within 30 days.</li>
      </ol>
      <p>Lost your password? <Link href="/recovery/">Recover the account</Link> first with your recovery code, or open a <Link href="/support/">Chat with Moderator</Link> case.</p>
      {status ? (
        <div className="card">
          <h2>Status</h2>
          <p>Reference <code className="mono">{status.deletion_ref}</code> · <span className="badge badge-primary">{titleCase(status.state)}</span></p>
          <p>Requested {formatDateTime(status.requested_at)}{status.completed_at ? ` · completed ${formatDateTime(status.completed_at)}` : ""}</p>
          <p><strong>Kept with restricted access:</strong></p>
          <ul>{status.retained_categories.map((c) => <li key={c}>{c}</li>)}</ul>
          <Button variant="secondary" onClick={() => void load()}>Refresh</Button>
        </div>
      ) : (
        <form className="card" onSubmit={access}>
          <h2>Check deletion status</h2>
          {error ? <Notice kind="error">{error}</Notice> : null}
          <Field label="Deletion reference" value={reference} onChange={(e) => setReference(e.target.value)} placeholder="dl_…" autoComplete="off" />
          <Field label="Receipt secret" value={secret} onChange={(e) => setSecret(e.target.value)} autoComplete="off" />
          <Button type="submit" busy={busy}>Show status</Button>
        </form>
      )}
    </div>
  );
}

export default function Page() {
  return <Suspense fallback={<div className="container page"><Loading /></div>}><Deletion /></Suspense>;
}
