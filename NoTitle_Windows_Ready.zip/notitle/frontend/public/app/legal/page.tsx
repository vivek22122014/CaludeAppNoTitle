import { PolicyPage, policyMetadata } from "@/components/PolicyPage";

export const metadata = policyMetadata("legal");

export default function Page() {
  return <PolicyPage kind="legal" />;
}
