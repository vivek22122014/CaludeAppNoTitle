"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";

import { Button, Dialog, EmptyState, Loading, Notice, errorMessage, labelFor, useAsync } from "@notitle/shared";

import { useApp } from "@/components/AppContext";
import { InviteBanner } from "@/components/chat/InviteBanner";
import { useChat } from "@/components/chat/useChat";
import { RequireIdentity } from "@/components/forms";
import { api } from "@/lib/client";
import { coordinator } from "@/lib/coordinator";

interface Friend {
  relationship_id: string;
  state: "saved" | "saving" | "temporary";
  revision: number;
  presence: "available" | "busy" | "offline";
  friend: { display_name: string; gender: string; topic_id: string; bio: string };
  since: string | null;
}

function FriendsList() {
  const { catalogs } = useApp();
  const chat = useChat(true);
  const router = useRouter();
  const { data, error, loading, reload } = useAsync(() => api.get<{ items: Friend[] }>("/api/v1/friends"), []);
  const [notice, setNotice] = useState<string | null>(null);
  const [confirm, setConfirm] = useState<{ friend: Friend; action: "remove" | "block" } | null>(null);
  const [busy, setBusy] = useState(false);

  // Presence/relationship events from the socket trigger a quiet refresh.
  useEffect(() => {
    const t = setTimeout(reload, 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chat.version]);

  useEffect(() => {
    if (chat.phase === "in_interaction" && chat.source === "invite") router.push("/chat/");
  }, [chat.phase, chat.source, router]);

  async function invite(f: Friend) {
    setNotice(null);
    try {
      const r = await coordinator.invite(f.relationship_id);
      if (r.state === "accepted") router.push("/chat/");
      else setNotice(`Invitation sent to ${f.friend.display_name}. They have 30 seconds to accept.`);
    } catch (e) {
      setNotice(errorMessage(e));
    }
  }

  async function act() {
    if (!confirm) return;
    setBusy(true);
    try {
      if (confirm.action === "remove") {
        await api.delete(`/api/v1/friends/${encodeURIComponent(confirm.friend.relationship_id)}?expected_revision=${confirm.friend.revision}`);
      } else {
        await api.post("/api/v1/blocks", { relationship_id: confirm.friend.relationship_id });
      }
      setConfirm(null);
      reload();
    } catch (e) {
      setNotice(errorMessage(e));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="container page narrow">
      <h1>Friends</h1>
      <p className="muted">Friends need mutual agreement inside a conversation. Friendships between two accounts are saved; with a guest they are temporary. Presence shows only Available, Busy or Offline.</p>
      <InviteBanner invites={chat.invites} busy={chat.phase === "in_interaction"} />
      {notice ? <Notice kind="info" live>{notice}</Notice> : null}
      {chat.outgoingInvite ? (
        <Notice kind="info">Waiting for your friend to accept… <Button variant="ghost" onClick={() => coordinator.cancelInvite()}>Cancel invitation</Button></Notice>
      ) : null}
      {loading && !data ? <Loading /> : error ? <Notice kind="error">{errorMessage(error)}</Notice> : !data?.items.length ? (
        <EmptyState title="No friends yet">
          <p>In a conversation, choose <strong>Add friend</strong>. If they agree, they appear here.</p>
          <Link className="btn btn-primary" href="/chat/">Go to Chat</Link>
        </EmptyState>
      ) : (
        <div className="card">
          {data.items.map((f) => (
            <div key={f.relationship_id} className="friend-row">
              <div>
                <strong>{f.friend.display_name}</strong>{" "}
                <span className={`badge ${f.state === "saved" ? "badge-success" : "badge-warning"}`}>
                  {f.state === "saved" ? "Saved" : f.state === "saving" ? "Saving…" : "Temporary"}
                </span>
                <div className="small muted">
                  <span className={`presence-dot presence-${f.presence}`} aria-hidden="true" />
                  {f.presence === "available" ? "Available" : f.presence === "busy" ? "Busy" : "Offline"} ·{" "}
                  {labelFor(catalogs?.topics, f.friend.topic_id)}
                </div>
              </div>
              <div className="row">
                <Button onClick={() => invite(f)} disabled={f.presence !== "available" || chat.phase === "in_interaction" || chat.conn !== "open"}>
                  Invite to talk
                </Button>
                <Button variant="secondary" onClick={() => setConfirm({ friend: f, action: "remove" })}>Remove</Button>
                <Button variant="danger" onClick={() => setConfirm({ friend: f, action: "block" })}>Block</Button>
              </div>
            </div>
          ))}
        </div>
      )}
      <Dialog open={Boolean(confirm)} title={confirm?.action === "block" ? "Block this friend?" : "Remove this friend?"}
        onClose={() => setConfirm(null)}
        footer={<>
          <Button variant="secondary" onClick={() => setConfirm(null)}>Cancel</Button>
          <Button variant="danger" busy={busy} onClick={act}>{confirm?.action === "block" ? "Block" : "Remove"}</Button>
        </>}>
        <p>{confirm?.action === "block"
          ? "Blocking removes the friendship, ends any conversation between you and prevents future matches."
          : "Removing ends any current conversation between you. You can become friends again later only by mutual agreement."}</p>
      </Dialog>
    </div>
  );
}

export default function FriendsPage() {
  return <RequireIdentity what="Friends"><FriendsList /></RequireIdentity>;
}
