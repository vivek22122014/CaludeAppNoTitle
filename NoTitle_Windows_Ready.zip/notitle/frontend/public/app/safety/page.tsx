import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Safety",
  description: "End, Block and Report, moderator support and what NoTitle does with safety reports.",
};

export default function Safety() {
  return (
    <div className="container page narrow">
      <h1>Safety</h1>
      <div className="grid grid-2">
        <div className="card">
          <h2>End</h2>
          <p>Stops the conversation for both of you and clears its temporary text. Next ends first and then searches again for you only.</p>
        </div>
        <div className="card">
          <h2>Block</h2>
          <p>Immediately ends contact and prevents future matches with that identity. For guests, a block protects only that temporary identity.</p>
        </div>
        <div className="card">
          <h2>Report</h2>
          <p>You choose which recent messages to include. Only those, and your description, are copied into a retained safety case for moderators. Audio is never recorded.</p>
        </div>
        <div className="card">
          <h2>Chat with Moderator</h2>
          <p>A saved support thread with staff. Guests receive a private receipt to return to their case. <Link href="/support/">Open Support</Link>.</p>
        </div>
      </div>
      <h2>Protect yourself</h2>
      <ul>
        <li>Do not share your employer&apos;s confidential information, your full name, phone number or address.</li>
        <li>Nobody from NoTitle will ever ask for your password, recovery code or payment codes.</li>
        <li>Pseudonymity is not anonymity: a peer can still copy what you write.</li>
        <li>If you are in immediate danger, contact local emergency services.</li>
      </ul>
      <p><Link href="/community-guidelines/">Read the Community Guidelines</Link></p>
    </div>
  );
}
