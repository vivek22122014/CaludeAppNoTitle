"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { type FormEvent, Suspense, useState } from "react";

import { ApiError, Button, Checkbox, Field, Loading, Notice, errorMessage, formatDuration, formatPaise, newNonce, useAsync } from "@notitle/shared";

import { RequireIdentity, fieldErrors } from "@/components/forms";
import { openCheckout, type Plan, type Purchase } from "@/lib/billing";
import { api } from "@/lib/client";

function Checkout() {
  const params = useSearchParams();
  const code = params.get("plan") ?? "";
  const plans = useAsync(() => api.get<{ plans: Plan[]; sales_open: boolean }>("/api/v1/billing/plans"), []);
  const [accepted, setAccepted] = useState(false);
  const [phone, setPhone] = useState("");
  const [nonce] = useState(newNonce); // one purchase intent per visit; retries reuse it
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [pendingRef, setPendingRef] = useState<string | null>(null);

  if (plans.loading && !plans.data) return <div className="container page"><Loading /></div>;
  const plan = plans.data?.plans.find((p) => p.code === code);
  if (!plan) return <div className="container page narrow"><Notice kind="error">Unknown pass. <Link href="/premium/">Back to Premium</Link></Notice></div>;

  async function pay(e: FormEvent) {
    e.preventDefault();
    if (!plan) return;
    setBusy(true);
    setError(null);
    setErrors({});
    try {
      const purchase = await api.post<Purchase>("/api/v1/billing/purchases", {
        plan_code: plan.code, plan_version: plan.version, policy_version: plan.refund_policy_version,
        policy_accepted: accepted, client_nonce: nonce, payment_phone: phone,
      });
      setPendingRef(purchase.purchase_ref);
      if (purchase.state === "paid") window.location.assign(`/payment/status/?ref=${purchase.purchase_ref}`);
      else if (purchase.checkout) await openCheckout(purchase);
      else window.location.assign(`/payment/status/?ref=${purchase.purchase_ref}`);
    } catch (err) {
      setErrors(fieldErrors(err));
      setError(errorMessage(err));
      if (err instanceof ApiError && (err.code === "policy_changed" || err.code === "stale_plan")) plans.reload();
      const ref = err instanceof ApiError ? (err.details.purchase_ref as string | undefined) : undefined;
      if (ref) setPendingRef(ref);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="container page narrow">
      <h1>Checkout: {plan.label}</h1>
      <div className="card" style={{ marginBottom: 16 }}>
        <p className="plan-price">{formatPaise(plan.price_paise)}</p>
        <p>One-time pass · {formatDuration(plan.duration_seconds)} · no automatic renewal · {plan.tax_note}</p>
        <p className="small muted">Payment is handled on the payment provider&apos;s hosted page. NoTitle never sees your card or UPI details.</p>
      </div>
      {error ? <Notice kind="error">{error}</Notice> : null}
      {pendingRef ? (
        <Notice kind="warning">
          If you were charged, do not pay again. <Link href={`/payment/status/?ref=${pendingRef}`}>Check payment status</Link>.
        </Notice>
      ) : null}
      <form className="card" onSubmit={pay} noValidate>
        <Field label="Mobile number for the payment provider" inputMode="numeric" autoComplete="tel-national" value={phone}
          onChange={(e) => setPhone(e.target.value)} error={errors.payment_phone}
          hint="Required by the payment provider for checkout. It is sent to the provider only — not stored in your profile or shown to anyone." />
        <Checkbox checked={accepted} onChange={setAccepted} error={errors.policy_accepted}
          label={<>I understand this is a one-time purchase with <strong>no voluntary refunds</strong> (including for non-use or change of mind), as set out in the <Link href="/refund-policy/" target="_blank">Refund and Billing Policy</Link> version {plan.refund_policy_version}.</>} />
        <div className="form-actions">
          <Button type="submit" busy={busy} disabled={!accepted || !plan.available}>Pay {formatPaise(plan.price_paise)}</Button>
          <Link className="btn btn-ghost" href="/premium/">Back</Link>
        </div>
      </form>
    </div>
  );
}

export default function CheckoutPage() {
  return (
    <RequireIdentity account what="Premium checkout">
      <Suspense fallback={<div className="container page"><Loading /></div>}><Checkout /></Suspense>
    </RequireIdentity>
  );
}
