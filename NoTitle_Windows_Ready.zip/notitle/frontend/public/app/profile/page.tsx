"use client";

import Link from "next/link";
import { type FormEvent, useEffect, useState } from "react";

import { Button, Field, Loading, Notice, Select, TextArea, errorMessage, labelFor } from "@notitle/shared";

import { useApp } from "@/components/AppContext";
import { ProfessionalFields, RequireIdentity, emptyProfessional, fieldErrors } from "@/components/forms";
import { api, type Me } from "@/lib/client";

function ProfileForm() {
  const { me, catalogs, setMe } = useApp();
  const [form, setForm] = useState({ display_name: "", gender: "", topic_id: "", bio: "" });
  const [professional, setProfessional] = useState(emptyProfessional);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [status, setStatus] = useState<{ kind: "success" | "error"; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!me) return;
    setForm({ display_name: me.display_name, gender: me.gender, topic_id: me.topic_id, bio: me.bio });
    setProfessional(me.professional ?? emptyProfessional);
  }, [me]);

  if (!me || !catalogs) return <div className="container page"><Loading /></div>;
  const profConsent = Boolean(me.consents.professional?.choice);

  async function save(e: FormEvent) {
    e.preventDefault();
    if (!me) return;
    setBusy(true);
    setStatus(null);
    setErrors({});
    try {
      const updated = await api.patch<Me>("/api/v1/me/profile", {
        expected_version: me.profile_version,
        ...(me.display_name_editable ? { display_name: form.display_name } : {}),
        gender: form.gender, topic_id: form.topic_id, bio: form.bio,
        ...(profConsent ? { professional } : {}),
      });
      setMe(updated);
      setStatus({ kind: "success", text: "Saved. Changes apply to your next conversation; a current peer keeps seeing the previous details." });
    } catch (err) {
      setErrors(fieldErrors(err));
      setStatus({ kind: "error", text: errorMessage(err) });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="container page narrow">
      <h1>Profile</h1>
      {status ? <Notice kind={status.kind} live>{status.text}</Notice> : null}
      <div className="card" style={{ marginBottom: 16 }}>
        <h2>What your next peer sees</h2>
        <p><strong>{form.display_name || me.display_name}</strong> · {labelFor(catalogs.genders, form.gender)} · {labelFor(catalogs.topics, form.topic_id)}</p>
        {form.bio ? <p>{form.bio}</p> : <p className="muted">No bio.</p>}
        <p className="hint">Your username, professional details, Premium status and payments are never shown to peers.</p>
      </div>
      <form className="card" onSubmit={save}>
        <Field label="Display name" value={form.display_name} maxLength={24} error={errors.display_name}
          onChange={(e) => setForm({ ...form, display_name: e.target.value })} disabled={!me.display_name_editable}
          hint={me.display_name_editable ? "2–24 characters. Avoid your real name." : "Guest pseudonyms are generated and cannot be changed."} />
        <Select label="Declared gender" options={catalogs.genders} value={form.gender} onChange={(e) => setForm({ ...form, gender: e.target.value })} />
        <Select label="Topic" options={catalogs.topics} value={form.topic_id} onChange={(e) => setForm({ ...form, topic_id: e.target.value })} />
        <TextArea label="Bio (optional)" value={form.bio} maxLength={160} onChange={(e) => setForm({ ...form, bio: e.target.value })}
          error={errors.bio} hint={`${Array.from(form.bio).length}/160 · Do not include identifying or confidential information.`} />
        {profConsent ? (
          <ProfessionalFields value={professional} onChange={setProfessional} catalogs={catalogs} />
        ) : (
          <Notice kind="info">Professional details are off. Turn on optional professional processing in <Link href="/account/privacy/">Privacy</Link> to add them.</Notice>
        )}
        <Button type="submit" busy={busy}>Save profile</Button>
      </form>
    </div>
  );
}

export default function ProfilePage() {
  return <RequireIdentity what="your profile"><ProfileForm /></RequireIdentity>;
}
