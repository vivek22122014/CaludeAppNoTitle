"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useEffect, useRef, useState } from "react";

import { Button, Loading, Notice, errorMessage, formatDateTime, formatPaise } from "@notitle/shared";

import { useApp } from "@/components/AppContext";
import { RequireIdentity } from "@/components/forms";
import { openCheckout, type Purchase } from "@/lib/billing";
import { api } from "@/lib/client";

/** A browser return never grants time: this page shows only what the server verified. */
function Status() {
  const ref = useSearchParams().get("ref") ?? "";
  const { refresh } = useApp();
  const [purchase, setPurchase] = useState<Purchase | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [checking, setChecking] = useState(false);
  const polls = useRef(0);
  const latest = useRef<Purchase | null>(null);

  async function check() {
    if (!ref) return;
    setChecking(true);
    try {
      const p = await api.get<Purchase>(`/api/v1/billing/purchases/${encodeURIComponent(ref)}`);
      latest.current = p;
      setPurchase(p);
      setError(null);
      if (p.state === "paid") void refresh();
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setChecking(false);
    }
  }

  useEffect(() => {
    void check();
    // Bounded polling while pending and visible: 3s, then backing off; never more than ~2 minutes.
    const timer = setInterval(() => {
      if (document.hidden || polls.current > 30) return;
      polls.current += 1;
      const p = latest.current;
      if (!p || p.state === "pending" || p.state === "created") void check();
    }, 4000);
    return () => clearInterval(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ref]);

  if (!ref) return <div className="container page narrow"><Notice kind="error">Missing purchase reference.</Notice></div>;
  if (!purchase && !error) return <div className="container page"><Loading label="Checking payment status…" /></div>;

  return (
    <div className="container page narrow">
      <h1>Payment status</h1>
      {error ? <Notice kind="error">{error}</Notice> : null}
      {purchase ? (
        <div className="card">
          <p>Purchase <code className="mono">{purchase.purchase_ref}</code> · {purchase.plan_code} · {formatPaise(purchase.amount_paise)}</p>
          {purchase.state === "paid" ? (
            <Notice kind="success" title="Payment verified" live>Your pass is active (verified {formatDateTime(purchase.captured_at)}).</Notice>
          ) : purchase.state === "failed" ? (
            <Notice kind="error" title="Payment not completed">{purchase.message}</Notice>
          ) : purchase.state === "needs_review" ? (
            <Notice kind="warning" title="Under review">{purchase.message}</Notice>
          ) : (
            <Notice kind="warning" title="Pending — do not pay again" live>{purchase.message}</Notice>
          )}
          <div className="row">
            {purchase.state === "pending" || purchase.state === "created" ? (
              <>
                <Button variant="secondary" busy={checking} onClick={() => void check()}>Refresh status</Button>
                {purchase.checkout ? <Button onClick={() => void openCheckout(purchase)}>Return to checkout</Button> : null}
              </>
            ) : null}
            <Link className="btn btn-secondary" href="/account/premium/">My Premium</Link>
            <Link className="btn btn-ghost" href="/support/">Chat with Moderator</Link>
          </div>
        </div>
      ) : null}
    </div>
  );
}

export default function PaymentStatusPage() {
  return (
    <RequireIdentity account what="payment status">
      <Suspense fallback={<div className="container page"><Loading /></div>}><Status /></Suspense>
    </RequireIdentity>
  );
}
