import Link from "next/link";

export default function NotFound() {
  return (
    <div className="container page narrow">
      <h1>Page not found</h1>
      <p>The page you asked for does not exist.</p>
      <p><Link className="btn btn-primary" href="/">Go to the home page</Link></p>
    </div>
  );
}
