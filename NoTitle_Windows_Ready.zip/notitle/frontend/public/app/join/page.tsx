"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { type FormEvent, useState } from "react";

import { Button, Loading, Notice, Select, errorMessage } from "@notitle/shared";

import { policyVersions, useApp } from "@/components/AppContext";
import { ConsentFields, ProfessionalFields, emptyConsents, emptyProfessional, fieldErrors } from "@/components/forms";
import { api } from "@/lib/client";

export default function JoinPage() {
  const { boot, catalogs, refresh, loading } = useApp();
  const router = useRouter();
  const [gender, setGender] = useState("");
  const [topic, setTopic] = useState("general");
  const [consents, setConsents] = useState(emptyConsents);
  const [professional, setProfessional] = useState(emptyProfessional);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  if (loading || !catalogs) return <div className="container page"><Loading /></div>;
  if (boot?.owner) {
    return (
      <div className="container page narrow">
        <Notice kind="info" title="You are already signed in">
          <Link href="/chat/">Go to Chat</Link>
        </Notice>
      </div>
    );
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    setErrors({});
    setError(null);
    if (!gender) {
      setErrors({ gender: "Choose how you describe your gender." });
      document.getElementById("gender")?.focus();
      return;
    }
    setBusy(true);
    try {
      await api.post("/api/v1/auth/guest", {
        gender, topic_id: topic, consents, policy_versions: policyVersions(boot),
        professional: consents.professional ? professional : undefined,
      });
      await refresh();
      router.push("/chat/");
    } catch (err) {
      const fields = fieldErrors(err);
      setErrors(fields);
      setError(errorMessage(err));
      if ((err as { code?: string }).code === "policy_changed") await refresh();
      const first = Object.keys(fields)[0];
      if (first) document.querySelector<HTMLElement>(`[aria-invalid="true"]`)?.focus();
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="container page narrow">
      <h1>Start a conversation</h1>
      <p>
        Continue as a guest with a generated pseudonym. Guest identities last at most 24 hours (30 minutes of
        inactivity) and end if the service restarts. Entering does not start a search — you choose when.
      </p>
      {error ? <Notice kind="error">{error}</Notice> : null}
      <form className="card" onSubmit={submit} noValidate>
        <Select id="gender" label="Declared gender (shown to peers)" placeholder="Choose…" options={catalogs.genders}
          value={gender} onChange={(e) => setGender(e.target.value)} error={errors.gender}
          hint="Self-declared and not verified." />
        <Select label="Topic you want to talk about" options={catalogs.topics} value={topic}
          onChange={(e) => setTopic(e.target.value)} error={errors.topic_id} />
        <ConsentFields value={consents} onChange={setConsents} errors={errors} />
        {consents.professional ? <ProfessionalFields value={professional} onChange={setProfessional} catalogs={catalogs} /> : null}
        <div className="form-actions">
          <Button type="submit" busy={busy}>Continue as guest</Button>
          <Link className="btn btn-secondary" href="/register/">Register instead</Link>
          <Link className="btn btn-ghost" href="/login/">Log in</Link>
        </div>
      </form>
    </div>
  );
}
