"use client";

import Link from "next/link";

import { Loading, Notice, errorMessage, formatPaise, useAsync } from "@notitle/shared";

import { useApp } from "@/components/AppContext";
import type { Plan } from "@/lib/billing";
import { api } from "@/lib/client";

export default function PremiumPage() {
  const { me } = useApp();
  const plans = useAsync(() => api.get<{ plans: Plan[]; sales_open: boolean }>("/api/v1/billing/plans"), []);
  return (
    <div className="container page">
      <h1>Premium passes</h1>
      <p className="muted" style={{ maxWidth: 720 }}>
        Free access already includes text, audio, friends, reports and blocks. A one-time Premium pass adds a gender
        preference for random matching and a very soft professional relevance. It never gives queue priority or a
        verified badge. There is no subscription and nothing renews automatically.
      </p>
      <Notice kind="warning" title="No voluntary refunds">
        Successful purchases are final, including for non-use, partial use, change of mind or account deletion. Legally
        required remedies and verified payment errors are still handled — see the <Link href="/refund-policy/">Refund and Billing Policy</Link>.
      </Notice>
      {plans.loading && !plans.data ? <Loading /> : plans.error ? <Notice kind="error">{errorMessage(plans.error)}</Notice> : (
        <div className="grid grid-3">
          {plans.data?.plans.map((p) => (
            <div key={p.code} className="card plan-card">
              <h2 style={{ margin: 0 }}>{p.label}</h2>
              <div className="plan-price">{formatPaise(p.price_paise)}</div>
              <p className="small muted">One-time · {p.duration_days} days of wall-clock time from verified payment · {p.tax_note}</p>
              {p.available ? (
                me?.kind === "account" ? (
                  <Link className="btn btn-primary" href={`/checkout/?plan=${p.code}`}>Choose {p.label}</Link>
                ) : (
                  <p className="small">Purchases need an account. <Link href="/register/">Register</Link> or <Link href="/login/">log in</Link>.</p>
                )
              ) : (
                <p className="small"><span className="badge">Unavailable</span> {p.unavailable_reason}</p>
              )}
            </div>
          ))}
        </div>
      )}
      <h2>How paid time works</h2>
      <ul>
        <li>Time starts when the payment is verified by the server — not when the browser returns from checkout.</li>
        <li>It elapses in real time, including while you are logged out. Several passes are used in purchase order.</li>
        <li>If Premium ends while a specific gender preference is saved, search asks before switching to Everyone.</li>
      </ul>
    </div>
  );
}
