import { PolicyPage, policyMetadata } from "@/components/PolicyPage";

export const metadata = policyMetadata("retention");

export default function Page() {
  return <PolicyPage kind="retention" />;
}
