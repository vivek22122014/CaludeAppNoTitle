"use client";

import { useRouter } from "next/navigation";
import { type FormEvent, useState } from "react";

import { Button, Checkbox, Field, Notice, SecretPanel, errorMessage } from "@notitle/shared";

import { useApp } from "@/components/AppContext";
import { fieldErrors } from "@/components/forms";
import { api } from "@/lib/client";
import { coordinator } from "@/lib/coordinator";

interface Prepared { reservation_id: string; secret: string }

export default function RecoveryPage() {
  const { refresh } = useApp();
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [code, setCode] = useState("");
  const [password, setPassword] = useState("");
  const [prep, setPrep] = useState<Prepared | null>(null);
  const [saved, setSaved] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function prepare(e: FormEvent) {
    e.preventDefault();
    setError(null);
    if (Array.from(password).length < 12) {
      setErrors({ new_password: "Use at least 12 characters." });
      return;
    }
    setBusy(true);
    try {
      setPrep(await api.post<Prepared>("/api/v1/operations/prepare", { kind: "recovery" }));
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  async function recover(e: FormEvent) {
    e.preventDefault();
    if (!prep) return;
    setBusy(true);
    setError(null);
    try {
      await api.post("/api/v1/auth/recover", {
        username, recovery_code: code, new_password: password, reservation_id: prep.reservation_id,
        new_recovery_code: prep.secret, saved,
      });
      coordinator.reset("recovered");
      await refresh();
      router.push("/settings/");
    } catch (err) {
      setErrors(fieldErrors(err));
      setError(errorMessage(err));
      if ((err as { code?: string }).code === "expired") setPrep(null);
      if ((err as { code?: string }).code === "invalid_recovery") setPrep(null);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="container page narrow">
      <h1>Recover your account</h1>
      <p>Use your username and the recovery code you saved. You will receive a new recovery code; the old one stops working and other devices are signed out.</p>
      {error ? <Notice kind="error">{error}</Notice> : null}
      {!prep ? (
        <form className="card" onSubmit={prepare} noValidate>
          <Field label="Username" value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username" required />
          <Field label="Recovery code" value={code} onChange={(e) => setCode(e.target.value)} autoComplete="off"
            hint="Dashes and spaces are ignored." required />
          <Field label="New password" type="password" value={password} onChange={(e) => setPassword(e.target.value)}
            autoComplete="new-password" error={errors.new_password} required />
          <Button type="submit" busy={busy}>Continue</Button>
        </form>
      ) : (
        <form className="card" onSubmit={recover}>
          <SecretPanel title="Your new recovery code" secret={prep.secret} filename="notitle-recovery-code.txt"
            explanation="Save this new code before continuing. Your old code is replaced only when you finish." />
          <Checkbox checked={saved} onChange={setSaved} label="I have saved my new recovery code." />
          <div className="form-actions">
            <Button type="submit" busy={busy} disabled={!saved}>Reset password</Button>
            <Button type="button" variant="secondary" onClick={() => setPrep(null)}>Back</Button>
          </div>
        </form>
      )}
    </div>
  );
}
