"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { type FormEvent, useState } from "react";

import {
  ApiError, Button, Checkbox, Dialog, Loading, Notice, SecretPanel, Select, TextArea, errorMessage, formatDateTime, newNonce,
  useAsync,
} from "@notitle/shared";

import { useApp } from "@/components/AppContext";
import { RequireIdentity } from "@/components/forms";
import { ReauthDialog } from "@/components/ReauthDialog";
import { api, type Me } from "@/lib/client";
import { coordinator } from "@/lib/coordinator";

interface ExportItem { export_ref: string; status: string; created_at: string; ready_at: string | null; expires_at: string | null }

const RIGHTS = [
  { id: "access", label: "Access my data" }, { id: "correction", label: "Correct my data" },
  { id: "erasure", label: "Erase specific data" }, { id: "objection", label: "Object to processing" },
  { id: "grievance", label: "Privacy grievance" }, { id: "other", label: "Other" },
];

function Consents() {
  const { me, boot, setMe } = useApp();
  const [confirmCore, setConfirmCore] = useState(false);
  const [status, setStatus] = useState<string | null>(null);
  if (!me) return null;
  const privacyVersion = boot?.policies.privacy?.version ?? "";
  async function change(purpose: "core" | "professional", choice: boolean) {
    try {
      const updated = await api.post<Me>("/api/v1/me/consents", { purpose, choice, policy_version: privacyVersion });
      setMe(updated);
      setStatus(purpose === "professional"
        ? (choice ? "Optional professional processing is on." : "Withdrawn. Your professional details and their matching influence were removed.")
        : (choice ? "Core processing consent restored." : "Core processing withdrawn. Conversations are unavailable; privacy, deletion and support remain available."));
      if (purpose === "core" && !choice) coordinator.reset("consent_withdrawn");
    } catch (e) {
      setStatus(errorMessage(e));
    }
  }
  const prof = Boolean(me.consents.professional?.choice);
  const core = Boolean(me.consents.core?.choice);
  return (
    <section className="card" style={{ marginBottom: 16 }}>
      <h2>Purposes and consent</h2>
      {status ? <Notice kind="info" live>{status}</Notice> : null}
      <p><strong>Adult confirmation and Terms:</strong> accepted (version {me.consents.terms?.policy_version}).</p>
      <div className="row-between" style={{ marginBottom: 12 }}>
        <span><strong>Core processing</strong> — needed to run conversations. {core ? "On" : "Off"}.</span>
        {core ? <Button variant="secondary" onClick={() => setConfirmCore(true)}>Withdraw</Button>
          : <Button onClick={() => change("core", true)}>Give consent</Button>}
      </div>
      <div className="row-between">
        <span><strong>Optional professional processing</strong> — very soft matching relevance. {prof ? "On" : "Off"}.</span>
        <Button variant="secondary" onClick={() => change("professional", !prof)}>{prof ? "Withdraw" : "Turn on"}</Button>
      </div>
      <p className="hint">Each change records the policy version and time. <a href="/api/v1/me/consent-proof" download>Download consent proof</a></p>
      <Dialog open={confirmCore} title="Withdraw core processing?" onClose={() => setConfirmCore(false)}
        footer={<><Button variant="secondary" onClick={() => setConfirmCore(false)}>Cancel</Button>
          <Button variant="danger" onClick={() => { setConfirmCore(false); void change("core", false); }}>Withdraw</Button></>}>
        <p>Any current conversation ends and you cannot search until you consent again. Privacy settings, account deletion, rights requests and support stay available.</p>
      </Dialog>
    </section>
  );
}

function Exports() {
  const list = useAsync(() => api.get<{ items: ExportItem[] }>("/api/v1/privacy/exports"), []);
  const [reauth, setReauth] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  async function request() {
    try {
      await api.post("/api/v1/privacy/exports");
      setMsg("Export requested. It is prepared in the background; refresh in a few seconds.");
      list.reload();
    } catch (e) {
      if (e instanceof ApiError && e.code === "reauth_required") setReauth(true);
      else setMsg(errorMessage(e));
    }
  }
  return (
    <section className="card" style={{ marginBottom: 16 }}>
      <h2>Export your data</h2>
      <p>A JSON file with your account, preferences, consents, friends, purchases, receipts and support cases. Ordinary chat is never stored, so it cannot be exported. Downloads expire after 24 hours.</p>
      {msg ? <Notice kind="info" live>{msg}</Notice> : null}
      <div className="row">
        <Button onClick={request}>Request export</Button>
        <Button variant="secondary" onClick={list.reload}>Refresh</Button>
      </div>
      {list.data?.items.length ? (
        <ul style={{ listStyle: "none", padding: 0 }}>
          {list.data.items.map((x) => (
            <li key={x.export_ref} className="friend-row">
              <span>Requested {formatDateTime(x.created_at)} · <span className="badge">{x.status}</span>{x.expires_at ? ` · expires ${formatDateTime(x.expires_at)}` : ""}</span>
              {x.status === "ready" ? <a className="btn btn-secondary" href={`/api/v1/privacy/exports/${x.export_ref}/download`} download>Download</a> : null}
            </li>
          ))}
        </ul>
      ) : null}
      <ReauthDialog open={reauth} onClose={() => setReauth(false)} onDone={() => { setReauth(false); void request(); }} />
    </section>
  );
}

function RightsRequest() {
  const [kind, setKind] = useState("");
  const [details, setDetails] = useState("");
  const [nonce, setNonce] = useState(newNonce);
  const [result, setResult] = useState<{ request_ref: string; case_ref: string; deadline_at: string } | null>(null);
  const [error, setError] = useState<string | null>(null);
  async function submit(e: FormEvent) {
    e.preventDefault();
    try {
      setResult(await api.post("/api/v1/privacy/requests", { kind, details, client_nonce: nonce }));
      setNonce(newNonce());
    } catch (err) {
      setError(errorMessage(err));
    }
  }
  return (
    <section className="card" style={{ marginBottom: 16 }}>
      <h2>Other rights requests</h2>
      {result ? (
        <Notice kind="success" title="Request received">
          Tracked as case <Link href={`/support/?case=${result.case_ref}`}>{result.case_ref}</Link>. Target response by {formatDateTime(result.deadline_at)}.
        </Notice>
      ) : (
        <form onSubmit={submit}>
          {error ? <Notice kind="error">{error}</Notice> : null}
          <Select label="Request type" placeholder="Choose…" options={RIGHTS} value={kind} onChange={(e) => setKind(e.target.value)} />
          <TextArea label="Details" value={details} maxLength={4000} onChange={(e) => setDetails(e.target.value)} />
          <Button type="submit" disabled={!kind || !details.trim()}>Submit request</Button>
        </form>
      )}
    </section>
  );
}

function DeleteAccount() {
  const { refresh } = useApp();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [receipt, setReceipt] = useState<{ reservation_id: string; reference: string; secret: string } | null>(null);
  const [saved, setSaved] = useState(false);
  const [confirm, setConfirm] = useState(false);
  const [reauth, setReauth] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function start() {
    setError(null);
    try {
      setReceipt(await api.post("/api/v1/operations/prepare", { kind: "deletion_receipt" }));
      setOpen(true);
    } catch (e) {
      setError(errorMessage(e));
    }
  }

  async function submit() {
    if (!receipt) return;
    setBusy(true);
    setError(null);
    try {
      await api.post("/api/v1/privacy/delete", { reservation_id: receipt.reservation_id, receipt_secret: receipt.secret, saved, confirm });
      coordinator.reset("account_deleted");
      await refresh();
      router.push("/account-deletion/?submitted=1");
    } catch (e) {
      if (e instanceof ApiError && e.code === "reauth_required") setReauth(true);
      else setError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="card" style={{ borderColor: "var(--danger)" }}>
      <h2>Delete account</h2>
      <p>Access stops immediately and your profile is minimised within 30 days. Some records are kept with restricted access where required: verified payment records, submitted safety reports (180 days), saved support cases (90 days after closure) and minimal consent proof. Deleting does not create a refund.</p>
      {error ? <Notice kind="error">{error}</Notice> : null}
      <Button variant="danger" onClick={start}>Delete my account…</Button>
      <Dialog open={open} title="Delete your account" onClose={() => setOpen(false)}
        footer={<><Button variant="secondary" onClick={() => setOpen(false)}>Cancel</Button>
          <Button variant="danger" busy={busy} disabled={!saved || !confirm} onClick={submit}>Delete account</Button></>}>
        {error ? <Notice kind="error">{error}</Notice> : null}
        {receipt ? <SecretPanel title="Deletion receipt" reference={receipt.reference} secret={receipt.secret} filename="notitle-deletion-receipt.txt"
          explanation="Use this on the Account deletion page to check progress. It cannot restore or access the account." /> : <Loading />}
        <Checkbox checked={saved} onChange={setSaved} label="I have saved the deletion receipt." />
        <Checkbox checked={confirm} onChange={setConfirm} label="I understand my account will be disabled now and deleted." />
      </Dialog>
      <ReauthDialog open={reauth} onClose={() => setReauth(false)} onDone={() => { setReauth(false); void submit(); }} />
    </section>
  );
}

function PrivacyPage() {
  const { me } = useApp();
  if (!me) return <div className="container page"><Loading /></div>;
  return (
    <div className="container page narrow">
      <h1>Privacy</h1>
      <p className="muted">See the <Link href="/privacy/">Privacy Policy</Link>, <Link href="/data-retention/">Data Retention Policy</Link> and <Link href="/your-rights/">Your Rights</Link>.</p>
      <Consents />
      {me.kind === "account" ? (
        <>
          <Exports />
          <RightsRequest />
          <DeleteAccount />
        </>
      ) : (
        <Notice kind="info">Guests have no stored account: your identity disappears when it expires. <a href="/api/v1/me/consent-proof" download>Download consent proof</a> · <Link href="/support/">Chat with Moderator</Link> for any request.</Notice>
      )}
    </div>
  );
}

export default function Page() {
  return <RequireIdentity what="privacy settings"><PrivacyPage /></RequireIdentity>;
}
