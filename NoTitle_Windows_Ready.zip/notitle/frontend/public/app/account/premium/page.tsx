"use client";

import Link from "next/link";

import { EmptyState, Loading, Notice, errorMessage, formatDateTime, formatDuration, formatPaise, useAsync } from "@notitle/shared";

import { RequireIdentity } from "@/components/forms";
import type { Entitlement, Purchase } from "@/lib/billing";
import { api } from "@/lib/client";

function AccountPremium() {
  const ent = useAsync(() => api.get<Entitlement>("/api/v1/billing/entitlement"), []);
  const purchases = useAsync(() => api.get<{ items: Purchase[] }>("/api/v1/billing/purchases"), []);
  return (
    <div className="container page narrow">
      <h1>My Premium</h1>
      {ent.loading && !ent.data ? <Loading /> : ent.error ? <Notice kind="error">{errorMessage(ent.error)}</Notice> : ent.data ? (
        <div className="card" style={{ marginBottom: 16 }}>
          <h2>{ent.data.active ? "Premium is active" : "No active pass"}</h2>
          {ent.data.active ? (
            <p>Available time: <strong>{formatDuration(ent.data.available_seconds)}</strong> · ends around {formatDateTime(ent.data.expires_at)}</p>
          ) : <p><Link href="/premium/">See passes</Link></p>}
          {ent.data.held_seconds ? <p>Held for a billing review: {formatDuration(ent.data.held_seconds)}</p> : null}
          <p className="hint">{ent.data.note}</p>
          {ent.data.lots.length ? (
            <div className="table-wrap">
              <table className="table">
                <thead><tr><th scope="col">Pass</th><th scope="col">Granted</th><th scope="col">Used</th><th scope="col">Left</th><th scope="col">Held</th><th scope="col">Revoked</th></tr></thead>
                <tbody>
                  {ent.data.lots.map((l) => (
                    <tr key={l.purchase_ref}>
                      <td>{l.plan_code}<br /><span className="small muted">{formatDateTime(l.granted_at)}</span></td>
                      <td>{formatDuration(l.granted_seconds)}</td><td>{formatDuration(l.consumed_seconds)}</td>
                      <td>{formatDuration(l.available_seconds)}</td><td>{l.held_seconds ? formatDuration(l.held_seconds) : "—"}</td>
                      <td>{l.revoked_seconds ? formatDuration(l.revoked_seconds) : "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : null}
        </div>
      ) : null}
      <div className="card">
        <div className="row-between"><h2 style={{ margin: 0 }}>Purchases</h2><Link href="/account/receipts/">Receipts</Link></div>
        {purchases.loading && !purchases.data ? <Loading /> : !purchases.data?.items.length ? <EmptyState title="No purchases yet" /> : (
          <ul style={{ listStyle: "none", padding: 0 }}>
            {purchases.data.items.map((p) => (
              <li key={p.purchase_ref} className="friend-row">
                <span>{p.plan_code} · {formatPaise(p.amount_paise)} · {formatDateTime(p.created_at)}</span>
                <span className="row">
                  <span className={`badge ${p.state === "paid" ? "badge-success" : p.state === "failed" ? "badge-danger" : "badge-warning"}`}>{p.state}</span>
                  <Link href={`/payment/status/?ref=${p.purchase_ref}`}>Status</Link>
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

export default function Page() {
  return <RequireIdentity account what="Premium"><AccountPremium /></RequireIdentity>;
}
