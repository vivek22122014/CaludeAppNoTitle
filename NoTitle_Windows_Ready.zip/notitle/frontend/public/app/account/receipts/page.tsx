"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { type FormEvent, Suspense, useState } from "react";

import { Button, EmptyState, Loading, Notice, Select, TextArea, errorMessage, formatDateTime, formatDuration, formatPaise, newNonce, useAsync } from "@notitle/shared";

import { RequireIdentity } from "@/components/forms";
import { api } from "@/lib/client";

interface ReceiptFacts {
  plan_code: string; description: string; amount_paise: number; currency: string; duration_seconds: number;
  merchant_order_id: string; provider: string; provider_payment_ref: string; policy_version: string; tax_treatment: string;
  merchant: string; issued_at: string;
}
interface Receipt { receipt_ref: string; receipt_number: number; issued_at: string; purchase_ref: string; facts: ReceiptFacts;
  remedies?: { public_ref: string; amount_paise: number; state: string; remedy_basis: string; created_at: string }[] }

const ISSUES = [
  { id: "duplicate_charge", label: "I was charged more than once" }, { id: "not_granted", label: "I paid but did not get my pass" },
  { id: "wrong_amount", label: "The amount was wrong" }, { id: "payment_error", label: "Another payment error" },
  { id: "statutory_remedy", label: "A legal right to a remedy" }, { id: "other", label: "Something else" },
];

function ReceiptDetail({ ref_ }: { ref_: string }) {
  const r = useAsync(() => api.get<Receipt>(`/api/v1/billing/receipts/${encodeURIComponent(ref_)}`), [ref_]);
  const [reason, setReason] = useState("");
  const [details, setDetails] = useState("");
  const [nonce] = useState(newNonce);
  const [result, setResult] = useState<{ case_ref: string; note: string } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  if (r.loading && !r.data) return <Loading />;
  if (r.error || !r.data) return <Notice kind="error">{errorMessage(r.error)}</Notice>;
  const f = r.data.facts;

  async function report(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      setResult(await api.post("/api/v1/billing/refund-requests", { purchase_ref: r.data!.purchase_ref, reason, details, client_nonce: nonce }));
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  const download = () => {
    const text = `NoTitle payment receipt #${r.data!.receipt_number}\nReference: ${r.data!.receipt_ref}\nIssued: ${f.issued_at}\n` +
      `Item: ${f.description}\nAmount: ${formatPaise(f.amount_paise)} ${f.currency}\nDuration: ${formatDuration(f.duration_seconds)}\n` +
      `Order: ${f.merchant_order_id}\nProvider: ${f.provider} (payment …${f.provider_payment_ref})\nPolicy version: ${f.policy_version}\n` +
      `Tax: ${f.tax_treatment}\nMerchant: ${f.merchant}\n`;
    const url = URL.createObjectURL(new Blob([text], { type: "text/plain" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = `notitle-receipt-${r.data!.receipt_number}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <>
      <div className="card" style={{ marginBottom: 16 }}>
        <h2>Receipt #{r.data.receipt_number}</h2>
        <dl className="grid grid-2">
          <div><dt className="muted small">Item</dt><dd>{f.description}</dd></div>
          <div><dt className="muted small">Amount</dt><dd>{formatPaise(f.amount_paise)} {f.currency}</dd></div>
          <div><dt className="muted small">Issued</dt><dd>{formatDateTime(r.data.issued_at)}</dd></div>
          <div><dt className="muted small">Order</dt><dd className="mono small">{f.merchant_order_id}</dd></div>
          <div><dt className="muted small">Policy accepted</dt><dd>{f.policy_version}</dd></div>
          <div><dt className="muted small">Tax</dt><dd className="small">{f.tax_treatment}</dd></div>
        </dl>
        {r.data.remedies?.length ? <p>Remedies: {r.data.remedies.map((m) => `${formatPaise(m.amount_paise)} (${m.state})`).join(", ")}</p> : null}
        <Button variant="secondary" onClick={download}>Download receipt</Button>
      </div>
      <div className="card">
        <h2>Report a billing issue</h2>
        <p className="hint">This opens a saved Chat with Moderator case. It does not pause your pass or guarantee a refund; a reviewer checks the verified payment records.</p>
        {result ? <Notice kind="success" title="Billing case opened">Case <Link href={`/support/?case=${result.case_ref}`}>{result.case_ref}</Link>. {result.note}</Notice> : (
          <form onSubmit={report}>
            {error ? <Notice kind="error">{error}</Notice> : null}
            <Select label="What went wrong?" placeholder="Choose…" options={ISSUES} value={reason} onChange={(e) => setReason(e.target.value)} />
            <TextArea label="Details" value={details} maxLength={4000} onChange={(e) => setDetails(e.target.value)}
              hint="Never include card numbers, bank passwords or OTPs." />
            <Button type="submit" busy={busy} disabled={!reason || !details.trim()}>Open billing case</Button>
          </form>
        )}
      </div>
    </>
  );
}

function Receipts() {
  const ref = useSearchParams().get("ref");
  const list = useAsync(() => api.get<{ items: Receipt[] }>("/api/v1/billing/receipts"), []);
  return (
    <div className="container page narrow">
      <h1>Receipts</h1>
      {ref ? <><p><Link href="/account/receipts/">← All receipts</Link></p><ReceiptDetail ref_={ref} /></> : (
        list.loading && !list.data ? <Loading /> : list.error ? <Notice kind="error">{errorMessage(list.error)}</Notice> :
        !list.data?.items.length ? <EmptyState title="No receipts yet"><p>Receipts appear after a verified payment.</p></EmptyState> : (
          <div className="card">
            {list.data.items.map((r) => (
              <div key={r.receipt_ref} className="friend-row">
                <span>#{r.receipt_number} · {r.facts.description} · {formatPaise(r.facts.amount_paise)} · {formatDateTime(r.issued_at)}</span>
                <Link href={`/account/receipts/?ref=${r.receipt_ref}`}>View</Link>
              </div>
            ))}
          </div>
        )
      )}
    </div>
  );
}

export default function Page() {
  return (
    <RequireIdentity account what="receipts">
      <Suspense fallback={<Loading />}><Receipts /></Suspense>
    </RequireIdentity>
  );
}
