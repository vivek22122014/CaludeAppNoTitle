"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { type FormEvent, useState } from "react";

import { Button, Checkbox, Field, Loading, Notice, SecretPanel, Select, errorMessage } from "@notitle/shared";

import { policyVersions, useApp } from "@/components/AppContext";
import { ConsentFields, emptyConsents, fieldErrors } from "@/components/forms";
import { api } from "@/lib/client";

interface Prepared { reservation_id: string; secret: string; expires_at: string }

export default function RegisterPage() {
  const { boot, me, catalogs, refresh, loading } = useApp();
  const router = useRouter();
  const [step, setStep] = useState<"details" | "code">("details");
  const [form, setForm] = useState({ username: "", password: "", confirm: "", display_name: "", gender: "", topic_id: "general" });
  const [consents, setConsents] = useState(emptyConsents);
  const [prep, setPrep] = useState<Prepared | null>(null);
  const [saved, setSaved] = useState(false);
  const [convert, setConvert] = useState(true);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  if (loading || !catalogs) return <div className="container page"><Loading /></div>;
  if (me?.kind === "account") {
    return <div className="container page narrow"><Notice kind="info" title="You already have an account"><Link href="/chat/">Go to Chat</Link></Notice></div>;
  }
  const isGuest = me?.kind === "guest";

  function validate(): boolean {
    const e: Record<string, string> = {};
    if (!/^[a-z0-9_-]{4,24}$/.test(form.username.trim().toLowerCase())) e.username = "Use 4–24 lowercase letters, numbers, - or _.";
    if (Array.from(form.password).length < 12) e.password = "Use at least 12 characters.";
    if (form.password !== form.confirm) e.confirm = "Passwords do not match.";
    if (Array.from(form.display_name.trim()).length < 2) e.display_name = "Display name must be 2–24 characters.";
    if (!form.gender) e.gender = "Choose how you describe your gender.";
    for (const k of ["adult", "terms", "core"] as const) if (!consents[k]) e[`consents.${k}`] = "This confirmation is required.";
    setErrors(e);
    if (Object.keys(e).length) setTimeout(() => document.querySelector<HTMLElement>('[aria-invalid="true"]')?.focus(), 0);
    return Object.keys(e).length === 0;
  }

  async function prepare(e: FormEvent) {
    e.preventDefault();
    setError(null);
    if (!validate()) return;
    setBusy(true);
    try {
      setPrep(await api.post<Prepared>("/api/v1/operations/prepare", { kind: "registration" }));
      setSaved(false);
      setStep("code");
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  async function create(e: FormEvent) {
    e.preventDefault();
    if (!prep) return;
    setBusy(true);
    setError(null);
    try {
      await api.post("/api/v1/auth/register", {
        reservation_id: prep.reservation_id, recovery_code: prep.secret, saved, username: form.username.trim().toLowerCase(),
        password: form.password, display_name: form.display_name.trim(), gender: form.gender, topic_id: form.topic_id,
        consents, policy_versions: policyVersions(boot), convert_guest: isGuest && convert,
      });
      await refresh();
      router.push("/chat/");
    } catch (err) {
      const code = (err as { code?: string }).code;
      if (code === "expired") {
        setError("The preparation expired. A new recovery code is needed.");
        setStep("details");
        setPrep(null);
      } else {
        const fields = fieldErrors(err);
        setErrors(fields);
        setError(errorMessage(err));
        if (fields.username || fields.password || fields.display_name) setStep("details");
      }
    } finally {
      setBusy(false);
    }
  }

  const set = (k: keyof typeof form) => (e: { target: { value: string } }) => setForm({ ...form, [k]: e.target.value });

  return (
    <div className="container page narrow">
      <h1>Create an account</h1>
      <ol className="stepper" aria-label="Registration steps">
        <li aria-current={step === "details" ? "step" : undefined}>1. Details</li>
        <li aria-current={step === "code" ? "step" : undefined}>2. Save your recovery code</li>
      </ol>
      <Notice kind="info">
        There is no email recovery. Your recovery code is the only way to reset a forgotten password, and staff cannot
        recreate it. Save it somewhere safe.
      </Notice>
      {error ? <Notice kind="error">{error}</Notice> : null}
      {step === "details" ? (
        <form className="card" onSubmit={prepare} noValidate>
          <Field label="Username (private, used to sign in)" value={form.username} onChange={set("username")}
            autoComplete="username" error={errors.username} hint="Never shown to the people you talk to." />
          <Field label="Password" type="password" value={form.password} onChange={set("password")}
            autoComplete="new-password" error={errors.password} hint="At least 12 characters. Spaces are allowed." />
          <Field label="Confirm password" type="password" value={form.confirm} onChange={set("confirm")}
            autoComplete="new-password" error={errors.confirm} />
          <Field label="Display name (shown to peers)" value={form.display_name} onChange={set("display_name")}
            maxLength={24} error={errors.display_name} hint="Avoid your real name." />
          <Select label="Declared gender" placeholder="Choose…" options={catalogs.genders} value={form.gender}
            onChange={set("gender")} error={errors.gender} />
          <Select label="Topic" options={catalogs.topics} value={form.topic_id} onChange={set("topic_id")} />
          <ConsentFields value={consents} onChange={setConsents} errors={errors} />
          {isGuest ? (
            <Checkbox checked={convert} onChange={setConvert}
              label="Keep my current guest conversation, temporary friends and blocks"
              description="Your guest pseudonym is replaced by your new display name for future conversations." />
          ) : null}
          <div className="form-actions">
            <Button type="submit" busy={busy}>Continue</Button>
            <Link className="btn btn-ghost" href="/login/">I already have an account</Link>
          </div>
        </form>
      ) : prep ? (
        <form className="card" onSubmit={create}>
          <SecretPanel title="Your recovery code" secret={prep.secret} filename="notitle-recovery-code.txt"
            explanation={<>This is shown once. Copy or download it now. It expires from this page at {new Date(prep.expires_at).toLocaleTimeString()} if you do not finish.</>} />
          <Checkbox checked={saved} onChange={setSaved} label="I have saved my recovery code somewhere safe." />
          <div className="form-actions">
            <Button type="submit" busy={busy} disabled={!saved}>Create account</Button>
            <Button type="button" variant="secondary" onClick={() => setStep("details")}>Back</Button>
          </div>
        </form>
      ) : null}
    </div>
  );
}
