import { PolicyPage, policyMetadata } from "@/components/PolicyPage";

export const metadata = policyMetadata("cookies");

export default function Page() {
  return <PolicyPage kind="cookies" />;
}
