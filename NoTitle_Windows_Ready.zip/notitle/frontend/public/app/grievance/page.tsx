import { PolicyPage, policyMetadata } from "@/components/PolicyPage";

export const metadata = policyMetadata("grievance");

export default function Page() {
  return <PolicyPage kind="grievance" />;
}
