import { PolicyPage, policyMetadata } from "@/components/PolicyPage";

export const metadata = policyMetadata("privacy");

export default function Page() {
  return <PolicyPage kind="privacy" />;
}
