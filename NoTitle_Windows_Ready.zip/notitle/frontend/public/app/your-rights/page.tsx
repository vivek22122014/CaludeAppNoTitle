import { PolicyPage, policyMetadata } from "@/components/PolicyPage";

export const metadata = policyMetadata("rights");

export default function Page() {
  return <PolicyPage kind="rights" />;
}
