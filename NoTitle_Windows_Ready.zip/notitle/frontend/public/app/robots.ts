import type { MetadataRoute } from "next";

export const dynamic = "force-static";

// Development builds are not indexable; switch to allow-list rules at public launch.
export default function robots(): MetadataRoute.Robots {
  return { rules: [{ userAgent: "*", disallow: "/" }] };
}
