"use client";

import { useRouter } from "next/navigation";
import { type FormEvent, useState } from "react";

import { Button, Field, Notice, errorMessage } from "@notitle/shared";

import { api } from "@/lib/client";

export default function SupportStatusPage() {
  const router = useRouter();
  const [reference, setReference] = useState("");
  const [secret, setSecret] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const r = await api.post<{ case_ref: string }>("/api/v1/support/access", { reference, secret });
      router.push(`/support/?case=${encodeURIComponent(r.case_ref)}`);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="container page narrow">
      <h1>Open a saved support case</h1>
      <p>Enter the case reference and secret from the receipt you saved. The secret is never put in a link. It opens only that case and cannot recover an account.</p>
      {error ? <Notice kind="error">{error}</Notice> : null}
      <form className="card" onSubmit={submit}>
        <Field label="Case reference" value={reference} onChange={(e) => setReference(e.target.value)} placeholder="cs_…" autoComplete="off" />
        <Field label="Receipt secret" value={secret} onChange={(e) => setSecret(e.target.value)} autoComplete="off" />
        <Button type="submit" busy={busy}>Open case</Button>
      </form>
    </div>
  );
}
