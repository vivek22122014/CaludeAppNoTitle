"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { type FormEvent, Suspense, useEffect, useState } from "react";

import {
  Button, Checkbox, EmptyState, Field, Loading, Notice, SecretPanel, Select, TextArea, errorMessage, formatDateTime,
  newNonce, titleCase, useAsync,
} from "@notitle/shared";

import { useApp } from "@/components/AppContext";
import { fieldErrors } from "@/components/forms";
import { type CaseDto, Thread } from "@/components/support/Thread";
import { api } from "@/lib/client";

const CATEGORIES = [
  { id: "general", label: "General question" }, { id: "safety", label: "Safety concern" }, { id: "payment", label: "Payment or billing" },
  { id: "privacy", label: "Privacy or my data" }, { id: "appeal", label: "Appeal a decision" }, { id: "security", label: "Account security" },
];

function NewCase({ onCreated }: { onCreated: (ref: string) => void }) {
  const { me } = useApp();
  const account = me?.kind === "account";
  const [form, setForm] = useState({ category: "general", subject: "", body: "" });
  const [receipt, setReceipt] = useState<{ reservation_id: string; reference: string; secret: string } | null>(null);
  const [saved, setSaved] = useState(false);
  const [nonce] = useState(newNonce);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!account && !receipt) {
      api.post<{ reservation_id: string; reference: string; secret: string }>("/api/v1/operations/prepare", { kind: "case_receipt" })
        .then(setReceipt).catch((e) => setError(errorMessage(e)));
    }
  }, [account, receipt]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const r = await api.post<{ case_ref: string }>("/api/v1/support/cases", {
        ...form, client_nonce: nonce,
        ...(!account && receipt ? { reservation_id: receipt.reservation_id, receipt_secret: receipt.secret, saved } : {}),
      });
      onCreated(r.case_ref);
    } catch (err) {
      setErrors(fieldErrors(err));
      setError(errorMessage(err));
      if ((err as { code?: string }).code === "expired") { setReceipt(null); setSaved(false); }
    } finally {
      setBusy(false);
    }
  }

  return (
    <form className="card" onSubmit={submit}>
      <h2>New case</h2>
      <p className="hint">Chat with Moderator is saved and reviewed by authorised staff — unlike ordinary chat. There is no support email.</p>
      {error ? <Notice kind="error">{error}</Notice> : null}
      <Select label="Category" options={CATEGORIES} value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} />
      <Field label="Subject" maxLength={120} value={form.subject} error={errors.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} />
      <TextArea label="Message" maxLength={4000} value={form.body} error={errors.body} onChange={(e) => setForm({ ...form, body: e.target.value })}
        hint="Do not include passwords, recovery codes or payment authentication codes." />
      {!account && receipt ? (
        <>
          <SecretPanel title="Case receipt" reference={receipt.reference} secret={receipt.secret} filename="notitle-case-receipt.txt"
            explanation="Without an account, this receipt is the only way back to your case. It opens this one case only and cannot recover an account." />
          <Checkbox checked={saved} onChange={setSaved} label="I have saved the case reference and secret." />
        </>
      ) : null}
      <Button type="submit" busy={busy} disabled={!form.subject.trim() || !form.body.trim() || (!account && !saved)}>Save case</Button>
    </form>
  );
}

function ReceiptAccess({ onOpened }: { onOpened: (ref: string) => void }) {
  const [reference, setReference] = useState("");
  const [secret, setSecret] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const r = await api.post<{ case_ref: string }>("/api/v1/support/access", { reference, secret });
      onOpened(r.case_ref);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }
  return (
    <form className="card" onSubmit={submit}>
      <h2>Open a saved case</h2>
      {error ? <Notice kind="error">{error}</Notice> : null}
      <Field label="Case reference" value={reference} onChange={(e) => setReference(e.target.value)} placeholder="cs_…" autoComplete="off" />
      <Field label="Receipt secret" value={secret} onChange={(e) => setSecret(e.target.value)} autoComplete="off" />
      <Button type="submit" busy={busy}>Open case</Button>
    </form>
  );
}

function Support() {
  const params = useSearchParams();
  const router = useRouter();
  const { me, loading } = useApp();
  const caseRef = params.get("case");
  const showNew = params.get("new") === "1";
  const cases = useAsync(() => api.get<{ items: (CaseDto & { access?: string })[] }>("/api/v1/support/cases").catch(() => ({ items: [] })), [caseRef, me?.kind]);

  if (loading) return <div className="container page"><Loading /></div>;
  const open = (ref: string) => router.push(`/support/?case=${encodeURIComponent(ref)}`);

  return (
    <div className="container page narrow">
      <h1>Chat with Moderator</h1>
      {caseRef ? (
        <>
          <p><Link href="/support/">← All cases</Link></p>
          <Thread caseRef={caseRef} />
        </>
      ) : showNew ? (
        <>
          <p><Link href="/support/">← Back</Link></p>
          <NewCase onCreated={open} />
        </>
      ) : (
        <>
          <p className="muted">Ask for help, raise a safety or billing concern, request something about your data or appeal a decision. Cases are saved; ordinary chat never is.</p>
          <p><Link className="btn btn-primary" href="/support/?new=1">New case</Link></p>
          {cases.loading && !cases.data ? <Loading /> : cases.data?.items.length ? (
            <div className="card" style={{ marginBottom: 16 }}>
              <h2>Your cases</h2>
              {cases.data.items.map((c) => (
                <div key={c.case_ref} className="friend-row">
                  <div>
                    <Link href={`/support/?case=${c.case_ref}`}><strong>{c.subject}</strong></Link>
                    <div className="small muted">{titleCase(c.category)} · updated {formatDateTime(c.updated_at)}</div>
                  </div>
                  <span className="row">
                    {c.unread ? <span className="badge badge-danger">{c.unread} new</span> : null}
                    <span className="badge">{titleCase(c.status)}</span>
                  </span>
                </div>
              ))}
            </div>
          ) : me?.kind === "account" ? <EmptyState title="No cases yet" /> : null}
          {me?.kind !== "account" ? <ReceiptAccess onOpened={open} /> : null}
        </>
      )}
    </div>
  );
}

export default function SupportPage() {
  return <Suspense fallback={<div className="container page"><Loading /></div>}><Support /></Suspense>;
}
