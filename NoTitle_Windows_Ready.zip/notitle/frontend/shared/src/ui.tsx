"use client";

/**
 * Accessible primitives shared by the public and private builds.
 * Targets are ≥44px, focus is always visible, errors are linked with aria-describedby,
 * dialogs trap focus and restore it to the trigger.
 */

import {
  type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes,
  type TextareaHTMLAttributes, useCallback, useEffect, useId, useRef, useState,
} from "react";

type Variant = "primary" | "secondary" | "danger" | "ghost";

export function Button({ variant = "primary", busy = false, children, className = "", disabled, ...rest }:
  ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; busy?: boolean }) {
  return (
    <button
      {...rest}
      className={`btn btn-${variant} ${className}`}
      disabled={disabled || busy}
      aria-busy={busy || undefined}
    >
      {busy ? <span className="spinner" aria-hidden="true" /> : null}
      {children}
    </button>
  );
}

interface FieldProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  hint?: ReactNode;
  error?: string;
}

export function Field({ label, hint, error, id, className = "", ...rest }: FieldProps) {
  const auto = useId();
  const inputId = id ?? auto;
  const hintId = `${inputId}-hint`;
  const errId = `${inputId}-err`;
  return (
    <div className={`field ${className}`}>
      <label htmlFor={inputId}>{label}</label>
      {hint ? <p className="hint" id={hintId}>{hint}</p> : null}
      <input
        id={inputId}
        aria-invalid={error ? true : undefined}
        aria-describedby={[hint ? hintId : "", error ? errId : ""].filter(Boolean).join(" ") || undefined}
        {...rest}
      />
      {error ? <p className="field-error" id={errId} role="alert">{error}</p> : null}
    </div>
  );
}

interface AreaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label: string;
  hint?: ReactNode;
  error?: string;
}

export function TextArea({ label, hint, error, id, ...rest }: AreaProps) {
  const auto = useId();
  const inputId = id ?? auto;
  return (
    <div className="field">
      <label htmlFor={inputId}>{label}</label>
      {hint ? <p className="hint" id={`${inputId}-hint`}>{hint}</p> : null}
      <textarea id={inputId} aria-invalid={error ? true : undefined}
        aria-describedby={hint ? `${inputId}-hint` : undefined} {...rest} />
      {error ? <p className="field-error" role="alert">{error}</p> : null}
    </div>
  );
}

interface SelectProps extends SelectHTMLAttributes<HTMLSelectElement> {
  label: string;
  options: { id: string; label: string }[];
  placeholder?: string;
  error?: string;
  hint?: ReactNode;
}

export function Select({ label, options, placeholder, error, hint, id, ...rest }: SelectProps) {
  const auto = useId();
  const inputId = id ?? auto;
  return (
    <div className="field">
      <label htmlFor={inputId}>{label}</label>
      {hint ? <p className="hint">{hint}</p> : null}
      <select id={inputId} aria-invalid={error ? true : undefined} {...rest}>
        {placeholder !== undefined ? <option value="">{placeholder}</option> : null}
        {options.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}
      </select>
      {error ? <p className="field-error" role="alert">{error}</p> : null}
    </div>
  );
}

export function Checkbox({ label, checked, onChange, id, error, description }: {
  label: ReactNode; checked: boolean; onChange: (v: boolean) => void; id?: string; error?: string; description?: ReactNode;
}) {
  const auto = useId();
  const inputId = id ?? auto;
  return (
    <div className="check">
      <input id={inputId} type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)}
        aria-invalid={error ? true : undefined} />
      <div>
        <label htmlFor={inputId}>{label}</label>
        {description ? <p className="hint">{description}</p> : null}
        {error ? <p className="field-error" role="alert">{error}</p> : null}
      </div>
    </div>
  );
}

export function MultiSelect({ label, options, value, onChange, max, hint }: {
  label: string; options: { id: string; label: string }[]; value: string[]; onChange: (v: string[]) => void;
  max: number; hint?: string;
}) {
  return (
    <fieldset className="field multi">
      <legend>{label}</legend>
      {hint ? <p className="hint">{hint}</p> : null}
      <div className="chips">
        {options.map((o) => {
          const on = value.includes(o.id);
          const full = !on && value.length >= max;
          return (
            <label key={o.id} className={`chip ${on ? "chip-on" : ""}`}>
              <input type="checkbox" checked={on} disabled={full}
                onChange={() => onChange(on ? value.filter((v) => v !== o.id) : [...value, o.id])} />
              {o.label}
            </label>
          );
        })}
      </div>
    </fieldset>
  );
}

export function Notice({ kind = "info", title, children, live = false }: {
  kind?: "info" | "success" | "warning" | "error"; title?: string; children?: ReactNode; live?: boolean;
}) {
  return (
    <div className={`notice notice-${kind}`} role={kind === "error" ? "alert" : live ? "status" : undefined}>
      {title ? <strong>{title}</strong> : null}
      {children ? <div>{children}</div> : null}
    </div>
  );
}

export function EmptyState({ title, children }: { title: string; children?: ReactNode }) {
  return (
    <div className="empty">
      <p className="empty-title">{title}</p>
      {children}
    </div>
  );
}

export function Loading({ label = "Loading…" }: { label?: string }) {
  return <p className="loading" role="status"><span className="spinner" aria-hidden="true" /> {label}</p>;
}

export function Dialog({ open, title, onClose, children, footer }: {
  open: boolean; title: string; onClose: () => void; children: ReactNode; footer?: ReactNode;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const titleId = useId();
  useEffect(() => {
    if (!open) return;
    const previous = document.activeElement as HTMLElement | null;
    const node = ref.current;
    const focusables = () => Array.from(node?.querySelectorAll<HTMLElement>(
      'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])',
    ) ?? []);
    (focusables()[0] ?? node)?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") { e.preventDefault(); onClose(); }
      if (e.key === "Tab") {
        const items = focusables();
        if (!items.length) return;
        const first = items[0], last = items[items.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    };
    document.addEventListener("keydown", onKey);
    return () => { document.removeEventListener("keydown", onKey); previous?.focus?.(); };
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="dialog-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="dialog" role="dialog" aria-modal="true" aria-labelledby={titleId} ref={ref} tabIndex={-1}>
        <div className="dialog-head">
          <h2 id={titleId}>{title}</h2>
          <button className="icon-btn" onClick={onClose} aria-label="Close dialog">×</button>
        </div>
        <div className="dialog-body">{children}</div>
        {footer ? <div className="dialog-foot">{footer}</div> : null}
      </div>
    </div>
  );
}

/** One-time secret display with explicit Copy and Download (no browser storage). */
export function SecretPanel({ title, reference, secret, filename, explanation }: {
  title: string; reference?: string | null; secret: string; filename: string; explanation: ReactNode;
}) {
  const [revealed, setRevealed] = useState(false);
  const [copied, setCopied] = useState(false);
  const text = (reference ? `Reference: ${reference}\n` : "") + `Secret: ${secret}\n`;
  const copy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      setRevealed(true);
    }
  }, [text]);
  const download = () => {
    const blob = new Blob([`${title}\n\n${text}\nKeep this private. Anyone with it can use it.\n`], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };
  return (
    <section className="secret" aria-label={title}>
      <h3>{title}</h3>
      <div className="hint">{explanation}</div>
      {reference ? <p>Reference: <code className="mono">{reference}</code></p> : null}
      <p className="secret-value">
        <code className="mono" aria-live="polite">{revealed ? secret : secret.replace(/[A-Z0-9]/g, "•")}</code>
      </p>
      <div className="row">
        <Button variant="secondary" type="button" onClick={() => setRevealed((v) => !v)}>{revealed ? "Hide" : "Reveal"}</Button>
        <Button variant="secondary" type="button" onClick={copy}>{copied ? "Copied" : "Copy"}</Button>
        <Button variant="secondary" type="button" onClick={download}>Download</Button>
      </div>
    </section>
  );
}

export function useAsync<T>(fn: () => Promise<T>, deps: unknown[]): {
  data: T | null; error: unknown; loading: boolean; reload: () => void; setData: (v: T) => void;
} {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<unknown>(null);
  const [loading, setLoading] = useState(true);
  const [tick, setTick] = useState(0);
  useEffect(() => {
    let alive = true; // ignore late results from an obsolete request
    setLoading(true);
    fn().then((v) => { if (alive) { setData(v); setError(null); } })
      .catch((e) => { if (alive) setError(e); })
      .finally(() => { if (alive) setLoading(false); });
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, tick]);
  return { data, error, loading, reload: () => setTick((t) => t + 1), setData };
}
