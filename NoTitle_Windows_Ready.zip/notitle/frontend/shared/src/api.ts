/**
 * Typed fetch client for the NoTitle API envelopes.
 *
 * - Success: { data, request_id }   Failure: { error: { code, message, fields?, details?, retryable }, request_id }
 * - Sends the CSRF token on every unsafe request; refreshes it once after a csrf_failed rejection
 *   (safe: the server rejected the request before doing anything).
 * - Never retries other failures automatically: an uncertain mutation is reported, not repeated.
 * - Credentials are HttpOnly cookies; nothing sensitive is written to browser storage.
 */

export class ApiError extends Error {
  status: number;
  code: string;
  fields: Record<string, string>;
  details: Record<string, unknown>;
  retryable: boolean;
  requestId: string | null;

  constructor(status: number, code: string, message: string, extra: Partial<ApiError> = {}) {
    super(message);
    this.status = status;
    this.code = code;
    this.fields = extra.fields ?? {};
    this.details = extra.details ?? {};
    this.retryable = extra.retryable ?? false;
    this.requestId = extra.requestId ?? null;
  }
}

type Method = "GET" | "POST" | "PATCH" | "DELETE";

export interface ApiClientOptions {
  base?: string;
  bootstrapPath: string;
  timeoutMs?: number;
}

export class ApiClient {
  private base: string;
  private bootstrapPath: string;
  private timeoutMs: number;
  private csrf: string | null = null;
  private bootstrapping: Promise<unknown> | null = null;
  generation = 0; // increments on sign-in/out so late responses can be ignored

  constructor(options: ApiClientOptions) {
    this.base = options.base ?? "";
    this.bootstrapPath = options.bootstrapPath;
    this.timeoutMs = options.timeoutMs ?? 15000;
  }

  setCsrf(token: string | null | undefined): void {
    if (token) this.csrf = token;
  }

  async bootstrap<T = Record<string, unknown>>(): Promise<T> {
    const data = await this.raw<T & { csrf_token?: string }>("GET", this.bootstrapPath);
    this.setCsrf((data as { csrf_token?: string }).csrf_token);
    return data;
  }

  private async ensureCsrf(): Promise<void> {
    if (this.csrf) return;
    if (!this.bootstrapping) this.bootstrapping = this.bootstrap().finally(() => (this.bootstrapping = null));
    await this.bootstrapping;
  }

  get<T>(path: string, params?: Record<string, string | number | undefined | null>): Promise<T> {
    let url = path;
    if (params) {
      const q = new URLSearchParams();
      for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== null && v !== "") q.set(k, String(v));
      const s = q.toString();
      if (s) url += (url.includes("?") ? "&" : "?") + s;
    }
    return this.request<T>("GET", url);
  }

  post<T>(path: string, body: unknown = {}): Promise<T> {
    return this.request<T>("POST", path, body);
  }

  patch<T>(path: string, body: unknown): Promise<T> {
    return this.request<T>("PATCH", path, body);
  }

  delete<T>(path: string): Promise<T> {
    return this.request<T>("DELETE", path);
  }

  async request<T>(method: Method, path: string, body?: unknown): Promise<T> {
    if (method !== "GET") await this.ensureCsrf();
    try {
      return await this.raw<T>(method, path, body);
    } catch (err) {
      if (err instanceof ApiError && err.code === "csrf_failed" && method !== "GET") {
        this.csrf = null;
        await this.ensureCsrf();
        return this.raw<T>(method, path, body);
      }
      throw err;
    }
  }

  private async raw<T>(method: Method, path: string, body?: unknown): Promise<T> {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    const headers: Record<string, string> = { Accept: "application/json" };
    if (body !== undefined) headers["Content-Type"] = "application/json";
    if (method !== "GET" && this.csrf) headers["X-CSRF-Token"] = this.csrf;
    let response: Response;
    try {
      response = await fetch(this.base + path, {
        method,
        headers,
        body: body !== undefined ? JSON.stringify(body) : undefined,
        credentials: "same-origin",
        cache: "no-store",
        signal: controller.signal,
      });
    } catch (e) {
      const aborted = (e as Error).name === "AbortError";
      throw new ApiError(0, aborted ? "timeout" : "network",
        aborted
          ? "The server did not answer in time. If you were saving something, check before retrying."
          : "Network problem. Check your connection and try again.",
        { retryable: true });
    } finally {
      clearTimeout(timer);
    }
    let payload: unknown = null;
    const text = await response.text();
    if (text.length > 2_000_000) throw new ApiError(response.status, "too_large", "Response too large.");
    try {
      payload = text ? JSON.parse(text) : null;
    } catch {
      payload = null;
    }
    const envelope = payload as { data?: T; error?: Record<string, unknown>; request_id?: string } | null;
    if (!response.ok || !envelope || envelope.error) {
      const e = (envelope?.error ?? {}) as Record<string, unknown>;
      throw new ApiError(
        response.status,
        String(e.code ?? (response.status === 503 ? "unavailable" : "error")),
        String(e.message ?? (response.status >= 500 ? "The service is unavailable. Try again shortly." : "Request failed.")),
        {
          fields: (e.fields as Record<string, string>) ?? {},
          details: (e.details as Record<string, unknown>) ?? {},
          retryable: Boolean(e.retryable),
          requestId: envelope?.request_id ?? null,
        },
      );
    }
    return envelope.data as T;
  }
}

export function newNonce(): string {
  const c: Crypto = globalThis.crypto;
  if (typeof c.randomUUID === "function") return c.randomUUID();
  // randomUUID needs a secure context; plain-http LAN addresses fall back to getRandomValues.
  const b = new Uint8Array(16);
  c.getRandomValues(b);
  b[6] = (b[6] & 0x0f) | 0x40;
  b[8] = (b[8] & 0x3f) | 0x80;
  const h = Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}

export function errorMessage(err: unknown): string {
  if (err instanceof ApiError) return err.message;
  if (err instanceof Error) return err.message;
  return "Something went wrong.";
}
