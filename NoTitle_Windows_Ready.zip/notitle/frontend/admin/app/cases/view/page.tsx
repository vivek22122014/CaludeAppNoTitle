"use client";

import { formatDateTime, Loading, Notice, titleCase } from "@notitle/shared";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { AssignForm, ClaimButton, Obligations, StatusForm } from "@/components/cases/CaseActions";
import { CaseMessages } from "@/components/cases/CaseMessages";
import { CaseNotes } from "@/components/cases/CaseNotes";
import { API } from "@/components/constants";
import { DataTable } from "@/components/DataTable";
import { AsyncState, Facts, PageTitle, RequireGrant, StatusBadge } from "@/components/Feedback";
import { useApi } from "@/components/hooks";
import { useStaff } from "@/components/StaffContext";
import type { CaseSummary } from "@/components/types";

function CaseDetail({ caseRef }: { caseRef: string }) {
  const { can, announce } = useStaff();
  const [result, setResult] = useState<string | null>(null);
  const state = useApi((c) => c.get<CaseSummary>(`${API}/cases/${encodeURIComponent(caseRef)}`), [caseRef]);
  const done = (message: string) => { setResult(message); announce(message); };

  return (
    <AsyncState state={state} label="Loading case…">
      {(s) => (
        <>
          {result ? <Notice kind="success">{result}</Notice> : null}
          <section className="card" aria-labelledby="summary-h">
            <div className="row-between">
              <h2 id="summary-h" style={{ margin: 0 }}>Summary</h2>
              <div className="row">
                {s.urgent ? <span className="badge badge-danger">Urgent</span> : null}
                <StatusBadge value={s.status} />
              </div>
            </div>
            <Facts items={[
              ["Category", titleCase(s.category)],
              ["Version", s.version],
              ["Assigned to", s.assigned_to ?? "Unassigned"],
              ["Owner", s.account_owned ? "Signed-in account" : "Receipt holder (no account)"],
              ["Messages", `${s.last_sequence} (staff seen through #${s.seen_staff_sequence})`],
              ["Created", formatDateTime(s.created_at)],
              ["Updated", formatDateTime(s.updated_at)],
              ["Closed", formatDateTime(s.closed_at)],
              ["Related ref", s.related_ref ? <code key="r">{s.related_ref}</code> : "—"],
            ]} />
            {s.report ? (
              <p>
                Linked report: {can("reports.read")
                  ? <Link href={`/reports/view/?ref=${encodeURIComponent(s.report.public_ref)}`}><code>{s.report.public_ref}</code></Link>
                  : <code>{s.report.public_ref}</code>}
                {" "}· reason <strong>{titleCase(s.report.reason)}</strong> · evidence {s.report.evidence_state}
                {s.report.blocked ? " · reporter blocked the subject" : ""}
              </p>
            ) : null}
            <ClaimButton summary={s} reload={state.reload} onDone={done} />
          </section>

          <section className="section" aria-labelledby="obl-h">
            <h2 id="obl-h">Legal obligations</h2>
            <Obligations summary={s} reload={state.reload} onDone={done} />
          </section>

          {can("cases.assign") || can("cases.manage") ? (
            <section className="card section" aria-labelledby="manage-h">
              <h2 id="manage-h">Manage</h2>
              <p className="small muted">Changes are made against version {s.version}. If someone else changed the case first you will be asked to review the latest version.</p>
              <div className="grid grid-2">
                <AssignForm summary={s} reload={state.reload} onDone={done} />
                <StatusForm summary={s} reload={state.reload} onDone={done} />
              </div>
            </section>
          ) : null}

          <CaseMessages summary={s} onPosted={(m) => { done(m); state.reload(); }} />
          <CaseNotes caseRef={s.case_ref} onDone={done} />

          <section className="section" aria-labelledby="events-h">
            <h2 id="events-h">Recent events</h2>
            <DataTable
              caption="Case events, newest first"
              rows={s.events}
              rowKey={(e) => `${e.created_at}-${e.kind}-${e.new_value ?? ""}`}
              empty="No events recorded."
              columns={[
                { key: "t", header: "Time", render: (e) => formatDateTime(e.created_at) },
                { key: "k", header: "Event", render: (e) => titleCase(e.kind) },
                { key: "c", header: "Change", render: (e) => [e.old_value, e.new_value].filter(Boolean).join(" → ") || "—" },
                { key: "r", header: "Reason", render: (e) => (e.reason ? <span className="plain">{e.reason}</span> : "—") },
                { key: "a", header: "Actor", render: (e) => <code className="small">{e.actor_ref}</code> },
              ]}
            />
          </section>
        </>
      )}
    </AsyncState>
  );
}

function CaseViewInner() {
  const ref = useSearchParams().get("ref")?.trim() ?? "";
  return (
    <>
      <p className="small"><Link href="/cases/">← Back to the queue</Link></p>
      <PageTitle title={ref ? `Case ${ref}` : "Case"} />
      {ref ? <CaseDetail key={ref} caseRef={ref} /> : (
        <Notice kind="warning">No case reference given. Open a case from the <Link href="/cases/">queue</Link>.</Notice>
      )}
    </>
  );
}

export default function CaseViewPage() {
  return (
    <div className="container page">
      <RequireGrant permission="cases.read">
        <Suspense fallback={<Loading />}>
          <CaseViewInner />
        </Suspense>
      </RequireGrant>
    </div>
  );
}
