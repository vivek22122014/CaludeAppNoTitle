"use client";

import { Button, formatDateTime, Select, titleCase } from "@notitle/shared";
import Link from "next/link";
import { useEffect, useState } from "react";
import { API, ASSIGNED_FILTERS, CASE_CATEGORIES, CASE_STATUSES } from "@/components/constants";
import { DataTable } from "@/components/DataTable";
import { AsyncState, ErrorNotice, PageTitle, RequireGrant, StatusBadge } from "@/components/Feedback";
import { useAction, useApi } from "@/components/hooks";
import { useStaff } from "@/components/StaffContext";
import type { Page, QueueItem } from "@/components/types";

function QueueInner() {
  const { client } = useStaff();
  const [status, setStatus] = useState("open");
  const [category, setCategory] = useState("");
  const [assigned, setAssigned] = useState("");
  const [extra, setExtra] = useState<QueueItem[]>([]);
  const [cursor, setCursor] = useState<string | null>(null);
  const more = useAction();

  const params = { status, category, assigned, limit: 30 };
  const state = useApi((c) => c.get<Page<QueueItem>>(`${API}/cases`, params), [status, category, assigned]);

  useEffect(() => {
    setExtra([]);
    setCursor(state.data?.next_cursor ?? null);
  }, [state.data]);

  const loadMore = async () => {
    if (!cursor) return;
    const page = await more.run(() => client.get<Page<QueueItem>>(`${API}/cases`, { ...params, cursor }));
    if (page) {
      setExtra((prev) => [...prev, ...page.items]);
      setCursor(page.next_cursor);
    }
  };

  return (
    <>
      <form className="filters" aria-label="Queue filters" onSubmit={(e) => e.preventDefault()}>
        <Select label="Status" options={CASE_STATUSES} placeholder="Any status" value={status}
          onChange={(e) => setStatus(e.target.value)} />
        <Select label="Category" options={CASE_CATEGORIES} placeholder="Any category" value={category}
          onChange={(e) => setCategory(e.target.value)} />
        <Select label="Assigned" options={ASSIGNED_FILTERS} value={assigned} onChange={(e) => setAssigned(e.target.value)} />
        <div className="form-actions">
          <Button type="button" variant="secondary" onClick={state.reload} busy={state.loading}>Refresh</Button>
        </div>
      </form>
      <AsyncState state={state} label="Loading the queue…">
        {(data) => {
          const rows = [...data.items, ...extra];
          return (
            <>
              <p className="small muted">{rows.length} case{rows.length === 1 ? "" : "s"} shown · urgent first, then most recently updated.</p>
              <DataTable
                caption="Support case queue"
                rows={rows}
                rowKey={(r) => r.case_ref}
                rowClass={(r) => (r.urgent ? "row-urgent" : undefined)}
                empty="No cases match these filters."
                columns={[
                  { key: "ref", header: "Case", render: (r) => <Link href={`/cases/view/?ref=${encodeURIComponent(r.case_ref)}`}><code>{r.case_ref}</code></Link> },
                  { key: "cat", header: "Category", render: (r) => titleCase(r.category) },
                  { key: "status", header: "Status", render: (r) => <StatusBadge value={r.status} /> },
                  { key: "urgent", header: "Urgent", render: (r) => (r.urgent ? <span className="badge badge-danger">Urgent</span> : <span className="sr-only">No</span>) },
                  { key: "unread", header: "Unread", render: (r) => (r.unread ? <span className="badge badge-primary">{r.unread} new</span> : "0") },
                  { key: "assigned", header: "Assigned to", render: (r) => r.assigned_to ?? <span className="muted">Unassigned</span> },
                  { key: "due", header: "Due", render: (r) => (
                    <>
                      {formatDateTime(r.due_at)}
                      {r.overdue ? <> <span className="badge badge-danger">Overdue</span></> : null}
                    </>
                  ) },
                  { key: "updated", header: "Updated", render: (r) => formatDateTime(r.updated_at) },
                ]}
              />
              <ErrorNotice error={more.error} />
              {cursor ? (
                <div className="form-actions">
                  <Button type="button" variant="secondary" onClick={loadMore} busy={more.busy}>Load more</Button>
                </div>
              ) : null}
            </>
          );
        }}
      </AsyncState>
    </>
  );
}

export default function CasesPage() {
  return (
    <div className="container page">
      <PageTitle title="Case queue">Chat with Moderator cases. Open a case to read it (reads are audited).</PageTitle>
      <RequireGrant permission="cases.queue"><QueueInner /></RequireGrant>
    </div>
  );
}
