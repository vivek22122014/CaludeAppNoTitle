"use client";

import { formatDateTime, Loading } from "@notitle/shared";
import Link from "next/link";
import type { ReactNode } from "react";
import { API } from "@/components/constants";
import { ErrorNotice, PageTitle } from "@/components/Feedback";
import { useApi } from "@/components/hooks";
import { SessionRules } from "@/components/SignIn";
import { useStaff } from "@/components/StaffContext";
import type { Health, Page, Purchase, QueueItem } from "@/components/types";

function StatCard({ label, value, href, linkText, loading, error, children }: {
  label: string; value: ReactNode; href?: string; linkText?: string; loading: boolean; error: unknown; children?: ReactNode;
}) {
  return (
    <section className="card stat" aria-label={label}>
      <h2 className="stat-label" style={{ margin: 0, fontSize: ".95rem", fontWeight: 600 }}>{label}</h2>
      {error ? <ErrorNotice error={error} /> : loading ? <Loading /> : <p className="stat-value" style={{ margin: 0 }}>{value}</p>}
      {children}
      {href && linkText ? <p style={{ margin: 0 }}><Link href={href}>{linkText}</Link></p> : null}
    </section>
  );
}

export default function OverviewPage() {
  const { staff, can } = useStaff();
  const canQueue = can("cases.queue");
  const canHealth = can("release.read");
  const canBilling = can("billing.read");

  const open = useApi((c) => canQueue
    ? c.get<Page<QueueItem>>(`${API}/cases`, { status: "open", limit: 50 })
    : Promise.resolve(null), [canQueue]);
  const health = useApi((c) => canHealth ? c.get<Health>(`${API}/health`) : Promise.resolve(null), [canHealth]);
  // Without health access, billing staff count payments needing attention directly.
  const payments = useApi(async (c) => {
    if (canHealth || !canBilling) return null;
    const [pending, review] = await Promise.all([
      c.get<{ items: Purchase[] }>(`${API}/billing/purchases`, { state: "pending" }),
      c.get<{ items: Purchase[] }>(`${API}/billing/purchases`, { state: "needs_review" }),
    ]);
    return pending.items.length + review.items.length;
  }, [canHealth, canBilling]);

  const openCount = open.data ? `${open.data.items.length}${open.data.next_cursor ? "+" : ""}` : "—";
  const urgent = open.data?.items.filter((i) => i.urgent).length ?? 0;
  const overdueInQueue = open.data?.items.filter((i) => i.overdue).length ?? 0;
  const paymentCount = canHealth ? health.data?.payments_needing_attention : payments.data;

  return (
    <div className="container page">
      <PageTitle title="Overview">Welcome, {staff?.username}. Fresh authenticator check valid until {formatDateTime(staff?.mfa_fresh_until)}.</PageTitle>
      <div className="grid grid-3">
        {canQueue ? (
          <StatCard label="Open cases" value={openCount} href="/cases/" linkText="Open the case queue"
            loading={open.loading} error={open.error}>
            {open.data ? (
              <p className="small muted" style={{ margin: 0 }}>
                {urgent} urgent · {overdueInQueue} with an overdue obligation
              </p>
            ) : null}
          </StatCard>
        ) : null}
        {canHealth ? (
          <StatCard label="Overdue legal obligations" value={health.data?.overdue_obligations ?? "—"}
            href="/release/" linkText="View system health" loading={health.loading} error={health.error}>
            <p className="small muted" style={{ margin: 0 }}>Acknowledge or act-by deadlines that have passed.</p>
          </StatCard>
        ) : null}
        {canHealth || canBilling ? (
          <StatCard label="Payments needing attention" value={paymentCount ?? "—"}
            href={canBilling ? "/billing/" : undefined} linkText="Review purchases"
            loading={canHealth ? health.loading : payments.loading} error={canHealth ? health.error : payments.error}>
            <p className="small muted" style={{ margin: 0 }}>Pending or needs-review purchases. Reconcile before anyone pays again.</p>
          </StatCard>
        ) : null}
      </div>
      {!canQueue && !canHealth && !canBilling ? (
        <p className="muted">Use the navigation above to reach the sections your role includes.</p>
      ) : null}
      <section className="card section" aria-labelledby="session-h">
        <h2 id="session-h">Your session</h2>
        <SessionRules />
      </section>
    </div>
  );
}
