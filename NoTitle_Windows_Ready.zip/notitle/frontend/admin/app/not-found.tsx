import Link from "next/link";

export default function NotFound() {
  return (
    <div className="container narrow page">
      <h1>Page not found</h1>
      <p>This staff page does not exist. Detail pages use links like <code>/cases/view/?ref=…</code>.</p>
      <p><Link href="/">Back to the overview</Link></p>
    </div>
  );
}
