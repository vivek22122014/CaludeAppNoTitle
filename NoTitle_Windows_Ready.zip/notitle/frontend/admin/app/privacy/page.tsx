"use client";

import { Button, Field, formatDateTime, Notice, Select, titleCase } from "@notitle/shared";
import Link from "next/link";
import { type FormEvent, useState } from "react";
import { API, HOLD_SCOPES, PRIVACY_STATUSES } from "@/components/constants";
import { DataTable } from "@/components/DataTable";
import { AsyncState, ErrorNotice, PageTitle, RequireGrant, StatusBadge } from "@/components/Feedback";
import { fieldErrors, useAction, useApi } from "@/components/hooks";
import { PreviewConfirmDialog } from "@/components/PreviewConfirmDialog";
import { useStaff } from "@/components/StaffContext";
import { useStepUp } from "@/components/StepUp";
import type { DeletionRequest, HoldResult, LegalHold, Preview, RightsRequest } from "@/components/types";

type Done = (message: string) => void;

function RequestStatus({ request, onDone }: { request: RightsRequest; onDone: Done }) {
  const { client } = useStaff();
  const [value, setValue] = useState("");
  const act = useAction();
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const res = await act.run(() => client.post<{ status: string }>(
      `${API}/privacy/requests/${encodeURIComponent(request.public_ref)}/status`, { status: value }));
    if (res) { setValue(""); onDone(`Request ${request.public_ref} is now ${titleCase(res.status)}.`); }
  };
  return (
    <form onSubmit={submit} className="inline-form" aria-label={`Update ${request.public_ref}`}>
      <Select label="Set status" placeholder="Choose…" value={value} onChange={(e) => setValue(e.target.value)}
        options={PRIVACY_STATUSES.filter((s) => s.id !== request.status)} />
      <div className="form-actions">
        <Button type="submit" variant="secondary" busy={act.busy} disabled={!value}>Update</Button>
      </div>
      {act.error ? <div style={{ flexBasis: "100%" }}><ErrorNotice error={act.error} /></div> : null}
    </form>
  );
}

function Requests({ onDone }: { onDone: Done }) {
  const state = useApi((c) => c.get<{ items: RightsRequest[]; deletions: DeletionRequest[] }>(`${API}/privacy/requests`), []);
  const done = (m: string) => { onDone(m); state.reload(); };
  return (
    <AsyncState state={state} label="Loading privacy requests…">
      {(data) => (
        <>
          <section className="section" aria-labelledby="rights-h">
            <h2 id="rights-h">Rights requests</h2>
            <p className="small muted">Access, correction and similar requests, soonest deadline first. Reply to the user from the linked case.</p>
            <DataTable
              caption="Privacy rights requests"
              rows={data.items}
              rowKey={(r) => r.public_ref}
              empty="No rights requests."
              columns={[
                { key: "ref", header: "Request", render: (r) => <code>{r.public_ref}</code> },
                { key: "kind", header: "Kind", render: (r) => titleCase(r.kind) },
                { key: "status", header: "Status", render: (r) => <StatusBadge value={r.status} /> },
                { key: "deadline", header: "Deadline", render: (r) => <>{formatDateTime(r.deadline_at)}{r.overdue ? <> <span className="badge badge-danger">Overdue</span></> : null}</> },
                { key: "case", header: "Case", render: (r) => <Link href={`/cases/view/?ref=${encodeURIComponent(r.case_ref)}`}><code>{r.case_ref}</code></Link> },
                { key: "created", header: "Received", render: (r) => formatDateTime(r.created_at) },
                { key: "set", header: "Update", render: (r) => <RequestStatus request={r} onDone={done} /> },
              ]}
            />
          </section>
          <section className="section" aria-labelledby="del-h">
            <h2 id="del-h">Account deletions</h2>
            <p className="small muted">Deletions are recorded in the privacy journal (sequence shown) so they survive a database restore.</p>
            <DataTable
              caption="Account deletion requests"
              rows={data.deletions}
              rowKey={(d) => d.public_ref}
              empty="No deletion requests."
              columns={[
                { key: "ref", header: "Deletion", render: (d) => <code>{d.public_ref}</code> },
                { key: "state", header: "State", render: (d) => <StatusBadge value={d.state} /> },
                { key: "seq", header: "Journal seq", render: (d) => d.journal_seq ?? "—" },
                { key: "req", header: "Requested", render: (d) => formatDateTime(d.requested_at) },
                { key: "done", header: "Completed", render: (d) => formatDateTime(d.completed_at) },
              ]}
            />
          </section>
        </>
      )}
    </AsyncState>
  );
}

function ReleaseHold({ hold, onDone }: { hold: LegalHold; onDone: Done }) {
  const { client } = useStaff();
  const { withFreshMfa, stepUpDialog } = useStepUp();
  const [reason, setReason] = useState("");
  const act = useAction();
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const res = await act.run(() => withFreshMfa(() => client.post<{ state: string }>(
      `${API}/privacy/holds/${encodeURIComponent(hold.public_ref)}/release`, { reason: reason.trim() })));
    if (res) onDone(`Hold ${hold.public_ref} released.`);
  };
  const f = fieldErrors(act.error);
  return (
    <>
      <form onSubmit={submit} className="inline-form" aria-label={`Release hold ${hold.public_ref}`}>
        <Field label="Release reason" value={reason} minLength={3} maxLength={400} onChange={(e) => setReason(e.target.value)} error={f.reason} />
        <div className="form-actions">
          <Button type="submit" variant="danger" busy={act.busy} disabled={reason.trim().length < 3}>Release</Button>
        </div>
        {act.error && !f.reason ? <div style={{ flexBasis: "100%" }}><ErrorNotice error={act.error} /></div> : null}
      </form>
      {stepUpDialog}
    </>
  );
}

function PlaceHold({ onDone }: { onDone: Done }) {
  const { client } = useStaff();
  const [target, setTarget] = useState("");
  const [scope, setScope] = useState("");
  const [basis, setBasis] = useState("");
  const [days, setDays] = useState("90");
  const [preview, setPreview] = useState<Preview | null>(null);
  const prep = useAction();
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const res = await prep.run(() => client.post<Preview>(`${API}/privacy/holds/preview`, {
      target: target.trim(), scope, basis: basis.trim(), review_days: Number(days) }));
    if (res) setPreview(res);
  };
  const f = fieldErrors(prep.error);
  const daysOk = /^\d+$/.test(days) && Number(days) >= 1 && Number(days) <= 365;
  return (
    <section className="card section" aria-labelledby="hold-h">
      <h2 id="hold-h">Place a legal hold</h2>
      <p className="small muted">A hold pauses scheduled purges for one subject and scope until released. Preview first, then confirm with a fresh authenticator code.</p>
      <form onSubmit={submit}>
        {prep.error && !Object.keys(f).length ? <ErrorNotice error={prep.error} /> : null}
        <div className="grid grid-2">
          <Field label="Target" hint="A username, case ref (cs_…) or report ref (rp_…)." value={target} maxLength={64} required
            onChange={(e) => setTarget(e.target.value)} error={f.target} autoCapitalize="none" spellCheck={false} />
          <Select label="Scope" placeholder="Choose…" options={HOLD_SCOPES} value={scope} onChange={(e) => setScope(e.target.value)} error={f.scope} />
        </div>
        <Field label="Legal basis" hint="At least 5 characters: the order, request or obligation requiring the hold." value={basis}
          minLength={5} maxLength={400} required onChange={(e) => setBasis(e.target.value)} error={f.basis} />
        <Field label="Review in (days)" type="number" min={1} max={365} inputMode="numeric" value={days} required
          onChange={(e) => setDays(e.target.value)} error={f.review_days} />
        <Button type="submit" busy={prep.busy} disabled={!target.trim() || !scope || basis.trim().length < 5 || !daysOk}>Preview hold</Button>
      </form>
      <PreviewConfirmDialog<HoldResult>
        preview={preview}
        title="Confirm legal hold"
        confirmPath={`${API}/privacy/holds/confirm`}
        confirmLabel="Place hold"
        format={{ review_at: (v) => formatDateTime(String(v)), scope: (v) => titleCase(String(v)) }}
        onClose={() => setPreview(null)}
        onDone={(r) => {
          setPreview(null); setTarget(""); setBasis(""); setScope("");
          onDone(`Hold ${r.hold_ref} placed (journal entry ${r.journal_seq}).`);
        }}
      />
    </section>
  );
}

function Holds({ onDone }: { onDone: Done }) {
  const state = useApi((c) => c.get<{ items: LegalHold[] }>(`${API}/privacy/holds`), []);
  const done = (m: string) => { onDone(m); state.reload(); };
  return (
    <>
      <section className="section" aria-labelledby="holds-h">
        <h2 id="holds-h">Legal holds</h2>
        <AsyncState state={state} label="Loading holds…">
          {(data) => (
            <DataTable
              caption="Legal holds"
              rows={data.items}
              rowKey={(h) => h.public_ref}
              empty="No legal holds."
              columns={[
                { key: "ref", header: "Hold", render: (h) => <code>{h.public_ref}</code> },
                { key: "subject", header: "Subject", render: (h) => <code className="small">{h.subject_ref}</code> },
                { key: "scope", header: "Scope", render: (h) => titleCase(h.scope) },
                { key: "basis", header: "Basis", render: (h) => <span className="plain">{h.basis}</span> },
                { key: "state", header: "State", render: (h) => <StatusBadge value={h.state} /> },
                { key: "review", header: "Review by", render: (h) => formatDateTime(h.review_at) },
                { key: "by", header: "Approved by", render: (h) => <>{h.username}<div className="small muted">{formatDateTime(h.created_at)}</div></> },
                { key: "release", header: "Release", render: (h) => (h.state === "active" ? <ReleaseHold hold={h} onDone={done} /> : "—") },
              ]}
            />
          )}
        </AsyncState>
      </section>
      <PlaceHold onDone={done} />
    </>
  );
}

function PrivacyInner() {
  const { announce } = useStaff();
  const [result, setResult] = useState<string | null>(null);
  const done = (m: string) => { setResult(m); announce(m); };
  return (
    <>
      {result ? <Notice kind="success">{result}</Notice> : null}
      <Requests onDone={done} />
      <Holds onDone={done} />
    </>
  );
}

export default function PrivacyPage() {
  return (
    <div className="container page">
      <PageTitle title="Privacy">Rights requests, account deletions and legal holds.</PageTitle>
      <RequireGrant permission="privacy.manage"><PrivacyInner /></RequireGrant>
    </div>
  );
}
