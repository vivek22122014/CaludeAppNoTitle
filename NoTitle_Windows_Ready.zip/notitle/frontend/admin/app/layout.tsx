import "@notitle/shared/src/tokens.css";
import "./admin.css";
import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { AppShell } from "@/components/AppShell";
import { StaffProvider } from "@/components/StaffContext";

export const metadata: Metadata = {
  title: "NoTitle Staff",
  description: "Private NoTitle staff console.",
  robots: { index: false, follow: false },
  referrer: "no-referrer",
};

export const viewport: Viewport = { width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <a className="skip" href="#main">Skip to main content</a>
        <StaffProvider>
          <AppShell>{children}</AppShell>
        </StaffProvider>
      </body>
    </html>
  );
}
