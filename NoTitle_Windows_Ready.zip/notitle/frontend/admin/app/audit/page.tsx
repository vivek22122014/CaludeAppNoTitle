"use client";

import { Button, Field, formatDateTime, titleCase } from "@notitle/shared";
import { type FormEvent, useEffect, useState } from "react";
import { API } from "@/components/constants";
import { DataTable } from "@/components/DataTable";
import { AsyncState, ErrorNotice, PageTitle, RequireGrant } from "@/components/Feedback";
import { useAction, useApi } from "@/components/hooks";
import { useStaff } from "@/components/StaffContext";
import type { AuditPage, AuditRow } from "@/components/types";

function AuditInner() {
  const { client } = useStaff();
  const [draft, setDraft] = useState("");
  const [action, setAction] = useState("");
  const [extra, setExtra] = useState<AuditRow[]>([]);
  const [cursor, setCursor] = useState<number | null>(null);
  const more = useAction();
  const state = useApi((c) => c.get<AuditPage>(`${API}/audit`, { action }), [action]);

  useEffect(() => { setExtra([]); setCursor(state.data?.next_cursor ?? null); }, [state.data]);

  const apply = (e: FormEvent) => { e.preventDefault(); setAction(draft.trim()); };
  const loadMore = async () => {
    if (cursor === null) return;
    const page = await more.run(() => client.get<AuditPage>(`${API}/audit`, { action, cursor }));
    if (page) { setExtra((p) => [...p, ...page.items]); setCursor(page.next_cursor); }
  };

  return (
    <>
      <form className="filters" onSubmit={apply} aria-label="Audit filters">
        <Field label="Action starts with" hint="For example: read, decision, login, hold_." value={draft} maxLength={40}
          onChange={(e) => setDraft(e.target.value)} autoCapitalize="none" spellCheck={false} />
        <div className="form-actions">
          <Button type="submit" variant="secondary">Apply filter</Button>
          {action ? <Button type="button" variant="ghost" onClick={() => { setDraft(""); setAction(""); }}>Clear</Button> : null}
        </div>
      </form>
      <AsyncState state={state} label="Loading audit log…">
        {(data) => {
          const rows = [...data.items, ...extra];
          return (
            <>
              <DataTable
                caption="Access audit log, newest first"
                rows={rows}
                rowKey={(r) => String(r.id)}
                empty={action ? "No audit entries match this action prefix." : "No audit entries."}
                columns={[
                  { key: "t", header: "Time", render: (r) => formatDateTime(r.created_at) },
                  { key: "actor", header: "Actor", render: (r) => <code className="small">{r.actor_ref}</code> },
                  { key: "purpose", header: "Purpose", render: (r) => titleCase(r.purpose) },
                  { key: "object", header: "Object", render: (r) => <>{r.object_type} <code className="small">{r.object_ref}</code></> },
                  { key: "action", header: "Action", render: (r) => <code className="small">{r.action}</code> },
                  { key: "decision", header: "Decision", render: (r) => <span className={`badge ${r.decision === "denied" ? "badge-danger" : "badge-success"}`}>{r.decision}</span> },
                  { key: "req", header: "Request ID", render: (r) => (r.request_id ? <code className="small">{r.request_id}</code> : "—") },
                ]}
              />
              <ErrorNotice error={more.error} />
              {cursor !== null ? (
                <div className="form-actions">
                  <Button type="button" variant="secondary" onClick={loadMore} busy={more.busy}>Load more</Button>
                </div>
              ) : null}
            </>
          );
        }}
      </AsyncState>
    </>
  );
}

export default function AuditPageView() {
  return (
    <div className="container page">
      <PageTitle title="Access audit">Every staff content read, sign-in and sensitive action, with its stated purpose.</PageTitle>
      <RequireGrant permission="audit.read"><AuditInner /></RequireGrant>
    </div>
  );
}
