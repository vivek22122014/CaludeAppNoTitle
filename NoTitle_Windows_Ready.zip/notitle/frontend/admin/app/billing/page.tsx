"use client";

import { Button, Field, formatDateTime, formatDuration, formatPaise, Notice, Select, TextArea, titleCase } from "@notitle/shared";
import { type FormEvent, useState } from "react";
import { API, PURCHASE_STATES, REMEDY_BASES } from "@/components/constants";
import { DataTable } from "@/components/DataTable";
import { AsyncState, ErrorNotice, PageTitle, RequireGrant, StatusBadge } from "@/components/Feedback";
import { fieldErrors, useAction, useApi } from "@/components/hooks";
import { PreviewConfirmDialog } from "@/components/PreviewConfirmDialog";
import { useStaff } from "@/components/StaffContext";
import type { Preview, Purchase, Refund, RefundResult, SummaryValue } from "@/components/types";

type Done = (message: string) => void;

/** "149" / "149.5" / "149.50" rupees → integer paise without floating-point error. */
function rupeesToPaise(input: string): number | null {
  const m = /^\s*(\d{1,7})(?:\.(\d{1,2}))?\s*$/.exec(input);
  if (!m) return null;
  return Number(m[1]) * 100 + Number((m[2] ?? "").padEnd(2, "0") || "0");
}

function ReconcileButton({ purchase, onDone }: { purchase: Purchase; onDone: Done }) {
  const { client } = useStaff();
  const act = useAction();
  if (purchase.state === "paid" || purchase.state === "failed") return <span className="muted small">Final</span>;
  const run = async () => {
    const res = await act.run(() => client.post<{ state: string }>(
      `${API}/billing/purchases/${encodeURIComponent(purchase.purchase_ref)}/reconcile`));
    if (res) onDone(`Reconciled ${purchase.purchase_ref}: state is now ${titleCase(res.state)}.`);
  };
  return (
    <div>
      <Button type="button" variant="secondary" onClick={run} busy={act.busy}>Reconcile</Button>
      <ErrorNotice error={act.error} />
    </div>
  );
}

function Purchases({ onDone, reloadKey }: { onDone: Done; reloadKey: number }) {
  const [state, setState] = useState("");
  const data = useApi((c) => c.get<{ items: Purchase[] }>(`${API}/billing/purchases`, { state }), [state, reloadKey]);
  return (
    <section className="section" aria-labelledby="purchases-h">
      <h2 id="purchases-h">Purchases</h2>
      <form className="filters" onSubmit={(e) => e.preventDefault()} aria-label="Purchase filters">
        <Select label="State" placeholder="All states" options={PURCHASE_STATES} value={state} onChange={(e) => setState(e.target.value)} />
        <div className="form-actions">
          <Button type="button" variant="secondary" onClick={data.reload} busy={data.loading}>Refresh</Button>
        </div>
      </form>
      <p className="small muted">Reconcile asks the payment provider for the true state. It grants paid time at most once and never charges anyone.</p>
      <AsyncState state={data} label="Loading purchases…">
        {(d) => (
          <DataTable
            caption="Purchases, newest first (latest 100)"
            rows={d.items}
            rowKey={(p) => p.purchase_ref}
            empty="No purchases match."
            columns={[
              { key: "ref", header: "Purchase", render: (p) => <><code>{p.purchase_ref}</code><div className="small muted">{p.merchant_order_id}</div></> },
              { key: "plan", header: "Plan", render: (p) => <>{titleCase(p.plan_code)} <span className="small muted">v{p.plan_version}</span><div className="small muted">{formatDuration(p.duration_seconds)}</div></> },
              { key: "amount", header: "Amount", render: (p) => formatPaise(p.amount_paise) },
              { key: "state", header: "State", render: (p) => <><StatusBadge value={p.state} /><div className="small muted">{p.message}</div></> },
              { key: "provider", header: "Provider", render: (p) => p.provider },
              { key: "created", header: "Created", render: (p) => <>{formatDateTime(p.created_at)}{p.captured_at ? <div className="small muted">Captured {formatDateTime(p.captured_at)}</div> : null}</> },
              { key: "refunds", header: "Remedies", render: (p) => p.refund_count },
              { key: "act", header: "Action", render: (p) => <ReconcileButton purchase={p} onDone={onDone} /> },
            ]}
          />
        )}
      </AsyncState>
    </section>
  );
}

function Refunds({ reloadKey }: { reloadKey: number }) {
  const data = useApi((c) => c.get<{ items: Refund[] }>(`${API}/billing/refunds`), [reloadKey]);
  return (
    <section className="section" aria-labelledby="refunds-h">
      <h2 id="refunds-h">Required remedies (refunds)</h2>
      <AsyncState state={data} label="Loading remedies…">
        {(d) => (
          <DataTable
            caption="Refunds and time adjustments, newest first"
            rows={d.items}
            rowKey={(r) => r.public_ref}
            empty="No remedies recorded."
            columns={[
              { key: "ref", header: "Remedy", render: (r) => <><code>{r.public_ref}</code><div className="small muted">for <code>{r.purchase_ref}</code></div></> },
              { key: "amount", header: "Amount", render: (r) => formatPaise(r.amount_paise) },
              { key: "time", header: "Time revoked / held", render: (r) => <>{formatDuration(r.revoke_seconds)}<div className="small muted">held {formatDuration(r.held_seconds)}</div></> },
              { key: "state", header: "State", render: (r) => <StatusBadge value={r.state} /> },
              { key: "basis", header: "Basis", render: (r) => <>{titleCase(r.remedy_basis)}<div className="small muted">evidence {r.evidence_ref}</div></> },
              { key: "reason", header: "Reason", render: (r) => <span className="plain">{r.decision_reason}</span> },
              { key: "by", header: "By", render: (r) => <>{r.username}<div className="small muted">{formatDateTime(r.created_at)}</div></> },
            ]}
          />
        )}
      </AsyncState>
    </section>
  );
}

function RemedyForm({ onDone }: { onDone: Done }) {
  const { client } = useStaff();
  const [purchaseRef, setPurchaseRef] = useState("");
  const [rupees, setRupees] = useState("");
  const [days, setDays] = useState("0");
  const [hours, setHours] = useState("0");
  const [basis, setBasis] = useState("");
  const [evidence, setEvidence] = useState("");
  const [reason, setReason] = useState("");
  const [preview, setPreview] = useState<Preview | null>(null);
  const [outcome, setOutcome] = useState<RefundResult | null>(null);
  const prep = useAction();

  const paise = rupeesToPaise(rupees);
  const whole = (v: string) => (/^\d+$/.test(v.trim()) ? Number(v) : null);
  const d = whole(days);
  const h = whole(hours);
  const seconds = d !== null && h !== null ? d * 86400 + h * 3600 : null;
  const valid = purchaseRef.trim() && paise !== null && paise >= 1 && seconds !== null && basis
    && evidence.trim().length >= 3 && reason.trim().length >= 3;

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!valid) return;
    setOutcome(null);
    const res = await prep.run(() => client.post<Preview>(`${API}/billing/refunds/preview`, {
      purchase_ref: purchaseRef.trim(), amount_paise: paise, revoke_seconds: seconds,
      remedy_basis: basis, evidence_ref: evidence.trim(), reason: reason.trim() }));
    if (res) setPreview(res);
  };
  const f = fieldErrors(prep.error);
  const money = (v: SummaryValue) => (typeof v === "number" ? formatPaise(v) : String(v ?? "—"));
  const secs = (v: SummaryValue) => (typeof v === "number" ? `${formatDuration(v)} (${v} s)` : String(v ?? "—"));

  return (
    <section className="card section" aria-labelledby="remedy-h">
      <h2 id="remedy-h">Record a required remedy</h2>
      <Notice kind="warning" title="There are no voluntary refunds">
        Use this only when a remedy is required: a payment error, a statutory remedy, or a direction from the payment
        provider or bank. Unused paid time is not refundable on request. Only the origin purchase&apos;s time can be adjusted.
      </Notice>
      {outcome ? (
        <Notice kind="success" title="Remedy submitted" live>
          Remedy <code>{outcome.refund_ref}</code> is <strong>{titleCase(outcome.state)}</strong>. {formatDuration(outcome.held_seconds)} of paid time is held.
        </Notice>
      ) : null}
      <form onSubmit={submit}>
        {prep.error && !Object.keys(f).length ? <ErrorNotice error={prep.error} /> : null}
        <div className="grid grid-2">
          <Field label="Purchase reference" value={purchaseRef} maxLength={64} required autoCapitalize="none" spellCheck={false}
            onChange={(e) => setPurchaseRef(e.target.value)} error={f.purchase_ref} />
          <Field label="Amount to refund (₹)" hint="Rupees, up to 2 decimals. Sent as integer paise." inputMode="decimal" value={rupees} required
            onChange={(e) => setRupees(e.target.value)}
            error={f.amount_paise ?? (rupees && paise === null ? "Enter an amount like 149 or 149.50." : undefined)} />
          <Field label="Revoke paid time: days" type="number" min={0} inputMode="numeric" value={days}
            onChange={(e) => setDays(e.target.value)} error={f.revoke_seconds} />
          <Field label="Revoke paid time: hours" type="number" min={0} inputMode="numeric" value={hours}
            onChange={(e) => setHours(e.target.value)} hint={seconds !== null ? `= ${seconds} seconds` : "Whole numbers only."} />
        </div>
        <Select label="Remedy basis" placeholder="Choose…" options={REMEDY_BASES} value={basis}
          onChange={(e) => setBasis(e.target.value)} error={f.remedy_basis} />
        <Field label="Evidence reference" hint="Ticket, provider notice or legal reference (3–200 characters)." value={evidence}
          maxLength={200} required onChange={(e) => setEvidence(e.target.value)} error={f.evidence_ref} />
        <TextArea label="Reason" value={reason} maxLength={400} required onChange={(e) => setReason(e.target.value)} error={f.reason} />
        <Button type="submit" busy={prep.busy} disabled={!valid}>Preview remedy</Button>
      </form>
      <PreviewConfirmDialog<RefundResult>
        preview={preview}
        title="Confirm required remedy"
        confirmPath={`${API}/billing/refunds/confirm`}
        confirmLabel="Confirm remedy"
        danger
        format={{
          amount_paise: money, remaining_refundable_paise: money,
          revoke_seconds: secs, max_revocable_seconds: secs, remedy_basis: (v) => titleCase(String(v)),
        }}
        onClose={() => setPreview(null)}
        onDone={(r) => {
          setPreview(null); setOutcome(r);
          setPurchaseRef(""); setRupees(""); setDays("0"); setHours("0"); setBasis(""); setEvidence(""); setReason("");
          onDone(`Remedy ${r.refund_ref} is ${titleCase(r.state)}.`);
        }}
      />
    </section>
  );
}

function BillingInner() {
  const { can, announce } = useStaff();
  const [result, setResult] = useState<string | null>(null);
  const [reloadKey, setReloadKey] = useState(0);
  const done = (m: string) => { setResult(m); announce(m); setReloadKey((k) => k + 1); };
  return (
    <>
      {result ? <Notice kind="success">{result}</Notice> : null}
      <Purchases onDone={done} reloadKey={reloadKey} />
      <Refunds reloadKey={reloadKey} />
      {can("billing.remedy") ? <RemedyForm onDone={done} /> : null}
    </>
  );
}

export default function BillingPage() {
  return (
    <div className="container page">
      <PageTitle title="Billing">Purchases, reconciliation and required remedies.</PageTitle>
      <RequireGrant permission="billing.read"><BillingInner /></RequireGrant>
    </div>
  );
}
