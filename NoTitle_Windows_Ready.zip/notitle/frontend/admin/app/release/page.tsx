"use client";

import { Button, Notice, titleCase } from "@notitle/shared";
import type { ReactNode } from "react";
import { API } from "@/components/constants";
import { DataTable } from "@/components/DataTable";
import { AsyncState, Facts, PageTitle, RequireGrant } from "@/components/Feedback";
import { useApi } from "@/components/hooks";
import type { Health } from "@/components/types";

function OnOff({ on, yes = "On", no = "Off" }: { on: boolean; yes?: string; no?: string }) {
  return <span className={`badge ${on ? "badge-success" : ""}`}>{on ? yes : no}</span>;
}

function Gate({ name, value, children }: { name: string; value: ReactNode; children: ReactNode }) {
  return (
    <tr>
      <th scope="row">{name}</th>
      <td>{value}</td>
      <td className="small">{children}</td>
    </tr>
  );
}

function HealthView() {
  const state = useApi((c) => c.get<Health>(`${API}/health`), []);
  return (
    <AsyncState state={state} label="Checking health…">
      {(h) => {
        const pendingMigrations = h.migrations.filter((m) => !m.applied).length;
        const badChecksums = h.migrations.filter((m) => m.checksum_ok === false).length;
        const journalPct = h.journal.capacity ? Math.round((h.journal.entries / h.journal.capacity) * 100) : 0;
        return (
          <>
            <div className="row-between">
              <p className="muted" style={{ margin: 0 }}>Environment: <strong>{h.environment}</strong></p>
              <Button type="button" variant="secondary" onClick={state.reload} busy={state.loading}>Refresh</Button>
            </div>
            {h.database !== "ok" ? <Notice kind="error" title="Database unavailable">The runtime cannot reach PostgreSQL.</Notice> : null}
            {pendingMigrations || badChecksums ? (
              <Notice kind="warning" title="Migrations need attention">
                {pendingMigrations} pending, {badChecksums} with a checksum mismatch.
              </Notice>
            ) : null}

            <section className="card section" aria-labelledby="core-h">
              <h2 id="core-h">Core</h2>
              <Facts items={[
                ["Database", <span key="d" className={`badge ${h.database === "ok" ? "badge-success" : "badge-danger"}`}>{h.database}</span>],
                ["Owner epoch", <code key="e">{String(h.owner_epoch ?? "—")}</code>],
                ["Overdue obligations", <span key="o" className={h.overdue_obligations ? "badge badge-danger" : ""}>{h.overdue_obligations ?? "—"}</span>],
                ["Payments needing attention", h.payments_needing_attention ?? "—"],
                ["Latest backup", h.latest_backup ? <code key="b">{h.latest_backup}</code> : <span key="b" className="badge badge-warning">None found</span>],
              ]} />
              <p className="small muted">The owner epoch increases each time a runtime instance takes ownership of realtime state; a change means a restart or failover happened.</p>
            </section>

            <div className="grid grid-2 section">
              <section className="card" aria-labelledby="runtime-h">
                <h2 id="runtime-h">Realtime runtime</h2>
                <Facts items={Object.entries(h.runtime).map(([k, v]): [ReactNode, ReactNode] => [titleCase(k), v])} />
                <p className="small muted">Live in-memory counts. &ldquo;Connected&rdquo; counts admitted identities including guests, not unique people.</p>
              </section>
              <section className="card" aria-labelledby="jobs-h">
                <h2 id="jobs-h">Durable jobs</h2>
                <Facts items={Object.entries(h.jobs).map(([k, v]): [ReactNode, ReactNode] => [
                  titleCase(k), k === "failed" && v ? <span key={k} className="badge badge-danger">{v}</span> : v])} />
                <p className="small muted">Due = ready or waiting to retry. Failed jobs need an operator to inspect them.</p>
              </section>
            </div>

            <section className="card section" aria-labelledby="journal-h">
              <h2 id="journal-h">Privacy journal</h2>
              <Facts items={[
                ["Entries", `${h.journal.entries} / ${h.journal.capacity} (${journalPct}%)`],
                ["Head", <code key="h">{h.journal.head || "—"}</code>],
                ["File", <code key="p" className="small">{h.journal.path}</code>],
              ]} />
              <p className="small muted">The append-only journal records deletions and legal holds so they are re-applied after a database restore. Keep it with backups.</p>
            </section>

            <section className="section" aria-labelledby="gates-h">
              <h2 id="gates-h">Feature gates</h2>
              <div className="table-wrap">
                <table className="table">
                  <caption className="sr-only">Feature gates and what they mean</caption>
                  <thead><tr><th scope="col">Gate</th><th scope="col">State</th><th scope="col">Meaning</th></tr></thead>
                  <tbody>
                    <Gate name="Admission" value={<OnOff on={h.gates.admission} yes="Open" no="Closed" />}>Whether new visitors can enter matching.</Gate>
                    <Gate name="Audio calls" value={<OnOff on={h.gates.audio} />}>Voice calls between matched users.</Gate>
                    <Gate name="Audio relay only" value={<OnOff on={h.gates.audio_relay_only} yes="Required" no="Not required" />}>When required, calls go through the TURN relay so peers never see each other&apos;s IP address.</Gate>
                    <Gate name="Payments" value={<OnOff on={h.gates.payments} yes="Selling" no="Not selling" />}>Whether passes can be bought right now. Provider: <code>{h.gates.payment_provider}</code>.</Gate>
                    <Gate name="Annual (365-day) pass" value={<OnOff on={h.gates.annual365} yes="Enabled" no="Disabled" />}>Deliberately off in this release; only shorter passes are sold.</Gate>
                    <Gate name="Policies" value={<span className={`badge ${h.gates.policies === "draft" ? "badge-warning" : "badge-success"}`}>{h.gates.policies}</span>}>
                      {h.gates.policies === "draft"
                        ? "Legal policies are still drafts pending operator review; the public site shows a draft banner."
                        : "Legal policies are published."}
                    </Gate>
                  </tbody>
                </table>
              </div>
            </section>

            <section className="section" aria-labelledby="mig-h">
              <h2 id="mig-h">Migrations</h2>
              <DataTable
                caption="Database migrations"
                rows={h.migrations}
                rowKey={(m) => m.id}
                empty="Migration status unavailable."
                columns={[
                  { key: "id", header: "Migration", render: (m) => <code>{m.id}</code> },
                  { key: "applied", header: "Applied", render: (m) => <OnOff on={m.applied} yes="Applied" no="Pending" /> },
                  { key: "sum", header: "Checksum", render: (m) => (m.checksum_ok === null ? "—"
                    : <span className={`badge ${m.checksum_ok ? "badge-success" : "badge-danger"}`}>{m.checksum_ok ? "Matches" : "Mismatch"}</span>) },
                ]}
              />
            </section>
          </>
        );
      }}
    </AsyncState>
  );
}

export default function ReleasePage() {
  return (
    <div className="container page">
      <PageTitle title="Health">Release readiness and runtime state of this NoTitle instance.</PageTitle>
      <RequireGrant permission="release.read"><HealthView /></RequireGrant>
    </div>
  );
}
