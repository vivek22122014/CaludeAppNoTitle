"use client";

import { Button, Field, formatDateTime, MultiSelect, Notice, SecretPanel, titleCase } from "@notitle/shared";
import { type FormEvent, useEffect, useRef, useState } from "react";
import { API } from "@/components/constants";
import { DataTable } from "@/components/DataTable";
import { AsyncState, ErrorNotice, PageTitle, RequireGrant, StatusBadge } from "@/components/Feedback";
import { fieldErrors, useAction, useApi } from "@/components/hooks";
import { useStaff } from "@/components/StaffContext";
import { useStepUp } from "@/components/StepUp";
import type { CreatedStaff, StaffList, StaffMember } from "@/components/types";

type Done = (message: string) => void;

/** Best guess of which roles produced a permission set (owner covers everything). */
function rolesFor(member: StaffMember, roles: Record<string, string[]>): string[] {
  const has = new Set(member.permissions);
  const covers = (r: string) => roles[r].every((p) => has.has(p));
  if (roles.owner && covers("owner")) return ["owner"];
  return Object.keys(roles).filter((r) => r !== "owner" && covers(r));
}

function roleOptions(roles: Record<string, string[]>) {
  return Object.keys(roles).map((r) => ({ id: r, label: titleCase(r) }));
}

function EditRoles({ member, roles, onDone }: { member: StaffMember; roles: Record<string, string[]>; onDone: Done }) {
  const { client, staff, refresh } = useStaff();
  const { withFreshMfa, stepUpDialog } = useStepUp();
  const [value, setValue] = useState<string[]>(() => rolesFor(member, roles));
  const act = useAction();
  const self = staff?.username === member.username;
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const res = await act.run(() => withFreshMfa(() => client.post<{ roles: string[] }>(
      `${API}/staff/${encodeURIComponent(member.username)}/roles`, { roles: value })));
    if (res) {
      onDone(`Roles for ${member.username} set to ${res.roles.join(", ") || "none"}. Their existing sessions were signed out.`);
      if (self) void refresh();
    }
  };
  return (
    <>
    <details>
      <summary>Change roles</summary>
      <form onSubmit={submit} aria-label={`Change roles for ${member.username}`}>
        <MultiSelect label={`Roles for ${member.username}`} options={roleOptions(roles)} value={value} onChange={setValue}
          max={Object.keys(roles).length} hint="Saving signs this person out everywhere so the new grants apply." />
        {self ? <Notice kind="warning">You are changing your own roles. You will be signed out and must sign in again.</Notice> : null}
        <ErrorNotice error={act.error} />
        <Button type="submit" variant="secondary" busy={act.busy}>Save roles</Button>
      </form>
    </details>
    {stepUpDialog}
    </>
  );
}

function CreateStaff({ roles, onCreated }: { roles: Record<string, string[]>; onCreated: (c: CreatedStaff) => void }) {
  const { client } = useStaff();
  const { withFreshMfa, stepUpDialog } = useStepUp();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [selected, setSelected] = useState<string[]>([]);
  const act = useAction();
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const res = await act.run(() => withFreshMfa(() => client.post<CreatedStaff>(`${API}/staff`,
      { username: username.trim().toLowerCase(), password, roles: selected })));
    if (res) { setUsername(""); setPassword(""); setSelected([]); onCreated(res); }
  };
  const f = fieldErrors(act.error);
  return (
    <section className="card section" aria-labelledby="create-h">
      <h2 id="create-h">Create a staff account</h2>
      <p className="small muted">Needs a fresh authenticator check. The new person&apos;s authenticator secret and recovery codes are shown once.</p>
      <form onSubmit={submit}>
        {act.error && !Object.keys(f).length ? <ErrorNotice error={act.error} /> : null}
        <div className="grid grid-2">
          <Field label="Username" hint="3–32 lowercase letters, numbers, dot, dash or underscore." value={username} maxLength={32}
            required autoCapitalize="none" spellCheck={false} autoComplete="off"
            onChange={(e) => setUsername(e.target.value)} error={f.username} />
          <Field label="Initial password" type="password" autoComplete="new-password" value={password} required
            onChange={(e) => setPassword(e.target.value)} error={f.password} />
        </div>
        <MultiSelect label="Roles" options={roleOptions(roles)} value={selected} onChange={setSelected}
          max={Object.keys(roles).length} hint="Grant the least access that lets them do their job." />
        {f.roles ? <p className="field-error" role="alert">{f.roles}</p> : null}
        <Button type="submit" busy={act.busy} disabled={!username.trim() || !password || !selected.length}>Create staff account</Button>
      </form>
      {stepUpDialog}
    </section>
  );
}

function CreatedSecrets({ created, onDismiss }: { created: CreatedStaff; onDismiss: () => void }) {
  const heading = useRef<HTMLHeadingElement>(null);
  useEffect(() => { heading.current?.focus(); }, [created]);
  return (
    <section className="card section" aria-labelledby="secrets-h">
      <h2 id="secrets-h" ref={heading} tabIndex={-1}>New account: {created.username}</h2>
      <Notice kind="warning" title="Shown once — save it now">
        {created.warning} These values cannot be shown again. Leaving or reloading this page discards them.
      </Notice>
      <p>Roles: {created.roles.map(titleCase).join(", ")}</p>
      <SecretPanel title="Authenticator (TOTP) secret" secret={created.totp_secret} filename={`${created.username}-totp.txt`}
        explanation="Enter this in an authenticator app, or use the setup URI below." />
      <SecretPanel title="Authenticator setup URI" secret={created.otpauth_uri} filename={`${created.username}-otpauth.txt`}
        explanation="An otpauth:// link authenticator apps can import." />
      <SecretPanel title="Recovery codes" secret={created.recovery_codes.join("\n")} filename={`${created.username}-recovery-codes.txt`}
        explanation={`${created.recovery_codes.length} single-use codes for signing in without the authenticator.`} />
      <Button type="button" variant="secondary" onClick={onDismiss}>I have handed these over securely — hide them</Button>
    </section>
  );
}

function StaffInner() {
  const { announce } = useStaff();
  const state = useApi((c) => c.get<StaffList>(`${API}/staff`), []);
  const [result, setResult] = useState<string | null>(null);
  const [created, setCreated] = useState<CreatedStaff | null>(null);
  const done = (m: string) => { setResult(m); announce(m); state.reload(); };

  return (
    <>
      {result ? <Notice kind="success">{result}</Notice> : null}
      {created ? <CreatedSecrets created={created} onDismiss={() => setCreated(null)} /> : null}
      <AsyncState state={state} label="Loading staff…">
        {(data) => (
          <>
            <section aria-labelledby="list-h">
              <h2 id="list-h">Staff accounts</h2>
              <DataTable
                caption="Staff accounts and permissions"
                rows={data.items}
                rowKey={(m) => m.username}
                empty="No staff accounts."
                columns={[
                  { key: "user", header: "Username", render: (m) => <strong>{m.username}</strong> },
                  { key: "status", header: "Status", render: (m) => <StatusBadge value={m.status} /> },
                  { key: "roles", header: "Roles (inferred)", render: (m) => rolesFor(m, data.roles).map(titleCase).join(", ") || "—" },
                  { key: "perms", header: "Permissions", render: (m) => (
                    <details><summary>{m.permissions.length} permissions</summary>
                      <ul className="small" style={{ margin: 0, paddingLeft: "1.2em" }}>{m.permissions.map((p) => <li key={p}><code>{p}</code></li>)}</ul>
                    </details>
                  ) },
                  { key: "created", header: "Created", render: (m) => formatDateTime(m.created_at) },
                  { key: "edit", header: "Change", render: (m) => <EditRoles member={m} roles={data.roles} onDone={done} /> },
                ]}
              />
            </section>
            <CreateStaff roles={data.roles} onCreated={(c) => {
              setCreated(c);
              done(`Staff account ${c.username} created. Save the one-time secrets shown above.`);
            }} />
          </>
        )}
      </AsyncState>
    </>
  );
}

export default function SettingsPage() {
  return (
    <div className="container page">
      <PageTitle title="Staff">Staff accounts, roles and enrolment. Role changes and new accounts need a fresh authenticator check.</PageTitle>
      <RequireGrant permission="staff.manage"><StaffInner /></RequireGrant>
    </div>
  );
}
