"use client";

import { ApiError, Button, EmptyState, Field, formatDateTime, Loading, Notice, Select, titleCase } from "@notitle/shared";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { type FormEvent, Suspense, useState } from "react";
import { API, APPEAL_OUTCOMES, DECISION_ACTIONS } from "@/components/constants";
import { DataTable } from "@/components/DataTable";
import { ErrorNotice, Facts, PageTitle, RequireGrant, StatusBadge } from "@/components/Feedback";
import { fieldErrors, useAction } from "@/components/hooks";
import { PreviewConfirmDialog } from "@/components/PreviewConfirmDialog";
import { PurposePicker } from "@/components/PurposePicker";
import { useStaff } from "@/components/StaffContext";
import { useStepUp } from "@/components/StepUp";
import type { Decision, DecisionResult, Preview, ReportDetail } from "@/components/types";

function DecisionForm({ reportRef, onDone }: { reportRef: string; onDone: (r: DecisionResult) => void }) {
  const { client } = useStaff();
  const [action, setAction] = useState("");
  const [reason, setReason] = useState("");
  const [hours, setHours] = useState("");
  const [preview, setPreview] = useState<Preview | null>(null);
  const prep = useAction();

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const res = await prep.run(() => client.post<Preview>(`${API}/decisions/preview`, {
      report_ref: reportRef, action, reason_code: reason.trim(),
      duration_hours: action === "suspend" ? Number(hours) : null,
    }));
    if (res) setPreview(res);
  };
  const f = fieldErrors(prep.error);
  const suspend = action === "suspend";
  const hoursOk = !suspend || (/^\d+$/.test(hours) && Number(hours) >= 1 && Number(hours) <= 2160);

  return (
    <section className="card section" aria-labelledby="decide-h">
      <h2 id="decide-h">Make a decision</h2>
      <p className="small muted">Step 1 prepares a signed preview; step 2 confirms it with a fresh authenticator code. Nothing changes until you confirm.</p>
      <form onSubmit={submit}>
        {prep.error && !Object.keys(f).length ? <ErrorNotice error={prep.error} /> : null}
        <Select label="Action" placeholder="Choose an action…" options={DECISION_ACTIONS} value={action}
          onChange={(e) => setAction(e.target.value)} error={f.action} required />
        <Field label="Reason code" hint="Short policy code, e.g. harassment, spam, threats." value={reason} maxLength={64}
          required onChange={(e) => setReason(e.target.value)} error={f.reason_code} autoCapitalize="none" />
        {suspend ? (
          <Field label="Suspension length (hours)" hint="1 to 2160 hours (90 days)." type="number" min={1} max={2160}
            inputMode="numeric" value={hours} required onChange={(e) => setHours(e.target.value)} error={f.duration_hours} />
        ) : null}
        <Button type="submit" busy={prep.busy} disabled={!action || !reason.trim() || !hoursOk}>Preview decision</Button>
      </form>
      <PreviewConfirmDialog<DecisionResult>
        preview={preview}
        title="Confirm moderation decision"
        confirmPath={`${API}/decisions/confirm`}
        confirmLabel="Confirm decision"
        danger={action === "suspend" || action === "ban"}
        format={{ action: (v) => titleCase(String(v)) }}
        onClose={() => setPreview(null)}
        onDone={(r) => { setPreview(null); setAction(""); setReason(""); setHours(""); onDone(r); }}
      />
    </section>
  );
}

function AppealForm({ decision, onDone }: { decision: Decision; onDone: (message: string) => void }) {
  const { client } = useStaff();
  const { withFreshMfa, stepUpDialog } = useStepUp();
  const [outcome, setOutcome] = useState("");
  const [reason, setReason] = useState("");
  const act = useAction();

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const res = await act.run(() => withFreshMfa(() => client.post<{ appeal_outcome: string }>(
      `${API}/appeals/${encodeURIComponent(decision.public_ref)}/resolve`, { outcome, reason: reason.trim() })));
    if (res) onDone(`Appeal for ${decision.public_ref} resolved: ${res.appeal_outcome}.`);
  };
  const f = fieldErrors(act.error);
  return (
    <>
    <form onSubmit={submit} className="inline-form" aria-label={`Resolve appeal for ${decision.public_ref}`}>
      <Select label="Appeal outcome" placeholder="Choose…" options={APPEAL_OUTCOMES} value={outcome}
        onChange={(e) => setOutcome(e.target.value)} error={f.outcome} />
      <Field label="Reason" value={reason} maxLength={400} onChange={(e) => setReason(e.target.value)} error={f.reason} />
      <div className="form-actions">
        <Button type="submit" variant="secondary" busy={act.busy} disabled={!outcome || !reason.trim()}>Resolve appeal</Button>
      </div>
      {act.error && !Object.keys(f).length ? (
        <div style={{ flexBasis: "100%" }}><ErrorNotice error={act.error} /></div>
      ) : null}
    </form>
    {stepUpDialog}
    </>
  );
}

function ReportDetailView({ reportRef }: { reportRef: string }) {
  const { client, can, announce } = useStaff();
  const [purpose, setPurpose] = useState("");
  const [report, setReport] = useState<ReportDetail | null>(null);
  const [result, setResult] = useState<string | null>(null);
  const load = useAction();

  const loadReport = async (p = purpose) => {
    const res = await load.run(() => client.get<ReportDetail>(`${API}/reports/${encodeURIComponent(reportRef)}`, { purpose: p }));
    if (res) setReport(res);
  };
  const done = (message: string) => { setResult(message); announce(message); void loadReport(); };

  const notFound = load.error instanceof ApiError && load.error.status === 404;

  return (
    <>
      <form className="card filters" onSubmit={(e) => { e.preventDefault(); if (purpose) void loadReport(); }} aria-label="Load evidence">
        <PurposePicker value={purpose} onChange={setPurpose} />
        <div className="form-actions">
          <Button type="submit" busy={load.busy} disabled={!purpose}>{report ? "Reload evidence" : "Load evidence"}</Button>
        </div>
      </form>
      {notFound ? <Notice kind="warning">No report with this reference.</Notice> : <ErrorNotice error={load.error} />}
      {result ? <Notice kind="success">{result}</Notice> : null}
      {!report ? (
        load.busy ? <Loading /> : <p className="muted">Evidence is hidden until you choose a purpose and load it.</p>
      ) : (
        <>
          <section className="card section" aria-labelledby="facts-h">
            <h2 id="facts-h">Report</h2>
            <Facts items={[
              ["Reason", titleCase(report.reason)],
              ["Reporter", titleCase(report.reporter_kind)],
              ["Subject", <span key="s">{titleCase(report.subject_kind)} <code className="small">{report.subject_ref}</code></span>],
              ["Submitted", formatDateTime(report.submitted_at)],
              ["Evidence state", titleCase(report.evidence_state)],
              ["Reporter blocked subject", report.blocked ? "Yes" : "No"],
              ["Other reports about this subject", report.other_reports_about_subject],
              ["Case", can("cases.read")
                ? <Link key="c" href={`/cases/view/?ref=${encodeURIComponent(report.case_ref)}`}><code>{report.case_ref}</code></Link>
                : <code key="c">{report.case_ref}</code>],
            ]} />
            <h3>Allegation — the reporter&apos;s own account</h3>
            <p className="small muted">{report.allegation_note}</p>
            <div className="allegation"><p className="plain">{report.allegation}</p></div>
          </section>

          <section className="card section" aria-labelledby="evidence-h">
            <h2 id="evidence-h">Server-snapshot evidence</h2>
            <p className="small muted">Messages captured by the server at report time (not supplied by the reporter).</p>
            {report.evidence.length === 0 ? <EmptyState title="No server-captured messages for this report." /> : (
              <ol className="evidence-list" aria-label="Evidence messages, oldest first">
                {report.evidence.map((m) => (
                  <li key={m.message_id} className="msg">
                    <div className="msg-head">
                      <strong>{titleCase(m.sender)}</strong>
                      <time dateTime={m.sent_at}>{formatDateTime(m.sent_at)}</time>
                      <span className="badge">{m.source.replace(/_/g, " ")}</span>
                    </div>
                    <p className="plain">{m.body}</p>
                  </li>
                ))}
              </ol>
            )}
          </section>

          <section className="section" aria-labelledby="decisions-h">
            <h2 id="decisions-h">Decisions</h2>
            <DataTable
              caption="Moderation decisions on this report"
              rows={report.decisions}
              rowKey={(d) => d.public_ref}
              empty="No decisions yet."
              columns={[
                { key: "ref", header: "Decision", render: (d) => <code>{d.public_ref}</code> },
                { key: "action", header: "Action", render: (d) => titleCase(d.action) },
                { key: "reason", header: "Reason code", render: (d) => d.reason_code },
                { key: "period", header: "Period", render: (d) => <>{formatDateTime(d.starts_at)} → {d.ends_at ? formatDateTime(d.ends_at) : d.action === "ban" ? "indefinite" : "—"}</> },
                { key: "by", header: "By", render: (d) => d.username },
                { key: "appeal", header: "Appeal", render: (d) => (d.appeal_outcome
                  ? <StatusBadge value={d.appeal_outcome} />
                  : can("appeals.review") ? <AppealForm decision={d} onDone={done} />
                    : <span className="muted small">No appeal outcome</span>) },
              ]}
            />
            {can("appeals.review") ? (
              <p className="small muted">Appeals need an independent reviewer: you cannot resolve an appeal on a decision you made. Resolving asks for a fresh authenticator code if your last check is older than 5 minutes.</p>
            ) : null}
          </section>

          {can("decisions.make") ? (
            <DecisionForm reportRef={report.report_ref}
              onDone={(r) => done(`Decision ${r.decision_ref} recorded: ${titleCase(r.action)}${r.ends_at ? ` until ${formatDateTime(r.ends_at)}` : ""}.`)} />
          ) : null}
        </>
      )}
    </>
  );
}

function ReportViewInner() {
  const ref = useSearchParams().get("ref")?.trim() ?? "";
  return (
    <>
      <p className="small"><Link href="/reports/">← Back to reports</Link></p>
      <PageTitle title={ref ? `Report ${ref}` : "Report"} />
      {ref ? <ReportDetailView key={ref} reportRef={ref} /> : (
        <Notice kind="warning">No report reference given. Open a report from the <Link href="/reports/">list</Link>.</Notice>
      )}
    </>
  );
}

export default function ReportViewPage() {
  return (
    <div className="container page">
      <RequireGrant permission="reports.read">
        <Suspense fallback={<Loading />}>
          <ReportViewInner />
        </Suspense>
      </RequireGrant>
    </div>
  );
}
