"use client";

import { Button, formatDateTime, titleCase } from "@notitle/shared";
import Link from "next/link";
import { API } from "@/components/constants";
import { DataTable } from "@/components/DataTable";
import { AsyncState, PageTitle, RequireGrant, StatusBadge } from "@/components/Feedback";
import { useApi } from "@/components/hooks";
import type { ReportListItem } from "@/components/types";

function ReportList() {
  const state = useApi((c) => c.get<{ items: ReportListItem[] }>(`${API}/reports`), []);
  return (
    <>
      <div className="form-actions" style={{ marginBottom: 12 }}>
        <Button type="button" variant="secondary" onClick={state.reload} busy={state.loading}>Refresh</Button>
      </div>
      <AsyncState state={state} label="Loading reports…">
        {(data) => (
          <DataTable
            caption="Safety reports, urgent first"
            rows={data.items}
            rowKey={(r) => r.public_ref}
            rowClass={(r) => (r.urgent ? "row-urgent" : undefined)}
            empty="No reports."
            columns={[
              { key: "ref", header: "Report", render: (r) => <Link href={`/reports/view/?ref=${encodeURIComponent(r.public_ref)}`}><code>{r.public_ref}</code></Link> },
              { key: "reason", header: "Reason", render: (r) => <>{titleCase(r.reason)}{r.urgent ? <> <span className="badge badge-danger">Urgent</span></> : null}</> },
              { key: "subject", header: "Subject", render: (r) => titleCase(r.subject_kind) },
              { key: "evidence", header: "Evidence", render: (r) => titleCase(r.evidence_state) },
              { key: "blocked", header: "Blocked", render: (r) => (r.blocked ? "Yes" : "No") },
              { key: "case", header: "Case", render: (r) => <><Link href={`/cases/view/?ref=${encodeURIComponent(r.case_ref)}`}><code>{r.case_ref}</code></Link> <StatusBadge value={r.status} /></> },
              { key: "decisions", header: "Decisions", render: (r) => r.decisions },
              { key: "submitted", header: "Submitted", render: (r) => formatDateTime(r.submitted_at) },
            ]}
          />
        )}
      </AsyncState>
    </>
  );
}

export default function ReportsPage() {
  return (
    <div className="container page">
      <PageTitle title="Reports">Safety reports and their moderation decisions. Evidence is only shown on the report page after you choose a purpose.</PageTitle>
      <RequireGrant permission="reports.read"><ReportList /></RequireGrant>
    </div>
  );
}
