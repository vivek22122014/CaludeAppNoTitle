"use client";

import { Button, EmptyState, formatDateTime, Notice, Select, titleCase } from "@notitle/shared";
import { type FormEvent, useMemo, useState } from "react";
import { API } from "@/components/constants";
import { AsyncState, ErrorNotice, PageTitle, RequireGrant } from "@/components/Feedback";
import { useAction, useApi } from "@/components/hooks";
import { useStaff } from "@/components/StaffContext";
import type { AnalyticsSummary, HistogramTotal, MetricInfo, Series, Suppressed } from "@/components/types";

type Resolution = "minute" | "hour" | "day";
const RESOLUTIONS: { id: Resolution; label: string; span: number; step: number }[] = [
  { id: "minute", label: "Per minute — last 24 hours", span: 24 * 3600e3, step: 60e3 },
  { id: "hour", label: "Per hour — last 7 days", span: 7 * 86400e3, step: 3600e3 },
  { id: "day", label: "Per day — last 30 days", span: 30 * 86400e3, step: 86400e3 },
];

function SuppressedValue({ value }: { value: Suppressed | undefined }) {
  if (value === null || value === undefined) return <span className="muted">—</span>;
  if (value === "<10") return <span>&lt;10 <span className="badge" title="Small values are suppressed for privacy">suppressed</span></span>;
  return <>{value.toLocaleString()}</>;
}

function isHistogram(v: unknown): v is HistogramTotal {
  return typeof v === "object" && v !== null && "count" in v;
}

function Summary() {
  const state = useApi((c) => c.get<AnalyticsSummary>(`${API}/analytics/summary`), []);
  return (
    <AsyncState state={state} label="Loading summary…">
      {(s) => {
        const current: [string, Suppressed][] = [
          ["Active now", s.current.active_now], ["Searching now", s.current.searching_now],
          ["Conversations now", s.current.conversations_now], ["Calls now", s.current.calls_now],
          ["Current accounts", s.current.current_accounts],
        ];
        const totals = Object.entries(s.totals_24h).sort(([a], [b]) => a.localeCompare(b));
        return (
          <>
            <section aria-labelledby="now-h">
              <div className="row-between">
                <h2 id="now-h">Right now</h2>
                <Button type="button" variant="secondary" onClick={state.reload} busy={state.loading}>Refresh</Button>
              </div>
              <div className="grid grid-3">
                {current.map(([label, value]) => (
                  <div key={label} className="card stat">
                    <span className="stat-label">{label}</span>
                    <span className="stat-value"><SuppressedValue value={value} /></span>
                  </div>
                ))}
              </div>
              <p className="small muted" style={{ marginTop: 8 }}>{s.current.note} Generated {formatDateTime(s.generated_at)}.</p>
            </section>
            <section className="section" aria-labelledby="totals-h">
              <h2 id="totals-h">Last 24 hours</h2>
              <p className="small muted">
                Error rate: {s.error_rate === null ? "not available (too few requests)" : `${(s.error_rate * 100).toFixed(2)}%`}.
                {" "}{s.completeness} Values below 10 are shown as &lt;10.
              </p>
              {totals.length === 0 ? <EmptyState title="No metrics recorded in the last 24 hours." /> : (
                <div className="table-wrap">
                  <table className="table">
                    <caption className="sr-only">Metric totals for the last 24 hours</caption>
                    <thead><tr><th scope="col">Metric</th><th scope="col">Total / samples</th><th scope="col">Mean</th></tr></thead>
                    <tbody>
                      {totals.map(([name, v]) => (
                        <tr key={name}>
                          <td>{titleCase(name)}</td>
                          <td><SuppressedValue value={isHistogram(v) ? v.count : v} /></td>
                          <td>{isHistogram(v) ? (v.mean === null ? <span className="muted">— (too few samples)</span> : v.mean.toLocaleString()) : "—"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </section>
          </>
        );
      }}
    </AsyncState>
  );
}

interface Bucket { t: number; value: number | "<10" | null; mean: number | null; present: boolean }

function buildBuckets(series: Series, start: number, step: number, count: number, plot: "count" | "mean"): Bucket[] {
  const byTime = new Map<number, Series["points"][number]>();
  for (const p of series.points) byTime.set(Math.floor(Date.parse(p.t) / step) * step, p);
  const out: Bucket[] = [];
  for (let i = 0; i < count; i++) {
    const t = start + i * step;
    const p = byTime.get(t);
    const raw = series.kind === "histogram" ? (plot === "mean" ? p?.mean ?? null : p?.count ?? null) : p?.value ?? null;
    out.push({ t, value: raw ?? null, mean: p?.mean ?? null, present: Boolean(p) });
  }
  return out;
}

function BarChart({ buckets, label, resolution }: { buckets: Bucket[]; label: string; resolution: Resolution }) {
  const W = 1000, H = 200;
  const numeric = buckets.map((b) => (typeof b.value === "number" ? b.value : b.value === "<10" ? 9 : 0));
  const max = Math.max(10, ...numeric);
  const slot = W / buckets.length;
  const barW = Math.max(0.6, slot - (buckets.length > 200 ? 0.2 : 2));
  const fmt = (t: number) => resolution === "day"
    ? new Date(t).toLocaleDateString(undefined, { dateStyle: "medium" })
    : new Date(t).toLocaleString(undefined, { dateStyle: "short", timeStyle: "short" });
  const present = buckets.filter((b) => b.present).length;
  return (
    <figure style={{ margin: 0 }}>
      <svg className="chart" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" role="img"
        aria-label={`${label}: ${present} of ${buckets.length} intervals have data; maximum ${max.toLocaleString()}. See the data table below.`}>
        {buckets.map((b, i) => {
          const x = i * slot + (slot - barW) / 2;
          if (b.value === null) {
            return <rect key={b.t} className="gap" x={x} y={H - 2} width={barW} height={2}><title>{fmt(b.t)}: no data</title></rect>;
          }
          if (b.value === "<10") {
            const h = Math.max(2, (9 / max) * (H - 4));
            return <rect key={b.t} className="bar-suppressed" x={x} y={H - h} width={barW} height={h} vectorEffect="non-scaling-stroke"><title>{fmt(b.t)}: &lt;10 (suppressed)</title></rect>;
          }
          const h = Math.max(b.value > 0 ? 2 : 0, (b.value / max) * (H - 4));
          return <rect key={b.t} className="bar" x={x} y={H - h} width={barW} height={h} rx={barW > 6 ? 2 : 0}><title>{fmt(b.t)}: {b.value.toLocaleString()}</title></rect>;
        })}
        <line className="axis" x1={0} y1={H - 0.5} x2={W} y2={H - 0.5} vectorEffect="non-scaling-stroke" />
      </svg>
      <figcaption className="row-between small muted">
        <span>{fmt(buckets[0].t)}</span>
        <span>max {max.toLocaleString()}</span>
        <span>{fmt(buckets[buckets.length - 1].t)}</span>
      </figcaption>
      <div className="chart-legend" aria-hidden="true">
        <span><span className="swatch swatch-bar" />Value</span>
        <span><span className="swatch swatch-suppressed" />&lt;10, suppressed (drawn at 9)</span>
        <span><span className="swatch swatch-gap" />No data recorded</span>
      </div>
    </figure>
  );
}

function SeriesViewer() {
  const { client } = useStaff();
  const catalog = useApi((c) => c.get<{ metrics: MetricInfo[] }>(`${API}/analytics/catalog`), []);
  const [metric, setMetric] = useState("");
  const [resolution, setResolution] = useState<Resolution>("hour");
  const [plot, setPlot] = useState<"count" | "mean">("count");
  const [loaded, setLoaded] = useState<{ series: Series; start: number; step: number; count: number } | null>(null);
  const load = useAction();

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const r = RESOLUTIONS.find((x) => x.id === resolution)!;
    const end = Math.floor(Date.now() / r.step) * r.step + r.step;
    const start = end - r.span;
    const series = await load.run(() => client.get<Series>(`${API}/analytics/series`, {
      metric_id: metric, resolution, start: new Date(start).toISOString(), end: new Date(end).toISOString() }));
    if (series) setLoaded({ series, start, step: r.step, count: Math.round(r.span / r.step) });
  };

  const buckets = useMemo(() => (loaded ? buildBuckets(loaded.series, loaded.start, loaded.step, loaded.count, plot) : []),
    [loaded, plot]);

  return (
    <section className="card section" aria-labelledby="series-h">
      <h2 id="series-h">Metric over time</h2>
      <AsyncState state={catalog} label="Loading metric catalog…">
        {(cat) => (
          <form className="filters" onSubmit={submit} aria-label="Series options">
            <Select label="Metric" placeholder="Choose a metric…" value={metric} onChange={(e) => setMetric(e.target.value)}
              options={cat.metrics.map((m) => ({ id: String(m.id), label: `${titleCase(m.name)} (${m.kind})` }))} />
            <Select label="Resolution" value={resolution} onChange={(e) => setResolution(e.target.value as Resolution)}
              options={RESOLUTIONS} />
            <div className="form-actions">
              <Button type="submit" busy={load.busy} disabled={!metric}>Show series</Button>
            </div>
          </form>
        )}
      </AsyncState>
      <ErrorNotice error={load.error} />
      {loaded ? (
        <>
          <h3>{titleCase(loaded.series.name)} <span className="small muted">({loaded.series.kind}, per {loaded.series.resolution})</span></h3>
          {loaded.series.kind === "histogram" ? (
            <Select label="Plot" value={plot} onChange={(e) => setPlot(e.target.value as "count" | "mean")}
              options={[{ id: "count", label: "Sample count" }, { id: "mean", label: "Mean value" }]} />
          ) : null}
          <p className="small muted">{loaded.series.suppression} Gaps are intervals with no recorded data. The most recent interval may be incomplete.</p>
          {loaded.series.points.length === 0 ? (
            <EmptyState title="No data in this period.">Nothing was recorded for this metric in the selected range.</EmptyState>
          ) : (
            <>
              <BarChart buckets={buckets} label={titleCase(loaded.series.name)} resolution={loaded.series.resolution} />
              <details>
                <summary>Data table ({loaded.series.points.length} intervals with data, {loaded.count - loaded.series.points.length} gaps)</summary>
                <div className="table-wrap">
                  <table className="table">
                    <caption className="sr-only">{titleCase(loaded.series.name)} values</caption>
                    <thead>
                      <tr>
                        <th scope="col">Interval start</th>
                        {loaded.series.kind === "histogram"
                          ? <><th scope="col">Samples</th><th scope="col">Mean</th></>
                          : <th scope="col">Value</th>}
                      </tr>
                    </thead>
                    <tbody>
                      {loaded.series.points.map((p) => (
                        <tr key={p.t}>
                          <td>{formatDateTime(p.t)}</td>
                          {loaded.series.kind === "histogram"
                            ? <><td><SuppressedValue value={p.count} /></td><td>{p.mean ?? <span className="muted">—</span>}</td></>
                            : <td><SuppressedValue value={p.value} /></td>}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </details>
            </>
          )}
        </>
      ) : null}
    </section>
  );
}

export default function AnalyticsPage() {
  return (
    <div className="container page">
      <PageTitle title="Analytics">Aggregate, privacy-preserving counts only. There is no per-person data here.</PageTitle>
      <RequireGrant permission="analytics.read">
        <Notice kind="info">Small historical counts (below 10) are suppressed and shown as &lt;10.</Notice>
        <Summary />
        <SeriesViewer />
      </RequireGrant>
    </div>
  );
}
