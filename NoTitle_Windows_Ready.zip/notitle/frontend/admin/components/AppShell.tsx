"use client";

import { Button, Loading } from "@notitle/shared";
import Link from "next/link";
import { usePathname } from "next/navigation";
import type { ReactNode } from "react";
import { API, NAV } from "./constants";
import { ErrorNotice } from "./Feedback";
import { useAction } from "./hooks";
import { SignIn } from "./SignIn";
import { useStaff } from "./StaffContext";

function normalise(path: string | null): string {
  if (!path) return "/";
  return path.endsWith("/") ? path : `${path}/`;
}

export function AppShell({ children }: { children: ReactNode }) {
  const { client, phase, bootError, staff, environment, can, refresh, setStaff, announce } = useStaff();
  const pathname = normalise(usePathname());
  const signOut = useAction();

  const doSignOut = async () => {
    await signOut.run(() => client.post(`${API}/auth/logout`));
    // Even if the request failed, re-check: the server is the source of truth.
    setStaff(null);
    announce("Signed out.");
    void refresh();
  };

  const links = staff ? NAV.filter((n) => can(n.permission)) : [];

  return (
    <>
      <header className="site-header">
        <div className="container header-inner">
          <Link href="/" className="brand">NoTitle <span>Staff</span></Link>
          {environment && environment !== "production" ? (
            <span className="badge badge-warning" title="Runtime environment">{environment}</span>
          ) : null}
          {staff ? (
            <nav className="nav" aria-label="Staff sections">
              {links.map((n) => {
                const current = pathname === n.href || pathname.startsWith(n.href);
                return (
                  <Link key={n.href} href={n.href} aria-current={current ? "page" : undefined}>{n.label}</Link>
                );
              })}
            </nav>
          ) : null}
          {staff ? (
            <div className="row header-user">
              <span className="small">Signed in as <strong>{staff.username}</strong></span>
              <Button variant="secondary" type="button" onClick={doSignOut} busy={signOut.busy}>Sign out</Button>
            </div>
          ) : null}
        </div>
      </header>
      <main id="main" tabIndex={-1}>
        {phase === "loading" ? (
          <div className="container page"><Loading label="Checking your staff session…" /></div>
        ) : phase === "error" ? (
          <div className="container page">
            <h1>Staff console unavailable</h1>
            <ErrorNotice error={bootError} onRetry={() => void refresh()} />
          </div>
        ) : staff ? (
          children
        ) : (
          <SignIn />
        )}
      </main>
    </>
  );
}
