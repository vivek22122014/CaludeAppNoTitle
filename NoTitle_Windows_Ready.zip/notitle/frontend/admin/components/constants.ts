/** Allowlists mirrored from the backend so filters and selects only offer accepted values. */

export const API = "/internal/v1";

export type Option = { id: string; label: string };

export const PURPOSES: Option[] = [
  { id: "case_handling", label: "Case handling" },
  { id: "safety_review", label: "Safety review" },
  { id: "billing_review", label: "Billing review" },
  { id: "privacy_request", label: "Privacy request" },
  { id: "legal_obligation", label: "Legal obligation" },
  { id: "appeal_review", label: "Appeal review" },
];

export const CASE_STATUSES: Option[] = [
  { id: "open", label: "Open" },
  { id: "in_progress", label: "In progress" },
  { id: "waiting_user", label: "Waiting for user" },
  { id: "resolved", label: "Resolved" },
  { id: "closed", label: "Closed" },
];

export const CASE_CATEGORIES: Option[] = [
  { id: "general", label: "General" },
  { id: "payment", label: "Payment" },
  { id: "safety", label: "Safety" },
  { id: "privacy", label: "Privacy" },
  { id: "appeal", label: "Appeal" },
  { id: "security", label: "Security" },
];

export const ASSIGNED_FILTERS: Option[] = [
  { id: "", label: "Everyone" },
  { id: "me", label: "Assigned to me" },
  { id: "unassigned", label: "Unassigned" },
];

export const DECISION_ACTIONS: Option[] = [
  { id: "dismiss", label: "Dismiss (no restriction)" },
  { id: "warn", label: "Warn (safety notice, no restriction)" },
  { id: "suspend", label: "Suspend (time-limited matching restriction)" },
  { id: "ban", label: "Ban (indefinite, appealable)" },
];

export const APPEAL_OUTCOMES: Option[] = [
  { id: "upheld", label: "Upheld (decision stays)" },
  { id: "overturned", label: "Overturned (restriction lifted)" },
];

export const PURCHASE_STATES: Option[] = [
  { id: "pending", label: "Pending" },
  { id: "paid", label: "Paid" },
  { id: "failed", label: "Failed" },
  { id: "needs_review", label: "Needs review" },
];

export const REMEDY_BASES: Option[] = [
  { id: "payment_error", label: "Payment error (duplicate / wrong amount / failed delivery)" },
  { id: "statutory_remedy", label: "Statutory remedy required by law" },
  { id: "provider_bank_direction", label: "Payment provider or bank direction" },
];

export const PRIVACY_STATUSES: Option[] = [
  { id: "in_review", label: "In review" },
  { id: "completed", label: "Completed" },
  { id: "rejected", label: "Rejected" },
];

export const HOLD_SCOPES: Option[] = [
  { id: "account_profile", label: "Account profile" },
  { id: "support_cases", label: "Support cases" },
  { id: "safety_reports", label: "Safety reports" },
  { id: "financial", label: "Financial records" },
  { id: "all", label: "All scopes" },
];

export const NAV: { href: string; label: string; permission: string }[] = [
  { href: "/cases/", label: "Cases", permission: "cases.queue" },
  { href: "/reports/", label: "Reports", permission: "reports.read" },
  { href: "/privacy/", label: "Privacy", permission: "privacy.manage" },
  { href: "/billing/", label: "Billing", permission: "billing.read" },
  { href: "/analytics/", label: "Analytics", permission: "analytics.read" },
  { href: "/audit/", label: "Audit", permission: "audit.read" },
  { href: "/settings/", label: "Staff", permission: "staff.manage" },
  { href: "/release/", label: "Health", permission: "release.read" },
];
