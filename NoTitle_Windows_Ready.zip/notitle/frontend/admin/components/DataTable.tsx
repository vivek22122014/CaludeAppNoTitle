"use client";

import { EmptyState } from "@notitle/shared";
import type { ReactNode } from "react";

export interface Column<T> {
  key: string;
  header: ReactNode;
  render: (row: T) => ReactNode;
  className?: string;
}

/** Accessible table: caption, column-scoped headers, horizontal scroll on small screens. */
export function DataTable<T>({ caption, columns, rows, rowKey, empty = "Nothing to show.", emptyHint, rowClass }: {
  caption: ReactNode;
  columns: Column<T>[];
  rows: T[];
  rowKey: (row: T) => string;
  empty?: string;
  emptyHint?: ReactNode;
  rowClass?: (row: T) => string | undefined;
}) {
  if (!rows.length) return <EmptyState title={empty}>{emptyHint}</EmptyState>;
  return (
    <div className="table-wrap" tabIndex={0} role="region" aria-label={typeof caption === "string" ? caption : undefined}>
      <table className="table">
        <caption className="sr-only">{caption}</caption>
        <thead>
          <tr>{columns.map((c) => <th key={c.key} scope="col" className={c.className}>{c.header}</th>)}</tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={rowKey(row)} className={rowClass?.(row)}>
              {columns.map((c) => <td key={c.key} className={c.className}>{c.render(row)}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
