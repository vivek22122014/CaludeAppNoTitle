"use client";

/**
 * Staff session context: one ApiClient for the whole app, the bootstrap staff
 * identity (or null when signed out), and helpers every page uses.
 *
 * Nothing is persisted in browser storage; the session is an HttpOnly cookie
 * and this context is rebuilt from GET /internal/v1/bootstrap on every load.
 */

import { ApiClient, ApiError } from "@notitle/shared";
import {
  createContext, type ReactNode, useCallback, useContext, useEffect, useMemo, useRef, useState,
} from "react";
import { API } from "./constants";
import type { Bootstrap, StaffInfo } from "./types";

type Phase = "loading" | "ready" | "error";

export interface StaffContextValue {
  client: ApiClient;
  phase: Phase;
  bootError: unknown;
  staff: StaffInfo | null;
  environment: string | null;
  /** Re-run bootstrap (e.g. after a 401). Signed-out results show the sign-in screen. */
  refresh: () => Promise<void>;
  /** Replace the staff identity after sign-in, step-up or sign-out. */
  setStaff: (staff: StaffInfo | null) => void;
  can: (permission: string) => boolean;
  /** Call with any caught error: an expired session triggers refresh (→ sign-in screen). */
  handleError: (err: unknown) => void;
  /** Announce a short message to assistive technology via a polite live region. */
  announce: (message: string) => void;
}

const StaffContext = createContext<StaffContextValue | null>(null);

export function StaffProvider({ children }: { children: ReactNode }) {
  const [client] = useState(() => new ApiClient({ bootstrapPath: `${API}/bootstrap` }));
  const [phase, setPhase] = useState<Phase>("loading");
  const [bootError, setBootError] = useState<unknown>(null);
  const [staff, setStaffState] = useState<StaffInfo | null>(null);
  const [environment, setEnvironment] = useState<string | null>(null);
  const [liveMessage, setLiveMessage] = useState("");
  const refreshing = useRef<Promise<void> | null>(null);

  const refresh = useCallback(async () => {
    if (refreshing.current) return refreshing.current;
    const run = (async () => {
      try {
        const data = await client.bootstrap<Bootstrap>();
        setStaffState((prev) => {
          if ((prev?.username ?? null) !== (data.staff?.username ?? null)) client.generation += 1;
          return data.staff;
        });
        setEnvironment(data.environment);
        setBootError(null);
        setPhase("ready");
      } catch (err) {
        setBootError(err);
        setPhase("error");
      }
    })();
    refreshing.current = run.finally(() => { refreshing.current = null; });
    return refreshing.current;
  }, [client]);

  useEffect(() => { void refresh(); }, [refresh]);

  const setStaff = useCallback((next: StaffInfo | null) => {
    setStaffState((prev) => {
      if ((prev?.username ?? null) !== (next?.username ?? null)) client.generation += 1;
      return next;
    });
  }, [client]);

  const handleError = useCallback((err: unknown) => {
    if (err instanceof ApiError && err.status === 401 && err.code === "unauthenticated") void refresh();
  }, [refresh]);

  const announce = useCallback((message: string) => {
    // Clear first so repeating the same message is announced again.
    setLiveMessage("");
    setTimeout(() => setLiveMessage(message), 50);
  }, []);

  const value = useMemo<StaffContextValue>(() => ({
    client, phase, bootError, staff, environment, refresh, setStaff,
    can: (permission: string) => Boolean(staff?.permissions.includes(permission)),
    handleError, announce,
  }), [client, phase, bootError, staff, environment, refresh, setStaff, handleError, announce]);

  return (
    <StaffContext.Provider value={value}>
      {children}
      <div className="sr-only" aria-live="polite" aria-atomic="true">{liveMessage}</div>
    </StaffContext.Provider>
  );
}

export function useStaff(): StaffContextValue {
  const ctx = useContext(StaffContext);
  if (!ctx) throw new Error("useStaff must be used inside <StaffProvider>");
  return ctx;
}
