"use client";

/**
 * Second step of a sensitive action: shows the server-signed preview summary and
 * asks for a fresh authenticator code before calling the confirm endpoint with
 * {nonce, totp}.  Previews expire after two minutes and are consumed once.
 */

import { ApiError, Button, Dialog, formatDateTime, Notice, titleCase } from "@notitle/shared";
import { type FormEvent, type ReactNode, useEffect, useState } from "react";
import { ErrorNotice, Facts, TotpField } from "./Feedback";
import { useStaff } from "./StaffContext";
import type { Preview, SummaryValue } from "./types";

function defaultValue(v: SummaryValue): ReactNode {
  if (v === null || v === undefined || v === "") return "—";
  if (typeof v === "boolean") return v ? "Yes" : "No";
  if (typeof v === "object") return <code>{JSON.stringify(v)}</code>;
  return String(v);
}

export function PreviewConfirmDialog<R>({ preview, title, confirmPath, confirmLabel = "Confirm", danger = false,
  format = {}, onClose, onDone }: {
  preview: Preview | null;
  title: string;
  confirmPath: string;
  confirmLabel?: string;
  danger?: boolean;
  format?: Record<string, (v: SummaryValue) => ReactNode>;
  onClose: () => void;
  onDone: (result: R) => void;
}) {
  const { client, handleError } = useStaff();
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    setCode("");
    setError(null);
    if (!preview) return;
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, [preview]);

  if (!preview) return null;
  const msLeft = new Date(preview.expires_at).getTime() - now;
  const expired = msLeft <= 0 || (error instanceof ApiError && (error.status === 410 || error.code === "preview_consumed"));

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (busy || expired) return;
    setBusy(true);
    setError(null);
    try {
      const result = await client.post<R>(confirmPath, { nonce: preview.nonce, totp: code });
      onDone(result);
    } catch (err) {
      setError(err);
      handleError(err);
      setCode("");
    } finally {
      setBusy(false);
    }
  };

  const mfaError = error instanceof ApiError && error.code === "invalid_mfa" ? error.message : undefined;

  return (
    <Dialog open title={title} onClose={() => { if (!busy) onClose(); }}>
      <form onSubmit={submit} noValidate>
        <p>Review exactly what will happen. Nothing has changed yet.</p>
        <Facts items={[
          ["Object", <code key="o">{preview.object_ref}</code>],
          ...Object.entries(preview.summary).map(([k, v]): [ReactNode, ReactNode] =>
            [titleCase(k), (format[k] ?? defaultValue)(v)]),
        ]} />
        {expired ? (
          <Notice kind="warning" title="This preview is no longer valid">
            Close this dialog and create a new preview. Nothing was changed.
          </Notice>
        ) : (
          <p className="small muted">
            Preview expires at {formatDateTime(preview.expires_at)} ({Math.max(0, Math.ceil(msLeft / 1000))} s left).
          </p>
        )}
        {error && !mfaError && !expired ? <ErrorNotice error={error} /> : null}
        {!expired ? <TotpField value={code} onChange={setCode} error={mfaError} /> : null}
        <div className="form-actions">
          {!expired ? (
            <Button type="submit" variant={danger ? "danger" : "primary"} busy={busy} disabled={code.length !== 6}>
              {confirmLabel}
            </Button>
          ) : null}
          <Button type="button" variant="secondary" onClick={onClose} disabled={busy}>
            {expired ? "Close" : "Cancel"}
          </Button>
        </div>
      </form>
    </Dialog>
  );
}
