"use client";

/**
 * Fresh-MFA helper.  Wrap an action with `withFreshMfa(fn)`: if the server answers
 * 403 mfa_required, a dialog asks for an authenticator code, calls
 * POST /auth/step-up and then retries the action exactly once.
 */

import { ApiError, Button, Dialog, errorMessage, Notice } from "@notitle/shared";
import { type FormEvent, type ReactNode, useCallback, useRef, useState } from "react";
import { API } from "./constants";
import { TotpField } from "./Feedback";
import { useStaff } from "./StaffContext";
import type { StaffInfo } from "./types";

interface Pending {
  fn: () => Promise<unknown>;
  resolve: (v: unknown) => void;
  reject: (e: unknown) => void;
}

export function cancelledError(): ApiError {
  return new ApiError(0, "cancelled", "Cancelled. The action was not performed.");
}

export function useStepUp(): { withFreshMfa: <T>(fn: () => Promise<T>) => Promise<T>; stepUpDialog: ReactNode } {
  const { client, setStaff, handleError } = useStaff();
  const pending = useRef<Pending | null>(null);
  const [open, setOpen] = useState(false);
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);

  const withFreshMfa = useCallback(async <T,>(fn: () => Promise<T>): Promise<T> => {
    try {
      return await fn();
    } catch (err) {
      if (err instanceof ApiError && err.status === 403 && err.code === "mfa_required") {
        return new Promise<T>((resolve, reject) => {
          pending.current = { fn, resolve: resolve as (v: unknown) => void, reject };
          setCode("");
          setError(null);
          setOpen(true);
        });
      }
      throw err;
    }
  }, []);

  const cancel = useCallback(() => {
    if (busy) return;
    pending.current?.reject(cancelledError());
    pending.current = null;
    setOpen(false);
  }, [busy]);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const job = pending.current;
    if (!job || busy) return;
    setBusy(true);
    setError(null);
    try {
      const fresh = await client.post<StaffInfo>(`${API}/auth/step-up`, { totp: code });
      setStaff(fresh);
    } catch (err) {
      setBusy(false);
      handleError(err);
      if (err instanceof ApiError && err.status === 401 && err.code === "unauthenticated") {
        job.reject(err);
        pending.current = null;
        setOpen(false);
        return;
      }
      setError(err);
      return;
    }
    // Code accepted: retry the original action once and hand its outcome back to the caller.
    pending.current = null;
    setOpen(false);
    setBusy(false);
    try {
      job.resolve(await job.fn());
    } catch (err) {
      job.reject(err);
    }
  };

  const stepUpDialog = (
    <Dialog open={open} title="Confirm it's you" onClose={cancel}>
      <form onSubmit={submit} noValidate>
        <p>This action needs a fresh authenticator check (valid for 5 minutes).</p>
        {error ? <Notice kind="error">{errorMessage(error)}</Notice> : null}
        <TotpField value={code} onChange={setCode}
          error={error instanceof ApiError && error.code === "invalid_mfa" ? error.message : undefined} />
        <div className="form-actions">
          <Button type="submit" busy={busy} disabled={code.length !== 6}>Confirm and continue</Button>
          <Button type="button" variant="secondary" onClick={cancel} disabled={busy}>Cancel</Button>
        </div>
      </form>
    </Dialog>
  );

  return { withFreshMfa, stepUpDialog };
}
