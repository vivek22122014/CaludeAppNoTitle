"use client";

import { Button, Field, Notice } from "@notitle/shared";
import { type FormEvent, useEffect, useRef, useState } from "react";
import { API } from "./constants";
import { ErrorNotice, TotpField } from "./Feedback";
import { fieldErrors, useAction } from "./hooks";
import { useStaff } from "./StaffContext";
import type { LoginResult } from "./types";

export function SessionRules() {
  return (
    <ul className="small muted session-rules">
      <li>A staff session ends after 15 minutes without activity, and always after 4 hours.</li>
      <li>Sensitive actions (decisions, refunds, legal holds, staff changes) ask for a fresh authenticator code.</li>
      <li>Reading case messages, notes or report evidence is audited with the purpose you choose.</li>
    </ul>
  );
}

export function SignIn() {
  const { client, setStaff, announce } = useStaff();
  const [mode, setMode] = useState<"totp" | "recovery">("totp");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [totp, setTotp] = useState("");
  const [recovery, setRecovery] = useState("");
  const [note, setNote] = useState<string | null>(null);
  const { busy, error, run, reset } = useAction();
  const heading = useRef<HTMLHeadingElement>(null);

  useEffect(() => { heading.current?.focus(); }, []);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const result = await run(() => mode === "totp"
      ? client.post<LoginResult>(`${API}/auth/login`, { username: username.trim(), password, totp })
      : client.post<LoginResult>(`${API}/auth/recovery`, { username: username.trim(), password, recovery_code: recovery.trim() }));
    setPassword("");
    setTotp("");
    setRecovery("");
    if (result) {
      if (result.note) setNote(result.note);
      announce(`Signed in as ${result.staff.username}.`);
      setStaff(result.staff);
    }
  };

  const fields = fieldErrors(error);

  return (
    <div className="container narrow page">
      <div className="card signin">
        <h1 ref={heading} tabIndex={-1}>Staff sign-in</h1>
        <p className="muted">Private NoTitle staff console. Access is limited to authorised staff and is logged.</p>
        {note ? <Notice kind="warning">{note}</Notice> : null}
        <ErrorNotice error={error} />
        <form onSubmit={submit} noValidate>
          <Field label="Username" autoComplete="username" value={username} required
            onChange={(e) => setUsername(e.target.value)} error={fields.username} autoCapitalize="none" spellCheck={false} />
          <Field label="Password" type="password" autoComplete="current-password" value={password} required
            onChange={(e) => setPassword(e.target.value)} error={fields.password} />
          {mode === "totp" ? (
            <TotpField value={totp} onChange={setTotp} error={fields.totp} />
          ) : (
            <Field label="Recovery code" autoComplete="off" value={recovery} required spellCheck={false}
              hint="One of the recovery codes you received when your account was created. Each works once."
              onChange={(e) => setRecovery(e.target.value)} error={fields.recovery_code} />
          )}
          <div className="form-actions">
            <Button type="submit" busy={busy}
              disabled={!username || !password || (mode === "totp" ? totp.length !== 6 : !recovery.trim())}>
              Sign in
            </Button>
            <Button type="button" variant="ghost" onClick={() => { reset(); setMode(mode === "totp" ? "recovery" : "totp"); }}>
              {mode === "totp" ? "Use a recovery code instead" : "Use my authenticator app"}
            </Button>
          </div>
        </form>
        <hr className="divider" />
        <SessionRules />
      </div>
    </div>
  );
}
