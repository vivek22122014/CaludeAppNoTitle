"use client";

import { type ApiClient, ApiError, useAsync } from "@notitle/shared";
import { useCallback, useEffect, useRef, useState } from "react";
import { useStaff } from "./StaffContext";

/** useAsync bound to the staff client; an expired session sends the user to sign-in. */
export function useApi<T>(fn: (client: ApiClient) => Promise<T>, deps: unknown[]) {
  const { client, handleError } = useStaff();
  const state = useAsync(() => fn(client), [client, ...deps]);
  useEffect(() => { if (state.error) handleError(state.error); }, [state.error, handleError]);
  return state;
}

/** Busy/error state for one mutation. `run` never throws; it returns undefined on failure. */
export function useAction() {
  const { handleError } = useStaff();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const inFlight = useRef(false);

  const run = useCallback(async <T,>(fn: () => Promise<T>): Promise<T | undefined> => {
    if (inFlight.current) return undefined;
    inFlight.current = true;
    setBusy(true);
    setError(null);
    try {
      return await fn();
    } catch (err) {
      setError(err);
      handleError(err);
      return undefined;
    } finally {
      inFlight.current = false;
      setBusy(false);
    }
  }, [handleError]);

  const reset = useCallback(() => setError(null), []);
  return { busy, error, run, reset, setError };
}

export function isApiError(err: unknown, status?: number, code?: string): err is ApiError {
  return err instanceof ApiError && (status === undefined || err.status === status)
    && (code === undefined || err.code === code);
}

/** Per-field messages from a 422 response (empty object otherwise). */
export function fieldErrors(err: unknown): Record<string, string> {
  return err instanceof ApiError && err.status === 422 ? err.fields : {};
}
