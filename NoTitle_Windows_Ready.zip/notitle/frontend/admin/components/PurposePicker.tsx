"use client";

import { Select } from "@notitle/shared";
import { PURPOSES } from "./constants";

/** Required purpose for audited content reads. */
export function PurposePicker({ value, onChange, id }: { value: string; onChange: (v: string) => void; id?: string }) {
  return (
    <Select
      id={id}
      label="Purpose of this read"
      hint="Every content read is recorded in the access audit log with your username and this purpose. Read only what you need."
      placeholder="Choose a purpose…"
      options={PURPOSES}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      required
    />
  );
}
