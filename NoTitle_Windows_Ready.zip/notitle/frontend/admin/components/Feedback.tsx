"use client";

import { ApiError, Button, errorMessage, Field, Loading, Notice } from "@notitle/shared";
import type { ReactNode } from "react";
import { useStaff } from "./StaffContext";

export const FORBIDDEN_TEXT = "Your role does not include this.";

/** Consistent rendering of a failed request: 403, 401, 409, 410, 422 and everything else. */
export function ErrorNotice({ error, onRetry, title }: { error: unknown; onRetry?: () => void; title?: string }) {
  if (!error) return null;
  if (error instanceof ApiError) {
    if (error.status === 403 && error.code === "forbidden") {
      // Grant-denied keeps the server's explanation when it is more specific (e.g. independent appeal reviewer).
      const generic = /does not include this permission|do not have access/i.test(error.message);
      return (
        <Notice kind="warning" title={FORBIDDEN_TEXT}>
          {generic ? "Ask an owner if you need this permission." : error.message}
        </Notice>
      );
    }
    if (error.status === 401 && error.code === "unauthenticated") {
      return <Notice kind="warning" title="Your staff session ended">Sign in again to continue.</Notice>;
    }
    if (error.code === "cancelled") {
      return <Notice kind="info">{error.message}</Notice>;
    }
  }
  const ref = error instanceof ApiError && error.requestId ? error.requestId : null;
  return (
    <Notice kind="error" title={title}>
      <p style={{ margin: 0 }}>{errorMessage(error)}</p>
      {ref ? <p className="small" style={{ margin: "4px 0 0" }}>Request ID: <code>{ref}</code></p> : null}
      {onRetry ? (
        <div className="row" style={{ marginTop: 8 }}>
          <Button variant="secondary" type="button" onClick={onRetry}>Try again</Button>
        </div>
      ) : null}
    </Notice>
  );
}

/** Loading / error / content switch for a useApi state. */
export function AsyncState<T>({ state, label, children }: {
  state: { data: T | null; error: unknown; loading: boolean; reload: () => void };
  label?: string;
  children: (data: T) => ReactNode;
}) {
  if (state.error && !state.loading) return <ErrorNotice error={state.error} onRetry={state.reload} />;
  if (state.data === null) return state.loading ? <Loading label={label} /> : null;
  return (
    <>
      {state.loading ? <Loading label="Refreshing…" /> : null}
      {children(state.data)}
    </>
  );
}

/** Render children only when the signed-in staff member holds `permission`. */
export function RequireGrant({ permission, children }: { permission: string; children: ReactNode }) {
  const { can } = useStaff();
  if (!can(permission)) {
    return (
      <Notice kind="warning" title={FORBIDDEN_TEXT}>
        This page needs the <code>{permission}</code> permission. Ask an owner if you need access.
      </Notice>
    );
  }
  return <>{children}</>;
}

export function TotpField({ value, onChange, error, id, label = "Authenticator code" }: {
  value: string; onChange: (v: string) => void; error?: string; id?: string; label?: string;
}) {
  return (
    <Field
      id={id}
      label={label}
      hint="The current 6-digit code from your authenticator app. Each code works once."
      value={value}
      onChange={(e) => onChange(e.target.value.replace(/\D/g, "").slice(0, 6))}
      inputMode="numeric"
      autoComplete="one-time-code"
      pattern="[0-9]{6}"
      maxLength={6}
      required
      error={error}
      className="totp-field"
    />
  );
}

export function StatusBadge({ value }: { value: string | null | undefined }) {
  if (!value) return <span className="badge">—</span>;
  const kind = ({
    open: "primary", in_progress: "primary", waiting_user: "warning", resolved: "success", closed: "",
    paid: "success", failed: "danger", pending: "warning", needs_review: "danger", created: "",
    succeeded: "success", submitting: "warning", held: "warning", cancelled: "",
    completed: "success", rejected: "", received: "primary", in_review: "warning",
    active: "primary", released: "", overdue: "danger", acknowledged: "primary",
    upheld: "", overturned: "warning", disabled: "danger",
  } as Record<string, string>)[value] ?? "";
  return <span className={`badge ${kind ? `badge-${kind}` : ""}`}>{value.replace(/_/g, " ")}</span>;
}

/** Definition list for summary facts. */
export function Facts({ items }: { items: [ReactNode, ReactNode][] }) {
  return (
    <dl className="facts">
      {items.map(([k, v], i) => (
        <div key={i} className="fact">
          <dt>{k}</dt>
          <dd>{v ?? "—"}</dd>
        </div>
      ))}
    </dl>
  );
}

export function PageTitle({ title, children }: { title: string; children?: ReactNode }) {
  return (
    <div className="page-title">
      <h1>{title}</h1>
      {children ? <div className="muted">{children}</div> : null}
    </div>
  );
}
