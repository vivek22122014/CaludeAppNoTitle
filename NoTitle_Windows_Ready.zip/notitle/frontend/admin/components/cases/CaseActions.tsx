"use client";

import { ApiError, Button, Field, formatDateTime, Notice, Select, titleCase } from "@notitle/shared";
import { type FormEvent, useState } from "react";
import { API, CASE_STATUSES } from "../constants";
import { DataTable } from "../DataTable";
import { ErrorNotice, StatusBadge } from "../Feedback";
import { fieldErrors, isApiError, useAction } from "../hooks";
import { useStaff } from "../StaffContext";
import type { CaseSummary, Obligation } from "../types";

type Done = (message: string) => void;

/** Wrap a versioned write: on 409 the shown version is stale, so reload the summary. */
function useVersionedAction(reload: () => void) {
  const action = useAction();
  const run = <T,>(fn: () => Promise<T>) => action.run(async () => {
    try {
      return await fn();
    } catch (err) {
      if (isApiError(err, 409)) reload();
      throw err;
    }
  });
  return { ...action, run };
}

function ConflictNotice({ error }: { error: unknown }) {
  if (!(error instanceof ApiError) || error.status !== 409) return <ErrorNotice error={error} />;
  if (error.code === "obligations_open") {
    return (
      <Notice kind="warning" title="Case cannot be closed yet">
        {error.message} Every legal obligation listed below must be completed (with an outcome and evidence reference)
        before the case is closed. You can mark it resolved instead.
      </Notice>
    );
  }
  const who = typeof error.details.assigned_to === "string" ? error.details.assigned_to : null;
  return (
    <Notice kind="warning" title="This case changed while you were viewing it">
      {error.message}{who ? ` It is now assigned to ${who}.` : ""} The latest version has been reloaded; review it and try again.
    </Notice>
  );
}

export function ClaimButton({ summary, reload, onDone }: { summary: CaseSummary; reload: () => void; onDone: Done }) {
  const { client, can } = useStaff();
  const action = useVersionedAction(reload);
  if (!can("cases.claim") || summary.assigned_to) return null;
  const claim = async () => {
    const res = await action.run(() => client.post<{ version: number }>(
      `${API}/cases/${encodeURIComponent(summary.case_ref)}/claim`, { expected_version: summary.version }));
    if (res) { onDone("Case claimed. It is now assigned to you."); reload(); }
  };
  return (
    <div>
      <ConflictNotice error={action.error} />
      <Button type="button" onClick={claim} busy={action.busy}>Claim this case</Button>
    </div>
  );
}

export function AssignForm({ summary, reload, onDone }: { summary: CaseSummary; reload: () => void; onDone: Done }) {
  const { client, can } = useStaff();
  const [username, setUsername] = useState("");
  const [reason, setReason] = useState("");
  const action = useVersionedAction(reload);
  if (!can("cases.assign")) return null;
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const target = username.trim() || null;
    const res = await action.run(() => client.post<{ version: number }>(
      `${API}/cases/${encodeURIComponent(summary.case_ref)}/assignment`,
      { expected_version: summary.version, staff_username: target, reason: reason.trim() }));
    if (res) {
      onDone(target ? `Case assigned to ${target}.` : "Case unassigned.");
      setUsername(""); setReason("");
      reload();
    }
  };
  const f = fieldErrors(action.error);
  return (
    <form onSubmit={submit} aria-labelledby="assign-h">
      <h3 id="assign-h">Assign</h3>
      <ConflictNotice error={action.error instanceof ApiError && action.error.status === 422 ? null : action.error} />
      <Field label="Staff username" hint="Leave empty to unassign." value={username} autoCapitalize="none"
        onChange={(e) => setUsername(e.target.value)} error={f.staff_username} />
      <Field label="Reason" value={reason} maxLength={400} required onChange={(e) => setReason(e.target.value)}
        error={f.reason} />
      <Button type="submit" variant="secondary" busy={action.busy} disabled={!reason.trim()}>Save assignment</Button>
    </form>
  );
}

export function StatusForm({ summary, reload, onDone }: { summary: CaseSummary; reload: () => void; onDone: Done }) {
  const { client, can } = useStaff();
  const [target, setTarget] = useState("");
  const [reason, setReason] = useState("");
  const action = useVersionedAction(reload);
  if (!can("cases.manage")) return null;
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const res = await action.run(() => client.post<{ status: string; version: number }>(
      `${API}/cases/${encodeURIComponent(summary.case_ref)}/status`,
      { expected_version: summary.version, target_status: target, reason: reason.trim() }));
    if (res) {
      onDone(`Status changed to ${titleCase(res.status)}.`);
      setTarget(""); setReason("");
      reload();
    }
  };
  const f = fieldErrors(action.error);
  return (
    <form onSubmit={submit} aria-labelledby="status-h">
      <h3 id="status-h">Change status</h3>
      <ConflictNotice error={action.error instanceof ApiError && action.error.status === 422 ? null : action.error} />
      <Select label="New status" placeholder="Choose…" value={target} onChange={(e) => setTarget(e.target.value)}
        options={CASE_STATUSES.filter((s) => s.id !== summary.status)} error={f.target_status}
        hint="Closing requires every legal obligation to be completed first." />
      <Field label="Reason" value={reason} maxLength={400} required onChange={(e) => setReason(e.target.value)}
        error={f.reason} />
      <Button type="submit" variant="secondary" busy={action.busy} disabled={!target || !reason.trim()}>Change status</Button>
    </form>
  );
}

function CompleteObligation({ caseRef, obligation, reload, onDone }: {
  caseRef: string; obligation: Obligation; reload: () => void; onDone: Done;
}) {
  const { client } = useStaff();
  const [outcome, setOutcome] = useState("");
  const [evidence, setEvidence] = useState("");
  const action = useAction();
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const res = await action.run(() => client.post<{ completed: boolean }>(
      `${API}/cases/${encodeURIComponent(caseRef)}/obligations/complete`,
      { obligation_id: obligation.id, outcome: outcome.trim(), evidence_ref: evidence.trim() }));
    if (res) { onDone(`Obligation ${obligation.rule_id} marked completed.`); reload(); }
  };
  const f = fieldErrors(action.error);
  return (
    <form onSubmit={submit} className="inline-form" aria-label={`Complete obligation ${obligation.rule_id}`}>
      <Field label="Outcome" value={outcome} maxLength={400} required onChange={(e) => setOutcome(e.target.value)} error={f.outcome} />
      <Field label="Evidence reference" value={evidence} maxLength={200} required
        hint="Where the proof lives (ticket, letter ref)." onChange={(e) => setEvidence(e.target.value)} error={f.evidence_ref} />
      <div className="form-actions">
        <Button type="submit" variant="secondary" busy={action.busy} disabled={!outcome.trim() || !evidence.trim()}>Complete</Button>
      </div>
      {action.error && !Object.keys(f).length ? <div style={{ flexBasis: "100%" }}><ErrorNotice error={action.error} /></div> : null}
    </form>
  );
}

export function Obligations({ summary, reload, onDone }: { summary: CaseSummary; reload: () => void; onDone: Done }) {
  const { can } = useStaff();
  const legal = can("cases.legal");
  return (
    <>
      <DataTable
        caption="Legal obligations for this case"
        rows={summary.obligations}
        rowKey={(o) => o.id}
        empty="No legal obligations apply to this case."
        columns={[
          { key: "rule", header: "Rule", render: (o) => <><code>{o.rule_id}</code> <span className="small muted">({o.rule_version})</span></> },
          { key: "status", header: "Status", render: (o) => <StatusBadge value={o.status} /> },
          { key: "ack", header: "Acknowledge by", render: (o) => (
            <>{formatDateTime(o.acknowledge_by)}{o.acknowledged_at ? <div className="small muted">Done {formatDateTime(o.acknowledged_at)}</div> : null}</>
          ) },
          { key: "act", header: "Act by", render: (o) => formatDateTime(o.act_by) },
          { key: "outcome", header: "Outcome", render: (o) => (o.status === "completed"
            ? <><p className="plain">{o.outcome ?? "—"}</p><div className="small muted">{formatDateTime(o.completed_at)}</div></>
            : legal ? <CompleteObligation caseRef={summary.case_ref} obligation={o} reload={reload} onDone={onDone} />
              : <span className="muted small">Needs the cases.legal permission to complete.</span>) },
        ]}
      />
    </>
  );
}
