"use client";

import { Button, EmptyState, formatDateTime, TextArea } from "@notitle/shared";
import { type FormEvent, useState } from "react";
import { API } from "../constants";
import { ErrorNotice } from "../Feedback";
import { fieldErrors, useAction } from "../hooks";
import { useStaff } from "../StaffContext";
import type { InternalNote } from "../types";

/** Staff-only notes. Never shown to the user and never part of the public history. */
export function CaseNotes({ caseRef, onDone }: { caseRef: string; onDone: (message: string) => void }) {
  const { client, can } = useStaff();
  const [notes, setNotes] = useState<InternalNote[] | null>(null);
  const [body, setBody] = useState("");
  const load = useAction();
  const add = useAction();
  if (!can("cases.notes")) return null;

  const path = `${API}/cases/${encodeURIComponent(caseRef)}/notes`;
  const loadNotes = async () => {
    const res = await load.run(() => client.get<{ items: InternalNote[] }>(path));
    if (res) setNotes(res.items);
  };
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const res = await add.run(() => client.post<{ note_id: string }>(path, { body }));
    if (res) {
      setBody("");
      onDone("Internal note saved (staff only).");
      if (notes !== null) void loadNotes();
    }
  };
  const f = fieldErrors(add.error);

  return (
    <section className="card notes-zone section" aria-labelledby="notes-h">
      <span className="zone-label zone-private">Staff only · never shown to the user</span>
      <h2 id="notes-h">Internal notes</h2>
      <p className="small">
        Private working notes for staff. They are not part of the conversation and the user cannot see them.
        Loading notes is recorded in the access audit log (purpose: case handling).
      </p>
      <div className="form-actions" style={{ marginBottom: 12 }}>
        <Button type="button" variant="secondary" onClick={loadNotes} busy={load.busy}>
          {notes ? "Reload internal notes" : "Load internal notes"}
        </Button>
      </div>
      <ErrorNotice error={load.error} />
      {notes === null ? null : notes.length === 0 ? (
        <EmptyState title="No internal notes yet." />
      ) : (
        <ol className="thread" aria-label="Internal notes, oldest first">
          {notes.map((n) => (
            <li key={n.note_id} className="note">
              <div className="msg-head"><strong>{n.author}</strong><time dateTime={n.created_at}>{formatDateTime(n.created_at)}</time></div>
              <p className="plain">{n.body}</p>
            </li>
          ))}
        </ol>
      )}
      <form onSubmit={submit} aria-label="Add internal note">
        {add.error && !f.body ? <ErrorNotice error={add.error} /> : null}
        <TextArea label="New internal note (staff only)" value={body} maxLength={4000}
          onChange={(e) => setBody(e.target.value)} error={f.body} />
        <Button type="submit" variant="secondary" busy={add.busy} disabled={!body.trim()}>Save internal note</Button>
      </form>
    </section>
  );
}
