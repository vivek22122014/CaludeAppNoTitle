"use client";

import { ApiError, Button, EmptyState, formatDateTime, newNonce, Notice, TextArea } from "@notitle/shared";
import { type FormEvent, useEffect, useRef, useState } from "react";
import { API } from "../constants";
import { ErrorNotice } from "../Feedback";
import { fieldErrors, useAction } from "../hooks";
import { PurposePicker } from "../PurposePicker";
import { useStaff } from "../StaffContext";
import type { CaseMessage, CaseSummary, MessagePage, PostedMessage } from "../types";

const BODY_MAX = 4000;

function mergeMessages(a: CaseMessage[], b: CaseMessage[]): CaseMessage[] {
  const map = new Map<number, CaseMessage>();
  for (const m of [...a, ...b]) map.set(m.sequence, m);
  return [...map.values()].sort((x, y) => x.sequence - y.sequence);
}

/** Public history (visible to the user) plus the reply composer. */
export function CaseMessages({ summary, onPosted }: { summary: CaseSummary; onPosted: (message: string) => void }) {
  const { client, can, handleError } = useStaff();
  const ref = summary.case_ref;
  const [purpose, setPurpose] = useState("");
  const [items, setItems] = useState<CaseMessage[] | null>(null);
  const load = useAction();
  const seenSent = useRef(summary.seen_staff_sequence);

  const path = `${API}/cases/${encodeURIComponent(ref)}/messages`;

  const loadLatest = async () => {
    const page = await load.run(() => client.get<MessagePage>(path, {
      purpose, before_sequence: summary.last_sequence + 1, limit: 50 }));
    if (page) setItems(page.items);
  };
  const loadOlder = async () => {
    if (!items?.length) return;
    const page = await load.run(() => client.get<MessagePage>(path, { purpose, before_sequence: items[0].sequence, limit: 50 }));
    if (page) setItems((prev) => mergeMessages(page.items, prev ?? []));
  };
  const loadNewer = async () => {
    if (!items || !purpose) return;
    const after = items.length ? items[items.length - 1].sequence : 0;
    const page = await load.run(() => client.get<MessagePage>(path, { purpose, after_sequence: after, limit: 50 }));
    if (page) setItems((prev) => mergeMessages(prev ?? [], page.items));
  };

  // After rendering, record what staff have now seen (highest sequence shown).
  const highest = items?.length ? items[items.length - 1].sequence : 0;
  useEffect(() => {
    if (!highest || highest <= seenSent.current) return;
    seenSent.current = highest;
    client.post(`${API}/cases/${encodeURIComponent(ref)}/seen`, { seen_through: highest }).catch(handleError);
  }, [highest, ref, client, handleError]);

  const hasOlder = Boolean(items?.length && items[0].sequence > 1);

  return (
    <section className="card public-zone section" aria-labelledby="history-h">
      <span className="zone-label zone-public">Visible to the user</span>
      <h2 id="history-h">Conversation with the user</h2>
      <p className="small muted">
        Messages here are the case&apos;s public history. Anything you send below is delivered to the user and kept with the case.
      </p>
      <form className="filters" onSubmit={(e) => { e.preventDefault(); if (purpose) void loadLatest(); }}>
        <PurposePicker value={purpose} onChange={setPurpose} />
        <div className="form-actions">
          <Button type="submit" variant="secondary" busy={load.busy} disabled={!purpose}>
            {items ? "Reload messages" : "Load messages"}
          </Button>
        </div>
      </form>
      <ErrorNotice error={load.error} />
      {items === null ? (
        <p className="muted">Messages are not loaded. Choose a purpose and load them when you need to read the case.</p>
      ) : items.length === 0 ? (
        <EmptyState title="No messages yet." />
      ) : (
        <>
          {hasOlder ? (
            <div className="form-actions" style={{ marginBottom: 12 }}>
              <Button type="button" variant="ghost" onClick={loadOlder} busy={load.busy}>Load older messages</Button>
            </div>
          ) : null}
          <ol className="thread" aria-label="Message history, oldest first">
            {items.map((m) => (
              <li key={m.sequence} className={`msg msg-${m.sender_kind === "staff" ? "staff" : m.sender_kind === "user" ? "user" : "system"}`}>
                <div className="msg-head">
                  <strong>{m.display_role}</strong>
                  <span>#{m.sequence}</span>
                  <time dateTime={m.created_at}>{formatDateTime(m.created_at)}</time>
                </div>
                <p className="plain">{m.body}</p>
              </li>
            ))}
          </ol>
        </>
      )}
      {can("cases.reply") ? (
        <ReplyComposer summary={summary} onSent={(seq) => { onPosted(`Reply #${seq} sent to the user.`); void loadNewer(); }} />
      ) : null}
    </section>
  );
}

function ReplyComposer({ summary, onSent }: { summary: CaseSummary; onSent: (sequence: number) => void }) {
  const { client } = useStaff();
  const [body, setBody] = useState("");
  // Same nonce for a retry of the same text; a new nonce whenever the text changes.
  const [nonce, setNonce] = useState(() => newNonce());
  const send = useAction();
  const closed = summary.status === "closed";

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const res = await send.run(() => client.post<PostedMessage>(
      `${API}/cases/${encodeURIComponent(summary.case_ref)}/messages`, { body, client_nonce: nonce }));
    if (res) {
      setBody("");
      setNonce(newNonce());
      onSent(res.sequence);
    }
  };

  const f = fieldErrors(send.error);
  const length = Array.from(body).length;
  const uncertain = send.error instanceof ApiError && (send.error.code === "timeout" || send.error.code === "network");

  return (
    <form onSubmit={submit} aria-labelledby="reply-h" className="section">
      <h3 id="reply-h">Reply to the user</h3>
      {closed ? (
        <Notice kind="info">This case is closed. Change its status to reopen it before replying.</Notice>
      ) : null}
      <Notice kind="warning">
        The user will see this reply. Do not include email addresses, and never ask for passwords, recovery codes, OTPs or payment details.
      </Notice>
      {send.error && !f.body ? <ErrorNotice error={send.error} /> : null}
      {uncertain ? (
        <p className="small">If you are unsure whether it was sent, press Send again: the same text is sent with the same id and will not be duplicated.</p>
      ) : null}
      <TextArea label="Reply (visible to the user)" value={body} disabled={closed} maxLength={BODY_MAX}
        hint={`${length} / ${BODY_MAX} characters`}
        onChange={(e) => { setBody(e.target.value); setNonce(newNonce()); send.reset(); }} error={f.body} />
      <Button type="submit" busy={send.busy} disabled={closed || !body.trim() || length > BODY_MAX}>Send reply to user</Button>
    </form>
  );
}
