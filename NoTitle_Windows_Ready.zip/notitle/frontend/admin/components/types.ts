/** DTOs returned by the private staff API (/internal/v1). Mirrors backend/app/api/private/routes.py. */

export interface StaffInfo {
  username: string;
  permissions: string[];
  mfa_fresh_until: string;
}

export interface Bootstrap {
  csrf_token: string;
  staff: StaffInfo | null;
  server_time: string;
  environment: string;
}

export interface LoginResult {
  staff: StaffInfo;
  note?: string;
}

// ---------------------------------------------------------------- cases

export type CaseStatus = "open" | "in_progress" | "waiting_user" | "resolved" | "closed";

export interface QueueItem {
  case_ref: string;
  category: string;
  status: CaseStatus;
  urgent: boolean;
  version: number;
  unread: number;
  assigned_to: string | null;
  updated_at: string;
  created_at: string;
  due_at: string | null;
  overdue: boolean;
}

export interface Page<T> {
  items: T[];
  next_cursor: string | null;
}

export interface Obligation {
  id: string;
  rule_id: string;
  rule_version: number | string;
  received_at: string | null;
  acknowledge_by: string | null;
  act_by: string | null;
  acknowledged_at: string | null;
  status: "open" | "acknowledged" | "overdue" | "completed" | string;
  completed_at: string | null;
  outcome: string | null;
}

export interface CaseEvent {
  actor_ref: string;
  kind: string;
  old_value: string | null;
  new_value: string | null;
  reason: string | null;
  created_at: string;
}

export interface LinkedReport {
  public_ref: string;
  reason: string;
  evidence_state: string;
  blocked: boolean;
}

export interface CaseSummary {
  case_ref: string;
  category: string;
  status: CaseStatus;
  urgent: boolean;
  version: number;
  assigned_to: string | null;
  account_owned: boolean;
  last_sequence: number;
  seen_staff_sequence: number;
  related_ref: string | null;
  created_at: string;
  updated_at: string;
  closed_at: string | null;
  report: LinkedReport | null;
  obligations: Obligation[];
  events: CaseEvent[];
}

export interface CaseMessage {
  sequence: number;
  sender_kind: "user" | "staff" | "system" | string;
  display_role: string;
  body: string;
  created_at: string;
}

export interface MessagePage {
  items: CaseMessage[];
  high_water_sequence: number;
  next_after: number | null;
}

export interface PostedMessage {
  sequence: number;
  created_at: string;
  status: string;
}

export interface InternalNote {
  note_id: string;
  author: string;
  created_at: string;
  body: string;
}

// ---------------------------------------------------------------- reports

export interface ReportListItem {
  public_ref: string;
  reason: string;
  evidence_state: string;
  blocked: boolean;
  submitted_at: string;
  subject_kind: string;
  case_ref: string;
  status: CaseStatus;
  urgent: boolean;
  decisions: number;
}

export interface EvidenceMessage {
  message_id: string;
  sender: string;
  sent_at: string;
  body: string;
  source: string;
}

export interface Decision {
  public_ref: string;
  action: "dismiss" | "warn" | "suspend" | "ban";
  reason_code: string;
  starts_at: string;
  ends_at: string | null;
  appeal_outcome: "upheld" | "overturned" | null;
  username: string;
}

export interface ReportDetail {
  report_ref: string;
  case_ref: string;
  reason: string;
  reporter_kind: string;
  subject_kind: string;
  subject_ref: string;
  blocked: boolean;
  evidence_state: string;
  submitted_at: string;
  allegation: string;
  allegation_note: string;
  evidence: EvidenceMessage[];
  other_reports_about_subject: number;
  decisions: Decision[];
}

export interface DecisionResult {
  decision_ref: string;
  action: string;
  ends_at: string | null;
}

// ---------------------------------------------------------------- previews

export type SummaryValue = string | number | boolean | null | undefined | Record<string, unknown>;

export interface Preview {
  nonce: string;
  kind: string;
  object_ref: string;
  expires_at: string;
  summary: Record<string, SummaryValue>;
  requires: string;
}

// ---------------------------------------------------------------- billing

export type PurchaseState = "created" | "pending" | "paid" | "failed" | "needs_review";

export interface Purchase {
  purchase_ref: string;
  plan_code: string;
  plan_version: number;
  amount_paise: number;
  currency: string;
  duration_seconds: number;
  state: PurchaseState;
  message: string;
  provider: string;
  created_at: string;
  captured_at: string | null;
  merchant_order_id: string;
  refund_count: number;
}

export interface Refund {
  public_ref: string;
  amount_paise: number;
  revoke_seconds: number;
  held_seconds: number;
  state: string;
  remedy_basis: string;
  evidence_ref: string;
  decision_reason: string;
  created_at: string;
  purchase_ref: string;
  username: string;
}

export interface RefundResult {
  refund_ref: string;
  state: string;
  held_seconds: number;
}

// ---------------------------------------------------------------- privacy

export interface RightsRequest {
  public_ref: string;
  kind: string;
  status: string;
  deadline_at: string;
  created_at: string;
  case_ref: string;
  overdue: boolean;
}

export interface DeletionRequest {
  public_ref: string;
  state: string;
  journal_seq: number | null;
  requested_at: string;
  completed_at: string | null;
}

export interface LegalHold {
  public_ref: string;
  subject_ref: string;
  scope: string;
  basis: string;
  state: string;
  review_at: string | null;
  expires_at: string | null;
  created_at: string | null;
  username: string;
}

export interface HoldResult {
  hold_ref: string;
  journal_seq: number;
}

// ---------------------------------------------------------------- analytics

export type Suppressed = number | "<10" | null;

export interface HistogramTotal {
  count: Suppressed;
  mean: number | null;
}

export interface AnalyticsSummary {
  window: string;
  generated_at: string;
  current: {
    active_now: number;
    searching_now: number;
    conversations_now: number;
    calls_now: number;
    current_accounts: Suppressed;
    note: string;
  };
  totals_24h: Record<string, Suppressed | HistogramTotal>;
  error_rate: number | null;
  completeness: string;
}

export interface MetricInfo {
  id: number;
  name: string;
  kind: "counter" | "integral" | "histogram";
}

export interface SeriesPoint {
  t: string;
  value?: Suppressed;
  count?: Suppressed;
  mean?: number | null;
}

export interface Series {
  metric_id: number;
  name: string;
  kind: MetricInfo["kind"];
  resolution: "minute" | "hour" | "day";
  points: SeriesPoint[];
  suppression: string;
}

// ---------------------------------------------------------------- audit / staff / health

export interface AuditRow {
  id: number;
  actor_ref: string;
  purpose: string;
  object_type: string;
  object_ref: string;
  action: string;
  decision: string;
  request_id: string | null;
  created_at: string;
}

export interface AuditPage {
  items: AuditRow[];
  next_cursor: number | null;
}

export interface StaffMember {
  username: string;
  status: string;
  created_at: string;
  permissions: string[];
}

export interface StaffList {
  items: StaffMember[];
  roles: Record<string, string[]>;
}

export interface CreatedStaff {
  username: string;
  totp_secret: string;
  otpauth_uri: string;
  recovery_codes: string[];
  roles: string[];
  warning: string;
}

export interface MigrationState {
  id: string;
  applied: boolean;
  checksum_ok: boolean | null;
}

export interface Health {
  database: "ok" | "unavailable";
  migrations: MigrationState[];
  owner_epoch: number | string | null;
  runtime: Record<string, number>;
  jobs: Record<string, number>;
  journal: { entries: number; capacity: number; path: string; head: string };
  overdue_obligations: number | null;
  payments_needing_attention: number | null;
  latest_backup: string | null;
  gates: {
    admission: boolean;
    audio: boolean;
    audio_relay_only: boolean;
    payments: boolean;
    payment_provider: string;
    annual365: boolean;
    policies: string;
  };
  environment: string;
}
