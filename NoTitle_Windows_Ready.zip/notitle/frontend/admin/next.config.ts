import type { NextConfig } from "next";

// Production builds are static exports served by the NoTitle runtime (no Node
// server at request time).  `npm run dev` proxies API calls to the runtime.
const isDev = process.env.NODE_ENV === "development";
const api = process.env.NOTITLE_API_ORIGIN ?? "http://127.0.0.1:8081";

const config: NextConfig = {
  output: isDev ? undefined : "export",
  trailingSlash: true,
  images: { unoptimized: true },
  poweredByHeader: false,
  reactStrictMode: true,
  productionBrowserSourceMaps: false,
  transpilePackages: ["@notitle/shared"],
  ...(isDev
    ? { async rewrites() { return [{ source: "/internal/:path*", destination: `${api}/internal/:path*` }]; } }
    : {}),
};

export default config;
