<#
.SYNOPSIS
  One-time (and repeatable) setup for NoTitle on Windows.

.DESCRIPTION
  1. Checks Python 3.11+ (3.12 recommended) and creates backend\.venv
  2. Installs pinned backend dependencies
  3. Creates .env with fresh random secrets (an existing .env is kept)
  4. Ensures Node.js 20.9+ (downloads a portable, checksum-verified Node.js if missing)
  5. Starts PostgreSQL (Docker container, or portable binaries when Docker is unavailable)
  6. Creates least-privilege database roles and applies migrations
  7. Installs frontend dependencies and builds both static sites
  8. Creates a local staff owner account ("admin") for the private site

  Safe to re-run: every step is idempotent.

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File scripts\setup.ps1
.EXAMPLE
  scripts\setup.ps1 -DbMode portable      # force portable PostgreSQL (no Docker)
#>
param(
    [ValidateSet('', 'auto', 'docker', 'portable', 'external')][string]$DbMode = '',
    [switch]$SkipFrontend,
    [switch]$NoNodeInstall
)

. "$PSScriptRoot\lib\common.ps1"
Set-Location $script:Root
Ensure-Dir $script:Tools
Ensure-Dir $script:LocalDir

Write-Host 'NoTitle setup' -ForegroundColor White
Write-Note "Project folder: $script:Root"

# ---------------------------------------------------------------- Python
Write-Step 'Checking Python'
$python = Find-Python
if (-not $python) {
    Fail ("Python 3.11 or newer was not found.`n" +
          "Install Python 3.12 from https://www.python.org/downloads/windows/ and tick 'Add python.exe to PATH', then re-run this script.")
}
Write-Ok "Using $python"

Write-Step 'Installing backend dependencies (backend\.venv)'
if (-not (Test-Path $script:VenvPython)) {
    Invoke-Native $python @('-m', 'venv', (Join-Path $script:Backend '.venv')) 'Creating the virtual environment'
}
Invoke-Native $script:VenvPython @('-m', 'pip', 'install', '--disable-pip-version-check', '-q', '--upgrade', 'pip') 'Upgrading pip'
Invoke-Native $script:VenvPython @('-m', 'pip', 'install', '--disable-pip-version-check', '-q', '-r',
    (Join-Path $script:Backend 'requirements-dev.txt')) 'Installing backend dependencies'
Write-Ok 'Backend dependencies installed'

# ------------------------------------------------------------------- .env
Write-Step 'Configuration (.env)'
if (-not (Test-Path $script:EnvFile)) {
    $text = [System.IO.File]::ReadAllText((Join-Path $script:Root '.env.example'))
    $adminPw = New-Password; $ownerPw = New-Password; $appPw = New-Password
    $replacements = @{
        'DATABASE_URL=postgresql://notitle_app:<generated>@'          = "DATABASE_URL=postgresql://notitle_app:$appPw@"
        'DATABASE_MIGRATOR_URL=postgresql://notitle_owner:<generated>@' = "DATABASE_MIGRATOR_URL=postgresql://notitle_owner:$ownerPw@"
        'DATABASE_ADMIN_URL=postgresql://postgres:<generated>@'       = "DATABASE_ADMIN_URL=postgresql://postgres:$adminPw@"
        'HMAC_KEY=<generated>'                                        = "HMAC_KEY=$(New-Secret)"
        'WRAPPING_KEY=<generated>'                                    = "WRAPPING_KEY=$(New-Secret)"
        'JOURNAL_KEY=<generated>'                                     = "JOURNAL_KEY=$(New-Secret)"
        'PAYMENT_WEBHOOK_SECRET=<generated>'                          = "PAYMENT_WEBHOOK_SECRET=$(New-Secret)"
    }
    foreach ($key in $replacements.Keys) { $text = $text.Replace($key, $replacements[$key]) }
    Write-Utf8NoBom $script:EnvFile $text
    Write-Ok 'Created .env with new random secrets (keep this file private and backed up)'
} else {
    Write-Ok 'Keeping existing .env'
}
if ($DbMode -ne '') {
    $text = [System.IO.File]::ReadAllText($script:EnvFile)
    $text = [regex]::Replace($text, '(?m)^DB_MODE=.*$', "DB_MODE=$DbMode")
    Write-Utf8NoBom $script:EnvFile $text
    Write-Ok "DB_MODE set to $DbMode"
}

# ---------------------------------------------------------------- Node.js
function Install-PortableNode {
    $name = "node-$($script:NodeVersion)-win-x64"
    $downloads = Join-Path $script:Tools 'downloads'
    Ensure-Dir $downloads
    $zip = Join-Path $downloads "$name.zip"
    $sums = Join-Path $downloads "SHASUMS256-$($script:NodeVersion).txt"
    $base = "https://nodejs.org/dist/$($script:NodeVersion)"
    Write-Note "Downloading Node.js $($script:NodeVersion) from nodejs.org ..."
    Invoke-Native 'curl.exe' @('-fsSL', '-o', $sums, "$base/SHASUMS256.txt") 'Downloading Node.js checksums'
    if (-not (Test-Path $zip)) {
        Invoke-Native 'curl.exe' @('-fSL', '--progress-bar', '-o', $zip, "$base/$name.zip") 'Downloading Node.js'
    }
    $expected = (Select-String -Path $sums -Pattern "  $name.zip$").Line.Split(' ')[0]
    $actual = (Get-FileHash -Algorithm SHA256 $zip).Hash.ToLower()
    if ($expected -ne $actual) {
        Remove-Item $zip -Force
        Fail 'Node.js download failed checksum verification. Re-run setup.'
    }
    Write-Ok 'Checksum verified'
    $dest = Join-Path $script:Tools 'node'
    if (Test-Path $dest) { Remove-Item -Recurse -Force $dest }
    Invoke-Native 'tar.exe' @('-xf', $zip, '-C', $script:Tools) 'Extracting Node.js'
    Rename-Item (Join-Path $script:Tools $name) 'node'
}

Write-Step 'Checking Node.js'
$node = Find-Node
if (-not $node) {
    if ($NoNodeInstall) {
        Fail 'Node.js 20.9+ was not found. Install Node.js 24 LTS from https://nodejs.org/ or re-run without -NoNodeInstall.'
    }
    Write-Note 'Node.js 20.9+ not found; installing a portable copy into .tools\node (no admin rights needed).'
    Install-PortableNode
    $node = Find-Node
}
$nodeVersion = & $node --version
Write-Ok "Using Node.js $nodeVersion ($node)"

# -------------------------------------------------------------- PostgreSQL
function Install-PortablePostgres {
    $downloads = Join-Path $script:Tools 'downloads'
    Ensure-Dir $downloads
    $zip = Join-Path $downloads "postgresql-$($script:PgVersion)-windows-x64-binaries.zip"
    if (-not (Test-Path $zip)) {
        Write-Note 'Downloading PostgreSQL binaries (about 330 MB, one time) from get.enterprisedb.com ...'
        Invoke-Native 'curl.exe' @('-fSL', '--progress-bar', '-o', "$zip.part",
            "https://get.enterprisedb.com/postgresql/postgresql-$($script:PgVersion)-windows-x64-binaries.zip") 'Downloading PostgreSQL'
        Move-Item "$zip.part" $zip
    }
    Write-Note 'Extracting PostgreSQL (server and client tools only) ...'
    $pg = Join-Path $script:Tools 'pgsql'
    if (Test-Path $pg) { Remove-Item -Recurse -Force $pg }
    Invoke-Native 'tar.exe' @('-xf', $zip, '-C', $script:Tools, '--exclude', 'pgsql/pgAdmin 4', '--exclude', 'pgsql/symbols',
        '--exclude', 'pgsql/StackBuilder', '--exclude', 'pgsql/doc') 'Extracting PostgreSQL'
    if (-not (Test-Path (Get-PgBin 'initdb'))) { Fail 'PostgreSQL extraction failed (initdb.exe missing).' }
}

function Initialize-PortableCluster {
    $data = Join-Path $script:LocalDir 'pgdata'
    if (Test-Path (Join-Path $data 'PG_VERSION')) { return }
    $adminUrl = Get-EnvValue 'DATABASE_ADMIN_URL'
    $adminPw = ([uri]$adminUrl).UserInfo.Split(':')[1]
    $pwFile = Join-Path $script:LocalDir 'initdb-pw.tmp'
    Write-Utf8NoBom $pwFile $adminPw
    try {
        Invoke-Native (Get-PgBin 'initdb') @('-D', $data, '-U', 'postgres', "--pwfile=$pwFile", '-E', 'UTF8',
            '--locale=C', '-A', 'scram-sha-256') 'Initialising the PostgreSQL data directory'
    } finally { Remove-Item $pwFile -Force -ErrorAction SilentlyContinue }
}

Write-Step 'Preparing PostgreSQL'
$mode = Get-DbMode
Write-Note "Database mode: $mode"
if ($mode -eq 'docker') {
    if (-not (Test-Docker)) { Fail 'DB_MODE=docker but Docker is not running. Start Docker Desktop or run setup with -DbMode portable.' }
} elseif ($mode -eq 'portable') {
    if (-not (Test-Path (Get-PgBin 'pg_ctl'))) { Install-PortablePostgres }
    Initialize-PortableCluster
}
Start-Database

Write-Step 'Creating database roles and applying migrations'
if ($mode -ne 'external' -or (Get-EnvValue 'DATABASE_ADMIN_URL') -ne '') {
    if ((Invoke-Cli @('db-bootstrap')) -ne 0) { Fail 'Database bootstrap failed.' }
}
if ((Invoke-Cli @('migrate')) -ne 0) { Fail 'Migrations failed.' }
Write-Ok 'Database schema is up to date'

# ---------------------------------------------------------------- Frontend
if (-not $SkipFrontend) {
    Write-Step 'Installing frontend dependencies (this can take a few minutes the first time)'
    $npm = Get-Npm
    Push-Location $script:Frontend
    try {
        if (Test-Path 'package-lock.json') {
            Invoke-Native $npm @('ci', '--no-audit', '--no-fund') 'npm ci'
        } else {
            Invoke-Native $npm @('install', '--no-audit', '--no-fund') 'npm install'
        }
        Write-Step 'Building the public and private static sites'
        Invoke-Native $npm @('run', 'build') 'Frontend build'
    } finally { Pop-Location }
    Write-Ok 'Frontend built (frontend\public\out and frontend\admin\out)'
}

# ------------------------------------------------------------- Staff owner
Write-Step 'Local staff owner account'
$staffDir = Join-Path $script:LocalDir 'staff'
Ensure-Dir $staffDir
$pwPath = Join-Path $staffDir 'admin-password.txt'
if (Test-Path (Join-Path $staffDir 'admin-enrollment.txt')) {
    Write-Ok 'Staff account "admin" already exists (see .local\staff\)'
} else {
    $staffPw = New-Password 20
    $env:NOTITLE_STAFF_PASSWORD = $staffPw
    $code = Invoke-Cli @('create-staff', '--username', 'admin', '--roles', 'owner')
    Remove-Item Env:\NOTITLE_STAFF_PASSWORD
    if ($code -ne 0) {
        Write-Warn 'Could not create the staff account (it may already exist). You can create one later with scripts\create-staff.ps1'
    } else {
        Write-Utf8NoBom $pwPath "username: admin`r`npassword: $staffPw`r`n"
        Write-Ok "Staff login saved in .local\staff\admin-password.txt (development only)"
    }
}

Write-Host "`nSetup complete." -ForegroundColor Green
Write-Host '  Start the app:      scripts\start.ps1   (or double-click start.cmd)'
Write-Host '  Public site:        http://localhost:8080'
Write-Host '  Private staff site: http://localhost:8081   (user "admin", password in .local\staff\admin-password.txt,'
Write-Host '                      authenticator code: scripts\staff-code.ps1)'
Write-Host '  Run all tests:      scripts\test.ps1'
