<#
.SYNOPSIS
  Developer mode with hot reload: runs the backend plus both Next.js dev servers.
    Public site (hot reload):  http://localhost:3000   (API proxied to :8080, WebSocket direct to :8080)
    Staff site  (hot reload):  http://localhost:3001   (API proxied to :8081)
  The built static sites keep working on :8080 / :8081 at the same time.
  Close the opened windows (or press Ctrl+C in each) to stop.
#>
. "$PSScriptRoot\lib\common.ps1"
Set-Location $script:Root

& "$PSScriptRoot\start.ps1" -Background
if ($LASTEXITCODE -ne 0) { exit 1 }
$node = Use-Node
$nodeDir = Split-Path $node -Parent
foreach ($app in @('public', 'admin')) {
    $cmd = "`$env:Path='$nodeDir;' + `$env:Path; Set-Location '$($script:Frontend)'; npm.cmd run dev -w @notitle/$app"
    Start-Process powershell -ArgumentList @('-NoExit', '-NoProfile', '-Command', $cmd) | Out-Null
}
Write-Ok 'Started Next.js dev servers in two new windows.'
Write-Host '  Public (hot reload): http://localhost:3000'
Write-Host '  Staff  (hot reload): http://localhost:3001'
Write-Host '  Stop the backend with scripts\stop.ps1'
