<#
.SYNOPSIS
  Installs frontend dependencies (if needed) and builds both static sites.
#>
. "$PSScriptRoot\lib\common.ps1"

$npm = Get-Npm
Push-Location $script:Frontend
try {
    if (-not (Test-Path 'node_modules')) {
        Write-Step 'Installing frontend dependencies'
        if (Test-Path 'package-lock.json') { Invoke-Native $npm @('ci', '--no-audit', '--no-fund') 'npm ci' }
        else { Invoke-Native $npm @('install', '--no-audit', '--no-fund') 'npm install' }
    }
    Write-Step 'Building public and private static sites'
    Invoke-Native $npm @('run', 'build') 'Frontend build'
} finally { Pop-Location }
Write-Ok 'Built frontend\public\out and frontend\admin\out (restart NoTitle is not required; reload the browser)'
