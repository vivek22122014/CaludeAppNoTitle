<#
.SYNOPSIS
  Database helper.
.EXAMPLE
  scripts\db.ps1 start      # start PostgreSQL
  scripts\db.ps1 stop       # stop PostgreSQL
  scripts\db.ps1 status     # connectivity + migration status
  scripts\db.ps1 migrate    # apply pending migrations (stop NoTitle first)
  scripts\db.ps1 backup     # SQL backup + journal copy into .local\backups
  scripts\db.ps1 restore -File .local\backups\notitle-XXXX.sql -TargetDb notitle_restore
#>
param(
    [Parameter(Mandatory = $true)][ValidateSet('start', 'stop', 'status', 'migrate', 'backup', 'restore')][string]$Action,
    [string]$File = '',
    [string]$TargetDb = 'notitle_restore'
)

. "$PSScriptRoot\lib\common.ps1"
switch ($Action) {
    'start' { Start-Database }
    'stop' { Stop-Database; Write-Ok 'PostgreSQL stopped' }
    'status' { Start-Database; exit (Invoke-Cli @('check')) }
    'migrate' {
        if ((Get-RunnerProcesses).Count -gt 0) { Fail 'Stop NoTitle first (scripts\stop.ps1); migrations never run under a live runtime.' }
        Start-Database; exit (Invoke-Cli @('migrate'))
    }
    'backup' { Start-Database; exit (Invoke-Cli @('backup')) }
    'restore' {
        if ($File -eq '') { Fail 'Pass -File <backup.sql>' }
        Start-Database; exit (Invoke-Cli @('restore', '--file', (Resolve-Path $File).Path, '--target-db', $TargetDb))
    }
}
