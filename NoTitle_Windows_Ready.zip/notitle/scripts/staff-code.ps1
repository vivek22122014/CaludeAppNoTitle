<#
.SYNOPSIS
  Development helper: prints the next valid authenticator (TOTP) code for a staff user,
  so you can sign in to the private site without an authenticator app.
  Refused when APP_ENV=production.  In real use, add the TOTP secret from
  .local\staff\<user>-enrollment.txt to an authenticator app instead.
#>
param([string]$Username = 'admin')

. "$PSScriptRoot\lib\common.ps1"
$code = Invoke-Cli @('dev-totp', '--username', $Username)
exit $code
