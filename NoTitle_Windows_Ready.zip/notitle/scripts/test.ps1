<#
.SYNOPSIS
  Runs every automated check and prints a pass/fail summary.

.DESCRIPTION
  1. Backend unit tests            (no database needed)
  2. Backend integration tests     (real PostgreSQL + the real runtime on ports 18080/18081)
  3. Policy publication lint
  4. Frontend type checks          (shared, public, admin)
  5. Frontend static builds        (only when missing, or with -Build)
  6. Browser end-to-end tests      (Playwright/Chromium against an isolated runtime on 18180/18181)

  Test databases (notitle_test, notitle_e2e) are disposable; your development data is untouched.
  A summary is also written to .local\test-report.txt.

.EXAMPLE
  scripts\test.ps1
  scripts\test.ps1 -SkipE2E        # skip the browser tests
  scripts\test.ps1 -Build          # rebuild the frontend first
#>
param([switch]$SkipE2E, [switch]$Build, [switch]$SkipIntegration)

. "$PSScriptRoot\lib\common.ps1"
Set-Location $script:Root
if (-not (Test-Path $script:VenvPython)) { Fail 'Run scripts\setup.ps1 first.' }

$results = New-Object System.Collections.ArrayList
function Record([string]$Name, [int]$Code, [datetime]$Started) {
    $secs = [math]::Round(((Get-Date) - $Started).TotalSeconds)
    $status = 'PASS'
    if ($Code -ne 0) { $status = 'FAIL' }
    [void]$results.Add([pscustomobject]@{ Check = $Name; Result = $status; Seconds = $secs })
    if ($Code -eq 0) { Write-Ok "$Name passed" } else { Write-Warn "$Name FAILED (exit $Code)" }
}

Write-Step 'Starting PostgreSQL'
Start-Database

Write-Step '1/6 Backend unit tests'
$t = Get-Date
Push-Location $script:Backend
& $script:VenvPython -m pytest tests/unit -q
$code = $LASTEXITCODE
Pop-Location
Record 'Backend unit tests' $code $t

if (-not $SkipIntegration) {
    Write-Step '2/6 Backend integration tests (about 3 minutes)'
    $t = Get-Date
    Push-Location $script:Backend
    & $script:VenvPython -m pytest tests/integration -q
    $code = $LASTEXITCODE
    Pop-Location
    Record 'Backend integration tests' $code $t
}

Write-Step '3/6 Policy publication lint'
$t = Get-Date
Record 'Policy lint' (Invoke-Cli @('lint-policies')) $t

$npm = Get-Npm
Write-Step '4/6 Frontend type checks'
$t = Get-Date
Push-Location $script:Frontend
if (-not (Test-Path 'node_modules')) { Invoke-Native $npm @('ci', '--no-audit', '--no-fund') 'npm ci' }
& $npm run typecheck
$code = $LASTEXITCODE
Pop-Location
Record 'Frontend typecheck' $code $t

$built = (Test-Path (Join-Path $script:Frontend 'public\out\index.html')) -and (Test-Path (Join-Path $script:Frontend 'admin\out\index.html'))
if ($Build -or -not $built) {
    Write-Step '5/6 Frontend builds'
    $t = Get-Date
    Push-Location $script:Frontend
    & $npm run build
    $code = $LASTEXITCODE
    Pop-Location
    Record 'Frontend build' $code $t
} else {
    Write-Step '5/6 Frontend builds (already built; use -Build to rebuild)'
}

if (-not $SkipE2E) {
    Write-Step '6/6 Browser end-to-end tests'
    $t = Get-Date
    $browsers = Join-Path $env:LOCALAPPDATA 'ms-playwright'
    $hasChromium = (Test-Path $browsers) -and (Get-ChildItem $browsers -Directory -Filter 'chromium*' -ErrorAction SilentlyContinue)
    if (-not $hasChromium) {
        Write-Note 'Installing the Playwright Chromium browser (one time, about 150 MB) ...'
        Push-Location $script:Frontend
        $npx = Join-Path (Split-Path $npm -Parent) 'npx.cmd'
        & $npx playwright install chromium
        Pop-Location
    }
    & $script:VenvPython (Join-Path $script:Root 'scripts\run_e2e.py') --reporter=list
    Record 'Browser E2E tests' $LASTEXITCODE $t
}

Write-Host "`nSummary" -ForegroundColor White
$results | Format-Table -AutoSize | Out-String | Write-Host
$report = Join-Path $script:LocalDir 'test-report.txt'
Ensure-Dir $script:LocalDir
Write-Utf8NoBom $report (("NoTitle test run " + (Get-Date -Format 's') + "`r`n") + ($results | Format-Table -AutoSize | Out-String))
$failed = @($results | Where-Object { $_.Result -eq 'FAIL' }).Count
if ($failed -gt 0) {
    Write-Host "$failed check(s) failed. Details are in the output above." -ForegroundColor Red
    exit 1
}
Write-Host 'All checks passed.' -ForegroundColor Green
