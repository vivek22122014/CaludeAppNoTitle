"""Browser end-to-end tests against an isolated runtime.

Creates a disposable ``notitle_e2e`` database, applies migrations, starts the
runtime in APP_ENV=test on ports 18180/18181 (serving the built static sites),
runs Playwright, then stops everything.  The development database is untouched.

Usage (from the project root):  backend\\.venv\\Scripts\\python.exe scripts\\run_e2e.py [playwright args]
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parent.parent
BACKEND = ROOT / "backend"
FRONTEND = ROOT / "frontend"
DB = "notitle_e2e"
PUBLIC_PORT, PRIVATE_PORT = 18180, 18181


def dotenv() -> dict[str, str]:
    out: dict[str, str] = {}
    for line in (ROOT / ".env").read_text(encoding="utf-8").splitlines():
        if "=" in line and not line.lstrip().startswith("#"):
            k, _, v = line.partition("=")
            out[k.strip()] = v.strip()
    return out


def with_db(url: str, name: str) -> str:
    return urlunsplit(urlsplit(url)._replace(path="/" + name))


def main() -> int:
    import psycopg
    from psycopg import sql

    if not (FRONTEND / "public" / "out" / "index.html").exists():
        print("The frontend is not built. Run scripts\\build.ps1 first.")
        return 2
    env_file = dotenv()
    admin, app_url, owner_url = env_file["DATABASE_ADMIN_URL"], env_file["DATABASE_URL"], env_file["DATABASE_MIGRATOR_URL"]
    owner = urlsplit(owner_url).username
    with psycopg.connect(admin, autocommit=True) as conn:
        conn.execute(sql.SQL("DROP DATABASE IF EXISTS {} WITH (FORCE)").format(sql.Identifier(DB)))
        conn.execute(sql.SQL("CREATE DATABASE {} OWNER {} TEMPLATE template0").format(sql.Identifier(DB), sql.Identifier(owner)))
        conn.execute(sql.SQL("GRANT CONNECT ON DATABASE {} TO {}").format(sql.Identifier(DB), sql.Identifier(urlsplit(app_url).username)))
    with psycopg.connect(with_db(admin, DB), autocommit=True) as conn:
        conn.execute(sql.SQL("ALTER SCHEMA public OWNER TO {}").format(sql.Identifier(owner)))

    data_dir = Path(tempfile.mkdtemp(prefix="notitle-e2e-"))
    public, private = f"http://localhost:{PUBLIC_PORT}", f"http://localhost:{PRIVATE_PORT}"
    env = {**os.environ, "APP_ENV": "test", "LOG_LEVEL": "WARNING",
           "DATABASE_URL": with_db(app_url, DB), "DATABASE_MIGRATOR_URL": with_db(owner_url, DB),
           "PUBLIC_PORT": str(PUBLIC_PORT), "PRIVATE_PORT": str(PRIVATE_PORT),
           "PUBLIC_ORIGIN": public, "PRIVATE_ORIGIN": private,
           "EXTRA_PUBLIC_ORIGINS": f"http://127.0.0.1:{PUBLIC_PORT}", "EXTRA_PRIVATE_ORIGINS": f"http://127.0.0.1:{PRIVATE_PORT}",
           "DATA_DIR": str(data_dir), "PAYMENT_PROVIDER": "simulator", "PYTHONUNBUFFERED": "1"}
    python = str(BACKEND / ".venv" / "Scripts" / "python.exe") if os.name == "nt" else sys.executable
    subprocess.run([python, "-m", "app.cli", "migrate"], cwd=BACKEND, env=env, check=True, capture_output=True)
    staff_password = "E2E-staff-password-1"
    subprocess.run([python, "-m", "app.cli", "create-staff", "--username", "e2eadmin", "--roles", "owner"], cwd=BACKEND,
                   env={**env, "NOTITLE_STAFF_PASSWORD": staff_password}, check=True, capture_output=True)
    log_path = data_dir / "runner.log"
    log = open(log_path, "wb")
    proc = subprocess.Popen([python, "-m", "app.runner"], cwd=BACKEND, env=env, stdout=log, stderr=subprocess.STDOUT)
    try:
        deadline = time.time() + 40
        while time.time() < deadline:
            try:
                if urlopen(f"http://127.0.0.1:{PUBLIC_PORT}/health/ready", timeout=2).status == 200:
                    break
            except OSError:
                time.sleep(0.4)
            if proc.poll() is not None:
                break
        else:
            print("runtime did not become ready")
            return 1
        if proc.poll() is not None:
            print(log_path.read_text(errors="replace")[-2000:])
            return 1
        npx = shutil.which("npx.cmd") or shutil.which("npx")
        if npx is None:
            portable = ROOT / ".tools" / "node" / "npx.cmd"
            npx = str(portable) if portable.exists() else None
        if npx is None:
            print("npx not found; run scripts\\setup.ps1")
            return 2
        node_dir = str(Path(npx).parent)
        # The e2e helpers call the dev-totp CLI, which must point at the disposable database.
        run_env = {**env, "E2E_BASE_URL": public, "E2E_PRIVATE_URL": private,
                   "E2E_STAFF_USER": "e2eadmin", "E2E_STAFF_PASSWORD": staff_password,
                   "PATH": node_dir + os.pathsep + os.environ.get("PATH", "")}
        result = subprocess.run([npx, "playwright", "test", "--config", "e2e/playwright.config.ts", *sys.argv[1:]],
                                cwd=FRONTEND, env=run_env)
        return result.returncode
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()
        log.close()
        shutil.rmtree(data_dir, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())
