<#
.SYNOPSIS
  Creates a staff account for the private site.  You are prompted for a password.
.EXAMPLE
  scripts\create-staff.ps1 -Username alice -Roles moderator
  Roles: owner, moderator, billing, privacy, analyst (several allowed).
#>
param(
    [Parameter(Mandatory = $true)][string]$Username,
    [string[]]$Roles = @('moderator')
)

. "$PSScriptRoot\lib\common.ps1"
$code = Invoke-Cli (@('create-staff', '--username', $Username, '--roles') + $Roles)
exit $code
