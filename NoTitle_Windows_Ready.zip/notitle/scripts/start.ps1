<#
.SYNOPSIS
  Starts PostgreSQL (if needed), applies pending migrations and runs NoTitle.

.DESCRIPTION
  Foreground (default): logs stream to this window; press Ctrl+C to stop.
  -Background: runs hidden, logs go to .local\runner.log; stop with scripts\stop.ps1.
#>
param([switch]$Background)

. "$PSScriptRoot\lib\common.ps1"
Set-Location $script:Root

if (-not (Test-Path $script:EnvFile) -or -not (Test-Path $script:VenvPython)) {
    Fail 'NoTitle is not set up yet. Run scripts\setup.ps1 first.'
}
$running = Get-RunnerProcesses
if ($running.Count -gt 0) {
    Write-Ok "NoTitle is already running (PID $($running[0].ProcessId)). Open $(Get-EnvValue 'PUBLIC_ORIGIN' 'http://localhost:8080')"
    exit 0
}

Write-Step 'Starting PostgreSQL'
Start-Database

Write-Step 'Applying pending migrations (runtime is stopped)'
if ((Invoke-Cli @('migrate')) -ne 0) { Fail 'Migrations failed.' }

foreach ($site in @('public', 'admin')) {
    if (-not (Test-Path (Join-Path $script:Frontend "$site\out\index.html"))) {
        Write-Warn "The $site site is not built. Run scripts\build.ps1 (the API still starts)."
    }
}

$public = Get-EnvValue 'PUBLIC_ORIGIN' 'http://localhost:8080'
$private = Get-EnvValue 'PRIVATE_ORIGIN' 'http://localhost:8081'

if ($Background) {
    Write-Step 'Starting NoTitle in the background'
    $log = Join-Path $script:LocalDir 'runner.log'
    $err = Join-Path $script:LocalDir 'runner.err.log'
    $proc = Start-Process -FilePath $script:VenvPython -ArgumentList @('-m', 'app.runner') -WorkingDirectory $script:Backend `
        -RedirectStandardOutput $log -RedirectStandardError $err -WindowStyle Hidden -PassThru
    if (Wait-Ready "$public/health/ready" 45) {
        Write-Ok "NoTitle is running (PID $($proc.Id))"
        Write-Host "  Public site:  $public"
        Write-Host "  Staff site:   $private"
        Write-Host "  Logs:         .local\runner.err.log"
        Write-Host "  Stop:         scripts\stop.ps1"
    } else {
        Write-Warn 'NoTitle did not become ready. Last log lines:'
        if (Test-Path $err) { Get-Content $err -Tail 25 | ForEach-Object { Write-Host "    $_" } }
        exit 1
    }
} else {
    Write-Step 'Starting NoTitle (press Ctrl+C to stop)'
    Write-Host "  Public site:  $public"
    Write-Host "  Staff site:   $private"
    Push-Location $script:Backend
    try { & $script:VenvPython -m app.runner } finally { Pop-Location }
    exit $LASTEXITCODE
}
