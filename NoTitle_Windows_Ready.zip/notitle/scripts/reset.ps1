<#
.SYNOPSIS
  DESTRUCTIVE: deletes the local database and all local data (.local), keeping .env and installed tools.
  Use when you want a completely fresh local environment.  Run scripts\setup.ps1 afterwards.
#>
param([switch]$Yes)

. "$PSScriptRoot\lib\common.ps1"
if (-not $Yes) {
    $answer = Read-Host 'This permanently deletes the local NoTitle database, journal, backups and staff files. Type DELETE to continue'
    if ($answer -ne 'DELETE') { Write-Note 'Cancelled.'; exit 0 }
}
& "$PSScriptRoot\stop.ps1"
$mode = Get-DbMode
if ($mode -eq 'docker') {
    & docker rm -f $script:DbContainer *> $null
    & docker volume rm $script:DbVolume *> $null
    Write-Ok 'Removed PostgreSQL container and volume'
} elseif ($mode -eq 'portable') {
    Stop-Database
}
if (Test-Path $script:LocalDir) { Remove-Item -Recurse -Force $script:LocalDir }
Write-Ok 'Removed .local'
Write-Host 'Now run scripts\setup.ps1 to create a fresh environment.'
