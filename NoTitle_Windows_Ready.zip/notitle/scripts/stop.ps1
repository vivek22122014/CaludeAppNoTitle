<#
.SYNOPSIS
  Stops the NoTitle runtime.  Add -Database to also stop PostgreSQL.
  Temporary conversations end on stop (by design); saved data is unaffected.
#>
param([switch]$Database)

. "$PSScriptRoot\lib\common.ps1"

$running = Get-RunnerProcesses
if ($running.Count -eq 0) {
    Write-Ok 'NoTitle runtime is not running'
} else {
    foreach ($p in $running) {
        Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue
        Write-Ok "Stopped NoTitle runtime (PID $($p.ProcessId))"
    }
}
if ($Database) {
    Stop-Database
    Write-Ok 'PostgreSQL stopped'
}
