# Shared helpers for the NoTitle Windows scripts (Windows PowerShell 5.1 compatible).
#
# Native commands are checked through $LASTEXITCODE.  ErrorActionPreference stays
# 'Continue' because Windows PowerShell 5.1 turns redirected native stderr into
# terminating errors under 'Stop' even when the command succeeds.

$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'  # Invoke-WebRequest is very slow with the progress bar
$script:Root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$script:Backend = Join-Path $script:Root 'backend'
$script:Frontend = Join-Path $script:Root 'frontend'
$script:Tools = Join-Path $script:Root '.tools'
$script:LocalDir = Join-Path $script:Root '.local'
$script:EnvFile = Join-Path $script:Root '.env'
$script:VenvPython = Join-Path $script:Backend '.venv\Scripts\python.exe'
$script:NodeVersion = 'v24.22.0'
$script:PgVersion = '17.11-1'
$script:DbContainer = 'notitle-postgres'
$script:DbVolume = 'notitle-pgdata'
$script:DbImage = 'postgres:17.11'

function Write-Step([string]$Message) { Write-Host "`n==> $Message" -ForegroundColor Cyan }
function Write-Ok([string]$Message) { Write-Host "    [ok] $Message" -ForegroundColor Green }
function Write-Note([string]$Message) { Write-Host "    $Message" -ForegroundColor Gray }
function Write-Warn([string]$Message) { Write-Host "    [warning] $Message" -ForegroundColor Yellow }
function Fail([string]$Message) {
    Write-Host "`n[error] $Message" -ForegroundColor Red
    exit 1
}

function Ensure-Dir([string]$Path) {
    if (-not (Test-Path $Path)) { New-Item -ItemType Directory -Force -Path $Path | Out-Null }
}

function Write-Utf8NoBom([string]$Path, [string]$Text) {
    $encoding = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $Text, $encoding)
}

function New-Secret([int]$Bytes = 32) {
    $buffer = New-Object byte[] $Bytes
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    $rng.GetBytes($buffer)
    $rng.Dispose()
    return [Convert]::ToBase64String($buffer).TrimEnd('=').Replace('+', '-').Replace('/', '_')
}

function New-Password([int]$Length = 24) {
    $chars = 'abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789'
    $buffer = New-Object byte[] $Length
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    $rng.GetBytes($buffer)
    $rng.Dispose()
    $out = ''
    foreach ($b in $buffer) { $out += $chars[$b % $chars.Length] }
    return $out
}

function Read-DotEnv {
    $values = @{}
    if (Test-Path $script:EnvFile) {
        foreach ($line in [System.IO.File]::ReadAllLines($script:EnvFile)) {
            $trim = $line.Trim()
            if ($trim -eq '' -or $trim.StartsWith('#')) { continue }
            $idx = $trim.IndexOf('=')
            if ($idx -lt 1) { continue }
            $values[$trim.Substring(0, $idx).Trim()] = $trim.Substring($idx + 1).Trim()
        }
    }
    return $values
}

function Get-EnvValue([string]$Name, [string]$Default = '') {
    $values = Read-DotEnv
    if ($values.ContainsKey($Name) -and $values[$Name] -ne '') { return $values[$Name] }
    return $Default
}

function Invoke-Native {
    # Runs a native command, streams its output and fails on a non-zero exit code.
    param([string]$File, [string[]]$Arguments, [string]$What)
    & $File @Arguments
    if ($LASTEXITCODE -ne 0) { Fail "$What failed (exit code $LASTEXITCODE)." }
}

function Find-Python {
    # Prefer the Windows py launcher with 3.12, then 3.13/3.11, then python on PATH.
    $py = Get-Command py -ErrorAction SilentlyContinue
    if ($py) {
        foreach ($v in @('3.12', '3.13', '3.11')) {
            $out = & py "-$v" -c "import sys; print(sys.executable)" 2>$null
            if ($LASTEXITCODE -eq 0 -and $out) { return $out.Trim() }
        }
    }
    $python = Get-Command python -ErrorAction SilentlyContinue
    if ($python) {
        $ver = & python -c "import sys; print('%d.%d' % sys.version_info[:2])" 2>$null
        if ($LASTEXITCODE -eq 0 -and $ver) {
            $parts = $ver.Trim().Split('.')
            if ([int]$parts[0] -eq 3 -and [int]$parts[1] -ge 11) { return $python.Source }
        }
    }
    return $null
}

function Find-Node {
    $portable = Join-Path $script:Tools 'node\node.exe'
    if (Test-Path $portable) { return $portable }
    $node = Get-Command node -ErrorAction SilentlyContinue
    if ($node) {
        $ver = & $node.Source --version 2>$null
        if ($LASTEXITCODE -eq 0 -and $ver -match '^v(\d+)\.(\d+)') {
            $major = [int]$Matches[1]; $minor = [int]$Matches[2]
            if ($major -gt 20 -or ($major -eq 20 -and $minor -ge 9)) { return $node.Source }
        }
    }
    return $null
}

function Use-Node {
    # Puts the chosen Node.js first on PATH for npm/npx in this session.
    $node = Find-Node
    if (-not $node) { Fail 'Node.js 20.9+ was not found. Run scripts\setup.ps1 (it can install a portable Node.js).' }
    $dir = Split-Path $node -Parent
    if (-not ($env:Path.Split(';') -contains $dir)) { $env:Path = "$dir;$env:Path" }
    return $node
}

function Get-Npm {
    $node = Use-Node
    $dir = Split-Path $node -Parent
    $npm = Join-Path $dir 'npm.cmd'
    if (Test-Path $npm) { return $npm }
    $cmd = Get-Command npm.cmd -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    Fail 'npm was not found next to Node.js.'
}

function Test-Docker {
    $docker = Get-Command docker -ErrorAction SilentlyContinue
    if (-not $docker) { return $false }
    & docker info --format '{{.ServerVersion}}' *> $null
    return ($LASTEXITCODE -eq 0)
}

function Get-DbMode {
    $mode = Get-EnvValue 'DB_MODE' 'auto'
    if ($mode -eq 'auto') {
        if (Test-Path (Join-Path $script:Tools 'pgsql\bin\pg_ctl.exe')) { return 'portable' }
        if (Test-Docker) { return 'docker' }
        return 'portable'
    }
    return $mode
}

function Get-PgBin([string]$Name) { return (Join-Path $script:Tools "pgsql\bin\$Name.exe") }

function Start-Database {
    $mode = Get-DbMode
    $port = Get-EnvValue 'DB_PORT' '5433'
    if ($mode -eq 'docker') {
        $state = & docker inspect -f '{{.State.Running}}' $script:DbContainer 2>$null
        if ($LASTEXITCODE -ne 0) {
            $values = Read-DotEnv
            $adminUrl = $values['DATABASE_ADMIN_URL']
            if (-not $adminUrl) { Fail 'DATABASE_ADMIN_URL is missing from .env. Run scripts\setup.ps1 first.' }
            $adminPassword = ([uri]$adminUrl).UserInfo.Split(':')[1]
            Write-Note "Creating PostgreSQL container $($script:DbContainer) on 127.0.0.1:$port ..."
            Invoke-Native 'docker' @('run', '-d', '--name', $script:DbContainer, '--restart', 'unless-stopped',
                '-e', 'POSTGRES_USER=postgres', '-e', "POSTGRES_PASSWORD=$adminPassword",
                '-p', "127.0.0.1:${port}:5432", '-v', "$($script:DbVolume):/var/lib/postgresql/data",
                $script:DbImage) 'Starting the PostgreSQL container'
        } elseif ($state.Trim() -ne 'true') {
            Invoke-Native 'docker' @('start', $script:DbContainer) 'Starting the PostgreSQL container'
        }
    } elseif ($mode -eq 'portable') {
        $data = Join-Path $script:LocalDir 'pgdata'
        $pgctl = Get-PgBin 'pg_ctl'
        if (-not (Test-Path $pgctl)) { Fail 'Portable PostgreSQL is not installed. Run scripts\setup.ps1.' }
        & $pgctl status -D $data *> $null
        if ($LASTEXITCODE -ne 0) {
            $log = Join-Path $script:LocalDir 'postgres.log'
            # Do not pipe pg_ctl's output: the server process would inherit the pipe and PowerShell
            # would wait for it to close forever.
            & $pgctl start -D $data -l $log -o "-p $port -h 127.0.0.1" -w -t 60
            if ($LASTEXITCODE -ne 0) { Fail "PostgreSQL did not start. See $log" }
        }
    } else {
        Write-Note 'DB_MODE=external: make sure your PostgreSQL server is running.'
    }
    Wait-Database
}

function Wait-Database([int]$Seconds = 60) {
    $code = @"
import sys, time, psycopg
url = sys.argv[1]
deadline = time.time() + int(sys.argv[2])
while True:
    try:
        psycopg.connect(url, connect_timeout=3).close()
        break
    except Exception as exc:
        if time.time() > deadline:
            print(str(exc).splitlines()[0] if str(exc) else type(exc).__name__)
            sys.exit(1)
        time.sleep(1)
"@
    $url = Get-EnvValue 'DATABASE_ADMIN_URL' (Get-EnvValue 'DATABASE_MIGRATOR_URL')
    $tmp = Join-Path $env:TEMP 'notitle-waitdb.py'
    Write-Utf8NoBom $tmp $code
    & $script:VenvPython $tmp $url $Seconds
    if ($LASTEXITCODE -ne 0) { Fail 'PostgreSQL is not reachable. Check scripts\db-start.ps1 output or .local\postgres.log.' }
    Write-Ok 'PostgreSQL is reachable'
}

function Stop-Database {
    $mode = Get-DbMode
    if ($mode -eq 'docker') {
        & docker stop $script:DbContainer *> $null
    } elseif ($mode -eq 'portable') {
        $data = Join-Path $script:LocalDir 'pgdata'
        $pgctl = Get-PgBin 'pg_ctl'
        if (Test-Path $pgctl) { & $pgctl stop -D $data -m fast *> $null }
    }
}

function Invoke-Cli([string[]]$Arguments) {
    Push-Location $script:Backend
    try {
        # Out-Host keeps the CLI's output on screen instead of in this function's return value.
        & $script:VenvPython -m app.cli @Arguments | Out-Host
        return $LASTEXITCODE
    } finally { Pop-Location }
}

function Get-RunnerProcesses {
    # Finds NoTitle runtimes started from this project's virtual environment.
    $venvDir = (Join-Path $script:Backend '.venv').ToLower()
    $procs = Get-CimInstance Win32_Process -Filter "Name = 'python.exe'" -ErrorAction SilentlyContinue
    return @($procs | Where-Object {
        $_.CommandLine -and $_.CommandLine.Contains('app.runner') -and
        $_.ExecutablePath -and $_.ExecutablePath.ToLower().StartsWith($venvDir)
    })
}

function Wait-Ready([string]$Url, [int]$Seconds = 40) {
    # "localhost" may try IPv6 (::1) first and stall; the server listens on IPv4.
    $Url = $Url.Replace('://localhost:', '://127.0.0.1:')
    $deadline = (Get-Date).AddSeconds($Seconds)
    while ((Get-Date) -lt $deadline) {
        try {
            $r = Invoke-WebRequest -UseBasicParsing -TimeoutSec 3 -Uri $Url
            if ($r.StatusCode -eq 200) { return $true }
        } catch { }
        Start-Sleep -Milliseconds 700
    }
    return $false
}
